/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file gridnconvol.c
   @brief Gridding, Diskpoint parsing, and convolution routines

   Gridding and convolution related routines come with this
   module. Also informal parsing of the Diskpoints structure is
   contained here.

   $Source: /Volumes/DATA_J_II/data/CVS/tirific/src/gridnconvol.c,v $
   $Date: 2011/05/25 22:25:26 $
   $Revision: 1.8 $
   $Author: jozsa $
   $Log: gridnconvol.c,v $
   Revision 1.8  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.7  2011/05/10 00:30:15  jozsa
   Left work

   Revision 1.6  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.5  2007/08/23 15:23:25  gjozsa
   Left work

   Revision 1.4  2007/08/22 15:58:41  gjozsa
   Left work

   Revision 1.3  2004/12/09 16:08:45  gjozsa
   Changed some floating point operations from double to float accuracy

   Revision 1.2  2004/12/08 16:22:50  gjozsa
   Left work

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


*/
/* ------------------------------------------------------------ */ 



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <fftw3.h>



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <gridnconvol.h>
#include <maths.h>



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def _MEMORY_HERE_ON
   @brief Controls the use of the memory_here module

   If you don't want to use the memory_here facility comment this
   define, otherways it will be included.

*/
/* ------------------------------------------------------------ */
/* #define _MEMORY_HERE_ON */
/* #include <memory_here.h> */
#include <cubarithm.h>



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE MACROS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* (PRIVATE) GLOBAL VARIABLES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE TYPEDEFS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE STRUCTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static Cube *gridon_disk(Cube *cube, Diskpoints *points, char gmode, float twosigmasq)
  @brief Grids a Diskpoints structure onto a cube adding the points
    
  Grids the points in the Diskpoints structure points on the Cube
  cube, which should be a dynamically allocated Cube. The values are
  added. The cube should be large enough for the gridding procedure
  (Which can be made sure when producing the cube with
  cubecreat). gmode describes the gridding mode, either BORDERS_NEXT,
  or BORDERS_INTER. NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. twosigmasq is only important when chosing
  gmode BORDERS_INTER or BORDERS_HYBRID. When doing a gaussian
  interpolation the eight (four) nearest pixels will get a value
  exp(dist^2/twosigmasq), where dist is the distance between the pixel
  and the point and then will be normalised to conserve the flux.

  @param cube       (Cube *)       Cube onto which the gridding takes 
  place
  @param points     (Diskpoints *) Structure to be gridded
  @param gmode      (char)         Gridding mode BORDERS_NEXT or 
  BORDERS_INTER
  @param twosigmasq (float)        Size of the convolution kernel 
  (in 2*sigma^2)

  @return (success) Cube *gridon_disk: Same pointer to the cube passed 
  into the function \n
          (error)
*/
/* ------------------------------------------------------------ */
static Cube *gridon_disk(Cube *cube, Diskpoints *points, char gmode, float twosigmasq);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static Cube *gridon_ring(Cube *cube, Ringpoints *points, char gmode, float twosigmasq)
  @brief Grids a Ringpoints structure onto a cube adding the points
    
  Grids the points in the Ringpoints structure points on the Cube
  cube, which should be a dynamically allocated Cube. The values are
  added. The cube should be large enough for the gridding procedure
  (Which can be made sure when producing the cube with
  cubecreat). gmode describes the gridding mode, either BORDERS_NEXT,
  or BORDERS_INTER. NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. twosigmasq is only important when chosing
  gmode BORDERS_INTER or BORDERS_HYBRID. When doing a gaussian
  interpolation the eight (four) nearest pixels will get a value
  exp(dist^2/twosigmasq), where dist is the distance between the pixel
  and the point and then will be normalised to conserve the flux.

  @param cube       (Cube *)       Cube onto which the gridding takes 
  place
  @param points     (Ringpoints *) Structure to be gridded
  @param gmode      (char)         Gridding mode BORDERS_NEXT or 
  BORDERS_INTER
  @param twosigmasq (float)        Size of the convolution kernel 
  (in 2*sigma^2)

  @return (success) Cube *gridon_ring: Same pointer to the cube passed 
  into the function \n
          (error)
*/
/* ------------------------------------------------------------ */
static Cube *gridon_ring(Cube *cube, Ringpoints *points, char gmode, float twosigmasq);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static Cube *gridon_sector(Cube *cube, Sectorpoints *points, char gmode, float twosigmasq)
  @brief Grids a Sectorpoints structure onto a cube adding the points
    
  Grids the points in the Sectorpoints structure points on the Cube
  cube, which should be a dynamically allocated Cube. The values are
  added. The cube should be large enough for the gridding procedure
  (Which can be made sure when producing the cube with
  cubecreat). gmode describes the gridding mode, either BORDERS_NEXT,
  or BORDERS_INTER. NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. twosigmasq is only important when chosing
  gmode BORDERS_INTER or BORDERS_HYBRID. When doing a gaussian
  interpolation the eight (four) nearest pixels will get a value
  exp(dist^2/twosigmasq), where dist is the distance between the pixel
  and the point and then will be normalised to conserve the flux.

  @param cube       (Cube *)       Cube onto which the gridding takes 
  place
  @param points     (Sectorpoints *) Structure to be gridded
  @param gmode      (char)         Gridding mode BORDERS_NEXT or 
  BORDERS_INTER
  @param twosigmasq (float)        Size of the convolution kernel 
  (in 2*sigma^2)

  @return (success) Cube *gridon_sector: Same pointer to the cube passed 
  into the function \n
          (error)
*/
/* ------------------------------------------------------------ */
static Cube *gridon_sector(Cube *cube, Sectorpoints *points, char gmode, float twosigmasq);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *gridon_pointsource(Cube *cube, Pointsource *point, float flux, char gmode, float twosigmasq)
  @brief Grids a Pointsource onto a Cube

  Grids the Pointsource with the flux flux on the Cube cube, which
  should be a dynamically allocated Cube. The values are added. The
  cube should be large enough for the gridding procedure (Which can be
  made sure when producing the cube with cubecreat). gmode describes
  the gridding mode, either BORDERS_NEXT, or BORDERS_INTER. NEXT is
  the gridding on the next pixel, BORDERS_INTER is a gaussian
  interpolation to the 8 pixels surrounding the sources. twosigmasq is
  only important when chosing gmode BORDERS_INTER or
  BORDERS_HYBRID. When doing a gaussian interpolation the eight (four)
  nearest pixels will get a value exp(dist^2/twosigmasq), where dist
  is the distance between the pixel and the point and then will be
  normalised to conserve the flux.

  @param cube       (Cube *)        Cube onto which the gridding takes 
  place
  @param point      (Pointsource *) Structure to be gridded
  @param flux       (float)         Flux of one pointsource
  @param gmode      (char)          Gridding mode BORDERS_NEXT or 
  BORDERS_INTER 
  @param twosigmasq (float)         Size of the convolution kernel 
  (in 2*sigma^2)

  @return (success) Cube *gridon_pointsource: The same pointer to the 
  cube passed to the function\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *gridon_pointsource(Cube *cube, Pointsource *point, float flux, char gmode, float twosigmasq);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int *findborders(void *points, char stype, char gmode, int border_x, int border_y, int border_v)
  @brief Find the borders of the points ll with additional borders

  Returns an array [refpix_x, refpix_y, refpix_v, size_x, size_y,
  size_v], that describes the Cube to be allocated when trying to grid
  *points, which is either the disk, a ring, or a sector in the
  Diskpoints dll. stype describes the character of *points, which can
  be BORDERS_DISK, BORDERS_RING, or BORDERS_SECTOR. mode describes the
  gridding mode, either BORDERS_NEXT, or BORDERS_INTER. NEXT is the
  gridding on the next pixel, BORDERS_INTER is a gaussian
  interpolation to the 8 pixels surrounding the sources. After the
  size of the cube in which all pointsources fit in is known a border
  of border pixels is added, to prevent aliasing when convolving with
  a gaussian. The border added is the value of border_axis.

  @param points   (void *) Structure to be gridded
  @param stype    (char)   Type of structure BORDERS_DISK, BORDERS_RING, 
  or BORDERS_SECTOR
  @param gmode    (char)   Gridding mode BORDERS_NEXT or BORDERS_INTER
  @param border_x (int)    border in x direction
  @param border_y (int)    border in y direction
  @param border_v (int)    border in v direction

  @return (success) int *findborders: Array of six numbers describing
  cube dimensions\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
static int *findborders(void *points, char stype, char gmode, int border_x, int border_y, int border_v);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int *findborders_sector(Sectorpoints *points, char gmode)
  @brief Find the borders of the cube to grid pointsources in a Sector

  Returns an array [refpix_x, refpix_y, refpix_v, max_x, max_y,
  max_v], that describes the Cube corners of a cube big enough when
  trying to grid *points, which is a sector in the Diskpoints
  dll. mode describes the gridding mode, either BORDERS_NEXT, or
  BORDERS_INTER. BORDERS_NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. No addditional border will be of concern
  here. The output is allocated and needs to be freed.

  @param points (Sectorpoints *) Sectoroints structure to be gridded
  @param gmode  (char)           Gridding mode BORDERS_NEXT or 
  BORDERS_INTER

  @return (success) int *findborders_sector Array of six numbers 
  describing cube borders
          (error) NULL
*/
/* ------------------------------------------------------------ */
static int *findborders_sector(Sectorpoints *points, char gmode);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int *findborders_ring(Ringpoints *points, char gmode)
  @brief Find the borders of the cube to grid pointsources in a Ring

  Returns an array [refpix_x, refpix_y, refpix_v, max_x, max_y,
  max_v], that describes the Cube corners of a cube big enough when
  trying to grid *points, which is a ring in the Diskpoints
  dll. mode describes the gridding mode, either BORDERS_NEXT, or
  BORDERS_INTER. BORDERS_NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. No addditional border will be of concern
  here. The output is allocated and needs to be freed.

  @param points (Ringpoints *) Ringoints structure to be gridded
  @param gmode  (char)           Gridding mode BORDERS_NEXT or 
  BORDERS_INTER

  @return (success) int *findborders_ring Array of six numbers 
  describing cube borders
          (error) NULL
*/
/* ------------------------------------------------------------ */
static int *findborders_ring(Ringpoints *points, char gmode);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int *findborders_disk(Diskpoints *points, char gmode)
  @brief Find the borders of the cube to grid pointsources in a Disk

  Returns an array [refpix_x, refpix_y, refpix_v, max_x, max_y,
  max_v], that describes the Cube corners of a cube big enough when
  trying to grid *points, which is a disk in the Diskpoints
  dll. mode describes the gridding mode, either BORDERS_NEXT, or
  BORDERS_INTER. BORDERS_NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. No addditional border will be of concern
  here. The output is allocated and needs to be freed.

  @param points (Diskpoints *) Diskoints structure to be gridded
  @param gmode  (char)           Gridding mode BORDERS_NEXT or 
  BORDERS_INTER

  @return (success) int *findborders_disk Array of six numbers 
  describing cube borders
          (error) NULL
*/
/* ------------------------------------------------------------ */
static int *findborders_disk(Diskpoints *points, char gmode);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *convolgaussdirect_point(Cube *cube, Pointsource *point, float flux, int *borders, float *expofacsdirect)
  @brief Convolve a pointsource with a gaussian and add it to the Cube

  Makes a direct convolution of the Pointsource *point with the flux
  flux onto the Cube cube. cube has to be allocated and to be large
  enough, e.g. by using cubecreat. expofacsdirect contains the
  information needed for the evaluation of the gaussian. The gaussian
  will be evaluated at the next pixel and to an uprounded size given
  by the borders.

  @param cube           (Cube *)        The cube
  @param point          (Pointsource *) The Pointsource       
  @param flux           (float)         The flux of the pointsource
  @param borders        (int *)         An array containing the uprounded 
  half sizes of the (float) bounding box for the gaussian 
  @param expofacsdirect (float *)       Factors in the exponent of the 
  gaussian  

  @return (success) Cube *convolgaussdirect_point: The convolved cube\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *convolgaussdirect_point(Cube *cube, Pointsource *point, float flux, int *borders, float *expofacsdirect);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static float *expofacsdirect(float sigma_maj, float sigma_min, float sigma_v, float *sincosofangle)
  @brief The factors needed to make a direct convolution

  Returns an allocated array containing factors needed by
  convolgausspointsource to convolve pointsources with a gaussian with
  sigma at the major axis sigma_major, minor axis sigma_minor, v axis
  sigma_v axis. These factors are calculated from the measures of the
  convolution kernel and won't change during the whole program.

  @param sigma_maj     (float)   The sigma in direction of the major axis
  @param sigma_min     (float)   The sigma in direction of the minor axis
  @param sigma_v       (float)   The sigma in v-direction
  @param sincosofangle (float *) An array containing the sin and the cos 
  of the position angle
  
  @return   float *expofacsdirect: The factors wanted, no error handling
*/
/* ------------------------------------------------------------ */
static float *expofacsdirect(float sigma_maj, float sigma_min, float sigma_v, float *sincosofangle);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static float gaussdirect(int i, int j, int k, float *distances, float *expofacsdirect)
  @brief Return a relative gaussian

  Calculates a gaussian with size and position angle given by
  expofacsdirect at the position i-distances[0], j-distances[1],
  k-distances[2].

  @param i              (int)   Integer relative x coordinate
  @param j              (int)   Integer relative x coordinate
  @param k              (int)   Integer relative x coordinate
  @param distances      (float) Array of small numbers to get the real 
  relative distances   
  @param expofacsdirect (float) Factors describing the gaussian

  @return float gaussdirect: The gaussian, no error handling
*/
/* ------------------------------------------------------------ */
static float gaussdirect(int i, int j, int k, float *distances, float *expofacsdirect);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *convolgaussdirect_sector(Cube *cube, Sectorpoints *sector, int *borders, float *expofacsdirect)
  @brief Convolves directly a Sector and adds it on the cube

  Makes a direct convolution of the Pointsources in the sector onto
  the Cube cube. cube has to be allocated and to be large enough,
  e.g. by using cubecreat. expofacsdirect contains the information
  needed for the evaluation of the gaussian. The gaussian will be
  evaluated at the next pixel and to an uprounded size given by the
  borders.

  @param cube           (Cube *)         The cube
  @param sector         (Sectorpoints *) The Sector
  @param borders        (int *)          An array containing the 
  uprounded half sizes of the (float) bounding box for the gaussian
  @param expofacsdirect (float *)        Factors in the exponent of 
  the gaussian

  @return (success) Cube *convolgaussdirect_sector: The convolved cube\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *convolgaussdirect_sector(Cube *cube, Sectorpoints *sector, int *borders, float *expofacsdirect);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *convolgaussdirect_ring(Cube *cube, Ringpoints *ring, int *borders, float *expofacsdirect)
  @brief Convolves directly a Ring and adds it on the cube

  Makes a direct convolution of the Pointsources in the Ring onto
  the Cube cube. cube has to be allocated and to be large enough,
  e.g. by using cubecreat. expofacsdirect contains the information
  needed for the evaluation of the gaussian. The gaussian will be
  evaluated at the next pixel and to an uprounded size given by the
  borders.

  @param cube           (Cube *)       The cube
  @param ring           (Ringpoints *) The Ring
  @param borders        (int *)        An array containing the 
  uprounded half sizes of the (float) bounding box for the gaussian
  @param expofacsdirect (float *)      Factors in the exponent of 
  the gaussian

  @return (success) Cube *convolgaussdirect_ring: The convolved cube\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *convolgaussdirect_ring(Cube *cube, Ringpoints *ring, int *borders, float *expofacsdirect);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *convolgaussdirect_disk(Cube *cube, Diskpoints *disk, int *borders, float *expofacsdirect)
  @brief Convolves directly a Disk and adds it on the cube

  Makes a direct convolution of the Pointsources in the disk onto
  the Cube cube. cube has to be allocated and to be large enough,
  e.g. by using cubecreat. expofacsdirect contains the information
  needed for the evaluation of the gaussian. The gaussian will be
  evaluated at the next pixel and to an uprounded size given by the
  borders.

  @param cube           (Cube *)       The cube
  @param disk           (Diskpoints *) The Disk
  @param borders        (int *)        An array containing the 
  uprounded half sizes of the (float) bounding box for the gaussian
  @param expofacsdirect (float *)      Factors in the exponent of 
  the gaussian

  @return (success) Cube *convolgaussdirect_disk: The convolved cube\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *convolgaussdirect_disk(Cube *cube, Diskpoints *disk, int *borders, float *expofacsdirect);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *convolgaussdirect(Cube *cube, void *points, char stype, int *borders, float *expofacsdirect)
  @brief Convolve a structure to an emptied Cube (direct convolution)

  Makes a direct convolution of the Pointsources in the structure
  points, either a disk, a ring, or a sector onto the Cube cube. The
  content of cube is deleted. cube has to be allocated and to be large
  enough, e.g. by using cubecreat. Stype is either BORDERS_DISK,
  BORDERS_RING, or BORDERS_SECTOR, describing the type of the
  structure. expofacsdirect contains the information needed for the
  evaluation of the gaussian. The gaussian will be evaluated at the
  next pixel and to a size given by the borders.

  @param cube           (Cube *)  The cube
  @param points         (void *)  The structure to be convolved
  @param stype          (char)    Type of the structure
  @param borders        (int *)   An array containing the uprounded 
  half sizes of the (float) bounding box for the gaussian
  @param expofacsdirect (float *) Factors in the exponent of the gaussian

  @return (success) Cube *convolgaussdirect: The convolved cube
          (error) NULL
*/
/* ------------------------------------------------------------ */
/* static Cube *convolgaussdirect(Cube *cube, void *points, char stype, int *borders, float *expofacsdirect); */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *convolgaussdirecton(Cube *cube, void *points, char stype, int *borders, float *expofacsdirect)
  @brief Convolve a structure to an emptied Cube (direct convolution)

  Makes a direct convolution of the Pointsources in the structure
  points, either a disk, a ring, or a sector onto the Cube cube. The
  content of cube is deleted. cube has to be allocated and to be large
  enough, e.g. by using cubecreat. Stype is either BORDERS_DISK,
  BORDERS_RING, or BORDERS_SECTOR, describing the type of the
  structure. expofacsdirect contains the information needed for the
  evaluation of the gaussian. The gaussian will be evaluated at the
  next pixel and to a size given by the borders.

  @param cube           (Cube *)  The cube
  @param points         (void *)  The structure to be convolved
  @param stype          (char)    Type of the structure
  @param borders        (int *)   An array containing the uprounded 
  half sizes of the (float) bounding box for the gaussian
  @param expofacsdirect (float *) Factors in the exponent of the gaussian

  @return (success) Cube *convolgaussdirect: The convolved cube
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *convolgaussdirecton(Cube *cube, void *points, char stype, int *borders, float *expofacsdirect);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *gridonexclude(Cube *cube, void *points, char stype, char gmode, float twosigmasq)
  @brief Grids on a structure excluding substructures already 
  containing a cube

  Grids the points in the structure points, either a disk, a ring, or
  a sector on the Cube cube, omitting any substructure already
  'owning' a cube. If there is a cube owned by the top structure which
  is identical with the input cube, the gridding takes place on that
  nevertheless. The cube on which the gridding takes place should be a
  dynamically allocated Cube. The values are added. Stype is either
  BORDERS_DISK, BORDERS_RING, or BORDERS_SECTOR, describing the type
  of the structure. The cube should be large enough for the gridding
  procedure (Which can be made sure when producing the cube with
  cubecreat). gmode describes the gridding mode, either BORDERS_NEXT,
  or BORDERS_INTER. NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. twosigmasq is only important when chosing
  gmode BORDERS_INTER or BORDERS_HYBRID. When doing a gaussian
  interpolation the eight (four) nearest pixels will get a value
  exp(dist^2/twosigmasq), where dist is the distance between the pixel
  and the point and then will be normalised to conserve the flux.

  @param cube       (Cube *) Cube onto which the gridding takes place
  @param points     (void *) Structure to be gridded
  @param stype      (char)   Type of structure BORDERS_DISK, 
  BORDERS_RING, or BORDERS_SECTOR
  @param gmode      (char)   Gridding mode BORDERS_NEXT or BORDERS_INTER 
  @param twosigmasq (float)  Size of the convolution kernel

  @return (success) Cube *gridonexclude The same pointer to the cube passed 
  into the function\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *gridonexclude(Cube *cube, void *points, char stype, char gmode, float twosigmasq);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *gridoncollect(Cube *cube, void *points, char stype, char gmode, float twosigmasq)
  @brief Grid on a structure excluding substructures containing a cube finally adding the omitted cubes

  Grids the points in the structure points, either a disk, a ring, or
  a sector on the Cube cube, omitting any substructure already
  'owning' a cube and finally adding the ommitted cubes. If there is a
  cube owned by the top structure which is identical with the input
  cube, the gridding takes place on that nevertheless. The cube on
  which the gridding takes place should be a dynamically allocated
  Cube. The values are added. Stype is either BORDERS_DISK,
  BORDERS_RING, or BORDERS_SECTOR, describing the type of the
  structure. The cube should be large enough for the gridding
  procedure (Which can be made sure when producing the cube with
  cubecreat). gmode describes the gridding mode, either BORDERS_NEXT,
  or BORDERS_INTER. NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. twosigmasq is only important when chosing
  gmode BORDERS_INTER or BORDERS_HYBRID. When doing a gaussian
  interpolation the eight (four) nearest pixels will get a value
  exp(dist^2/twosigmasq), where dist is the distance between the pixel
  and the point and then will be normalised to conserve the flux.

  @param cube       (Cube *) Cube onto which the gridding takes place
  @param points     (void *) Structure to be gridded
  @param stype      (char)   Type of structure DISK, RING, or SECTOR
  @param gmode      (char)   Gridding mode BORDERS_NEXT or BORDERS_INTER
  @param twosigmasq (float)  Size of the convolution kernel

  @return (success) Cube *gridoncollect The same pointer to the cube
  passed into the function
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *gridoncollect(Cube *cube, void *points, char stype, char gmode, float twosigmasq);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static Cube *convoldirectcollect(Cube *cube, void *points, char stype, int *borders, float *expofacsdirect)
  @brief Make a direct convolution exhausting already convolved substructure

  Makes a direct convolution of the pointsources in points with a
  gaussian described by expofacsdirect (get via expofacsdirect) in the
  area given by borders (get via imax(findborders)) on the cube cube,
  omitting already existing cubes iln the substructures of points and
  finally adding these cubes.

  @param cube           (Cube *) Cube onto which the adding takes place
  @param points         (void *) Structure to be searched
  @param stype          (char)   Type of structure DISK, RING, or SECTOR
  @param borders        (int)    Borders of the convolution kernel
  @param expofacsdirect (float)  Factors describing the gaussian

  @return (success) Cube *convoldirectcollect: The same pointer to the
  cube passed into the function
          (error) NULL
*/
/* ------------------------------------------------------------ */
static Cube *convoldirectcollect(Cube *cube, void *points, char stype, int *borders, float *expofacsdirect);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION CODE */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grids a ll of pointsources on a Cube erasing the Cube */

Cube *gridding(Cube *cube, void *points, char stype, char gmode, float twosigmasq)
{
  if (cube) {
    cuberase(cube);
    cube = gridon(cube, points, stype, gmode, twosigmasq);
  }
  return cube;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grids a ll of pointsources on a Cube adding to the Cube */

Cube *gridon(Cube *cube, void *points, char stype, char gmode, float twosigmasq)
{
  Ringpoints  *ringpoints;
  Sectorpoints *sectorpoints;
  Diskpoints *diskpoints;


  switch (stype) {
  case BORDERS_DISK:
    diskpoints = (Diskpoints *) points;
    cube = gridon_disk(cube, diskpoints, gmode, twosigmasq);
    break;
  case BORDERS_RING:
    ringpoints = (Ringpoints *) points;
    cube = gridon_ring(cube, ringpoints, gmode, twosigmasq);
    break;
  case  BORDERS_SECTOR:
    sectorpoints = (Sectorpoints *) points;
    cube = gridon_sector(cube, sectorpoints, gmode, twosigmasq);
    break;
  default:
    cube = NULL;
  }
  return cube;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grids a Diskpoints structure onto a cube adding the points */

static Cube *gridon_disk(Cube *cube, Diskpoints *points, char gmode, float twosigmasq)
{
  Ringpoints *ring = (*points).next_ring;
 
  if (cube) {
    while (ring) {
      cube = gridon_ring(cube, ring, gmode, twosigmasq);
      ring = (*ring).next;
    }
    return cube;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grids a Ringpoints structure onto a cube adding the points */

static Cube *gridon_ring(Cube *cube, Ringpoints *points, char gmode, float twosigmasq)
{
  Sectorpoints *sector = (*points).next_sector;
  if (cube) {
    while (sector) {
      cube = gridon_sector(cube, sector, gmode, twosigmasq);
      sector = (*sector).next;
    }
    return cube;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grids a Sectorpoints structure onto a cube adding the points */

static Cube *gridon_sector(Cube *cube, Sectorpoints *points, char gmode, float twosigmasq)
{
  Pointsource *point; 

  point = (*points).next_point;
  if (cube) {
    while (point) {
      cube = gridon_pointsource(cube, point, *((*points).f), gmode, twosigmasq);
      point = (*point).next;
    }
    return cube;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grids a Pointsource onto a Cube */

static Cube *gridon_pointsource(Cube *cube, Pointsource *point, float flux, char gmode, float twosigmasq)
{
  int i;
  float sum = 0;
  float *pixel;
  float *pointertopixel;
  float scale;

  scale = 1.0/(*cube).scale;

  /* Next pixel method */
  if (gmode == BORDERS_NEXT) {

    /* The next pixel gets the whole flux */
    pointertopixel = findpixel(cube, roundnormal((*point).x), roundnormal((*point).y), roundnormal((*point).v));
    *pointertopixel = *pointertopixel + scale*flux;
  }

  /* interpolation method */
  else if (gmode == BORDERS_INTER) {
    
    /* Now we need pixel to be large enough */
    pixel = (float *) malloc(8*sizeof(float));
    /* The pixels are weighted with a gaussian */
    pixel[0] = expf(-(modfupsq((*point).x)+modfupsq((*point).y)+modfupsq((*point).v))/twosigmasq);
    pixel[1] = expf(-(modfupsq((*point).x)+modfupsq((*point).y)+modfdownsq((*point).v))/twosigmasq);
    pixel[2] = expf(-(modfupsq((*point).x)+modfdownsq((*point).y)+modfupsq((*point).v))/twosigmasq);
    pixel[3] = expf(-(modfupsq((*point).x)+modfdownsq((*point).y)+modfdownsq((*point).v))/twosigmasq);
    pixel[4] = expf(-(modfdownsq((*point).x)+modfupsq((*point).y)+modfupsq((*point).v))/twosigmasq);
    pixel[5] = expf(-(modfdownsq((*point).x)+modfupsq((*point).y)+modfdownsq((*point).v))/twosigmasq);
    pixel[6] = expf(-(modfdownsq((*point).x)+modfdownsq((*point).y)+modfupsq((*point).v))/twosigmasq);
    pixel[7] = expf(-(modfdownsq((*point).x)+modfdownsq((*point).y)+modfdownsq((*point).v))/twosigmasq);

    /* Now scale the pixels and put them in */
    for (i = 0; i < 8; ++i)
      sum = sum + pixel[i];

    flux = scale*flux/sum;

    pointertopixel = findpixel(cube, roundup((*point).x), roundup((*point).y), roundup((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[0];
    pointertopixel = findpixel(cube, roundup((*point).x), roundup((*point).y), roundown((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[1];
    pointertopixel = findpixel(cube, roundup((*point).x), roundown((*point).y), roundup((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[2];  
    pointertopixel = findpixel(cube, roundup((*point).x), roundown((*point).y), roundown((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[3];  
    pointertopixel = findpixel(cube, roundown((*point).x), roundup((*point).y), roundup((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[4];  
    pointertopixel = findpixel(cube, roundown((*point).x), roundup((*point).y), roundown((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[5];  
    pointertopixel = findpixel(cube, roundown((*point).x), roundown((*point).y), roundup((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[6];  
    pointertopixel = findpixel(cube, roundown((*point).x), roundown((*point).y), roundown((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[7];

    free(pixel);
  }
  /* interpolation method */
  else if (gmode == BORDERS_HYBRID) {
    
    /* Now we need pixel to be large enough */
    pixel = (float *) malloc(4*sizeof(float));
    
    /* The pixels are weighted with a gaussian, only in one plane */
    pixel[0] = expf(-(modfupsq((*point).x)+modfupsq((*point).y))/twosigmasq);
    pixel[1] = expf(-(modfupsq((*point).x)+modfdownsq((*point).y))/twosigmasq);
    pixel[2] = expf(-(modfdownsq((*point).x)+modfupsq((*point).y))/twosigmasq);
    pixel[3] = expf(-(modfdownsq((*point).x)+modfdownsq((*point).y))/twosigmasq);

    /* Now scale the pixels and put them in */
    for (i = 0; i < 4; ++i)
      sum = sum + pixel[i];

    flux = scale*flux/sum;

    pointertopixel = findpixel(cube, roundup((*point).x), roundup((*point).y), roundnormal((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[0];
    pointertopixel = findpixel(cube, roundup((*point).x), roundown((*point).y), roundnormal((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[1];  
    pointertopixel = findpixel(cube, roundown((*point).x), roundup((*point).y), roundnormal((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[2];  
    pointertopixel = findpixel(cube, roundown((*point).x), roundown((*point).y), roundnormal((*point).v));
    *pointertopixel = *pointertopixel+flux*pixel[3];  
    free(pixel);
  }
  else 
    return NULL;
  return cube;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a cube suitable for gridding points of the structure points */

Cube *cubecreat(void *points, char stype, char gmode, int border_x, int border_y, int border_v, int padding, char produce)
{
 Cube *cube = NULL;
 int *borders;

  /* get the borders */
  if ((borders = findborders(points, stype, gmode, border_x, border_y, border_v))) {
  
    /* make a cube */
    if ((cube = (Cube *) malloc(sizeof(Cube)))) {
      
      /* determine the padding*/
      if ((padding)) 
 (*cube).padding = padding = ((*(borders+3))/2)*2+2-*(borders+3);
      else
 (*cube).padding = 0;

      /* Set the scale to 1 */
      (*cube).scale = 1;

      /* write the cube sizes in the cube structure */
      (*cube).refpix_x = *borders;
      (*cube).refpix_y = *(borders+1);
      (*cube).refpix_v = *(borders+2);
      (*cube).size_x = *(borders+3);
      (*cube).size_y = *(borders+4);
      (*cube).size_v = *(borders+5);

      /* Do we only want the borders and such? */
      if (produce == SIZE) {
 (*cube).points = NULL;
 free(borders);
 return cube;
      }

      /* allocate the cube array */
      if (((*cube).points = (float *) malloc((*(borders+3)+padding)*(*(borders+4))*(*(borders+5))*sizeof(float)))) {
 /* Don't forget */
 free(borders);
 return cube;
      }
      free(cube);
    }
    free(borders);
  }

  /* Some error */
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Find the borders of the points ll with additional borders */
static int *findborders(void *points, char stype, char gmode, int border_x, int border_y, int border_v)
{
  int *borders = NULL;

  /* In case of BORDERS_DISK */
  if (stype == BORDERS_DISK) {

    /* change the pointer type */
    points = (Diskpoints *) points;
    
    /* Now get the borders */
    if ((borders = findborders_disk(points, gmode)) == NULL)
      return NULL;
  }

  /* in case of BORDERS_RING */
  else   if (stype == BORDERS_RING) {

    /* change the pointer type */
    points = (Ringpoints *) points;
    
    /* Now get the borders */
    if ((borders = findborders_ring(points, gmode)) == NULL)
      return NULL;
  }

  /* in case of BORDERS_SECTOR */
  else if (stype == BORDERS_SECTOR) {

    /* change the pointer type */
    points = (Sectorpoints *) points;
    
    /* Now get the borders */
    if ((borders = findborders_sector(points, gmode)) == NULL)
      return NULL;
  }

  /* if no valid number for stype is given return nothing */
  else 
    return NULL; 

  /* change the values from borders to origin and width of the cube
  and add the border for the width */
  *(borders+3) = *(borders+3)-*borders+1+2*border_x; 
  *(borders+4) = *(borders+4)-*(borders+1)+1+2*border_y; 
  *(borders+5) = *(borders+5)-*(borders+2)+1+2*border_v;
  
  /* add the border for the origin */
  *borders = *borders - border_x;
  *(borders+1) = *(borders+1) - border_y;
  *(borders+2) = *(borders+2) - border_v;

  return borders;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Find the borders of the cube to grid pointsources in a Sector */

static int *findborders_sector(Sectorpoints *points, char gmode)
{
  float bordersfloat[6];
  int *borders;
  Pointsource *pointsource;
  
  /* array bordersfloat contains x_min, y_min, v_min, x_max, y_max, v_max */ 

  /* get the first pointsource */
  if ((pointsource = (*points).next_point)){
  
    bordersfloat[0] = (*pointsource).x;
    bordersfloat[1] = (*pointsource).y;
    bordersfloat[2] = (*pointsource).v;
    bordersfloat[3] = (*pointsource).x;
    bordersfloat[4] = (*pointsource).y;
    bordersfloat[5] = (*pointsource).v;

    /* Now scan the whole Sector to get the minimum and the maximum points */
    while ((pointsource = (*pointsource).next)) {
      if (bordersfloat[0] > (*pointsource).x)
 bordersfloat[0] = (*pointsource).x;
      if (bordersfloat[1] > (*pointsource).y)
 bordersfloat[1] = (*pointsource).y;
      if (bordersfloat[2] > (*pointsource).v)
 bordersfloat[2] = (*pointsource).v;
      if (bordersfloat[3] < (*pointsource).x)
 bordersfloat[3] = (*pointsource).x;
      if (bordersfloat[4] < (*pointsource).y)
 bordersfloat[4] = (*pointsource).y;
      if (bordersfloat[5] < (*pointsource).v)
 bordersfloat[5] = (*pointsource).v;
    }
    
    /* allocate memory for the return value */
    borders = (int *) malloc(6*sizeof(int));

    /* In case of  BORDERS_INTER the cube is padded to the borders */
    if (gmode == BORDERS_INTER) {
    borders[0] = roundown(bordersfloat[0]);
    borders[1] = roundown(bordersfloat[1]);
    borders[2] = roundown(bordersfloat[2]);
    borders[3] = roundup(bordersfloat[3]);
    borders[4] = roundup(bordersfloat[4]);
    borders[5] = roundup(bordersfloat[5]);
    }
    
    /* In case of  BORDERS_HYBRID the cube is padded to the borders in x and y and not in v */
    if (gmode == BORDERS_HYBRID) {
    borders[0] = roundown(bordersfloat[0]);
    borders[1] = roundown(bordersfloat[1]);
    borders[2] = roundnormal(bordersfloat[2]);
    borders[3] = roundup(bordersfloat[3]);
    borders[4] = roundup(bordersfloat[4]);
    borders[5] = roundnormal(bordersfloat[5]);
    }
    
    /* In case of BORDERS_NEXT the cube will only need to contain the
       next pixels */    
    if (gmode == BORDERS_NEXT) {
    borders[0] = roundnormal(bordersfloat[0]);
    borders[1] = roundnormal(bordersfloat[1]);
    borders[2] = roundnormal(bordersfloat[2]);
    borders[3] = roundnormal(bordersfloat[3]);
    borders[4] = roundnormal(bordersfloat[4]);
    borders[5] = roundnormal(bordersfloat[5]);
    }
    return borders;
  }
  else 
    return NULL;
  
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Find the borders of the cube to grid pointsources in a Ring */


static int *findborders_ring(Ringpoints *points, char gmode)
{
  int *borders = NULL, *bordersector;
  Sectorpoints *nextsector;
  
  /* Check if there is a sector */
  if ((nextsector = (*points).next_sector)) {

    /* Write the first numbers into the borders array */
    while (nextsector && !borders) {
      if ((bordersector = findborders_sector(nextsector,gmode)))
 borders = bordersector;
      nextsector = (*nextsector).next;
    }
     
    /* Now continue until the end is reached */
    while ((nextsector)) {

      /* if the sector contains anything */
      if ((bordersector = findborders_sector(nextsector,gmode))) {

 /* change the borders if necessary */
 if (*borders > *bordersector)
   *borders = *bordersector;
 if (*(borders+1) > *(bordersector+1)) 
   *(borders+1) = *(bordersector+1);
 if (*(borders+2) > *(bordersector+2)) 
   *(borders+2) = *(bordersector+2);
 if (*(borders+3) < *(bordersector+3)) 
   *(borders+3) = *(bordersector+3);
 if (*(borders+4) < *(bordersector+4))
   *(borders+4) = *(bordersector+4);
 if (*(borders+5) < *(bordersector+5)) 
   *(borders+5) = *(bordersector+5);

 /* Don't forget ! */
 free(bordersector);
      }
      nextsector = (*nextsector).next;    
    }
  }
  return borders;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Find the borders of the cube to grid pointsources in a Disk */

static int *findborders_disk(Diskpoints *points, char gmode)
{
  int *borders = NULL, *bordering;
  Ringpoints *nextring;
  
  /* Check if there is a sector */
  if ((nextring = (*points).next_ring)) {

    /* Write the first numbers into the borders array */
    while (nextring && !borders) {
      if ((bordering = findborders_ring(nextring,gmode)))
 borders = bordering;
      nextring = (*nextring).next;
    }
     
    /* Now continue until the end is reached */
    while (nextring) {

      /* if the sector contains anything */
      if ((bordering = findborders_ring(nextring,gmode))) {

 /* change the borders if necessary */
 if (*borders > *bordering)
   *borders = *bordering;
 if (*(borders+1) > *(bordering+1)) 
   *(borders+1) = *(bordering+1);
 if (*(borders+2) > *(bordering+2)) 
   *(borders+2) = *(bordering+2);
 if (*(borders+3) < *(bordering+3)) 
   *(borders+3) = *(bordering+3);
 if (*(borders+4) < *(bordering+4))
   *(borders+4) = *(bordering+4);
 if (*(borders+5) < *(bordering+5)) 
   *(borders+5) = *(bordering+5);

 /* Don't forget ! */
 free(bordering);
      }
      nextring = (*nextring).next;    
    }

  }
  return borders;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Convolve a cube with a gaussian via fft */

Cube *convolgaussfft(Cube *cube, float *expofacsfft)
{
  int i, j, k, newsize, dummy;
  fftwf_complex *transformed_cube; /* pointer to the floating point array that becomes comlex afterwards */
  fftwf_plan plan, plin;           /* configuration variable for fftw for forwards and backwards transformation */
  int padding;                     /* information about the original padding */
  float expofacs[5];               /* factors in the exponent normalised to unity */
  float expresult;                 /* A dummy */

  /* Does the cube exist and contain an array? */
  if (cube && (*cube).points) {

    /* point the trasnsformed cube to the cube itself for an in-place transformation */
    transformed_cube = (fftwf_complex *) (*cube).points;

/*     return NULL; */
    /* Pad the cube if necessary: */
    if ((padding = (*cube).padding) == 0)
      padcubex(cube);
    /************/
    /************/
    /************/
    /************/

    /* Calculate the factors in the exponent */
    expofacs[0] = expofacsfft[0]/((*cube).size_x*(*cube).size_x);
    expofacs[1] = expofacsfft[1]/((*cube).size_x*(*cube).size_y);
    expofacs[2] = expofacsfft[2]/((*cube).size_y*(*cube).size_y);
    expofacs[3] = expofacsfft[3]/((*cube).size_v*(*cube).size_v);
    expofacs[4] = logf(expofacsfft[4]/((*cube).size_v*(*cube).size_y*(*cube).size_x));

    /* Calculate the factors in the exponent */
/*     expofacs[0] = expofacsfft[0]; */
/*     expofacs[1] = expofacsfft[1]; */
/*     expofacs[2] = expofacsfft[2]; */
/*     expofacs[3] = expofacsfft[3]; */
/*     expofacs[4] = logf(expofacsfft[4]); */
    /************/
    /************/
    /************/
    /************/
/*   return NULL; */

    /* Convolution in all dimensions or in xy only */
    if ((*cube).size_v > 1) {

      /* fill plan and plin with the necessary information. Take care with the order of the axes, reversed for fftw */
      plan = fftwf_plan_dft_r2c_3d((*cube).size_v, (*cube).size_y, (*cube).size_x, (*cube).points, transformed_cube, FFTW_ESTIMATE);
      plin = fftwf_plan_dft_c2r_3d((*cube).size_v, (*cube).size_y, (*cube).size_x, transformed_cube, (*cube).points, FFTW_ESTIMATE);

      /* Now do the transform */
      fftwf_execute(plan);

      /* multiply with the gaussian, first for nu_v = 0 */
      newsize = (*cube).size_x/2+1;
      for (i = 0; i < newsize; ++i) {
 for (j = 0; j < (*cube).size_y; ++j) {
   
   /* The exponential will be evaluated from 0, ... , N/2 and -1, ..., -N/2 or -N/2 - 1 */
   expresult = fftgaussian2d((i <= (*cube).size_x/2) ? i : (i-(*cube).size_x), (j <= (*cube).size_y/2) ? j : (j-(*cube).size_y), expofacs);
     transformed_cube[i+newsize*j][0] = expresult*transformed_cube[i+newsize*j][0];
     transformed_cube[i+newsize*j][1] = expresult*transformed_cube[i+newsize*j][1];
   }
      }

      /* Check for an extra-axis in v, i.e. if the dimension in v is even, we have to calculate one v-plane separately */
      if (!((*cube).size_v % 2)) {
 /* multiply with the gaussian, first for nu_v = N_v/2 */
 dummy = (*cube).size_v/2;
 for (i = 0; i < newsize; ++i) {
   for (j = 0; j < (*cube).size_y; ++j)
     {
       /* The exponential will be evaluated from 0, ... , N/2 and -1, ..., -N/2 or -N/2 - 1 */
     expresult = fftgaussian((i <= (*cube).size_x/2) ? i : (i-(*cube).size_x), (j <= (*cube).size_y/2) ? j : (j-(*cube).size_y), dummy, expofacs);
     transformed_cube[i+newsize*(j+(*cube).size_y*dummy)][0] = expresult*transformed_cube[i+newsize*(j+(*cube).size_y*dummy)][0];
     transformed_cube[i+newsize*(j+(*cube).size_y*dummy)][1] = expresult*transformed_cube[i+newsize*(j+(*cube).size_y*dummy)][1];
     }
 }
      }
      
      /* Now the rest has to be done, v ranges from 1, ..., N_v-1/2, and using the symmetrics of the gaussian we fill the rest */
      for (i = 0; i < newsize; ++i) {
 for (j = 0; j < (*cube).size_y; ++j) {
   for (k = 1; k <= ((*cube).size_v-1)/2; ++k) {
     expresult = fftgaussian((i <= (*cube).size_x/2) ? i : (i-(*cube).size_x), (j <= (*cube).size_y/2) ? j : (j-(*cube).size_y), k, expofacs);
     transformed_cube[i+newsize*(j+(*cube).size_y*k)][0] = expresult*transformed_cube[i+newsize*(j+(*cube).size_y*k)][0];
     transformed_cube[i+newsize*(j+(*cube).size_y*k)][1] = expresult*transformed_cube[i+newsize*(j+(*cube).size_y*k)][1];

     /* Because of the symmetry, f(v) = f(-v), we can safe quite some calculations */
     transformed_cube[i+newsize*(j+(*cube).size_y*((*cube).size_v-k))][0] = expresult*transformed_cube[i+newsize*(j+(*cube).size_y*((*cube).size_v-k))][0];
     transformed_cube[i+newsize*(j+(*cube).size_y*((*cube).size_v-k))][1] = expresult*transformed_cube[i+newsize*(j+(*cube).size_y*((*cube).size_v-k))][1];
   }
 }
      }

      /* Now do the backtransformation */
      fftwf_execute(plin);    
    }

    /* if the cube has only one plane or only convolution in xy is desired then do this: */
    else {
      plan = fftwf_plan_dft_r2c_2d((*cube).size_y, (*cube).size_x, (*cube).points, transformed_cube, FFTW_ESTIMATE);
      plin = fftwf_plan_dft_c2r_2d((*cube).size_y, (*cube).size_x, transformed_cube, (*cube).points, FFTW_ESTIMATE);    
      
      /* Now do the transform */
      fftwf_execute(plan);
      
      /* multiply with the gaussian, first axis y, second x */
      newsize = (*cube).size_x/2+1; /* The physical size of the cube in x */
      for (i = 0; i < newsize; ++i) {
 for (j = 0; j < (*cube).size_y; ++j) {
   expresult = fftgaussian2d((i <= (*cube).size_x/2) ? i : (i-(*cube).size_x), (j <= (*cube).size_y/2) ? j : (j-(*cube).size_y), expofacs);
   transformed_cube[i+newsize*j][0] = expresult*transformed_cube[i+newsize*j][0];
   transformed_cube[i+newsize*j][1] = expresult*transformed_cube[i+newsize*j][1];

 }
      }
      
      /* Now do the backtransformation */
      fftwf_execute(plin);    
    }
    
    /* For some reason fftw knows if the cube is padded for an in-place transform (i.e. it checks wether in = out) This means that we pad backwards only if there was no padding */
    if (!padding)
      padcubex(cube);

  return cube; 
  }

/* There is either no allocated array in the cube or no cube at all */
  else 
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Calculate factors needed by convolgaussfft */

float *expofacsfft(float sigma_maj, float sigma_min, float sigma_v, float *sincosofangle)
{
  float *expofacs;

  if ((sincosofangle && (expofacs = (float *) malloc(5*sizeof(float))))) {

  /* First content is the factor to put before (n_x/N_x)^2 */
  expofacs[0] = -2*PI_HERE*PI_HERE*(sigma_min*sigma_min*sincosofangle[1]*sincosofangle[1]+sigma_maj*sigma_maj*sincosofangle[0]*sincosofangle[0]);

  /* Second content is the factor to put before (n_x/N_x)(n_y/N_y) */
  expofacs[1] = -4*PI_HERE*PI_HERE*sincosofangle[0]*sincosofangle[1]*(sigma_min*sigma_min-sigma_maj*sigma_maj);

  /* Third content is the factor to put before (n_y/N_y)^2 */
  expofacs[2] = -2*PI_HERE*PI_HERE*(sigma_min*sigma_min*sincosofangle[0]*sincosofangle[0]+sigma_maj*sigma_maj*sincosofangle[1]*sincosofangle[1]);

  /* Fourth content is the factor to put before (n_v/N_v)^2 */
  expofacs[3] = -2*(PI_HERE*sigma_v*PI_HERE*sigma_v);

  /* Fifth component is the normalisation factor due to the width of the gaussians. This is not a factor to put in the exponent though. Here we have to care if only one direction conovolution is desired */
    if (sigma_maj == 0) 
      sigma_maj = 1.0/sqrtf(2*PI_HERE);
    
    if (sigma_min == 0)
      sigma_min = 1.0/sqrtf(2*PI_HERE);

  expofacs[4] = 2*PI_HERE*sigma_min*sigma_maj;
  }
  else
    expofacs = NULL;

  return expofacs;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Calculate a gaussian */

float fftgaussian (int nx, int ny, int nv, float *expofacs)
{ 
  /* As the trial to safe some time as seen below failed for some reason, we postpone it */
/*   float number; */

  /* If the floating point is low enough, we can simply return 0 */
/*   if ((number = expofacs[0]*nx*nx+expofacs[1]*nx*ny+expofacs[2]*ny*ny+expofacs[3]*nv*nv+expofacs[4]) <= MINEXPONENT) */
/*     return exp(number); */
/*   else */
/*   return 0.0; */
    return expf(expofacs[0]*nx*nx+expofacs[1]*nx*ny+expofacs[2]*ny*ny+expofacs[3]*nv*nv+expofacs[4]);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Calculate a gaussian */

float fftgaussian2d (int nx, int ny, float *expofacs)
{
/*   double number; */

  /* If the floating point is low enough, we can simply return 0 */
/*   if ((number = expf(expofacs[0]*nx*nx+expofacs[1]*nx*ny+expofacs[2]*ny*ny+expofacs[4])) <= MINEXPONENT) */
/*     return (float) exp(number); */
/*   else */
    return (float) expf(expofacs[0]*nx*nx+expofacs[1]*nx*ny+expofacs[2]*ny*ny+expofacs[4]);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Convolve a pointsource with a gaussian and add it to the Cube */

static Cube *convolgaussdirect_point(Cube *cube, Pointsource *point, float flux, int *borders, float *expofacsdirect)

{
  float *centralpixel;
  float distances[3];      /* distances from the central pixel */
  int i, j, k, newsize;

  /* Check if there is a cube and a pointsource to grid */
  if ((cube && point)) {

    /* get the adress of the pixel next to the peak of the pointsource */
    centralpixel = findpixel(cube, roundnormal((*point).x), roundnormal((*point).y), roundnormal((*point).v));

    /* These will be needed for a proper convolution */
    distances[0] = (*point).x - (float) roundnormal((*point).x);
    distances[1] = (*point).y - (float) roundnormal((*point).y);
    distances[2] = (*point).v - (float) roundnormal((*point).v);

    /* We'll need this later */
    newsize = (*cube).size_x+(*cube).padding;

    /* One can simply calculate relative positions knowing the adress of the central pixel, that's it */
    for (i = -borders[0] ; i <= borders[0]; ++i) {
      for (j = -borders[1] ; j <= borders[1]; ++j) {
 for (k = -borders[2] ; k <= borders[2]; ++k) {
   *(centralpixel+i+newsize*(j+(*cube).size_y*k)) = *(centralpixel+i+newsize*(j+(*cube).size_y*k))+flux*gaussdirect(i, j, k, distances, expofacsdirect);
 }
      }
    }

    return cube;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* The factors needed to make a direct convolution */

static float *expofacsdirect(float sigma_maj, float sigma_min, float sigma_v, float *sincosofangle)
{
  float *expofacs;
  float facmaj = 1.0;
  float facmin = 1.0;

  if ((sincosofangle && (expofacs = (float *) malloc(5*sizeof(float))))) {

    /* We'll allow also for no convolution at all in a single direction. For the fft convolution this changes nothing. But here we are not allowed to divide by 0 */
    if (sigma_maj == 0) {
      facmaj = 0;
      sigma_maj = 1;
    }
    if (sigma_min == 0) {
      facmin = 0;
      sigma_min = 1;
    }

  /* First content is the factor to put before (n_x/N_x)^2 */
  expofacs[0] = -(facmin*sincosofangle[1]*sincosofangle[1]/(2*sigma_min*sigma_min)+facmaj*sincosofangle[0]*sincosofangle[0]/(2*sigma_maj*sigma_maj));

  /* Second content is the factor to put before (n_x/N_x)(n_y/N_y) */
  expofacs[1] = -sincosofangle[0]*sincosofangle[1]*(facmin/(sigma_min*sigma_min)-facmaj/(sigma_maj*sigma_maj));

  /* Third content is the factor to put before (n_y/N_y)^2 */
  expofacs[2] = -(facmin*sincosofangle[0]*sincosofangle[0]/(2*sigma_min*sigma_min)+facmaj*sincosofangle[1]*sincosofangle[1]/(2*sigma_maj*sigma_maj));

  /* Fourth content is the factor to put before (n_v/N_v)^2, if there is any */
  if (sigma_v)
    expofacs[3] = -1.0/(2*sigma_v*sigma_v);
  else 
    expofacs[3] = 0;

  /* Fifth component is the normalisation factor due to the width of the gaussians. If sigma_v = 0 it is assumed that there is no normalisation */
  if (sigma_v)
    expofacs[4] = logf(1.0/(sqrtf(2*PI_HERE)*sigma_v));
  else 
    expofacs[4] = 0;

  /* ready */
  return expofacs;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Return a relative gaussian */

static float gaussdirect(int i, int j, int k, float *distances, float *expofacsdirect)
{
  return expf(expofacsdirect[0]*(i-distances[0])*(i-distances[0])+expofacsdirect[1]*(i-distances[0])*(j-distances[1])+expofacsdirect[2]*(j-distances[1])*(j-distances[1])+expofacsdirect[3]*(k-distances[2])*(k-distances[2])+expofacsdirect[4]);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Convolve directly a Sector and add it on the cube */

static Cube *convolgaussdirect_sector(Cube *cube, Sectorpoints *sector, int *borders, float *expofacsdirect)
{  
  Pointsource *point; 

  if (cube && (point = (*sector).next_point)) {

    while (point) {
      convolgaussdirect_point(cube, point, *(*sector).f, borders, expofacsdirect);
      point = (*point).next;
    }
    return cube;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Convolves directly a Ring and adds it to the cube */

static Cube *convolgaussdirect_ring(Cube *cube, Ringpoints *ring, int *borders, float *expofacsdirect)
{  
  Sectorpoints *point; 

  if (cube && (point = (*ring).next_sector)) {

    while (point) {
      convolgaussdirect_sector(cube, point, borders, expofacsdirect);
      point = (*point).next;
    }
    return cube;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Convolves directly a Disk and adds it to the cube */

static Cube *convolgaussdirect_disk(Cube *cube, Diskpoints *disk, int *borders, float *expofacsdirect)
{  
  Ringpoints *point; 

  if (cube && (point = (*disk).next_ring)) {

    while (point) {
      convolgaussdirect_ring(cube, point, borders, expofacsdirect);
      point = (*point).next;
    }
    return cube;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Convolve a structure to an emptied Cube */

/* static Cube *convolgaussdirect(Cube *cube,  void *points, char stype, int *borders, float *expofacsdirect) */
/* { */
/*   cuberase(cube); */
/*   convolgaussdirect(cube, points, stype, borders, expofacsdirect); */
/*   return cube; */
/* } */

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Convolve a structure directly adding the points to a cube */

static Cube *convolgaussdirecton(Cube *cube, void *points, char stype, int *borders, float *expofacsdirect)
{
  Diskpoints *diskpoints;
  Ringpoints *ringpoints;
  Sectorpoints *sectorpoints;

  switch (stype) {
  case BORDERS_DISK:
    diskpoints = (Diskpoints *) points;
    cube = convolgaussdirect_disk(cube, diskpoints, borders, expofacsdirect);
    break;
  case BORDERS_RING:
    ringpoints = (Ringpoints *) points;
    cube = convolgaussdirect_ring(cube, ringpoints,  borders, expofacsdirect);
    break;
  case  BORDERS_SECTOR:
    sectorpoints = (Sectorpoints *) points;
    cube = convolgaussdirect_sector(cube, sectorpoints,  borders, expofacsdirect);
    break;
  default:
    cube = NULL;
  }
  return cube;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grid on a structure excluding substructures containing a cube */

static Cube *gridonexclude(Cube *cube, void *points, char stype, char gmode, float twosigmasq)
{
  Ringpoints *ring, *ringpoints;
  Sectorpoints *sector, *sectorpoints;
  Diskpoints *diskpoints;

  switch (stype) {
  case BORDERS_DISK:
    diskpoints = (Diskpoints *) points;

    /* First check if we are finished here, i.e. if there is already a cube do nothing */
    if ((*diskpoints).cube && (*(*diskpoints).cube).points && ((*diskpoints).cube != cube))
      ;
    else

      /* if there is no cube go to the next lower level, if there is any */
      if ((ring = (*diskpoints).next_ring))
	while (ring) {

	  /* call the function at the next lower level */
	  gridonexclude(cube, (void *) ring, BORDERS_RING, gmode, twosigmasq);
	  ring = (*ring).next;
	}
    break;

  case BORDERS_RING:
    ringpoints = (Ringpoints *) points;

    /* First check if we are finished here, i.e. if there is already a cube do nothing */
    if ((*ringpoints).cube && (*(*ringpoints).cube).points && ((*ringpoints).cube != cube))
      ;
    else

      /* if there is no cube go to the next lower level, if there is any */
      if ((sector = (*ringpoints).next_sector))
	while (sector) {

	  /* call the function at the next lower level */
	  gridonexclude(cube, (void *) sector, BORDERS_SECTOR, gmode, twosigmasq);
	  sector = (*sector).next;
	}
    break;

  case  BORDERS_SECTOR:
    sectorpoints = (Sectorpoints *) points;

    /* First check if we are finished here, i.e. if there is already a cube do nothing */
    if ((*sectorpoints).cube && (*(*sectorpoints).cube).points && ((*sectorpoints).cube != cube))
      ;
    else
      
      /* if there is no cube grid on, this is not safe */
      gridon(cube, sectorpoints, BORDERS_SECTOR, gmode, twosigmasq);
    break;
  default:
    cube = NULL;
  }
  return cube;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grid only where no cube is already there */

static Cube *gridoncollect(Cube *cube, void *points, char stype, char gmode, float twosigmasq)
{
  Diskpoints *diskpoints;
  Ringpoints *ringpoints;
  Sectorpoints *sectorpoints;

  switch (stype) {
  case BORDERS_DISK:
    diskpoints = (Diskpoints *) points;
    cube = gridonexclude(cube, diskpoints, BORDERS_DISK, gmode, twosigmasq);
    break;
  case BORDERS_RING:
    ringpoints = (Ringpoints *) points;
    cube = gridonexclude(cube, ringpoints, BORDERS_RING, gmode, twosigmasq);
    break;
  case  BORDERS_SECTOR:
    sectorpoints = (Sectorpoints *) points;
    cube = gridonexclude(cube, sectorpoints,  BORDERS_SECTOR, gmode, twosigmasq);
    break;
  default:
    cube = NULL;
  }

  if (cube)
    cube = collectcubes(cube, points, stype);

  return cube;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Searches the structure points for existing cubes and adds
  each top level cube to cube. */

Cube *collectcubes(Cube *cube, void *points, char stype)
{
  Ringpoints *ring, *ringpoints;
  Sectorpoints *sector, *sectorpoints;
  Diskpoints *diskpoints;

  switch (stype) {
  case BORDERS_DISK:
    diskpoints = (Diskpoints *) points;

    /* First check if we are finished here, i.e. if there is already a cube add it and stop */
    if ((*diskpoints).cube && (*(*diskpoints).cube).points && ((*diskpoints).cube != cube))
      addcubes(cube, (*diskpoints).cube);
    else

      /* if there is no cube go to the next lower level, if there is any */
      if ((ring = (*diskpoints).next_ring))
	while (ring) {

	  /* call the function at the next lower level */
	  collectcubes(cube, (void *) ring, BORDERS_RING);
	  ring = (*ring).next;
	}
    break;

  case BORDERS_RING:
    ringpoints = (Ringpoints *) points;

    /* First check if we are finished here, i.e. if there is already a cube do nothing */
    if ((*ringpoints).cube && (*(*ringpoints).cube).points && ((*ringpoints).cube != cube))
      addcubes(cube, (*ringpoints).cube);
    else

      /* if there is no cube go to the next lower level, if there is any */
      if ((sector = (*ringpoints).next_sector))
	while (sector) {

	  /* call the function at the next lower level */
	  collectcubes(cube, (void *) sector, BORDERS_SECTOR);
	  sector = (*sector).next;
	}
    break;

  case  BORDERS_SECTOR:
    sectorpoints = (Sectorpoints *) points;

    /* First check if we are finished here, i.e. if there is already a cube do nothing */
    if ((*sectorpoints).cube && (*(*sectorpoints).cube).points && ((*sectorpoints).cube != cube))
      addcubes(cube, (*sectorpoints).cube);
    else
      
      /* if there is no cube to add, do nothing */
      ;
    break;
  default:
    cube = NULL;
  }
  return cube;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Make a direct convolution exhausting already convolved substructure */

static Cube *convoldirectcollect(Cube *cube, void *points, char stype, int *borders, float *expofacsdirect)
{
  Ringpoints *ring, *ringpoints;
  Sectorpoints *sector, *sectorpoints;
  Diskpoints *diskpoints;
  
  switch (stype) {
  case BORDERS_DISK:
    diskpoints = (Diskpoints *) points;
    
    /* First check if we are finished here, i.e. if there is already a cube do nothing */
    if ((*diskpoints).cube && (*(*diskpoints).cube).points && ((*diskpoints).cube != cube))
      ;
    else
      
      /* if there is no cube go to the next lower level, if there is any */
      if ((ring = (*diskpoints).next_ring))
	while (ring) {
	  
	  /* call the function at the next lower level */
	  convoldirectcollect(cube, (void *) ring, BORDERS_RING, borders, expofacsdirect);
	  ring = (*ring).next;
	}
    break;
    
  case BORDERS_RING:
    ringpoints = (Ringpoints *) points;
    
    /* First check if we are finished here, i.e. if there is already a cube do nothing */
    if ((*ringpoints).cube && (*(*ringpoints).cube).points && ((*ringpoints).cube != cube))
      ;
    else

      /* if there is no cube go to the next lower level, if there is any */
      if ((sector = (*ringpoints).next_sector))
	while (sector) {
	  
	  /* call the function at the next lower level */
	  convoldirectcollect(cube, (void *) sector, BORDERS_SECTOR, borders, expofacsdirect);
	  sector = (*sector).next;
	}
    break;
    
  case BORDERS_SECTOR:
    sectorpoints = (Sectorpoints *) points;
    
    /* First check if we are finished here, i.e. if there is already a cube do nothing */
    if ((*sectorpoints).cube && (*(*sectorpoints).cube).points && ((*sectorpoints).cube != cube))
      ;
    else
      
      /* if there is no cube grid on if possible */
      convolgaussdirecton(cube, (void *) sectorpoints, BORDERS_SECTOR, borders, expofacsdirect);
    break;
    
  default:
    cube = NULL;
    break;
  }
  /* We're not finished yet. Now we'll add the cubes that were already at hand */
  
  cube = collectcubes(cube, points, stype);
   
  return cube;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Do a convolution or a gridding of a structure on a cube that is allocated in various ways */

Cube *gridnconvol(void *points, char stype, char contype, char conmode, char gmode, int **bordersgaussint, float **expofacsffts, float **expofacsdirects, float sigma_major_axis, float sigma_minor_axis, float sigma_v, float position_angle, float sizeofgauss, float twosigmasq, char produce, char create)
{
  Cube *gridnconvol = NULL;
  Diskpoints *diskpoints;
  Ringpoints *ringpoints;
  Sectorpoints *sectorpoints;
  float *sincospa = NULL;
  char didsincos = 0, didbordersgauss = 0, didcubecreat = 0, didexpofacsfft = 0, didexpofacsdirect = 0;
  int padding, i, j, k;

  /* First check if there is a structure to grid at all */
  if (points) {

      /* Do we want to create a new cube, or do we chose another mode */
    if (create == POINTER) {
      
      /* check if there is already a cube */

      switch(stype) {
      case DISK:
	diskpoints = (Diskpoints *) points;

	/* If there is a cube we'll return this cube */
	if (((*diskpoints).cube))
	  gridnconvol = (*diskpoints).cube;
	else
	  gridnconvol = NULL;
	break;

      case RING:
	ringpoints = (Ringpoints *) points;
	if (((*ringpoints).cube))
	  gridnconvol = (*ringpoints).cube;
	else
	  gridnconvol = NULL;
	break;

      case SECTOR:
	sectorpoints = (Sectorpoints *) points;
	if (((*sectorpoints).cube))
	  gridnconvol = (*sectorpoints).cube;
	else
	  gridnconvol = NULL;
	break;
      }
      
      if (gridnconvol) {
	/* check if a cube is required, if not we have finished */
	if (produce == SIZE)
	  goto success;

	/* if there is also the points structure, we'll stop here */
	if (((*gridnconvol).points))
	  goto success;
	
	/* if there is no cube, we have to allocate it, if a cube is required. */
	else {
	  
	  /* if we cannot, we have to stop */
	  if (!((*gridnconvol).points = (float *) malloc (((*gridnconvol).size_x+(*gridnconvol).padding)*((*gridnconvol).size_y)*((*gridnconvol).size_v)*sizeof(float))))
	    goto error;
	}
      }
    }
  
    /* If we want to copy a cube */

    if (create == COPY) {
      
      /* check if there is already a cube (this has to be that long, because we have to deal with the contents of the points structure */
      
      switch(stype) {
      case DISK:
	diskpoints = (Diskpoints *) points;
	
	/* If there is a cube we'll try to make a copy */
	if (((*diskpoints).cube)) {
	  
	  /* check if there is disk space for the cube */
	  if ((gridnconvol = (Cube *) malloc(sizeof(Cube)))) {
	    
	    /* fill the cube with the known sizes and such */
	    (*gridnconvol).refpix_x = (*(*diskpoints).cube).refpix_x;
	    (*gridnconvol).refpix_y = (*(*diskpoints).cube).refpix_y; 
	    (*gridnconvol).refpix_v = (*(*diskpoints).cube).refpix_v; 
	    (*gridnconvol).size_x = (*(*diskpoints).cube).size_x; 
	    (*gridnconvol).size_y = (*(*diskpoints).cube).size_y; 
	    (*gridnconvol).size_v = (*(*diskpoints).cube).size_v; 
	    (*gridnconvol).scale   = (*(*diskpoints).cube).scale; 
	    (*gridnconvol).padding  = (*(*diskpoints).cube).padding;
	    
	    /* As long as we don't know, if we want this */
	    (*gridnconvol).points   = NULL;
	    
	    /* we created a cube */
	    didcubecreat = 1;
	  }
	  
	  /* if we cannot even allocate a cube */
	  else 
	    goto error;
	  
	  /* Do we want to have the points also? */
	  if (produce == SIZE)
	    goto success;
	  
	  /* we want to have the points, so we try to allocate them */
	  if (!((*gridnconvol).points = (float *) malloc (((*gridnconvol).size_x+(*gridnconvol).padding)*((*gridnconvol).size_y)*((*gridnconvol).size_v)*sizeof(float))))
	    goto error;
	  
	  /* If there is the points in the cube we will copy them and stop */
	  if (((*(*diskpoints).cube).points)) {
	    
	    for (i = 0; i < (*gridnconvol).size_x; ++i) {
	      for (j = 0; j < (*gridnconvol).size_y; ++j) {
		for (k = 0; k < (*gridnconvol).size_v; ++k) {
		  ((*gridnconvol).points)[i+((*gridnconvol).size_x+(*gridnconvol).padding)*(j+(*gridnconvol).size_y*k)] = ((*(*diskpoints).cube).points)[i+((*gridnconvol).size_x+(*gridnconvol).padding)*(j+(*gridnconvol).size_y*k)];
		}
	      }
	    }
	    goto success;
	  }
	}
	break;
	
      case RING:
	ringpoints = (Ringpoints *) points;
	/* If there is a cube we'll try to make a copy */
	if (((*ringpoints).cube)) {
	  
	  /* check if there is disk space for the cube */
	  if ((gridnconvol = (Cube *) malloc(sizeof(Cube)))) {
	    
	    /* fill the cube with the known sizes and such */
	    (*gridnconvol).refpix_x = (*(*ringpoints).cube).refpix_x;
	    (*gridnconvol).refpix_y = (*(*ringpoints).cube).refpix_y; 
	    (*gridnconvol).refpix_v = (*(*ringpoints).cube).refpix_v; 
	    (*gridnconvol).size_x = (*(*ringpoints).cube).size_x; 
	    (*gridnconvol).size_y = (*(*ringpoints).cube).size_y; 
	    (*gridnconvol).size_v = (*(*ringpoints).cube).size_v; 
	    (*gridnconvol).scale   = (*(*ringpoints).cube).scale; 
	    (*gridnconvol).padding  = (*(*ringpoints).cube).padding;
	    
	    /* As long as we don't know, if we want this */
	    (*gridnconvol).points   = NULL;
	    
	    /* we created a cube */
	    didcubecreat = 1;
	  }
	  
	  /* if we cannot even allocate a cube */
	  else 
	    goto error;
	  
	  /* Do we want to have the points also? */
	  if (produce == SIZE)
	    goto success;
	  
	  /* we want to have the points, so we try to allocate them */
	  if (!((*gridnconvol).points = (float *) malloc (((*gridnconvol).size_x+(*gridnconvol).padding)*((*gridnconvol).size_y)*((*gridnconvol).size_v)*sizeof(float))))
	    goto error;
	  
	  /* If there is the points in the cube we will copy them and stop */
	  if (((*(*ringpoints).cube).points)) {
	    
	    for (i = 0; i < (*gridnconvol).size_x; ++i) {
	      for (j = 0; j < (*gridnconvol).size_y; ++j) {
		for (k = 0; k < (*gridnconvol).size_v; ++k) {
		  ((*gridnconvol).points)[i+((*gridnconvol).size_x+(*gridnconvol).padding)*(j+(*gridnconvol).size_y*k)] = ((*(*ringpoints).cube).points)[i+((*gridnconvol).size_x+(*gridnconvol).padding)*(j+(*gridnconvol).size_y*k)];
		}
	      }
	    }
	    goto success;
	  }
	}
	break;
	
      case SECTOR:
	sectorpoints = (Sectorpoints *) points;
	
	/* If there is a cube we'll try to make a copy */
	if (((*sectorpoints).cube)) {
	
	  /* check if there is disk space for the cube */
	  if ((gridnconvol = (Cube *) malloc(sizeof(Cube)))) {
	    
	    /* fill the cube with the known sizes and such */
	    (*gridnconvol).refpix_x = (*(*sectorpoints).cube).refpix_x;
	    (*gridnconvol).refpix_y = (*(*sectorpoints).cube).refpix_y; 
	    (*gridnconvol).refpix_v = (*(*sectorpoints).cube).refpix_v; 
	    (*gridnconvol).size_x = (*(*sectorpoints).cube).size_x; 
	    (*gridnconvol).size_y = (*(*sectorpoints).cube).size_y; 
	    (*gridnconvol).size_v = (*(*sectorpoints).cube).size_v; 
	    (*gridnconvol).scale   = (*(*sectorpoints).cube).scale; 
	    (*gridnconvol).padding  = (*(*sectorpoints).cube).padding;
	    
	    /* As long as we don't know, if we want this */
	    (*gridnconvol).points   = NULL;
	    
	    /* we created a cube */
	    didcubecreat = 1;
	  }
	  
	  /* if we cannot even allocate a cube */
	  else 
	    goto error;
	  
	  /* Do we want to have the points also? */
	  if (produce == SIZE)
	    goto success;
	  
	  /* we want to have the points, so we try to allocate them */
	  if (!((*gridnconvol).points = (float *) malloc (((*gridnconvol).size_x+(*gridnconvol).padding)*((*gridnconvol).size_y)*((*gridnconvol).size_v)*sizeof(float))))
	    goto error;
	  
	  /* If there is the points in the cube we will copy them and stop */
	  if (((*(*sectorpoints).cube).points)) {
	    
	    for (i = 0; i < (*gridnconvol).size_x; ++i) {
	      for (j = 0; j < (*gridnconvol).size_y; ++j) {
		for (k = 0; k < (*gridnconvol).size_v; ++k) {
		  ((*gridnconvol).points)[i+((*gridnconvol).size_x+(*gridnconvol).padding)*(j+(*gridnconvol).size_y*k)] = ((*(*sectorpoints).cube).points)[i+((*gridnconvol).size_x+(*gridnconvol).padding)*(j+(*gridnconvol).size_y*k)];
		}
	      }
	    }
	    goto success;
	  }
	}
      break;
      }
    }
    
  
    /* check if we already have the cube, if not make one */
    
    if (!gridnconvol) {
      /* Now we want to allocate a cube first. We have to know the borders, and if we need a padding */
      if (!(*bordersgaussint)) {
	/* We are accurate in this function, so we check even for these values if we can allocate memory */
	if ((sincospa = sincosofangle(position_angle))) {
	  didsincos = 1;
	  if (!(*bordersgaussint = calcbordergauss(sigma_major_axis, sigma_minor_axis, sigma_v, sincospa, sizeofgauss)))
	    goto error;
	else
	  didbordersgauss = 1;
	}
	else
	  goto error;
      }
      
      /* Now we know the gaussian borders, so we can proceed to allocate the cube */
      
      /* We do a padding if we want an fft convolution */
      padding = (contype == FFT);
      
      /* We set the gmode to the default for the direct convolution */
    if (contype == DIRECT)
      gmode = BORDERS_DIRECT;
    
    /* check if we can allocate the cube, if stype is  */
    if ((gridnconvol = cubecreat(points, stype, gmode, **bordersgaussint, *(*bordersgaussint+1), *(*bordersgaussint+2), padding, produce)))
      didcubecreat = 1;
    else 
    goto error; 
    }
    
    /* if we only wanted to have the size of the cube, stop here */
    if (produce == SIZE) {
      goto success;
    }
    /* initialise the cube */
    cuberase(gridnconvol);
    
    /* We have allocated the cube, next step is to check whether we only do a gridding, because then we don't need any other factors */
    
    if (contype == GRIDDING) {
      /* Do we do a collect or not */

      /* if the mode is collect then do so and we're finished */
      if (conmode == COLLECT) {
	gridoncollect(gridnconvol, points, stype, gmode, twosigmasq);
	goto success;
      }
      else if (conmode == NONCOLLECT) {
	gridon(gridnconvol, points, stype, gmode, twosigmasq);
	goto success;
      }
      else 
	goto error;
    }

    /* If we want a fft convolution... */
    else if (contype == FFT) {

      /* The first thing is to check for the expofacsfft array */
      if (!(*expofacsffts)) {
      
	/* But first check if we calculated sincos with all the consequences */
	if (!didsincos) {
	  if ((sincospa = sincosofangle(position_angle)))
	    didsincos = 1;
	  else
	    goto error;
	}

	/* if we cannot create it, stop */
	if ((*expofacsffts = expofacsfft(sigma_major_axis, sigma_minor_axis, sigma_v, sincospa)))
	  didexpofacsfft = 1;
	else
	  goto error;
      }

      /* again, now we're on the safe side */

      /* do we collect ? */
      if (conmode == COLLECT) {

	/* Collect everything we have no cubes for yet and grid it */
	gridonexclude(gridnconvol, points, stype, gmode, twosigmasq);

	/* Convolve it */
	convolgaussfft(gridnconvol, *expofacsffts);

	/* Then add the found cubes to it */
	collectcubes(gridnconvol, points, stype);

	/* That's it here */
	goto success;
      }
      /* We don't collect */
      else if (conmode == NONCOLLECT) {

	/* simply grid everything and then do the convolution */
	gridon(gridnconvol, points, stype, gmode, twosigmasq);
	convolgaussfft(gridnconvol, *expofacsffts);
	goto success;
      }

      /* If there's the wrong input value */
      else 
	goto error;
    }
      /* The last possibility is the direct convolution */
    else if (contype == DIRECT) {

      /* The first thing is to check for the expofacsdirect array */
      if (!(*expofacsdirects)) {
      
	/* But first check if we calculated sincos with all the consequences */
	if (!didsincos) {
	  if ((sincospa = sincosofangle(position_angle)))
	    didsincos = 1;
	  else
	    goto error;
	}

	/* if we cannot create it, stop */
	if ((*expofacsdirects = expofacsdirect(sigma_major_axis, sigma_minor_axis, sigma_v, sincospa)))
	  didexpofacsdirect = 1;
	else
	  goto error;
      }

      /* again, now we're on the safe side */

      /* do we collect ? */
      if (conmode == COLLECT) {

	/* Then it's really easy */
	convoldirectcollect(gridnconvol, points, stype, *bordersgaussint, *expofacsdirects);
	goto success;
      }
          else if (conmode == NONCOLLECT) {

	/* No comment, because you have to look into that function */
	convolgaussdirecton(gridnconvol, points, stype, *bordersgaussint, *expofacsdirects);
	goto success;
      }

      /* If there's the wrong input value */
      else 
	goto error;
    }
    else
      goto error;
  }

  /* No input structure */
  else
    goto error;

 success:
  /* this can cause problems */
  if (didsincos)
    free(sincospa);
  return gridnconvol;

 error:
  if (didsincos)
    free(sincospa);
  if (didbordersgauss)
    free(*bordersgaussint);
  if (didcubecreat) {
    freecube(gridnconvol);}
  if (didexpofacsfft)
    free(*expofacsffts);
  if (didexpofacsdirect)
    free(*expofacsdirects);
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: gridnconvol.c,v $
   Revision 1.8  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.7  2011/05/10 00:30:15  jozsa
   Left work

   Revision 1.6  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.5  2007/08/23 15:23:25  gjozsa
   Left work

   Revision 1.4  2007/08/22 15:58:41  gjozsa
   Left work

   Revision 1.3  2004/12/09 16:08:45  gjozsa
   Changed some floating point operations from double to float accuracy

   Revision 1.2  2004/12/08 16:22:50  gjozsa
   Left work

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


   ------------------------------------------------------------ */
