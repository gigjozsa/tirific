/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file tirific.c
   @brief Translation and recreation of tirific.f
   Is a code to apply simulated annealing fitting datacubes to a cube, currently in the gipsy environment.
   Guideline how to hack into it, without a guarantee:

   i) Introducing a new singular parameter:
   1. Chose a struct of the four loginf headerinf ringparms and fitparms to include the parameter as a component.
   2. Add the parameter into the identifyer list: Add the parameter identifyer as the last element in the first PRIMPOS list (after comment "Not in first header" but before "Third hdu"). Change all numbers in the PRIMPOS list (also after the comment) such that the numbers following the added identifyer are increased by 1. Increase the PRIMHDN_SINGLE symbolic constant by 1.
   3. Change the functions primpos_numtype() and primpos_value() hdl_init() by adding the new parameter at exactly the same place that it was added to the identifyer list.
   4. Go into the get_hdrinf(), get_loginf(), get_ringparms(), get_fitparms() functions and include the io of the parameter.
   5. Change the code as you like.

   ii) Introducing a new parameter for the second hdu (fit parameters)
   1. The place to add the parameter as a new component is the varlel struct
   2. Add the parameter into the identifyer list: Add the parameter identifyer as the last element in the second PRIMPOS list (before comment ""). Change all numbers in the PRIMPOS list (also after the comment) such that the numbers following the added identifyer are increased by 1. Include the parameter as a symbolic constant in the the _SECPOS list. Increase PRIMHDN_SINGLE symbolic constant by 1 and the SECHDN_MULTI by 1.
   3.  Change the functions primpos_numtype() and primpos_value() hdl_init() by adding the new parameter at exactly the same place that it was added to the identifyer list.
   4. Check the functions get_fitparms(), secpos_value(), fillhdvarele() for a correct handling of the new parameter, best by simply copying the lines concerning another parameter.
   5. That should be it. The parameter will be read and written and you can do what you like with it.

   iii) Introducing a new parameter for the third hdu
   1. Chose a struct of the four loginf headerinf ringparms and fitparms to include the parameter as a component, most likely to chose is the loginf struct that contains information about io.
   2. Add the parameter into the identifyer list: Add the parameter identifyer as the last element in the first PRIMPOS list (after comment "Third hdu"). Change all numbers in the PRIMPOS list (also after the comment) such that the numbers following the added identifyer are increased by 1. Increase the PRIMHDN_SINGLE symbolic constant by 1. Add in the same way a new identifyer to the _TABNR list and change the constant OUTTABNR
   3. Change the functions primpos_numtype() and primpos_value() hdl_init() by adding the new parameter at exactly the same place that it was added to the identifyer list.
   4. Check the functions prepout(), writeoutput(), open_hdu_3, create_hdu_3(), writeasctable() (Only a suggestion).
   5. Change the code as you like.

   iv) Adding a completely new ring parameter (such as dispersion)
   
   1. The place to add the parameter as a new component is the ringparms struct.
   2. Add the parameter into the identifyer list: Add the parameter identifyer as the last element in the  PXXXXX and XXXXX list. If it is a single parameter, change the NSPARAMS by adding 1, if it is a parameter for all rings, add 1 to the NPARAMS symbolic constant. 
   3.  Change the function hdl_init() by adding the new parameter at exactly the same place that it was added to the identifyer list.
   4. Check the functions dparamtointern(), dinterntoparam(), simpleinterntoglob(), simpleglobtointern(), globtointern(), interntoglob(), changetointern(), get_ringparms(), writeoutarray() for a correct handling of the new parameter. Check the graphics descriptor functions gr_ ...
   5. That should be it. The parameter will be read and written and you can do what you like with it.

   @todo check if the position angle read from dataset is correct
   @todo think about the degrees of freedom at the start of metropolis
   @todo check for memory leakage about line 5000 (varlel ll may not be deallocated properly)
   @todo removed the automatic logfile length control in function open_hdu3() for stability reasons (it doesn't work) This has to be checked.
   @todo Made logfile specification necessary to run tirific, because it doesn't run properly without a logfile. Before searching bugs, check whether the possibility not to have a logfile should be removed entirely.
   @todo Error source sorting the file at the end of histout? Probably not...

   @todo Last change was to include pointsource lists. The next thing
   to do is to get a generic enlargement of possible parameters. This
   will not happen for a while (the reason to write this down
   accurately). The new functions srprep() and srconst() gridpoint()
   that control the generation of a model already contain the
   parameter mode (which might be deleted, because there is a better
   variant). The plan is to run a check on starting time of the
   program, which calculations have to be done at runtime and control
   this by the use of pointers to functions that are in the ringparms
   struct. If e.g. a parameter is constant and will not be changed, a
   whole section of calculation can be omitted. The simplest example
   is the introduction of a vertical height of a disk. Calculations by
   adding something to z in srconst can be omitted, if the user has
   set this value uniformely to 0 and doesn't intend to change the
   height. The idea is to include a pointer to a function in the
   ringparms struct, that points to a function that either does the
   calculations or that does nothing. If now srprep or srconst is
   called, they will use the predefined pointers in a sensible series,
   doing either a calculation or nothing.

   $Source: /Volumes/DATA_J_II/data/CVS/tirific/src/tirific.c,v $
   $Date: 2011/05/10 00:30:16 $
   $Revision: 1.69 $
   $Author: jozsa $
   $Log: tirific.c,v $
   Revision 1.69  2011/05/10 00:30:16  jozsa
   Left work

   Revision 1.68  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.67  2007/08/22 15:58:45  gjozsa
   Left work

   Revision 1.66  2007/03/23 17:21:09  gjozsa
   Changed back the changes from rev. 1.64, instead corrected the gridding: If the velocity increases with channel number, the pa changes by 180 deg w.r.t version pre-1.64, otherways it stays. For post-1.64 one has to change the pa by changing its signum and adding or subtracting 180 deg.

   Revision 1.65  2007/02/23 10:28:10  gjozsa
   BUGFIX in tirout: Works now for TIRACC > 6. Enlargened accuracy in textlog.

   Revision 1.64  2007/01/17 15:54:52  gjozsa
   Changed coordinate system in srconst by mirroring pp[0] to get a right hand coordinate system. In order not to change the pa definition changed the conversion functions interntoglob globtointern etc. Also did some changes to the graphics functions of which I don't know the effect. One can spot the changes via searching for 180.0 and DEGTORAD in the source

   Revision 1.63  2006/12/11 12:42:07  gjozsa
   BUGFIX: removed reading beam from header: too much confusion

   Revision 1.62  2006/11/22 14:16:21  gjozsa
   Bugfix concerning RASH and horizontal/vertical lines

   Revision 1.61  2006/11/10 15:53:10  gjozsa
   minor bugfix

   Revision 1.60  2006/11/09 14:42:55  gjozsa
   minor change

   Revision 1.59  2006/11/08 14:05:03  gjozsa
   included line drawing with keywords GR_VERL_i GR_HORL_i GR_VLVA_i GR_HLVA_i GR_VLCA_i GR_HLCA_i

   Revision 1.58  2006/11/03 12:08:59  gjozsa
   Small bugfix

   Revision 1.57  2006/11/03 10:57:38  gjozsa
   Introduced logarithmic scaling keywords: GR_XLOG, GR_YLOG_i, introduced hms dms for xpos and ypos in graphics output, introduced keywords RFREQ (restfrequency in Hertz) and ITOU (conversion factor from intensity in Jy/squarearcsec in u/squarecentimeter), changed DOUBLE_ACCURACY to 3E-15 to account for near zero events

   Revision 1.56  2006/07/18 09:33:02  gjozsa
   Left work

   Revision 1.55  2006/04/11 11:46:00  gjozsa
   Removed the positive SBR restriction in input

   Revision 1.54  2006/04/06 10:40:25  gjozsa
   Bugfix: Call of engalmod_chflgs() after changing the input cube after chisquare initialisation

   Revision 1.53  2006/04/03 11:47:57  gjozsa
   Left work

   Revision 1.52  2005/10/12 14:50:59  gjozsa
   Not really a Bugfix: Corrected the calculation of the ring normal vector

   Revision 1.51  2005/10/12 09:53:45  gjozsa
   Included Brigg's plots

   Revision 1.50  2005/09/29 17:46:00  gjozsa
   BUGFIX in the golden_section() function: refreshing pointsource lists is a crucial point

   Revision 1.49  2005/08/25 10:15:05  gjozsa
   Slight bug in the plot routines

   Revision 1.48  2005/08/18 13:06:52  gjozsa
   Left work

   Revision 1.47  2005/08/15 13:15:03  gjozsa
   BUGFIX: At 12523, not copying to the par array will result in funny results, when the only output is a .def file. Don't know whether this will cause sequals

   Revision 1.45  2005/07/27 14:27:34  gjozsa
   Again improved the graphics output

   Revision 1.44  2005/07/27 14:01:30  gjozsa
   Improved the graphics output

   Revision 1.43  2005/06/28 13:28:08  gjozsa
   Changed the out of range behaviour in golden_section()

   Revision 1.42  2005/06/24 16:44:51  gjozsa
   added interpolation possibility for the TIRDEF= output, not yet for TIRSMOOTH=

   Revision 1.41  2005/06/24 12:00:30  gjozsa
   Left work

   Revision 1.43  2005/06/17 14:56:45  gjozsa
   Bugfix

   Revision 1.42  2005/06/17 14:50:45  gjozsa
   Bugfix

   Revision 1.41  2005/06/17 14:23:48  gjozsa
   Added penalty for outliers

   Revision 1.40  2005/06/13 10:40:29  gjozsa
   Added possibility just to examine results

   Revision 1.39  2005/06/09 14:07:45  gjozsa
   Left work

   Revision 1.38  2005/06/09 08:22:58  gjozsa
   BUGFIX: Multiple Parameter fitting was not working properly, fixed that

   Revision 1.37  2005/05/25 15:47:39  gjozsa
   Added inclinogram output

   Revision 1.36  2005/05/24 15:59:08  gjozsa
   Added LON and LMV to table output

   Revision 1.34  2005/05/24 10:42:03  gjozsa
   Included graphics

   Revision 1.33  2005/05/03 12:42:18  gjozsa
   Left work

   Revision 1.32  2005/04/28 12:44:44  gjozsa
   bugfix

   Revision 1.31  2005/04/28 10:13:47  gjozsa
   Full introduction of pointsource lists

   Revision 1.28  2005/04/26 11:44:53  gjozsa
   Seems to work

   Revision 1.25  2005/04/20 14:33:39  gjozsa
   bug

   Revision 1.24  2005/04/20 13:26:25  gjozsa
   Left work

   Revision 1.23  2005/04/19 13:58:50  gjozsa
   Left work

   Revision 1.22  2005/04/19 15:29:28  gjozsa
   Finished the output functions

   Revision 1.21  2005/04/19 10:59:13  gjozsa
   Extended the possibilities for the histogram output

   Revision 1.19  2005/04/19 07:44:43  gjozsa
   Left work

   Revision 1.18  2005/04/18 15:53:40  gjozsa
   Added histogram functions

   Revision 1.17  2005/04/18 15:02:02  gjozsa
   Included TIR functions

   Revision 1.16  2005/04/15 15:52:09  gjozsa
   Left work

   Revision 1.15  2005/04/15 15:39:13  gjozsa
   Bugfix: in fct get_ringparms, documented as BUGFIX , in fct decodestring, also reported

   Revision 1.14  2005/04/14 14:26:05  gjozsa
   Left work

   Revision 1.13  2005/04/14 10:32:16  gjozsa
   Left work

   Revision 1.10  2005/04/12 14:54:33  gjozsa
   Changed the character of PARMAX= and PARMIN=

   Revision 1.9  2005/04/11 14:23:37  gjozsa
   Left work

   Revision 1.8  2005/04/08 15:30:40  gjozsa
   Taking into account the whole cube now, no counting for the user

   Revision 1.7  2005/04/08 07:27:44  gjozsa
   Bugfixes

   Revision 1.6  2005/04/08 07:25:59  gjozsa
   Bugfixes

   Revision 1.5  2005/04/07 15:15:16  gjozsa
   Bugfix in galmod(): subring velocity was overwritten by a radius, I hacked a bit, not nic at the moment

   Revision 1.3  2005/04/06 15:46:25  gjozsa
   Bugfixes, included monitoring of golden_section

   Revision 1.2  2005/04/05 16:06:06  gjozsa
   Left work

   Revision 1.1  2005/04/05 11:07:37  gjozsa
   The former tiridev, officially release 1

   Revision 1.41  2005/04/04 08:42:09  gjozsa
   removed bug

   Revision 1.40  2005/04/01 15:31:54  gjozsa
   Introduced writecubup and a lot of debugging, check whether the output is not too large

   Revision 1.39  2005/03/29 15:56:24  gjozsa
   left work

   Revision 1.36  2005/03/25 18:17:20  gjozsa
   Left work

   Revision 1.35  2005/03/23 17:48:49  gjozsa
   Implemented hdu_3 support, seems to work

   Revision 1.32  2005/03/23 13:44:33  gjozsa
   Implemented and tested 2nd hdu i/o

   Revision 1.31  2005/03/22 17:48:07  gjozsa
   Left work

   Revision 1.30  2005/03/21 18:54:17  gjozsa
   Left work

   Revision 1.29  2005/03/19 17:55:52  gjozsa
   Left work

   Revision 1.26  2005/03/17 18:00:50  gjozsa
   Left work

   Revision 1.25  2005/03/16 17:52:00  gjozsa
   Left work

   Revision 1.23  2005/03/15 18:53:08  gjozsa
   Left work

   Revision 1.22  2005/03/15 17:28:59  gjozsa
   Last changes to get a clear program structure, not ideal, but ok. Some debugging, deleting the fortran thingies

   Revision 1.21  2005/03/12 16:48:33  gjozsa
   Removed all clutter from readringparms and associated structs

   Revision 1.19  2005/03/12 13:24:49  gjozsa
   Removed all clutter from hdrinit

   Revision 1.17  2005/03/12 11:37:46  gjozsa
   Rearranged completely galmod, debugged and tested version of new galmod, including convolution routines, changed position angle to angle with respect to minor

   Revision 1.16  2005/03/11 17:45:55  gjozsa
   Left work

   Revision 1.15  2005/03/10 17:56:39  gjozsa
   Left work

   Revision 1.13  2005/03/08 17:55:07  gjozsa
   Left work

   Revision 1.12  2005/03/05 17:56:09  gjozsa
   Left work

   Revision 1.11  2005/03/04 18:13:53  gjozsa
   Left work

   Revision 1.10  2005/03/03 18:00:49  gjozsa
   Left work

   Revision 1.9  2005/03/02 17:56:09  gjozsa
   Left work

   Revision 1.8  2005/03/01 17:46:21  gjozsa
   Left work

   Revision 1.6  2005/02/25 18:13:08  gjozsa
   Left work

   Revision 1.5  2005/02/25 13:34:29  gjozsa
   cube io finished

   Revision 1.4  2005/02/25 11:38:27  gjozsa
   Created a header struct

   Revision 1.3  2005/02/24 17:48:46  gjozsa
   Left work


*/
/* ------------------------------------------------------------ */



/*
               tirific.dc1

Program:       TIRIFIC (Version 1.1)

Purpose:       Fit a tilted-ring model to a datacube

Category:      FITTING

File:          tirific.c

Authors:       Gyula Jozsa
               Franz Kenn
               Tom Oosterloo
               Uli Klein

Tirific is a routine that fits a simple tilted-ring model to a
datacube INSET=. In this description we try to show all aspects of its
functionality, starting with a description how the program generates a
model datacube, how the goodness-of-fit is calculated, and what
possibilities exist to reach a "best-fit" model.

------------------------------------
 Model specification and generation
------------------------------------

As the model generation is a derivate of the gipsy task galmod, we
refer to the description of this task for additional information. We
will point out the differences to this task.

A tirific tilted-ring-model is specified by a set of parameters at
different radii plus a set of global parameters. The number of
parameters belonging to the model is then the number of radii times
the number of parameters that change with radius plus the parameters
that are independent of radius. We call the set of parametes belonging
to a given radius a "ring" to stick to traditional terminology. (In
principle, this is not accurate...). To calculate a model, a number of
subrings with a width RADSEP= (in pixels) is created by interpolation
of the ring-specific parameters. Those subrings will then be modelled
by Monte-Carlo integration as being solid-body-rotators with a certain
orientation to the observer that is determined by position angle and
inclination and then projected on a cube the dimensions of which are
specified by the INSET=. The final step to get a model representing an
observation consists of a convolution with a 3d-gaussian.

Some parameters are being forced to a specific value following common
sense, but this restriction may being taken out in follow-up versions.

The user specifies (unlike galmod) the number of rings NUR= and for
each ring:

-A radius in a list RADI= in arcsec The first radius has to be 0 and
the radii have to be in increasing order. The model will be calculated
for radii roughly in-between the first and the last specified radius.

-The circular velocity in a list VROT= in km/s. Again, we restrict the
first value to be 0.

-The scaleheight in a list Z0= in arcsec, which must be positive or 0.

-The surface brightness in a list SBR= in Jy/(arcsec*arcsec). This is
unlike galmod, where the surface-brightness (or surface-density) is
specific to the HI emission line. The unusual unit has been chosen to
make a simple interchange of input cubes possible.

-The inclination in a list INCL= with respect to the LOS in degrees.

-The position angle in a list PA= in degrees. Contrary to the usual
custom (e.g. galmod), the position angle is defined as the angle
between the N-axis and the minor axis of each ring from N over E. In
comparison to galmod the tirific position angle is thus +90 deg
larger. We prefer this definition as from a position angle of the
minor axis one can estimate wheter a precession is present or not.

-The x RA coordinates in a list XPOS= for central positions of rings
in degree. Again, for portability reasons, we chose a unit not
specific to the actual dataset that is being examined.

-The y DEC coordinates in a list YPOS= for central positions of rings
in degrees.

-The systemic velocities in a list VSYS= in km/s. This should be the
radio velocity, which depends linearly on the frequency. tirific
cannot cope accurately with non-linear scales of the axes. In
principle, this accounts also for the spatial axes. The user has to be
aware of that fact.  Unlike in galmod, XPOS=, YPOS=, VSYS= can change
for each ring.

-The systemic velocities in km/s. This should be the radio velocity,
which depends linearly on the frequency. tirific cannot cope
accurately with non-linear scales of the axes. In principle, this
accounts also for the spatial axes. The user has to be aware of that
fact.  Unlike in galmod, XPOS=, YPOS=, VSYS= can change for each ring.

While galmod gives the possibility to specify a velocity dispersion
for each ring, in the current version of tirific, we allow only for a
global velocity dispersion, enhancing the speed of the program
substantially. Because of this tirific has no subclouds like
galmod. Note that the program code is kept extremely flexible, in
order to have the possibility to re-introduce e.g. a changing velocity
dispersion (See note at the end).

-We introduce a global parameter CONDISP= in km/s, that describes the
global velocity dispersion. A user should be aware that this includes
an instrumental dispersion.

-The second global parameter is the Layer type LAYER= for the vertical
density-distribution. The user can chose between a Gaussian, Sech2,
Exponential, Lorentzian and a Box layer.

-Instead of defining a pointsource surface density like it is present
in galmod, in tirific the constant flux CFLUX= of one pointsource (or
cloud) has to be given in Jy*km/s. Knowing the total flux of the
galaxy, the user can immediately estimate the total number of
pointsources in the final model. We don't allow a varying pointsource
flux specified by the user. When calculating the pointsources for a
subring, however, we will change the cloudflux by a tiny fraction for
flux conservation (to be accurate, the difference between the
user-given value CFLUX= and the actual flux is at most CFLUX= divided
by the (large) number of pointsources in a subring).

After the calculation of a point-source model and a gridding of the
Monte-Carlo pointsources on the model cube (which has the dimensions
of INSET=), the cube will be convolved with a 3d-gaussian, a product
of a 2d-gaussian in the xy-plane, and a 1d gaussian determined by the
CONDISP= velocity dispersion in v-direction. The form of the gaussian
in the x-y-plane is determined by the observational beam. Ususally,
the program is not able to read the parameters describing the (clean)
beam from the INSET= datacube, so the user has to supply them (BMAJ=,
BMIN= in arcsec, BPA= in degrees). Here, the user has to note the
following fact: The actual convolution will be performed with a
gaussian with an extent as defined by the user (or as read from the
dataset). Assuming that the original (not the observed) brightness
distribution consists of pointsources, such, that the pointsource
model is in fact a representation of a possible brightness
distribution, the actual convolution with this gaussian would NOT
represent an observation. This is due to the fact that the applied
form of gridding (we grid a pointsource directly to a single pixel) is
the same as a convolution with a box-function of the size of a
pixel. If one then convolves with a gaussian, the
brightness-distribution is convolved twice, once with a (usually
small) box function, once with a gaussian. This topic is also
mentioned in the description of galmod. If one wants to examine the
apperance of an actual pointsource model in a fake observation this is
an error that has to be corrected for (see galmod description for an
approximation, correctly one would introduce a deconvolution by a
division with a sinc function in fourier space...). However, when
comparing a galaxy HI distribution with a pointsource model, the size
and the distribution of specific HI clouds comes as an incalculable
error. For tirific, we assume the gaseous distribution to be smooth,
justifying a double convolution.

We implemented a convolution routine that is meant to be as fast as
possible. The only possibility to reach the required speed is by
fft-convolution. We use the FFTW library that seems to be the most
flexible and of the highest quality of all free libraries. As the
convolution is the most time-consuming part of the fitting routine (up
to a pointsource-number of a 1.000.000 or so), there are some issues
to be discussed:

The size of the cube plays a great role for the performance. Here are
the simple rules (if you want to calculate many models):

i)   Chose a small INSET= cube, the smaller the better.
ii)  As we employ an FFT convolution the emission should be well inside 
the cube to avoid aliasing. A border of 3 HPBW is ok, but 5 HPBW is good. 
iii) size_in_x, size_in_y, size_in_v should be multiples of 2,3,5, and/or 7.

FFTW comes with a set of fft algorithms, which have to be tested in
view of performance before starting to do ffts over and over
again. This testing needs of course a certain initialisation time. The
more algorithms are tested, the higher is the probability that final
convolutions will be sped up. We introduced the parameter INIMODE= to
let the user control whether he/she prefers a fast initialisation or a
faster fft per iteration. Furthermore we implemented several ways to
perform an actual convolution that are incrementally faster but
consume incrementally memory. This is controlled by the parameter
MEMMODE=.

-----------------------------
 goodness-of-fit calculation
-----------------------------

Tirific calculates the chisquare and with that, the relative
probability of two models.

The chisquare calculation is influenced by the WEIGHT= and the RMS=
parameters.

The usual chisquare calculates with:

chi2 = Sum_i (model(i)-original(i))^2/(sigma(i)^2) 
     = Sum_i (model(i)-original(i))^2/w(i),

where i is an index over all pixels, model is the model cube and
original the original cube and sigma the (pixel dependent) noise.  If
no quantisation noise is assumed, then

sigma(i) = sigma_rms, 

where sigma_rms is the rms noise in the original datacube and asked
for with the parameter RMS= in Jy/beam. As we perform a gaussian
integration, this assumption is not true and we have to set

w(i) = sigma_rms^2+sigma_q^2(i)

The noise sigma_q(i) of a pixel i with n pointsources of total flux
cflux in the unconvolved model cube is given by:

sigma_q(i) = sqrt(n(i))*cflux = sqrt(model(i)/cflux) 
           = sqrt(model(i)*cflux)

If g(i) is the convolving function, then the noise noise(i) in the
convolved map is given by:

noise(i) = (Sum_i g^2(i)*sigma_q^2(i))^0.5 
         = (Sum_i g^2(i)*model(i)*cflux)^0.5

That is equivalent to a convolution with a gaussian of size
sqrt(2)*sigma_gauss in every direction, neglecting
normalisation. Tirific can calculate the weight map:

w(i) = sigma_rms^2+sigma_q^2(i)

To perform a correct chisquare evaluation. It is, however, a bigger
computational effort to do so, and the user might be inclined to
modify the goodness-of-fit evaluation.  With the weight parameter
WEIGHT= the weight map is calculated to:

w(i) = (sigma_rms^2*weight^2+sigma_q^2(i))/weight^2   .

In case of an infinite weight parameter (WEIGHT= 0.0), the weight map
becomes a constant sigma_rms^2. In this case it will not be calculated
leading to a higher speed. If set to 1.0, the correct noise will be
evaluated, including the quantisation noise (which can easily exceed
the rms noise). We kept the parameter from the two discrete cases to
give the user a kind of a weighting scheme at hand. With an increasing
weight parameter, the emphasis will be more and more taken away from
the high-noise (and high emission) regions towards the regions of low
emission.

--------------------
 Fitting procedures
--------------------

Tirific offers two basic modes to find a best-fit model, a Metropolis
Monte-Carlo-Markov-chain algorithm, and a golden-section search
algorithm.  The first can serve for the search of global minima of the
chisquare in parameter-space including a very simple functionality to
perform a simulated annealing. Furthermore it can possibly provide
statistical errorbars for the model. While it works the way as
described below, we haven't yet tested, whether it brings the desired
results. The second algorithm is a tested golden-section method to
find local (and, hopefully, global) minima. The user decides which one
to use by setting the FITMODE= parameter.

Metropolis algorithm and simulated annealing
--------------------------------------------

The Metropolis algorithm is described by Koonin & Meredith (1990,
p.210), further information can be found in Press et al. (1987).

The implemented version works in a very simple way:

1. A first model is calculated, parameters given by the user (see
above)

2. A trial model is calculated from the previous model, each parameter
is being varied randomly within a given interval (Keywords MODERATE=,
DELSTART=, and DELEND=, see below).

3. If the chisquare chi_trial of the trial model is lower than the
chisquare chi_bef of the previous model and if is inside a
user-given range (Keywords MODERATE=, PARMAX=, and PARMIN=, see
below), it will be accepted as the next model. If it is not better,
then the trial model will be accepted as the next model with a
probability

p = exp((chi_bef-chi_trial)/2*ann)

(ann is provided by the user with the keywords MODERATE=,
ANSTART=, and ANEND=, see below)

4. If the trial model is accepted, it is written to a list and it
becomes the previous model in the next step. If it is not accepted,
the previous model will stay the previous model in the next iteration
and will be written to the list.

It can be shown (Koonin & Mederith 1990) that after a sufficient
number of iterations, this Markov chain converges, and the parameters
in the list are distributed like

exp(-chisquare/(2*ann))

This means that (especially with ann = 1) after a number of steps this
very simple analysis can provide the user with a set of models that
are distributed following a statistics that relates the chisquare to
the probability of the models (see Press et al. 1987, chap. 14.1)
without having to know the distribution itself. The implemented
algorithm can be used for two purposes. One is to derive a
statistically distributed sample of models (which it should do, in
theory). With that it is easy to derive errorbars. The sample of
models has to be sorted by probability (chisquare), and then the
variance of the parameters is e.g. given by the 68.26 best-fitting
percent (see keyword FRACTION=) of the models. Tirific provides the
possibility to perform this analysis (Parameters TABLE=, FRACTION=,
see below).

The second possibility that tirific provides is a very simple version
of simulated annealing (See Press et al. 1987, chap. 10.9). When
starting the program, the factor ann will be varied linearly
in-between the user-given ANSTART= and ANEND= within a number of steps
given by ANSTEPS=. The user has thus the possibility to "cool" his
system of models (or to heaten it), while the possibility to vary the
energy input is given, too (by variation of the maximum stepwidth with
keywords MODERATE=, DELSTART=, and DELEND=, see below). The algorithm
can thus be used for a global minimum search. A schedule for such a
search would look like this: At the start, set the stepwidth and the
annealing factor to higher values. The models will then vary in a wide
range in parameter space. With cooling, i.e. reducing the ann factor,
and at the same time lowering the energy input, i.e. reducing the
stepwidth, the system will be forced to more and more relax at a
global minimum.

With the parameter LOOPS= the user specifies how many models will be
calculated and written in a list.

The functionality of both possibilities of the Metropolis algorithm
and the simulated annealing has not been tested sufficiently and it
may be necessary to implement more sophisticated versions. The success
of these algorithms depends critically on the number of models
required to form a statistical sample and at the moment we don't have
any experience yet other than that a really low stepwidth is
required. With a small stepwidth the quantisation noise becomes
important, and may play the dominant role, forcing the user to use a
lower pointsource flux, which in turn slows down the algorithm.

Golden Section algorithm
------------------------

The golden section algorithm (see Press et al. 1987, chap. 10.1) is a
simple way to find a local minimum in parameter space. Sequentially
each specified parameter undergoes a nested intervals process
minimising the chisquare (A whole series of iteration processes for
all specified parameters is being referred to as a loop). The
stepwidth is varied by changing the search direction and/or
multiplication with a factor. With

w = (3-sqrt(5))/2, 

this factor is given by 

(1-w)/w 

when enlargening the stepwidth or by 

w/(1-w) = 0.6180339887498948

to reduce the stepwidth. The start point for the variation is
controlled by the parameters MODERATE=, DELSTART=, and DELEND=. The
user has certain possibilities to interrupt the iteration
process. First, the user specifies the maximum number of steps to take
in the nested intervals process (Parameters MODERATE=, ITESTART=,
ITEEND=). Second, the user specifies a minimum stepwidth MINDELTA= at
which the process is to be interrupted. 

At the end of each iterative process, tirific checks, whether it is
still "satisfied" with the results. Tirific won't be satisfied, if it
wasn't before. If is was satisfied, it will stay so, if 
i)   it hasn't reached the maximum number of iterations, 
ii)  it hasn't reached a parameter maximum or minimum, 
iii) the parameter hasn't changed by more than an absolute value SATDELT= 
with respect to it's value at the start of the iterative process.
iv)  With the parameters PARMAX= and PARMIN= the user tells tirific to 
reject the algorithm results if the parameter gets out of the range 
in-between PARMAX= and PARMIN=. In that case it will also switch from 
being satisfied to not satisfied.
If tirific encounters a situation where at the end of a loop it is
still satisfied, tirific stops. If it is not satisfied, the
satisfaction flag will be set to "satisfied", and a new loop is
started, until the number LOOPS= of loops is reached or until tirific
is satisfied at the end of a loop.

-----------------------------------------------------------------
 How to specify the parameters that vary, and how to specify the
 parameters that control the fit mechanism
-----------------------------------------------------------------

The parameter lists VARYMULT= and VARYSING= give the user the
possibility to specify parameters and groups of paramters that are to
be varied in both fitting processes. The syntax for the input is as
follows:

The user defines a group of parameters by specifying first a parameter
name as in the input of tirific. If the user wants to vary a rotation
velocity, he/she types VROT as a first argument to VARYMULT= or
VARYSING=. This name is followed by a specification of ring-numbers
(starting with 1), for which the parameter(s) shall be varied. The
user can specify a series of single numbers, a range between
ringnumbers a and b (including a and b) by using colons a:b, a range
from the first ring to a with :a, a range from b to the last ring with
:b, and all rings with not specifying anything. This first group can
be followed by a further groups by typing a new parameter name. NOTE
that tirific doesn't recognise redundancies. Specifying e.g. VROT 2: 3
would mean that the circular velocity of ring 2 will be varied twice,
the same accounts for e.g. VROT VROT 2. With VARYMULT= the user
specifies a list of parameters that are being varied each. So, for a
specification VARYMULT= VROT 2 3, the circular velocity of ring 2 will
be varied independently from the circular velocity of ring 3 (while
they will have the same (start) values for the stepwidth). With
VARYSING= the user specifies groups of parameters that are varied as
one unit, a variation of one parameter in the group will be a
variation of the other one in the group in each iteration step. For
instance, VARYSING= VSYS means that the systemic velocity will always
be changed for all rings with the same amount. So, if the user wants
to produce a classic tilted-ring model, in which all rings have the
same centre, that nevertheless shall be fitted, the user will define
it with the VARYSING= XPOS YPOS. If the user wants to fit two disks
with different centres, he/she specifies VARYSING= XPOS 1:3 XPOS 4:
YPOS 1:3 YPOS 4: (which is NOT the same as XPOS 1:3 4: which would be
equivalent to XPOS 1: or XPOS)
 
In the golden-section algorithm the order of the input to VARYSING=
and VARYMULT= plays a role. First, the parameters given in VARYMULT=
are fitted in the order as they are given, then the parameter groups
of VARYSING=.

Depending on the algorithm chosen, additionally to the parameter
groups, for each group a series of parameters have to be given that
specifies the fitting process. They have to be given in the same order
as the VARYMULT, and then the VARYSING parameter groups. PARMAX= and
PARMIN= are the parameter maxima/minima that are allowed (it makes
e.g. sense to specify a PARMIN=0 for SBR=).

For the Metropolis mode: 

For MODERATE= models (loops) the maximum variation of the parameter is
interpolated linearly in-between DELSTART= and DELEND= For the first
model the absolute maximum stepwidth is given by DELSTART= and for the
MODERATE+1st loop it will have a value DELEND=. This can be used for a
simulated annealing.

For the Golden-Section mode:

The start stepwidth for each nested intervals process is varied
linearly in-between DELSTART= and DELEND= for MODERATE= loops. For the
first loop it will have the value of DELSTART= and with the
MODERATE+1st loop it will reach a value of DELEND=. The maximum number
of iterations for each iteration process is varied in the same way
in-between ITESTART= and ITEEND=. SATDELT= is the tolerance with which
tirific will stay satisfied after an iterative process. If after an
iterative process the difference between the start- and the endvalue
of a parameter (group) is beyond this value, the satisfaction flag
will be put to "not satisfied (see above). With MINDELTA= the user
gives the minimum delta, at which the iteration is interrupted. A
model will not be calculated anymore, if the stepwidth reaches
MINDELTA=.

------------ 
Input/Output 
------------ 

The user specifies an INSET= within a BOX=, to wich the model will be
fitted. At the same time the INSET= is a template for the OUTSET=, the

model cube, which doesn't have to be specified. The OUTSET= will be
updated i) in case of FITMODE= 0 (Metropolis) each OUTCUBUP=th
loop/model ii) in case of FITMODE= 1 each OUTCUBUP=th golden-section
process (A loop in the case of the golden-section mode contains lots
of models).  Of great importance is the specification of a logfile, in
which the whole fitting process will be recorded. The logfile is a
fits-table, which enables the user to interrupt the fitting process at
any time without the loss of many data (there are cases, where
something will get lost due to the specific structure of fits files,
but not excessively so). The specification of the logfile name
LOGNAME= is necessary. The TEXTLOG= file is an ascii file in which
tirific may record an ascii version of the logfile without containing
a complete information. With specifying a TABLE= ascii file, the user
produces the currently single output of tirific, an ascii table
containing the resulting set of parameters. It contains all parameters
including those that are not fitted in tabulated form. Furthermore,
the table contains various outputs for the radius and the
surface-brightness, as well as for orientational parameters of the
disk: Radii are given additionally in kpc using a simple conversion in
dependence of the parameter DISTANCE=, the distance of the object in
Mpc. The surface brightness is converted to atoms per cm^2 and solar
masses per pc^2, assuming that an HI disk has been fitted. Here, and
in no other place, a rough relativistic correction of the
surface-density takes place in dependence on the recession velocity of
the ring (VSYS). The next two columns show a warp angle. For each
radius, the inclination of the actual ring is listed in degrees, i)
with respect to a user-given reference ring (keyword REFRING=,
defaults to 5) listed as WA_old, ii) with respect to a ring that
rotates with the total angular modemtum of the fitted component. The
last eight columns give the position of the line-of-nodes and the line
of extreme velocities. In that order: LON_ASC_RA (deg): right
ascension of the ascending node, LON_ASC_DEC (deg): declination of the
ascending node, LON_DSC_RA (deg): right ascension of the descending
node, LON_DSC_DEC (deg): declination of the descending node,
LMV_APP_RA (deg): right ascension of the approaching point of extreme
velocity, LMV_APP_DEC (deg): declination of the approaching point of
extreme velocity, LMV_REC_RA (deg) right ascension of the approaching
point of extreme velocity, LMV_REC_DEC (deg) declination of the
receding point of extreme velocity.  For the Metropolis mode: If the
number of loops exceeds ANSTEPS=, the logfile will be sorted with
respect to the chisquare from the ANSTEPS=th+1st iteration to the
end. Then a fraction FRACTION= of the best-fit models will be selected
of which the maximum and the minimum of each parameter determines the
best fit value (the mean) and it's errors (the width in-between the
extreme parameters).  If the number of loops is lower than ANSTEPS=,
then simply the parameters of the best-fit model will be
listed. Errors have no meaning.  For the golden-section mode: The
best-fit-model will be listed, errors have no meaning.
 
 Monitoring:
------------
 
The excessive monitoring function of tirific reports the current
process by writing a line to the prompt each time a model is being
calculated. The meaning of the shortcuts is:

Metropolis mode:
  TM:          Total model number
  NP:          Number of pointsources in current trial model
  TF:          Total flux
  CC:          Current accepted chisquare
  PR:          Probability of trial model
  SW:          Current maximum stepwidth
  AC:          Acceptance flag: Trial model accepted: 1 Not accepted: 0
  RA:          Out of range flag, 1: A parameter was out of range, 
               0: everything ok
  AN:          Current annealing factor                                

Golden-section mode:
SM/FM:       Searching/Found Minimum
   BL:       Loop number
   KL:       Total number of iteration processes
   TM:       Total number of models since restarting tirific
   KW:       Parameter name of current fitting process 
   FR:       First ringnumber in a group
   KM:       Iterations in this iterative process/Maximum number of 
             iterations for this process
   NP:       Number of pointsources of a trial model
   TF:       Total flux of trial model in Jy km/s
   CC:       Current minimum chisquare
   DC:       Difference between trial model chisquare and current minimum
   SW:       Current stepwidth/Start stepwidth
   AC:       Satisfaction flag: 1: satisfied, 0: not satisfied      
             
------------------
restarting tirific
------------------

With it's logfile, tirific will remember most of the user input from
previous times tirific has been started. If the current input in a
tirific.def file differs from former inputs, tirific will prompt the
user how to proceed. If changes are applied, the logfile will be
changed, and the former input will be forgotten. In extreme cases, a
lot of the contents of a logfile will be deleted. If run for a long
time, the user should be aware that there is a risk of overwriting a
file if giving the wrong command. However, with the possibility of
remembering input, the user can restart tirific with a lot less input
than has to be given when starting tirific for the first time. The
only input that has to be given each time when tirific is being
started is LOGNAME= INSET= BOX= OKAY=Y (when overwriting an output
cube), everything else is stored in the logfile.

--------------------------
 Analysis and help output
--------------------------
Tirific offers a small amount of Analysis tools. These are accessed 
by hidden keywords. If you don't give a value, the output will not
take place. No keywords concerning analysis output and analysis tools
 are stored in the logfile. They have to be given each time, tirific
is being started (with the result that the user won't be asked any time
he changes parameters.

COOLGAL
-------
If the keyword COOLGAL= is set, tirific produces a 3d-cube of the 
best-fit model that can be revied with graphic tools (we recommend 
the xray tool of the Karma software package). The format of the cube
is fits. The cube is produced in the same way as model cubes with the
difference that it is a projection on three spatial dimensions. The 
user has the possibility to specify a gaussian convolution kernel with
the keyword COOLBEAM= (HPBW units is arcsec). This defaults to the
major axis beam. If set to 0, no convolution will take place.

BIGTABLE
--------
The structure of the file BIGTABLE= is the same as of TABLE= and the
same DISTANCE= and REFRING= keyword is used. But the output table
doesn't contain the paramtetrisation of the rings of the result, but
of all subrings. This is hence the "true" tilted-ring model, because
each row contains the description of a solid-body rotator.

TIRDEF
------

If the keyword TIRDEF= is set, tirific will output a file with that
name which contains the complete input, except for the tilted-ring
parameters. Those will be substituted with the results. With TIRACC=
the floating point accuracy of that output is specified, global
spatial coordinates (right ascension and declination) having a 3 times
higher accuracy. The file with the name TIRSMO= will contain the same
output, but the output values are median-filtered with a filter length
of TIRLEN= rings. This is sometimes useful, if you want to modify the
results of a previous run.

HISNAME
-------

If the keyword HISNAME= is set, tirific will produce a 1d- or 2d-
histogram of the tabulated models with the name HISNAME=. This makes
sense especially for a chosen FITMODE= 0 (Metropolis). In principle,
after the annealing is finished, a histogram will resemble the
probability distribution of the models, Hence, gaussianity and
correlation of parameters can be checked with this functionality.

The histogram (fits format) will be carried out in-between HISTARTROW=
and HISTENDROW=. As the logfile contains as a first item the input
parameters, the number of the first row in the table is 0. With
HISKEY1= (defaults to VROT) and HISRING1= (defaults to 1), the
parameter belonging to one axis of the histogram is specified. In
addition to the input parameter names , the user can give: CHISQ, the
tabulated chisquare, RCHISQ, the tabulated reduced chisquare, LOOPNR,
the loop number, ACCEPT, the acceptance flag (for metropolis mode: 1
if this is an accepted trial model, 0 if the trial model has not been
accepted).  If a second parameter is specified with the keywords
HISKEY2= (defaults to VROT) and HISRING2= (defaults to 1), a 2d
histogram will be produced, otherways a normal histogram of one
parameter. It will, however, have two identical rows in order to be
able to visualise it with the Karma software.  For each parameter or
axis i, a minimum HISMINi= and a maximum HISMAXi= can be
specified. Only values in-between those are taken into account. If
HISMAXi= is less than HISMINi= (the default), minimum and maximum are
calculated by tirific. The binsize is dictated by specifying the
number of bins with HISBINSi=. The binsize will be calculated to
produce HISBINSi= bins. Only if HISBINS= 0 or if the maximum and the
minimum is eqal for a parameter, the user has to specify HISDELTAi=,
the bin size, from which the number of bins will then be calculated.

RECT
----
If RECT= is set, an output file with that name will be produced that
can be used as a .def file for the gipsy task rectify. Note that the
output does not resemble the model that tirific uses, for two
reasons. Rectify's tilted-ring model is a simpler version than the one
used in tirific. The centre of the rings in Rectify is a common centre
to all rings. Therefore, the RECT= output contains only one central
position: the centre of the first ring. Second, rectify has no
interpolation method to interpolate over rings. A correct rectify.def
file that (provided all rings have a common centre) produces the
correct output can be produced with BIGRECT=. Here, the parameters of
the subrings will be put.

TILT
----
If TILT= is specified, tirific will produce a so-called "Tiltogram" in
fits-format. This is a threedimensional diagram in which for each ring
the inclination (or tilt) with respect to another ring is
shown (in degrees). As the specified radii at which the rings are specified,
the axis scaling might be inaccurate. This is not the case for
BIGTILT=, the same diagram for the subrings (which have always the
same width).

INCLINO
-------
If INCLINO= is specified, tirific will produce a fits file with that
name, that contains a cube with the number of rings as the number of
planes. In each plane the corresponding projected ring is represented
as an ellipse. Inside the ellipses, the cube has a value of 1, 0
outside. If one plots a Renzogram with such a file, the projected
ellipses corresponding to each ring can be visualised. The parameter
IN_REFINE= is a positive integer, with which the pixelsize of the
INCLINO= output can be influenced. If set to 1, the pixelsize of the
output equals the pixelsize of the input. If set to 5, the pixelsize
of the output is one fifth the pixelsize of the input.

GRAPHICS
--------
Tirific possesses the possibilities for a simple graphics output. The
graphics are implemented with the pgplot library. Depending on the
installation of this library a number of graphics devices can be
chosen to plot on. With specifying GR_DEVICE= as a pgplot device,
e.g. /xwindow, tirific will generate a plot containing the best-fit
parameters. While tirific tries to generate a proper format,
formatting will fail in some cases. With the parameters GR_MR= and
GR_ML= the user specifies a margin between the right and left border
of the plot and the axis description. The parameter GR_TXHT= specifies
the height of text in the plot including numbers in pgplot
units. GR_SBHT specifies the height of symbols (dots) in the plot
relative to the height of GR_TXHT=. If GR_LGND= is not set to 0, a
legend will be generated explaining the abbreviated axis labelling. As
a default, tirific will plot the real best-fit function, i.e., for
every subring tirific plots a bar of width given by RADSEP=. This can
be turned off by specifying GR_SBRP= 0. The user gives then a number
of parameters for which the best-fit values are to be plotted with the
parameter GR_PARMS= The first specified parameter is the parameter
that will be plotted on the x-axis. Consecutive parameters will be
plotted in a series of single graphs that share the x-axis. The names
of the parameters are as in the specification of the tilted-ring
model. Additionally the user can chose to set DENS to plot the
surface-density in different units than if SBR is specified. If WA is
specified, tirific will plot the warp angle with respect to a ring
that contains the total angular momentum of an observed disk. If WOLD
is specified, tirific plots the warping angle with respect to the ring
specified by REFRING= (s.a.). As an alternative unit differing from
arcse for the radius tirific will always give a kpc scale above the
plot, which scales according to the DISTANCE= parameter (in Mpc). The
minimum and the maximum of the x-axis are chosen by tirific to contain
all best-fit parameters, but these values can be changed by setting
the parameters GR_XMIN= and GR_XMAX. Each plot can now accessed with
parameters that are specified with an index i that is the number of
the plot.  For each viewgraph the user specifies the colour with
GR_COL_i=. The user decides whether to draw lines in-between the
points by setting GR_LINES_i= to a value differing from 0. If
errorbars are to be generated, the use has to set GR_ERRB_i= to a
value differing from 0. Also, for each viewgraph, the user may specify
the minimum of the y axis by setting GR_YMIN_i= and GR_YMAX_i=.  The
default is to generate a plot that contains all best-fit points and
the additional user-defined points (s.b.). In addition too plot the
best-fit-points the user has the possibility to overplot a series of
points. The number of points are given with GR_NPAD_i=, the points
themself are given by GR_XPAD_i= (x-axis), GR_YPAD_i=
(y-axis). GR_ERAD_i= specifies if errorbars of each point should bee
plotted, with GR_EBAD_i= the user defines those errorbars (for y axis
only in this version). With GR_COAD_i= the user defines the colour of
the adddditional points, with GR_LIAD_i= set, lines will be plotted
in-between the user-defined points.

Keywords:

   INSET=      Give input set and subsets:

               Input set, no default

   BOX=        Give area of operation: [whole dataset]

               Resize the INPUT by entering a box. The default is
               the entire set as selected by INSET= and the box
               values cannot exceed the limits of INSET=

   OUTSET=     Give output set [no output set]:
               
               The output set has the dimensions of the inset
               (rezised by BOX=). If specified, the outset will
               contain a model datacube. If not specified (left
               blank), no output set will be produced.

  [OUTCUBUP=]  Give update frequency of model output [1000000]:

               The frequency with which the OUTSET will be
               recreated. Every OUTCUBUPth loop the OUTSET will be
               recreated with the actual model
           
  LOGNAME=     Give logfile name: [no default]

               In a logfile the whole fitting process and most of the
               input parameters and the results are stored. When
               interruting tirific and restarting it, tirific
               recovers the information of the current status of the
               fitting process from the logfile. This accounts for all
               kinds of interrupts (except a headcrash of the disk).

  [TEXTLOG=]   Give text logfile name: [no text logfile]

               The text logfile contains a part of the information
               that is contained in the (binary) logfile. If you want
               to control the fitting process you may want to
               generate a text logfile. If a file with the given name
               exists, the information will be attached.

  [TABLE=]     Give output table name: [no output table]

               Contains the results of the fitting process in an
               ASCII table suitable for the use in plotting programs,
               such as SM. If a file with the given name
               exists, the information will be attached.

  [DISTANCE=]  Give distance of object in Mpc: [10]
               
               For the use of the calculation of the output table

  [REFRING=]   Give reference ring: [5]

               The reference ring for the column containing the warp
               angle in TABLE

  [FRACTION=]  Give fraction to calculate errorbars. [0.6828]

               If FITMODE= is set to 0 (Metropolis), then, if the
               number of LOOPS= exceeds the number of ANSTEPS, the
               best-fit value will be calculated by sorting the
               model list with respect to the chisquare after ANSTEPS=
               models, and rejecting a fraction of FRACTION=
               models. The worst models are being rejected. Errorbars 
               and best-fit values are calculated by evaluating the
               minimum and the maximum for each parameter of the
               remaining models. 

 [BIGTABLE=]   Give big table name [No bigtable]:

               If specified, a large table like TABLE= will be
               produced, which doesn't contain the parameters for the
               rings, but for the subrings. If a file with the given name
               exists, the information will be attached.

 [TIRDEF=]     Give a .def file name for best results output

               A .def file for tirific that reproduces all input, but
               instead of the input model parameters it contains the
               results. If a file with the given name exists, it will 
               be overwritten.

 [TIRSMO=]     Give a file name for smoothed results output

               A .def file for tirific as TIRDEF=, but the results
               are median filtered over TIRLEN= rings. If a file with
               the given name exists, it will be overwritten.

 [TIRACC=]     Give accuracy of def file output [2]:

               Floating point accuracy of the output for TIRSMO= and
               TIRDEF=. global spatial coordinates (right ascension
               and declination) having a 3 times higher accuracy

 [TIRLEN=]     Give length of smoothing kernel [3]:
               
               The parameter output of TIRSMO= is median filtered
               over a length of TIRLEN= rings

 [HISNAME=]    Give a filename for a histogram: [No historgram]

               Name of a fits output file containing a histogram of
               the table in the logfile. If a fits file with the given
               name exists, the histogram will be attached as an
               extension.

 [HISTARTROW=] Give start row for histogram: [1]

               Start row for the histogram. The first row contains
               the input parameters and is row 0.

 [HISTENDROW=] Give end row for histogram: [Last row]

               End row for the calculation of the histogram.

 [HISKEY1=]    Give first keyword for histogram: [VROT]

               Give a keyword for the parameter as in the input,
               e.g. VROT. In addition to the input parameter names ,
               the user can give: CHISQ, the tabulated chisquare,
               RCHISQ, the tabulated reduced chisquare, LOOPNR, the
               loop number, ACCEPT, the acceptance flag (for
               metropolis mode: 1 if this is an accepted trial model,
               0 if the trial model has not been accepted).

 [HISRING1=]   Give ringnumber 1 for histogram: [1]

               The number of the ring to be examined in the histogram

 [HISMIN1=]    Give minimum of key 1 for histogram [1.0]

               Minimum to be accepted for the calculation of the
               histogram, first parameter. If HISMAX1= is less than
               HISMIN1=, minimum and maximum are calculated from the
               content of the table.

 [HISMAX1=]    Give maximum of key 1 for histogram [-1.0]

               Maximum to be accepted for the calculation of the
               histogram, first parameter. If HISMAX1= is less than
               HISMIN1=, minimum and maximum are calculated from the
               content of the table.

 [HISBINS1=]   Give number of bins for key 1 of histogram [100]

               Number of bins for the axis of the first parameter in
               the histogram. If set to 0, this number will be
               calculated from HISDELTA1=.

 [HISDELTA1=]  Give bin size for key 1 of histogram [0.1]

               If HISBINS1= 0 or if the minimum equals the maximum
               for the specified first parameter, the binsize has to
               be specified here.

 [HISKEY2=]    Give second keyword for histogram

               Give a keyword for the second parameter as in the
               input, e.g. VROT. If specified, a 2d histogram will be
               carried out, if not a 1d histogram for the first
               paramter. In addition to the input parameter names ,
               the user can give: CHISQ, the tabulated chisquare,
               RCHISQ, the tabulated reduced chisquare, LOOPNR, the
               loop number, ACCEPT, the acceptance flag (for
               metropolis mode: 1 if this is an accepted trial model,
               0 if the trial model has not been accepted).

 [HISRING2=]   Give ringnumber 2 for histogram [1]

               The number of the ring to be examined in the histogram

 [HISMIN2=]    Give minimum of key 2 for histogram

               Minimum to be accepted for the calculation of the
               histogram, second parameter. If HISMAX1= is less than
               HISMIN1=, minimum and maximum are calculated from the
               content of the table.

 [HISMAX2=]    Give maximum of key 2 for histogram

               Maximum to be accepted for the calculation of the
               histogram, second parameter. If HISMAX1= is less than
               HISMIN1=, minimum and maximum are calculated from the
               content of the table.

 [HISBINS2=]   Give number of bins for key 2 of histogram [100]

               Number of bins for the axis of the second parameter in
               the histogram. If set to 0, this number will be
               calculated from HISDELTA2=.

 [HISDELTA2=]  Give bin size for key 1 of histogram [0.1]

               If HISBINS2= 0 or if  the minimum equals the maximum
               for the specified second parameter, the binsize has to
               be specified here.

 [RECT=]       Give a filename for a rectify output [no output]

               If set, tirific produces a suitable rectify.def file
               with the given name and the number of rings as input
               rings are given minus one. An existing file with the
               given name will be overwritten.

 [BIGRECT=]    Give a filename for a big rectify output [no output]

               If set, tirific produces a suitable rectify.def file
               with the given name and a number of rings as is the
               number of subrings of the result of the fitting in
               tirific. An existing file with the given name will be
               overwritten.

 [TILT=]       Give a filename for a tiltogram output: [No tiltogram]

               If TILT= is specified, tirific will produce a
               so-called "Tiltogram" in fits-format, showing the
               inclination of each ring with respect to every other
               ring. An existing file with the given name will be
               overwritten.

 [BIGTILT=]    Give a filename for a big tiltogram output: [No tiltogram]

               If BIGTILT= is specified, tirific will produce a
               so-called "Tiltogram" in fits-format, showing the
               inclination of each subring with respect to every other
               subring. An existing file with the given name will be
               overwritten.

  BMIN=        Beam major axis in arcsec:

               In the case that  this value cannot be read from the
               dataset, the user will be prompted to provide it
               manually.

  BMAJ=        Beam minor axis in arcsec:

               In the case that  this value cannot be read from the
               dataset, the user will be prompted to provide it
               manually.
         
  BPA=         Beam position angle in degrees:
         
               In the case that  this value cannot be read from the
               dataset, the user will be prompted to provide it
               manually.
         
  RMS=         Give sigma_rms for input map in map units. (Jy/beam)"):
         
               In the case that  this value cannot be read from the
               dataset, the user will be prompted to provide it
               manually.
          
  NUR=         Give number of rings:
         
               Specify the number of rings.
         
  RADI=        Give radii of rings (arcsec):

               Specify the radius of each ring. The first radius has
               to be 0.
         
  VROT=        Give circular velocities. (km/s):
         
               Specify the circular velocity of each ring. The first
               velocity has to be 0.
         
  Z0=          Give scaleheight of rings. (arcsec):
         
               Specify the scaleheight of each ring.
           
  LTYPE=       Give type of layer. [list options]
         
               Specify the global layer type.
         
               1 -- Gaussian layer
               2 -- Sech2 layer
               3 -- Exponential layer
               4 -- Lorentzian layer
               5 -- Box layer

  SBR=         Give surface-brightness of rings. (Jy/(arcsec*arcsec)):
         
               Specify the surface-brightness of each ring.
           
  INCL=        Give inclinations of rings. (degree):
         
               Specify the inclination of each ring.
           
  PA=          Give position angles of rings (minor axis). (degree):
         
               Contrary to the usual custom inside GIPSY, the position
               angle is defined as the angle between the N-axis and
               the minor axis of each ring from N over E. In
               comparison to galmod this is +90 deg.
           
  XPOS=        Give x coordinates for central positions of
               rings. (degree):
         
               Specifyabsolute center coordinates of x axis (J2000,
               RA) in deg foreach ring.
           
  YPOS=        Give y coordinates for central positions of
               rings. (degree):

               Specify absolute center coordinates of y axis (J2000,
               DEC) in deg for each ring.
  
  VSYS=        Give systemic velocities of rings in (km/s):

               Specify the systemic velocity of each ring.
   
  CONDISP=     Give global velicity dipersion (km/s):

               Specify the global velocity dispersion. While (at the
               moment) no velocity dispersion for each ring is
               foreseen, before chisquare evaluation the artificial
               cube containing pointsources will be convolved in
               v-direction with the given global dispersion. (The
               spatial convolution is defined by the beam
               parameters). Note that while a gridding already is a
               convolution with a box function, no correction for this
               will be made.

  CFLUX=       Cloud flux in (Jy*km/s): [1E-5]

               Specify the total flux of a cloud in the pointsource
               model. The number of clouds that is used for the model
               is then the total flux of the model divided by this value.

  WEIGHT=      Give noise weighting (0.0 means inf). [1.0]

               The calculation of the chisquare can take into account the
               quantisation noise. For a pixel in the model cube
               (unconvolved), the noise is given by the square root of
               the number of the pointsources in the pixel times the
               flux of a pointsource. One can calculate the
               quantisation noise in the convolved cube then. Usually
               the weight to calculate the contribution of one
               pixel to the chisquare is:

               1/(sigma_rms^2+sigma_quant^2), 

               where sigma_rms is the noise in the original datacube
               and sigma_quant is the quantisation noise. With this
               parameter the weight is changed to

               weight^2/((sigma_rms*weight)^2+sigma_quant^2)

               While not being exact, the user has thus the
               possibility to influence the weight of areas of
               different surface brightness to the chisquare evaluation. 
               A value of 1 will cause a downweighting of areas with high
               surface brightness. A value of infinity (0) puts the weight 
               on high surface-brightness regions. A value of 0 will speed
               up the calculation substantially.
  
  [RADSEP=]    Give subring width (grids): [0.75]

               The user can specify the width of subrings (see galmod
               documentation). While the model will get smoother with
               lower values, the routine becomes slower.

  MEMMODE=     Give memory consumption mode. [list options]

               Specify how much memory tirific should try to consume
               to get faster. 0 is the slowest but least memory consuming
               mode, 3 is the fastest mode that needs quite some memory.
               tirific will automatically correct down a too high value.

  INIMODE=     Give initialisation time 0 short, 3 long [1]:

               A short initialisation will result in a longer
               calculation time for each model and vice versa. If you
               expect to calculate lots of models without having to
               interrupt the calculation many times, a long
               initialisation is recommended.
  
  ISEED2=      Give one integer to initialize RNG. [1803]:

               Initialisator for one of the random generators that are
               used in this program.

  FITMODE=     Give fitting mode 0: annealing, 1: golden section [0]:

               The user has the possibility to perform two kinds of
               fitting (see below), a simulated annealing or
               metropolis algorithm to find global minima, and a
               golden section method to find local (and hopefully
               global) xhisquare minima in the parameter space.
  
  LOOPS=       Give number of loops to process. [500000]");
  
               The maximum number of loops that tirific is run. In
               the case of FITMODE= 0 (Metropolis) that is the exact
               number of calculated models. In the case of FITMODE= 1
               (golden section) one loop is the complete performance
               of a nested intervals chisquare minimization for one
               group of parameters.

  ANSTEPS=     Give number of annealing steps [0]:

               The simulated annealing in this module is very
               simple. The relative probability of two models 1 and 2 is given
               by:
        
               exp((chisquare2 - chisquare1)/(2*anneal))

               A new model will be accepted with this probability (not
               exact but short). If anneal is high, the probability of
               acceptance is high. In this task one can vary the value
               of anneal from a value ANSTART to ANEND within ANSTEPS
               loops.  The actual anneal of a loop is calculated by a
               simple interpolation. This parameter will not be asked
               for in case of FITMODE= 1 (golden section).

  ANSTART=     Give start annealing factor. [1]:

               The anneal factor (see keyword ANSTEPS or below) with
               which the modelling starts.

  ANEND=       Give end annealing factor. [1]:

               The anneal factor (see keyword ANSTEPS or below)
               reached after ANSTEPS loops.


  ISEED=       Give two integers to initialize RNG. [1802 9373]:

               Initialisators for the second of the random generators
               that are used in this program.

  VARYMULT=    Parameters to be varied for each ring

               The user specifies a group of parameters by the
               parameter name (as defined above) followed by ring
               numbers (starting with 1), specifying as many
               parameters as there are specified rings. Each of those
               parameters will be varied seperately in the fitting
               process.  The syntax is best demonstrated with
               examples. For a model with 6 rings, with

               VARYMULT= VROT 2: VSYS 5 1:3 PA INCL 6 :3

               results in parameters that will be varied seperately:
               rotational velocities of rings 2-6
               systemic velocities of rings 1-3 and 5
               position angles of rings 1-6
               inclinations of rings 1-3 and 6
       
               VARYMULT= VROT 2:

               is equivalent to (see below)
               VARYSING= VROT 2 VROT 3 VROT 4 VROT 5 VROT 6
       
               If a parameter is specified twice this will result in a
               double change or double fitting.
       
               To vary any parameter seperately in the model one would
               type:

               VARYMULT= RADI VROT Z0 SBR INCL PA XPOS YPOS VSYS CONDISP 

  VARYSING=    Values to be varied as a single parameter (group):

               The user specifies a group of parameters by the
               parameter name (as defined above) followed by ring
               numbers (starting with 1). All parameters
               of a group will be varied simultaneously in the fitting
               process. The syntax is best demonstrated with an
               example, for a model with 6 rings, with

               VARYMULT= VROT 2: VSYS 5 1:3 VSYS 6 PA PA 2
       
               All rotational velocities of rings 2-6
               All systemic velocities of rings 1-3 and 5
               The systemic velocity of ring 6
               All position angles
               Then the position angle of ring 2

               Will be varied simultaneously for each trial model.

  PARMAX=      Give parameter maximum (in the same order):

               The maximum value for a parameter group. The first
               value refers to the first parameter group as defined in
               VARYMULT. A model that exceeds the maximum for
               one parameter is deemed as being impossible.
               Specify as many values as keywords (groups) are given
               in VARYMULT and VARYSING. Usually PARMAX can be set to
               a very high value.

  PARMIN=      Give parameter minimum (in the same order):
          
               The minimum value for a parameter group. The first value
               refers to the first parameter group as defined in
               VARYMULT. A trial model that exceeds the maximum for one
               parameter is deemed as being impossible.  Specify as
               many values as keywords (groups) are given in VARYMULT
               and VARYSING. Usually PARMIN can be set to an extremely
               negative value.
        
  MODERATE=    Give moderating steps (in the same order):
        
               For the first MODERATE loops (big loops) the values of
               DEL and ITE will be interpolated linearly between the
               START and END values. Specify as many values as keywords
               (groups) are given in VARYMULT and VARYSING.
        
  DELSTART=    Give the start delta (in the same order):
        
               The variation of the parameter group for the first
               loop. For FITMODE= 0 (METROPOLIS) this is the maximum
               variation of each parameter group. Specify as many
               values as keywords (groups) are given in VARYMULT and
               VARYSING.
        
  DELEND=      Give the end delta (in the same order): [DELSTART]
        
               The variation of the parameter group after MODERATE big 
               loops. For FITMODE= 0 (METROPOLIS) this is the maximum
               variation of each parameter group. Specify as many
               values as keywords (groups) are given in VARYMULT and
               VARYSING.
        
  ITESTART=    Give starting number of iterations (in the same order):
        
               The maximum number of iterations that intervals are
               nested for one parameter group at the start of the
               fitting process. This will be asked for in case of
               FITMODE= 1 (golden section) only. Specify as many
               values as keywords (groups) are given in VARYMULT and
               VARYSING.
            
  ITEEND=      Give final number of iterations (in the same order): [ITESTART]
        
               The maximum number of iterations that intervals are
               nested for one parameter group after MODERATE big
               loops. This will be asked for in case of FITMODE= 1
               (golden section) only. Specify as many values as
               keywords (groups) are given in VARYMULT and VARYSING.
        
        
  SATDELT=     Give the satisfaction deltas (in the same order):
        
               Will be asked for only in case of FITMODE= 1 (golden
               section). Each parameter group will undergo a nested
               intervals process. If after the process the value of
               each parameter in the group differs from the original
               value before starting the process with an absolute value
               that is less than SATDELT, the fitting routine stays
               satisfied. If after a big loop the routine is satisfied,
               the fitting stops and results are written.
            
        
  MINDELTA=    Give the minimum deltas (in the same order):
        
               Will be asked for only in case of FITMODE= 1 (golden
               section). Each parameter group will undergo a nested
               intervals process. If the current delta will drop below
               MINDELTA, the nesting will be stopped and the next
               parameter group will be adressed.
        
 [COOLGAL=]    Give name of 3d cube:
        
               If set, tirific produces a projection of the model on
               three spatial dimensions stored in a fits file with the
               given name.
        
 [COOLBEAM=]   Give 3d beam size (HPBW in arcsec) [BMAJ]:
               
               Defines a gaussian convolution kernel for a convolution
               of the COOLGAL= dataset. If set to 0, no convolution
               will take place. Defaults to the major axis of the clean
               beam.

 [INCLINO=]    Give inclinogram name:

               If set, tirific produces a fits datacube with the given
               name, each plane containing an ellipse representing a
               projected ring. Inside the ellipse the pixel value is 1
               0 outside. This can be used for a representation of the
               tilted-ring-model if plotted as a Renzogram.

 [IN_REFINE=]  Give inclinogram refinement:

               Integer influencing the pixelsize of INCLINO=. The
               pixelsize of the inclinogram is a IN_REFINE=th of the
               pixelsize in the original cube.
        
 [GR_DEVICE=]  Give graphics (pgplot) device:

               Specifies the pgplot device for graphics output. If
               unset, no output will be produced. If set, a plot with
               the best-fit values will be produced.

 [GR_MR=]      Give right hand margin:

               Margin between right hand axis descriptor and border of
               the plot.
             
 [GR_ML=]      Give left hand margin:

               Margin between left hand axis descriptor and border of
               the plot.

 [GR_TXHT=]    Give height of Text:

               Specifies the height of the text in pgplot units (1
               corresponds to about 1/40 of the height of the plot).

 [GR_SBHT=]    Give height of symbols:

               Specifies the height of symbols (dots) in the plot as
               multiples of GR_TXHT=

 [GR_LGND=]    Plot legend (1/0)? [1]

               If set to a different value than 0, a legend explaining
               the axis descriptors will be generated.

 [GR_SBRP=]    Plot values for subrings 1/0? [1]

               If set to a value different from 0, best-fit values of
               the subrings are plotted as bars.

 [GR_PARMS=]   Give parameters to plot:

               Specification of the parameters to plot. In addition to
               the parameters that are specified above as RADI= VROT=,
               ... , DENS (surface density), WA (Warp angle relative
               to the total angular momentum of the observed
               component), and WOLD (Warp angle relative to the ring
               fixed with REFRING=) can be specified. The first
               parameter will deliver the values for the x-axis, the
               consecutive parameters will then be plotted in a series
               of graphs in deependence of the x-axis parameter. For
               RADI= the radius in kiloparsec will be plotted,
               calculated with the DISTANCE= parameter. Spatial
               coordinates are given as decimal fraction of deg.

 [GR_COL_i=]   Give Colour of plot i: [i]

               Pgplot colour of ith plot (Usually ranging from 0-15).

 [GR_LINES_i=] Plot lines 1/0? [0]

               If set to a value different from 0, lines will be
               plotted in-between the points.

 [GR_ERRB_i=]  Plot errorbars 1/0? [0]

               If set to a value different from 0, errorbars will be
               imposed on the datapoints of plot i.

 [GR_XMIN=]    Give minimum of x-axis:

               Specifies minimum of x-axis. The default is chosen such
               that all points are displayed.

 [GR_XMAX=]    Give maximum of x-axis:

               Specifies maximum of x-axis. The default is chosen such
               that all points are displayed.

 [GR_XMIN_i=]  Give minimum of y-axis i:

               Specifies minimum of x-axis of ith plot. The default is
               chosen such that all points are displayed.

 [GR_XMAX_i=]  Give maximum of y-axis i:

               Specifies maximum of y-axis of ith plot. The default is
               chosen such that all points are displayed.

 [GR_NPAD_i=]  Give number of additional points for plot %i: [0]

               The number of additional points to be plotted.

 [GR_XPAD_i=]  Give additional points, x axis for plot i:

               The x-axis values of the additional points. GR_NPAD_i
               values have to be given.

 [GR_YPAD_i=]  Give additional points, y axis for plot i:

               The y-axis values of the additional points. GR_NPAD_i
               values have to be given.

 [GR_ERAD_i=]  Errorbars to additional points of plot i (1/0)? [0]

               If not set to 0, errorbars will be displayed to the
               additional datapoints.

 [GR_EBAD_i=]  Give errorbars for additional points of plot i:

               If GR_ERAD_i!=0, GR_NPAD_i values for errorbars have to
               be given.

 [GR_COAD_i=]  Give colour of additional points of plot i:

               Colour of additional points of ith plot. Typically
               values range from 0-15, depending on the chosen device.

 [GR_LIAD_i=]  Draw lines between additional points of plot %i (1/0)? [0]

               If not set to 0, the additional points on plot i will
               be connected with lines.

 [GR_CONT=]    Continue (type return)?

               Simple question, if a viewgrph is plotted. The program
               holds until anything is put in this parameter.

               ------------ !!!!NOTE!!!!  ------------

Tirific is still under construction and in a test phase and does not
yet implement all functionality that will be reached with time
moving. There are many betterments that are already on our todo list,
ranging from speed improvements to a completely different
user-interface. The tirific source is held extremely flexible, such
that any user can hack easily hack away, but in any case, we are open
for any suggestion (and one will of course be to introduce a
radius-dependent velocity dispersion) and wishes and especially, we
are happy about any bug report. For receiving update reports, critics,
wishes, bug reports, send a mail to:

gjozsa@astro.uni-bonn.de

 */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <stdio.h>
#include <string.h>
#include <float.h>
#include <limits.h>



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */

/* This is generated by the makefile and contains the gipsy header
   files. I found no other than this disgusting way. If this module is
   being changed, the makefile has to be changed accordingly. I found
   no way around this */
#include "gipsylinc.c"
#include <engalmod.h>
#include <maths.h>
#include <ftstab.h>
#include <ftsoutput.h>
#include <gridnconvol.h>
#include <cubarithm.h>
#include <pgp.h>
#include "opsystems.h"

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def _MEMORY_HERE_ON
   @brief Controls the use of the memory_here module

   If you don't want to use the memory_here facility comment this
   define, otherways it will be included.

*/
/* ------------------------------------------------------------ */
#define _MEMORY_HERE_ON
#include <memory_here.h>



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */
#define MAXNUR 128
#define MAXNAX 5
#define MAXNSUBS 2048
#define MAXVARY MAXNUR*9+1

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define FLOAT_ACCURACY
   @brief Tolerance for floats
*/
/* ------------------------------------------------------------ */
#define FLOAT_ACCURACY 1.0E-7


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define DOUBLE_ACCURACY
   @brief Tolerance for floats
*/
/* ------------------------------------------------------------ */
#define DOUBLE_ACCURACY 3.0E-15


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define VARYSTRELES
   @brief Number of words in the varystr table in function readfit()
*/
/* ------------------------------------------------------------ */
#define VARYSTRELES 3000



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define VARYHSTRELES
   @brief Length of the varyhstr in function readfit()
*/
/* ------------------------------------------------------------ */
#define VARYHSTRELES 3000



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define MAXVERHOLINES
   @brief maximum of vertical and horizontal lines in graphout
*/
/* ------------------------------------------------------------ */
#define MAXVERHOLINES 10




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define PRADI
   @brief A parameter for each ring is adressed by PXXXX*rpm -> nur+ringnr
*/
/* ------------------------------------------------------------ */
#define PRADI    0
#define PVROT    1   
#define PZ0      2   
#define PSBR     3   
#define PINCL    4   
#define PPA      5   
#define PXPOS    6   
#define PYPOS    7   
#define PVSYS    8   
#define PCONDISP 9   
  

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define RADI
   @brief Identification
*/
/* ------------------------------------------------------------ */
#define RADI    1
#define VROT    2   
#define Z0      3   
#define SBR     4   
#define INCL    5   
#define PA      6   
#define XPOS    7   
#define YPOS    8   
#define VSYS    9   
#define CONDISP 10 
  

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define NPARAMS
   @brief The number of parameters for each ring
*/
/* ------------------------------------------------------------ */
#define NPARAMS 9



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define NSPARAMS
   @brief The number of global parameters for all rings
*/
/* ------------------------------------------------------------ */
#define NSPARAMS 1



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define RA2AS
   @brief Conversion factor from rad to arcsec
*/
/* ------------------------------------------------------------ */
#define RA2AS 206264.8062470964

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define DEGTORAD
   @brief Conversion factor from deg to rad
*/
/* ------------------------------------------------------------ */
#define DEGTORAD 0.0174532925199433
#define RADTODEG 57.29577951308232

#define TWOPI 6.283185307179586
#define PIHALF 1.570796326794897
#define SQRTOFPIHALF 0.886226925452758
#define HPBWTOSIGMATOFORTH 0.03252139032821276
#define SPEEDOFLIGHT 2.99792458E5
#define HIRESFREQ 1.420405751786E9
#define HICONVERSION 1.248683E24
#define UTOSOLAR 8.01325e-21
/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define BMAJ_PRIMPOS @brief Position of the value for BMAJ in the
   first description table, in case that it's not in the first header,
   identifyer for primpos_numtype()
*/
/* ------------------------------------------------------------ */
#define BMAJ_PRIMPOS 1
#define BMIN_PRIMPOS 2
#define BPA_PRIMPOS 3
#define RMS_PRIMPOS 4
#define NUR_PRIMPOS 5
#define RADSEP_PRIMPOS 6
#define LTYPE_PRIMPOS 7
#define CFLUX_PRIMPOS 8
#define WEIGHT_PRIMPOS 9
#define MODE_PRIMPOS 10
#define ISEED2_PRIMPOS 11
#define LOOPS_PRIMPOS 12
#define ISEED_1_PRIMPOS 13
#define ISEED_2_PRIMPOS 14
#define ANSTART_PRIMPOS 15
#define ANEND_PRIMPOS 16
#define ANSTEPS_PRIMPOS 17
#define INIMODE_PRIMPOS 18
#define FITMODE_PRIMPOS 19
#define OUTCUBUP_PRIMPOS 20
#define DISTANCE_PRIMPOS 21
#define PENALTY_PRIMPOS 22
#define RFREQ_PRIMPOS 23
#define ITOU_PRIMPOS 24

/* Not in first header */
#define PARMAX_PRIMPOS 25
#define PARMIN_PRIMPOS 26
#define MODERATE_PRIMPOS 27
#define DELSTART_PRIMPOS 28
#define DELEND_PRIMPOS 29
#define ITESTART_PRIMPOS 30
#define ITEEND_PRIMPOS 31
#define SATDELT_PRIMPOS 32
#define MINDELTA_PRIMPOS 33
#define ELEMENTS_PRIMPOS 34

/* Third hdu */
#define CHISQ_PRIMPOS 35
#define RCHISQ_PRIMPOS 36
#define LOOPNR_PRIMPOS 37
#define ACCEPT_PRIMPOS 38

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define PRIMHDN_SINGLE
   @brief Number of first singular values in the first header
*/
/* ------------------------------------------------------------ */
#define PRIMHDN_SINGLE 24



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define PARMAX_SECPOS
   @brief Position of the value for BMAJ in the first description table
*/
/* ------------------------------------------------------------ */
#define PARMAX_SECPOS   1
#define PARMIN_SECPOS   2
#define MODERATE_SECPOS 3
#define DELSTART_SECPOS 4
#define DELEND_SECPOS   5
#define ITESTART_SECPOS 6
#define ITEEND_SECPOS   7
#define SATDELT_SECPOS  8
#define MINDELTA_SECPOS  9
#define ELEMENTS_SECPOS  10



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define SECHDN_MULTI
   @brief Number of columns in the second header
*/
/* ------------------------------------------------------------ */
#define SECHDN_MULTI 10



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define CHISQ_TABNR
   @brief Position of the variable in the outarray after the par content
*/
/* ------------------------------------------------------------ */
#define CHISQ_TABNR  1
#define RCHISQ_TABNR 2
#define LOOPNR_TABNR 3
#define ACCEPT_TABNR 4

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define OUTTABNR
   @brief Number of additional entries in the outtab
*/
/* ------------------------------------------------------------ */
#define OUTTABNR 4



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define WANGLE_GRAPHNR
   @brief Description of a number of a special graphics output
*/
/* ------------------------------------------------------------ */
#define WA_GRAPHNR  NPARAMS+1
#define DENS_GRAPHNR NPARAMS+2
#define WOLD_GRAPHNR NPARAMS+3
#define TIP_GRAPHNR NPARAMS+4
#define LON_GRAPHNR NPARAMS+5
#define RASH_GRAPHNR NPARAMS+6
#define DESH_GRAPHNR NPARAMS+7

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define MAXGRAPHS
   @brief Maximum allowed number of viewgraphs on one page
*/
/* ------------------------------------------------------------ */
#define MAXGRAPHS 20



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define GRAPHNR
   @brief Number of additional entries for graphics
*/
/* ------------------------------------------------------------ */
#define GRAPHNR 5



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define VERSION_NUMBER
   @brief Version number of this module
*/
/* ------------------------------------------------------------ */
#define VERSION_NUMBER 1


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define GOLDEN_SECTION
   @brief Identifyer for the GOLDEN_SECTION method
*/
/* ------------------------------------------------------------ */
#define GOLDEN_SECTION 1
#define METROPOLIS 0



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define EXMAXMETRO
   @brief Maximum number of allowed attempts to make a model "out of range"

   The user has the possibility to give a minimum and a maximum for a
   given entry in the VARYSING and VARYMULT. If one of the parameters
   is changed to a value out of range, then the model will be
   discarded, and a new attempt will be done. To prevent an endless
   loop, the number of maximal attempts is given. chprm_metro will
   return 0 in that case.

*/
/* ------------------------------------------------------------ */
#define EXMAXMETRO 100000



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define MAGNIFICNR
   @brief The number with which the delta is multiplied with at most

   To make the iteration method a bit more effective, for each
   unsuccessful step to surround a minimum, the delta is multiplied
   with a number. After several steps, the number with which the
   original delta is multiplied is big. If we have repeated this enlargement
   MAGNIFICNR of times we won't do it anymore.
*/
/* ------------------------------------------------------------ */
#define MAGNIFICNR 100


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @define AFAC
   @brief A constant needed for the golden section

   omega = (3-sqrt(5))/2 0.3819660112501052
   AFAC = (1-omega)/omega
   BFAC = 1-omega = omega/(1-omega)
*/
/* ------------------------------------------------------------ */
#define AFAC 1.618033988749894
#define BFAC 0.6180339887498948



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE MACROS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE STRUCTS */
/* ------------------------------------------------------------ */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct loginf
   @brief Information about logfiles

   The struct contains all necessary information and the location of
   structures concerning logfiles.

*/
/* ------------------------------------------------------------ */
typedef struct loginf
{
  /** @brief Name of the logfile */
  char *logname;

  /** @brief Logfile present or not, 0 present, 1 not present */
  int logpres;

  /** @brief Name of the text logfile */
  char *textlog; 

  /** @brief Name of the output table */
  char *table; 

  /** @brief Distance of object */
  double distance;

  /** @brief reference x position */
  double xref;

  /** @brief reference y position */
  double yref;

  /** @brief Stream of the text logfile */
  FILE *tstream; 

  /** @brief An array of length nur*NPARAMS+5 containing the output numbers */
  double *outarray;

  /** @brief A signal for an encountered change */
  int changes;

} loginf;




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct hdrinf
   @brief Information about a cube

   The struct contains all necessary information and the location of
   structures concerning a datacube that is needed by other functions
   in this module than hdr_init(). It is initialised by hdr_init. As
   memeory allocation has to take place as early as possible, this is
   done by hdr_init(). At the stage of hdr_init(), the chisquare
   evaluation will already being initialised, hence the struct
   contains the pointer to the chisquare, also.

*/
/* ------------------------------------------------------------ */
typedef struct hdrinf
{
  /** @brief O/I E The name of the input set  */
  char *inset; 

  /** @brief axis numbers */
  fint inaxperm[MAXNAX];

    /** @brief The outset name */
  char *outset;

  /** @brief Every outcubup loops there will be an update of the output cube */
  int outcubup;

  /** @brief The reference pixels in the set */
  double setcrpix[3]; 
  
  /** @brief Conversion factor from grid units to userdeltunit */
  double deltgridtouser[3];
  
  /** @brief Conversion factor from grids to userglobunit */
  double globgridtouser[3]; 

  /** @brief Conversion factor from cuniti to userglobunit */
  double globsettouser[3]; 

  /** @brief The reference values in user units */
  double userglobcrval[3]; 

  /** @brief The cdelt values in user units */
  double userglobcdelt[3];

  /** @brief The signum of the velocity direction, this is positive if the velocity decreases with channels in the cube, since the internal velocity direction points to the observer */
  float signv;

  /** @brief Conversion factor from HI column density to intensity */
  double jygridtouser;
  
  /** @brief E O beam major and minor axis and beam position angle */
  float bmaj, bmin, bpa;

  /** @brief sigma rms in the map */
  float rms;

  /** @brief rest frequency */
  double rfreq;

  /** @brief conversion from Jy/sqarearcsecond to atoms per square centimeter */
  double itou;

  /** @brief E The size of the cube in axis 1 */
  int bsize1;  

  /** @brief E The size of the cube in axis 1 */
  int bcsize1;  

  /** @brief E The size of the cube in axis 2 */
  int bsize2;  

  /** @brief The total number of pixels in one plane plus padding */
  fint nprof;
  
  /** @brief E Number of subsets, that is the number of planes */
  fint nsubs; 

   /** @brief So-called coordinate words describing axes */
  fint *cwlo; 

  /** @brief So-called coordinate words describing axes */
  fint *cwhi;

  /** @brief Coordinate description (coordinate words) of the subsets (planes) */
  fint *insubs;

  /** @brief The cube himself */
  float *ori;
  
  /** @brief The model */
  float *model;

  /** @brief The chisquare */
  double chi2;
  
  /** @brief An old chisquare */
  double oldchi2;

} hdrinf;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct varlel
   @brief Element of a linked list, describing the change of the model

   varlel is an element of a linked list that describes the change of
   the model. Each element contains a list of numbers (int) that are
   the component numbers of the parameter in the par array of the
   ringparms struct, the number of adressed elements, and a delta
   which controls the variation of the parameters at a time.
*/
/* ------------------------------------------------------------ */
typedef struct varlel
{
  /** @brief The number of elements */
  int nelem;

  /** @brief numbers of the elements in the varlist */
  int *elements;

  /** @brief The parameter maximum */
  double parmax;

  /** @brief The parameter minimum */
  double parmin;

  /** @brief moderating steps */
  int moderate;

  /** @brief The starting delta */
  double delstart;

  /** @brief The end delta */
  double delend;

  /** @brief The starting number of iterations */
  double itestart;

  /** @brief The ending number of iterations */
  double iteend;

  /** @brief The delta for the satisfaction */
  double satdelt;

  /** @brief Delta to stop the iteration process */
  double mindelta;

  /** @brief The next element */
  struct varlel *next;
} varlel;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct srd
   @brief Sub-ring-descriptor

   Contains a preprocessed description of a subring, such as
   floating-point pre-calculations. Is touched by functions srinit(),
 */
/* ------------------------------------------------------------ */
typedef struct srd
{
  /** @brief Sin of the inclination */
  float sini;

  /** @brief Cos of inclination */
  float cosi;

  /** @brief Sin of position angle */
  float sinp;

  /** @brief Cos of position angle */
  float cosp;

  /** @brief Number of pointsources */
  long n;

  /** @brief Number of pointsources outside the cube */
  long outn;

  /** @brief Flux of one pointsource */
  float pf;

  /** @brief Pointsource list, an array of pointers to points in the cube */
  float **pl;
} srd;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct inlistel
   @brief A linked list of integers
 */
/* ------------------------------------------------------------ */
typedef struct inlistel
{
  int i;
  struct inlistel *next;
} inlistel;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* 
   @struct ringparms
   @brief All variables that are needed for the description of the rings

   @li @c float @c x  x position in arcsec (grids)
*/
/* ------------------------------------------------------------ */
typedef struct ringparms
{
  /** @brief Number of rings */
  fint nur;

  /** @brief Array of size nur*NPARAMS+1 containing the parameters */
  double *par;

  /* Layer type */
  fint ltype; 

  /** @brief Array of same size containing the previous parameters */
  double *oldpar;

  /** @brief Subset separation in grids */
  double radsep; 

  /** @brief number of subrings */
  int nr;
  
  /** @brief big version of par, for all subrings */
  float *modpar;

  /** @brief Flux of one cloud */
  double cflux;

  /** @brief Noise weighting */
  float weight;

  /** @brief Memory mode */
  int mode;

  /** @brief Initialisation mode */
  int inimode;

  /** @brief The allocated permanent random generator */
  maths_rstrf *permrandstr;

  /** @brief One seed argument for the permanent random number generator */
  int iseed2[2];

  /** @brief A list of subring descriptors */
  srd *sd;

  /** @brief The number of parameters that are variable for each ring */
  int varpars;

  /** @brief The number of pointsources outside the cube */
  long outpoints;

  /** @brief The penalty for outlyers */
  double penalty;

  /** @brief The factor for penalties sigmax^2*sigmay^2/sigma_rms^2 */
  double penfact;

} ringparms;

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* 
   @struct fitparms
   @brief All variables that are needed for the description of the fitting process

   @li @c float @c x  x position in arcsec (grids)
*/
/* ------------------------------------------------------------ */
typedef struct fitparms
{
  /** @brief The list for variation of parameters */
  varlel *varylist;

  /** @brief Number of models to compute */
  fint loops; 

  /** @brief Start annealing factor */
  double anstart;
  
  /** @brief Stop annealing factor */
  double anend; 

  /** @brief Annealing steps */
  fint ansteps;

  /** @brief The initialised normal random generator */
  maths_rstr *normrandstr; 

  /** @brief Random number initialisation */
  int iseed[2];

  /** @brief The fitting procedure: 0: annealing, 1: golden section */
  int fitmode;

  /** @brief The number of the current loop minus one */
  long loopnr;

  /** @brief An indicator if something is out of range */
  int outofrange;

  /** @brief The current number of pointsources */
  int npoints;

} fitparms;


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* 
   @struct vector
   @brief A threedimensional vector

   @li @c float @c x  x position in arcsec (grids)
*/
/* ------------------------------------------------------------ */
typedef struct vector
{
  /** @brief x component */
  double x;

  /** @brief y component */
  double y;

  /** @brief z component */
  double z;

} vector;


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* (PRIVATE) GLOBAL VARIABLES */
/* ------------------------------------------------------------ */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @var errno
   @brief Needed by giplib for no obvious reason
*/
/* ------------------------------------------------------------ */
int errno;

/* Check for the beam read-in and the map unit read-in if changing this, also check function makecoolhdr() */
static char userdeltunit[] = "ARCSEC";
static char user3deltunit[] = "KM/S";
static char userglobunit[] = "DEGREE";
static char user3globunit[] = "KM/S";



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE TYPEDEFS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static int writemodel(hdrinf *origin, ringparms *rpm);
   @brief Writes the model to the output

   @param origin (hdrinf *)  header info struct initialised by get_hdrinf()
   @param rpm    (ringparms) properly configured ringparms struct
   @return (success) 1;
           (error) 0;
*/
/* ------------------------------------------------------------ */
static int writemodel(hdrinf *origin, ringparms *rpm);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static char *getfcharray(int length)
   @brief Returns a fortran compatible char array

   Returns an allocated char array of length length+1 that is
   terminated, but contains no terminating characters ('\0') in the
   string. Has to freed.

   @param length (int) Length of text in string

   @return char *getfcharray: Allocated char array suitable for the use in fortran
*/
/* ------------------------------------------------------------ */
static char *getfcharray(int length);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static loginf *create_loginf(void)
   @brief Creates a loginf structure

   Creates a hdrinf structure allocating and if necessary initialising
   all structs and arrays.

   @return (success) hdrinf create_hdrinf: Allocated and initialised
   hdrinf struct\n 
           (error): NULL
*/
/* ------------------------------------------------------------ */
static loginf *create_loginf(void);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void destroy_loginf(loginf *hdr)
   @brief Destroys a loginf structure

   Destroys a loginf structure deallocating all arrays. A
   non-allocated array has to be terminated (has to have a NULL value)
   to get the function work properly.

   @param hdr (loginf *) A loginf struct to be destroyed

   @return void
*/
/* ------------------------------------------------------------ */
static void destroy_loginf(loginf *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static loginf *get_hdrinf(void)
   @brief Initialisation of the program concerning logfiles

   Takes over all logfile related io, returns an allocated loginf struct.

   @return (success) loginf *get_loginf: A loginf struct with the acquired info
           (error) NULL
*/
/* ------------------------------------------------------------ */
static loginf *get_loginf(void);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static hdrinf *create_hdrinf()
   @brief Creates a hdrinf structure

   Creates a hdrinf structure allocating and if necessary initialising
   all arrays

   @return (success) hdrinf create_hdrinf: Allocated and initialised
   hdrinf struct\n 
           (error): NULL
*/
/* ------------------------------------------------------------ */
static hdrinf *create_hdrinf(void);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void destroy_hdrinf(hdrinf *hdr)
   @brief Destroys a hdrinf structure

   Destroys a hdrinf structure deallocating all arrays. A
   non-allocated array has to be terminated (has to have a NULL value)
   to get the function work properly

   @param hdr (hdrinf *) A hdrinf struct to be destroyed

   @return void
*/
/* ------------------------------------------------------------ */
static void destroy_hdrinf(hdrinf *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static hdrinf *get_hdrinf(loginf *log)
   @brief Initialisation of the program concerning info from the dataset

   Takes over all dataset related io, returns an allocated hdrinf struct, with all the current rubbish.
   @param log (loginf *) A log descriptor struct, properly filled.

    @return (success) hdrinf *get_hdrinf: A hdrinf struct with the acquired info and rubbish
           (error) NULL
*/
/* ------------------------------------------------------------ */
static hdrinf *get_hdrinf(loginf *log);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static srd *create_srd(int n)
   @brief Creates a list of subring descriptors with n elements

   The pointsource lists are terminated with NULL

   @param n (int) Number of subrings to allocate the list for

   @return (success) srd *create_srd: Allocated and initialised
   srd list\n 
           (error): NULL
*/
/* ------------------------------------------------------------ */
static srd *create_srd(int n);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void destroy_srd(srd *sd, int n)
   @brief Destroys a list of subring descriptors

   The pointsource lists shold be terminated with NULL if they are
   deallocated

   @param sd (srd *) The list to destroy
   @param n (int)    Number of elements of the list.

   @return void
*/
/* ------------------------------------------------------------ */
static void destroy_srd(srd *sd, int n);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static ringparms *create_ringparms(void)
   @brief Creates a ringparms structure

   Creates a ringparms structure allocating and if necessary initialising
   all arrays

   @return (success) ringparms *create_ringparms: Allocated and initialised
   hdrinf struct\n 
           (error): NULL
*/
/* ------------------------------------------------------------ */
static ringparms *create_ringparms(void);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void destroy_ringparms(ringparms *hdr)
   @brief Destroys a ringparms structure

   Destroys a ringparms structure deallocating all arrays. A
   non-allocated array has to be terminated (has to have a NULL value)
   to get the function work properly

   @param hdr (ringparms *) A hdrinf struct to be destroyed

   @return void
*/
/* ------------------------------------------------------------ */
static void destroy_ringparms(ringparms *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static ringparms *get_ringparms(loginf *log, hdrinf *hdr)
   @brief Fill the ringparms struct from the input

   Reads in properly the ringparms struct.

   @param log (loginf *) A log descriptor struct, properly filled.
   @param hdr (hdrinf *) A header descriptor struct, properly filled.

   @return    @return (success) ringparms *get_ringparms: A ringparms struct with the acquired info and rubbish
           (error) NULL
*/
/* ------------------------------------------------------------ */
static ringparms *get_ringparms(loginf *log, hdrinf *hdr);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static fitparms *create_fitparms(void)
   @brief Creates a fitparms structure

   Creates a fitparms structure allocating and if necessary initialising
   all arrays

   @return (success) fitparms *create_fitparms: Allocated and initialised
   fitparms struct\n 
           (error): NULL
*/
/* ------------------------------------------------------------ */
static fitparms *create_fitparms(void);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void destroy_fitparms(fitparms *hdr)
   @brief Destroys a fitparms structure

   Destroys a fitparms structure deallocating all arrays. A
   non-allocated array has to be terminated (has to have a NULL value)
   to get the function work properly

   @param hdr (fitparms *) A hdrinf struct to be destroyed

   @return void
*/
/* ------------------------------------------------------------ */
static void destroy_fitparms(fitparms *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static fitparms *get_fitparms(loginf *log, hdrinf *hdr, ringparms *rpm)
   @brief Fill the fitparms struct from the input

   Reads in properly the fitparms struct.

   @param log (hdrinf *) A log descriptor struct, properly filled.
   @param hdr (hdrinf *) A header descriptor struct, properly filled.
   @param rpm (ringparms *) A ring parameter descriptor struct, properly filled.

   @return    @return (success) fitparms *get_fitparms: A fitparms struct with the acquired info and rubbish
           (error) NULL
*/
/* ------------------------------------------------------------ */
static fitparms *get_fitparms(loginf *log, hdrinf *hdr, ringparms *rpm);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static double dparamtointern(double value, int par, hdrinf *hdr)
   @brief conversion of some units

Converts the input as being coordinates given by the user to inernal (grid-) units. Caution!!! For the conversion of absolute map coordinates this function is not appropriate.
 Use globtointern instead!

   RADI    1  
   VROT    2  
   Z0      3  
   SBR    4  
   INCL    5  
   PA      6  
   XPOS    7  
   YPOS    8  
   VSYS    9  
   CONDISP 10
   
   @param value (double)   value to convert
   @param par   (char)     type of parameter (see above)
   @param hdr   (hdrinf *) The properly configured header description struct

   @return double paramtointern: converted value
*/
/* ------------------------------------------------------------ */
static double dparamtointern(double value, int par, hdrinf *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static double dinterntoparam(double value, int par, hdrinf *hdr)
   @brief conversion of some units

Converts the input as being inernal (map-) coordinates to units as given by the user. Caution!!! For the conversion of map coordinates this function is, strictly speaking, not appropriate.
 Use globtointern instead!

   RADI    1  
   VROT    2  
   Z0      3  
   SBR    4  
   INCL    5  
   PA      6  
   XPOS    7  
   YPOS    8  
   VSYS    9  
   CONDISP 10
   
   @param value (double)   value to convert
   @param par   (char)     type of parameter (see above)
   @param hdr   (hdrinf *) The properly configured header description struct

   @return double dinterntoparam: converted value
*/
/* ------------------------------------------------------------ */
static double dinterntoparam(double value, int par, hdrinf *hdr);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static double simpleinterntoglob(double value, int par, hdrinf *hdr)
   @brief conversion of some units

   Converts the input globals as being inernal (map-) coordinates to units as
   given by the user in a simple way for the use as min and max.

   RADI    1  
   VROT    2  
   Z0      3  
   SBR    4  
   INCL    5  
   PA      6  
   XPOS    7  
   YPOS    8  
   VSYS    9  
   CONDISP 10

   @param value (double)   value to convert
   @param par   (char)     type of parameter (see above)
   @param hdr   (hdrinf *) The properly configured header description struct

   @return double simpleinterntoglob: converted value
*/
/* ------------------------------------------------------------ */
static double simpleinterntoglob(double value, int par, hdrinf *hdr);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static double simpleglobtointern(double value, int par, hdrinf *hdr)
   @brief conversion of some units

   Converts the input globals as being global coordinates to internal
   map units as given by the user in a simplified way, for the use as min and max.

   RADI    1  
   VROT    2  
   Z0      3  
   SBR    4  
   INCL    5  
   PA      6  
   XPOS    7  
   YPOS    8  
   VSYS    9  
   CONDISP 10
  
   @param value (double)   value to convert
   @param par   (char)     type of parameter (see above)
   @param hdr   (hdrinf *) The properly configured header description struct

   @return double simpleglobtointern: converted value
*/
/* ------------------------------------------------------------ */
static double simpleglobtointern(double value, int par, hdrinf *hdr);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static double vusertointern(double value, hdrinf *hdr)
   @brief conversion of absolute velocity units

Converts the input as being absolute velocity coordinates given by the user to inernal (grid-) units. 

   
   @param value (double)   value to convert
   @param hdr   (hdrinf *) The properly configured header description struct

   @return double vusertointern: converted value
*/
/* ------------------------------------------------------------ */
/* static double vusertointern(double value, hdrinf *hdr); */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static double vinterntouser(double value, hdrinf *hdr)
   @brief conversion of absolute velocity units

Converts the input as being absolute velocity coordinates in the internal map to units given by the user.
   
   @param value (double)   value to convert
   @param hdr   (hdrinf *) The properly configured header description struct

   @return double vinterntouser: converted value
*/
/* ------------------------------------------------------------ */
/* static double vinterntouser(double value, hdrinf *hdr); */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void globtointern(double *invalue, double *outvalue, hdrinf *hdr)
   @brief conversion of map units

   Converts the input as being (map-) coordinates to internal units. 

   
   @param invalue (double *)  values to convert, x, y, v.
   @param outvalue (double *)  converted values, x, y, v.
   @param hdr   (hdrinf *) The properly configured header description struct

   @return double dinterntoparam: converted value
*/
/* ------------------------------------------------------------ */
static void globtointern(double *invalue, double *outvalue, hdrinf *hdr);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void interntoglob(double *invalue, double *outvalue, hdrinf *hdr)
   @brief conversion of map units

   Converts the input as being internal units to (map-) coordinates. 

   
   @param value (double *)  values to convert, x, y, v.
   @param outvalue (double *)  converted values, x, y, v.
   @param hdr   (hdrinf *) The properly configured header description struct

   @return double dinterntoparam: converted value
*/
/* ------------------------------------------------------------ */
static void interntoglob(double *invalue, double *outvalue, hdrinf *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void changetointern(double *params, int nur, hdrinf *hdr)
   @brief Change the parameter list params to internal units as if being user units
   
   @param params (double *) parameter list, nur*NPARAMS+NSPARAMS elements
   @param nur    (int)      number of rings
   @param hdr    (hdrinf *) A properly configured hdrinf struct

   @return void
*/
/* ------------------------------------------------------------ */
static void changetointern(double *params, int nur, hdrinf *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/*
   @fn static int par2int(char *par);
   @brief Identification of string keywords with numbers

   Identifies the input string (No whitespaces to be passed) and
   returns it's identification. This is somewhat critical and
   dependent on the implementation of the ftstab module, call
   ftstab_hdlreset_() before using:

   default   par2int=0
   "RADI"    par2int=1
   "VROT"    par2int=2
   "Z0"      par2int=3
   "SBR"    par2int=4
   "INCL"    par2int=5
   "PA"      par2int=6
   "XPOS"    par2int=7
   "YPOS"    par2int=8
   "VSYS"    par2int=9
   "CONDISP"  par2int=10

   @param par (char *) A string to pass to the function
   @return int par2int: The identifyer as defined above.
*/
/* ------------------------------------------------------------ */
/*   int ftstab_gtitln_(char *titl); */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/*
   @fn static void int2par(char *key, int par);
   @brief Identification of numbers with string keywords

   Identifies the input number and
   returns it's identification keyword in a string key. This is somewhat critical and
   dependent on the implementation of the ftstab module, call
   ftstab_hdlreset_() before using:

   "DEFAULT" par2int=0 
   "RADI"    par2int=1
   "VROT"    par2int=2
   "Z0"      par2int=3
   "SBR"    par2int=4
   "INCL"    par2int=5
   "PA"      par2int=6
   "XPOS"    par2int=7
   "YPOS"    par2int=8
   "VSYS"    par2int=9
   "CONDISP  par2int=10

   @param par (char *) A string to pass to the function
   @return int par2int: The identifyer as defined above.
*/
/* ------------------------------------------------------------ */
/* int ftstab_putcoltitl(char *key, int coltitle); */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static varlel *appendvarlel(varlel *last)
   @brief Constructor of an element of the varlel list

   Appends a varlel struct (terminated) to the last and returns a
   pointer to the appended element

   @param last (varlel *) The last varlel element (or NULL)

     @return (success) varlel *appendvarlel: The new element of the list
             (error) NULL
*/
/* ------------------------------------------------------------ */
static varlel *appendvarlel(varlel *last);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void destroyvarlel(varlel *first)
   @brief Destructor of a varlel list

   Destroys a varlel list from first on. The element before first will
   not be terminated, while the list has to be terminated. All
   elements arrays have to be dynamically allocated in case of nelem
   != 0.

   @param first (varlel *) The first varlel element to destroy(or NULL)

   @return void
*/
/* ------------------------------------------------------------ */
static void destroyvarlel(varlel *first);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static inlistel *appendinlistel(inlistel *last)
   @brief Constructor of an element of a inlistel list

   Appends a inlistel struct (terminated) to the last and returns a
   pointer to the appended element

   @param last (inlistel *) The last varlel element (or NULL)

     @return (success) inlistel *appendinlistel: The new element of the list
             (error) NULL
*/
/* ------------------------------------------------------------ */
static inlistel *appendinlistel(inlistel *last);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static int galmod(hdrinf *hdr, ringparms *rpm, int fitmode, varlel *varele)
   @brief Core to construct a pointsource cube from a parameter list

   This is the part where the things that are done with galmod are
   done. It is detached from the structure that passes packages of
   descriptors, because it can, in principle be used everywhere.  With
   the fitmode and varele, the interpolation of rings and the
   calculation of pointsources will be done only, if parameters have
   currently been changed. For this, the information contained in the
   varlel element is used. If NULL is passed, then everything will be
   calculated freshly. NULL should always be passed, if not sure
   whether the parameters have been interpolated correctly in a
   previous run or if interpover was used as a stand-alone or not at
   all before.

   @param hdr      (hdrinf *)    header information struct
   @param rpm      (ringparms *) Ring parameter information struct
   @param fitmode  (int)         Fitting mode as in fitparms -> fitmode
   @param varele   (varlel *)    Actual element that is processed in the varlel list

     @return (success) int galmod: 1
             (error) 0
*/
/* ------------------------------------------------------------ */
static int galmod(hdrinf *hdr, ringparms *rpm, int fitmode, varlel *varele);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void interpover(ringparms *rpm, double radsep, int fitmode, varlel *varele)
   @brief Constructs the modpar array by interpolating over the par array

   Constructs the modpar array by interpolating over the parameters,
   that are a content of the varlel item. If fitmode = 0, then varele
   is taken as the first item in a ll, and the function will scan
   through all elements of this ll, if fitmode = 1, then only the
   actually passed element will be scanned. If NULL is passed as a
   value of varele, then all parameters are changed or "touched" even
   if they stay the same value.

   @param rpm     (ringparms *) Ring parameter information struct
   @param radsep  (double)      Radius separation of subring in appropriate units
   @param fitmode (int)         Fit mode to check for
   @param varele  (varlel *)    Parameter list element.
   @return void
*/
/* ------------------------------------------------------------ */
static void interpover(ringparms *rpm, double radsep, int fitmode, varlel *varele);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void interpinit(ringparms *rpm, double radsep)
   @brief Constructs the modpar array by interpolating over the par array 

   This is the same as interpover but without checking the varlel
   list. Should always be used if the par parameter list has been
   changed without consulting the varlel list.

   @param rpm    (ringparms *) Ring parameter information struct
   @param radsep (double)      Radius separation of subring in appropriate units

   @return void
*/
/* ------------------------------------------------------------ */
static void interpinit(ringparms *rpm, double radsep);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int chkchange(varlel *varele, int fitmode, int ringnr, int nur)
  @brief Help function to interpover: Check if the modpar array in the range of a ring has to be changed
  
  If in the previous parameter change a change of the ring has
   occured, this function will return 1, 0 otherways.
  
  @param varele (varlel *) Actual element of the varlel list, or the
  first element in case of fitmode = 0
  
  @param fitmode (int)     Fitmode 0: Metropolis, 1: Golden section
  parameter information struct 
  @param ringnr  (int)     Number of ring to be checked, starting with 0
  @param nur      (int)     Number of rings

  @return int chkchange: 1 if change for ring has occured, 0 if not
*/
/* ------------------------------------------------------------ */
static int chkchange(varlel *varele, int fitmode, int ringnr, int nur);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int chkchangep(varlel *varele, int fitmode, int parnr, int nur)
  @brief Help function to interpover: Check if the modpar array has to be changed for a parameter
  
  If in the previous parameter change a change of the parameter has
   occured, this function will return 1, 0 otherways.
  
  @param varele (varlel *) Actual element of the varlel list, or the
  first element in case of fitmode = 0
  
  @param fitmode (int)     Fitmode 0: Metropolis, 1: Golden section
  parameter information struct 
  @param ringnr  (int)     Number of ring to be checked
  @param nur      (int)     Number of rings

  @return int chkchange: 1 if change for parameter has occured, 0 if not
*/
/* ------------------------------------------------------------ */
static int chkchangep(varlel *varele, int fitmode, int parnr, int nur);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void srprep(ringparms *rpm, int srnr, long mode)
  @brief Preparation of a srd struct
  
  Precalculations for the calculation of a ring.
  
  @param rpm  (ringparms *) Properly configured ringparms struct
  @param srnr (int *)       Number of the subring (start with 0)
  @param mode (long)        Dummy at the moment  

  @return void
*/
/* ------------------------------------------------------------ */
static void srprep(ringparms *rpm, int srnr, long mode);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static long srconst(hdrinf *hdr, ringparms *rpm, int srnr, long mode)
  @brief Generation of a pointsource list
  
  Generates a pointsource list that is attached to the appropriate srd struct

  @param hdr  (hdrinf *)    Properly configured hdrinf struct
  @param rpm  (ringparms *) Properly configured ringparms struct
  @param srnr (int *)       Number of the subring (start with 0)
  @param mode (long)        Dummy at the moment  

  @return long srconst: Number of pointsources outside the cube
*/
/* ------------------------------------------------------------ */
static long srconst(hdrinf *hdr, ringparms *rpm, int srnr, long mode);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void gridpoint(hdrinf *hdr, ringparms *rpm, int srnr, int *pnr, float *pp, long mode)
  @brief Grids a point to a pointsource list
  
  Grids the point point (6 phase-space coords) in a list of pointers to the cube hdr ->
  model. If the point doesn't fit the cube, the pointsource number of
  the subring will be redced by 1, if it fits, pnr will be increased
  by one. Called by srconst.

  @param hdr   (hdrinf *)    Properly configured hdrinf struct
  @param rpm   (ringparms *) Properly configured ringparms struct
  @param srnr  (int)         Number of the subring (start with 0)
  @param pnr   (int *)       Number of the pointsource (start with 0)
  @param pp    (float *)     Number of the subring (start with 0)
  @param mode  (long)        Dummy at the moment  

  @return void
*/
/* ------------------------------------------------------------ */
static void gridpoint(hdrinf *hdr, ringparms *rpm, int srnr, int *pnr, float *pp, long mode);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int srput(ringparms *rpm, int srnr, long mode)
  @brief Puts a pointsource list on a cube
  
  Puts the srnrth pointsource list in rpm on the cube by adding the
  flux in the list pointwise.

  @param hdr   (hdrinf *)    Properly configured hdrinf struct
  @param rpm   (ringparms *) Properly configured ringparms struct
  @param srnr  (int)         Number of the subring (start with 0)

  @return void
*/
/* ------------------------------------------------------------ */
static int srput(ringparms *rpm, int srnr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static int metropolis(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
   @brief Metropolis algorithm

   This is the part where the Metropolis iterations are done.

   @param log      (loginf *)    log information struct
   @param hdr      (hdrinf *)    header information struct
   @param rpm      (ringparms *) Ring parameter information struct
   @param fit      (fitparms *)  fit parameter information struct

   @return (success) int metropolis: 1
           (error) 0
*/
/* ------------------------------------------------------------ */
static int metropolis(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void destroyinlistel(inlistel *first)
   @brief Destructor of a inlistel list

   Destroys a inlistel list from first on. The element before first will
   not be terminated, while the list has to be terminated.

   @param first (inlistel *) The first inlistel element to destroy(or NULL)

   @return void
*/
/* ------------------------------------------------------------ */
static void destroyinlistel(inlistel *first);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static int decodestr(char *string, int *array, int max)
   @brief decodes an input string

   The input string of varymult and varystr has to be a:b where a is
   less or equal b, b is less than the number of rings (in this
   function given by the max parameter), and a is greater than 0. If
   the string is of that structure, the function returns 1 and a and b
   are put into array as integers, 0 otherways.

   @param string (char *) Input string
   @int   array  (int *)  Array to contain a and b
   @param max    (int)    The maximum value that may be read
 
   @return (success) int decodestr 1
           (error) 0
*/
/* ------------------------------------------------------------ */
static int decodestr(char *string, int *array, int max);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void prepout(loginf *log, headerinf *hdr, ringparms *rpm)
   @brief Opens a file and puts an old-style ascii header to the top

   Opens a file and puts an ascii header to the top, as in the old
   version of tirific. This function needs ftstab to be initialised as
   is done in get_ringparms(). The result is put to the component tstream of log.

   @param log (loginf *)    Log description object
   @param hdr (hdrinf *)    header description object
   @param rpm (ringparms *) Ring parameter description object

   @return void
*/
/* ------------------------------------------------------------ */
static void prepout(loginf *log, hdrinf *hdr, ringparms *rpm);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void termsinglestr(char *string)
   @brief Replaces the first occurence of  ' ' in string with '\0'

   @param string (char *) The input string
*/
/* ------------------------------------------------------------ */
static void termsinglestr(char *string);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void writeoutput(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit, char accept, int dof, int modcount)
   @brief Writes the information contained in rpm -> oldpar to the output

   @param log      (loginf *)    log information struct
   @param hdr      (hdrinf *)    header information struct
   @param rpm      (ringparms *) Ring parameter information struct
   @param fit      (fitparms *)  Fit parameter information struct
   @param accept   (char)        Indicator whether the last model was accepted
   @param dof      (int)         Degrees of freedom
   @param modcount (int)         Number of the model
   @param proba    (double)      Probability of acceptance

   @return void
*/
/* ------------------------------------------------------------ */
static void writeoutput(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit, char accept, int dof, int modcount, double proba);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static void writeoutarray(loginf *log, hdrinf *hdr, ringparms *rpm, char accept, double chisquare, int modcount, int dof)
   @brief Writes the information contained in rpm -> oldpar to the output array of rpm

   @param log       (loginf *)    log information struct
   @param hdr       (hdrinf *)    header information struct
   @param rpm       (ringparms *) Ring parameter information struct
   @param accept    (char)        Indicator whether the last model was accepted
   @param chisquare (double)      Degrees of freedom
   @param modcount  (int)         Number of the model
   @param dof       (int)         Degrees of freedom

   @return void
*/
/* ------------------------------------------------------------ */
static void writeoutarray(loginf *log, hdrinf *hdr, ringparms *rpm, char accept, double chisquare, int modcount, int dof);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static int chprm_metro(varlel *varylist, double *oldpar, double *newpar, maths_rstr *rnd, double deltfact)
   @brief Changes the parameters in par according to varylist

   Each parameter that is contained in the parameter lists of varylist
   will be changed randomly. It will be increased or diminished by a
   number in-between 0 and the delta of the element of the
   varylist. All parameters adressed in one varylist component will be
   changed by the same amount. The output is into newpar, while oldpar
   contains the input parameters to change.

   @param varylist (varlel *)     Information structure to vary the
   parameters (must be properly configured according to par)
   @param oldpar   (double *)     Old parameter list
   @param newpar   (double *)     New parameter list
   @param rnd      (maths_rstr *) An initialised random generator struct
   @param loopnr   (double)       Number of actual loop

   @return int chprm_metro: 1 if successful, 0 if a given number FALSEATTEMPTS of attempts to change the model towards an invalid value is exceeded.
*/
/* ------------------------------------------------------------ */
static int chprm_metro(varlel *varylist, double *oldpar, double *newpar, maths_rstr *rnd, long loopnr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn static float zprof(int option, maths_rstrf *permrandstr)
   @brief Delivers a random variable according to a profile identifyer

   Function to get random deviates for various functions.  The double
   precision variable fdev contains the random deviate.  If nran is
   within a factor two of the largest possible integer then integer
   overflow could occur.  DOUBLE PRECISION FUNCTION
   fdev(option,nran,iran,idum) Type of distribution function for the
   random deviates.  
   Options:

   option = 1 -- Gaussian deviates.
   option = 2 -- Sech2 deviates.
   option = 3 -- Exponential deviates.
   option = 4 -- Lorentzian deviates.
   option = 5 -- Box deviates. (is also default)
   option = 6 -- Reset the rng for gaussian

   @param option      (int)         The type of the random variate
   @param permrandstrf (maths_rstr *) An initialised random number control object from this module

   @return float zprof: A random number distributed specified by option
*/
/* ------------------------------------------------------------ */
static float zprof(int option, maths_rstrf *permrandstr);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void hdl_init(void)
  @brief Initializes the standard header context table
*/
/* ------------------------------------------------------------ */
static int hdl_init(void);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int create_hdu_3(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);
  @brief Opens if necessary creates the third hdu

  Will Create a third hdu of the logfile.

   @param log (loginf *)    log information struct
   @param hdr (hdrinf *)    header information struct
   @param rpm (ringparms *) Ring parameter information struct
   @param fit (fitparms *)  Fit parameter information struct

   @return (success) int create_hdu_3: 0\\
           (error) 1
*/
/* ------------------------------------------------------------ */
static int create_hdu_3(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int open_hdu_3(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);
  @brief Opens if necessary creates the third hdu

  Will Create a third hdu of the logfile.

   @param log (loginf *)    log information struct
   @param hdr (hdrinf *)    header information struct
   @param rpm (ringparms *) Ring parameter information struct
   @param fit (fitparms *)  Fit parameter information struct

   @return (success) int create_hdu_3: 0 \\
           (error) 1: Memory error
                   2: User decides not to fit
*/
/* ------------------------------------------------------------ */
static int open_hdu_3(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int create_hdu_1(log, hdr, rpm, fit)
  @brief Creates a fits table and puts the global information to the fits table

  Will create a ftstab fits table with the first hdu from the
  information acquired in the description objects.

   @param log       (loginf *)    log information struct
   @param hdr       (hdrinf *)    header information struct
   @param rpm       (ringparms *) Ring parameter information struct
   @param fit       (fitparms *)  Fit parameter information struct

   @return (success) int create_hdu_1: 0\\
           (error) 1
*/
/* ------------------------------------------------------------ */
static int create_hdu_1(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int create_hdu_2(char *logname, varlel *varylist, varlel **pointarray, int nur, hdrinf *hdr) 

  @brief Creates a second hdu of a fits table and puts the fit
  information contained in the varlel ll to the fits table

  Creates a second hdu of a fits table (deleting consequent elements)
  and puts the fit information contained in the varlel ll to the fits
  table. For a proper functionality make sure that the first hdu is already created.

  @param logname    (char *)    The name of the logfile
  @param varylist   (varlel *)  A properly configured varylist
  @param pointarray (varlel **) Array with pointers to varlels of the size of elements of deltas given by the user   
  @param nur        (int)       Number of rings
  @param hdr        (hdrinf *)  Properly configured headerinf struct

   @return (success) int create_hdu_1: 0\\
           (error) 1
*/
/* ------------------------------------------------------------ */
static int create_hdu_2(char *logname, varlel *varylist, varlel **pointarray, int nur, hdrinf *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int change_hdu_2(varlel *varylist, varlel **pointarray, int nur, hdrinf *hdr) 

  @brief Creates a second hdu of a fits table and puts the fit
  information contained in the varlel ll to the fits table

  Changes a second hdu of a fits table (deleting consequent elements)
  and puts the fit information contained in the varlel ll to the fits
  table. For a proper functionality make sure that the first hdu is already created and the second is opened. This is only of use if both tables have the identical size.

  @param varylist   (varlel *)  A properly configured varylist
  @param pointarray (varlel **) Array with pointers to varlels of the size of elements of deltas given by the user   
  @param nur        (int)       Number of rings
  @param hdr        (hdrinf *)  Properly configured headerinf struct

   @return (success) int change_hdu_2: 0\\
           (error) 1
*/
/* ------------------------------------------------------------ */
static int change_hdu_2(varlel *varylist, varlel **pointarray, int nur, hdrinf *hdr);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int primpos_numtype(int ident)
  @brief Returns the ftstab numerical type of a PRIMPOS identifyer

  @param ident (int) PRIMPOS idendifyer

  @return int primpos_numtype: Numerical type identifyer as in ftstab module
*/
/* ------------------------------------------------------------ */
static int primpos_numtype(int ident);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static double primpos_value(int ident, loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
  @brief Returns the value of a PRIMPOS identifyer from a varele pointer

  @param ident      (int)        identifyer
  @param log       (loginf *)    log information struct
  @param hdr       (hdrinf *)    header information struct
  @param rpm       (ringparms *) Ring parameter information struct
  @param fit       (fitparms *)  Fit parameter information struct

  @return double primpos_value: value of a PRIMPOS identifyer
*/
/* ------------------------------------------------------------ */
static double primpos_value(int ident, loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static double secpos_value(int ident, varele *varylist, int nur, hdrinf *hdr, int element)
  @brief Returns the value of a SECPOS identifyer from a varele pointer

  @param ident    (int)      SECPOS idendifyer
  @param varylist (varele *) pointer to the varele from which the values are extracted
  @param nur      (int)      Number of rings
  @param hdr      (hdrinf *) Properly configured headerinf struct
  @param element  (int)      Number of the element (start with 0) in case of ELEMENTS

  @return double secpos_value: value of a SECPOS identifyer
*/
/* ------------------------------------------------------------ */
static double secpos_value(int ident, varlel *varylist, int nur, hdrinf *hdr, int element);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int comparevarlel(varlel *varlel1, varlel *varlel2)
  @brief Checks if the varlels are identical

  @param varlel1 (varlel *) first varlel element
  @param varlel2 (varlel *) second varlel element

  @return int comparevarlel: 0 if they contain identical values, 1 if they are fatally different, -1, if they are different but contain the same number of elements
*/
/* ------------------------------------------------------------ */
static int comparevarlel(varlel *varlel1, varlel *varlel2);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int fillhdvarele(varlel *varele, int i, double *array,
  int parameter, double *parmax, double *parmin, int *moderate, double
  *delstart, double *delend, int *itestart, int *iteend, double
  *satdelt, double *mindelta, hdrinf *hdr, loginf *log)

  @brief Puts the values of the arrays into varele, checking for mismatch with array

  Puts the values of the global variables of a varele struct into
  varele from the single arrays, checking for mismatch with the
  content of array. If there is any mismatch the user will be
  prompted. Will return 1 if the user decides to abort. Will return 0
  if the user does not want to abort. The user is only prompted once
  and the keyword "proceed" has to be canceled afterwards.

  @param varele    (varlel *) An element of the varlist
  @param i         (int)      The position in the arrays
  @param parameter (int)      The parameter identification
  @param array     (double *) The array that will be checked
  @param parmax    (double *) Parameter list with maxima
  @param parmin    (double *) Parameter list with minima
  @param moderate  (int    *) Parameter list with moderate values
  @param delstart  (double *) Parameter list with delstart values
  @param delend    (double *) Parameter list with delend values
  @param itestart  (int    *) Parameter list with itestart values
  @param iteend    (int    *) Parameter list with iteend values
  @param satdelt   (double *) Parameter list with satdelt values
  @param mindelta  (double *) Parameter list with mindelta values
  @param hdr       (hdrinf *) Properly configured hdrinf struct
  @param log       (loginf *) Properly configured loginf struct
  
  @return int fillhdvarele 1 In case of an error, 0 if everything is ok
*/
/* ------------------------------------------------------------ */
static int fillhdvarele(varlel *varele, int i, double *array, int parameter, double *parmax, double *parmin, int *moderate, double *delstart, double *delend, int *itestart, int *iteend, double *satdelt, double *mindelta, hdrinf *hdr, loginf *log);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int putmetresults(loginf *log, ringparms *rpm, fitparms *fit)
  @brief Calculates and puts the results of the fitting procedure

  This function needs the logfile opened by ftstab module at the third
  extension

  @param  log (loginf *)    Properly configured loginf struct
  @param  rpm (ringparms *) Properly configured ringparms struct
  @param  fit (fitparms *)  Properly configured fitparms struct

  @return (success) int putresults: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int putmetresults(loginf *log, ringparms *rpm, fitparms *fit);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int golden_section(loginf *log, ringparms *rpm, fitparms *fit)
  @brief A golden section iteration

  The other working horse, a golden section iteration.

  @param  log (loginf *)    Properly configured loginf struct
  @param  hdr (hdrinf *)    Properly configured hdrinf struct
  @param  rpm (ringparms *) Properly configured ringparms struct
  @param  fit (fitparms *)  Properly configured fitparms struct

  @return int golden_section: Always 1...
*/
/* ------------------------------------------------------------ */
static int golden_section(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);
  


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int putgoldresults(loginf *log, ringparms *rpm, fitparms *fit)
  @brief Calculates and puts the results of the fitting procedure

  This function needs the logfile opened by ftstab module at the third
  extension

  @param  log (loginf *)    Properly configured loginf struct
  @param  rpm (ringparms *) Properly configured ringparms struct
  @param  fit (fitparms *)  Properly configured fitparms struct

  @return (success) int putresults: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int putgoldresults(loginf *log, ringparms *rpm, fitparms *fit);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int writeasctable(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);
  @brief Writes an ascii table with the results

  This function needs the logfile opened by ftstab module at the third
  extension

  @param  log (loginf *)    Properly configured loginf struct
  @param  hdr (hdrinf *)    Properly configured hdrinf struct
  @param  rpm (ringparms *) Properly configured ringparms struct
  @param  fit (fitparms *)  Properly configured fitparms struct
  @return (success) int writeasctable: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int writeasctable(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int writebigasctable(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);
  @brief Writes an ascii table with the results

  This function needs the logfile opened by ftstab module at the third
  extension. This will list all properties for the subrings.

  @param  log (loginf *)    Properly configured loginf struct
  @param  hdr (hdrinf *)    Properly configured hdrinf struct
  @param  rpm (ringparms *) Properly configured ringparms struct
  @param  fit (fitparms *)  Properly configured fitparms struct
  @return (success) int writeasctable: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int writebigasctable(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int coolgal(loginf *log, hdrinf *hdr, ringparms *rpm)
  @brief Produces a 3d fits image of the model.

  Prompts the user for a name (hidden) of an output cube. This will be a 3d image of the galaxy. As a smoothing value the largest hpbw is used in all three directions. This function will deallocate and reallocate the model and the original cube, such that this function should be called last before the program is being left. The extension of the output cube in the third dimension is the largest dimension in x-y. 

  @param  log (loginf *)    Properly configured loginf struct
  @param  hdr (hdrinf *)    Properly configured hdrinf struct
  @param  rpm (ringparms *) Properly configured ringparms struct
  @return (success) int coolgal: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int coolgal(loginf *log, hdrinf *hdr, ringparms *rpm);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static qfits_header *makecoolhdr(hdrinf *hdr, double beamsizeindeg)
  @brief Produces a header struct for coolgal output

  Produces a qfits_header object suitable for the coolgal output.

  @param  hdr (hdrinf *)           Properly configured hdrinf struct
  @param  beamsizeindeg (double *) 1d beam size in degrees

  @return (success) qfits_header *makecoolhdr: The properly configured header
          (error)   NULL
*/
/* ------------------------------------------------------------ */
static qfits_header *makecoolhdr(hdrinf *hdr, double beamsizeindeg);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int makecoolpoints(Cube *cube, hdrinf *hdr, ringparms *rpm)
  @brief Makes a 3d pointsource model and packs in on cube

  @param cube (Cube *)      The cube onto which the model is gridded
  @param hdr  (hdrinf *)    Properly configured hdrinf struct
  @param rpm  (ringparms *) Properly configured ringparms struct
  @return (success) int makecoolpoints: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int makecoolpoints(Cube *cube, hdrinf *hdr, ringparms *rpm);

  

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void tirout_a(FILE *stream, char *keyword, char *input)
  @brief Copies a part of the tirific input to a stream

  @param stream  (FILE *) An open stream
  @param keyword (char *) Name of the keyword as given in gipsy  
  @param input   (char *) Allocated string of length VARYHSTRELES (including terminating '\0')
  @return void
*/
/* ------------------------------------------------------------ */
static void tirout_a(FILE *stream, char *keyword, char *input);

  

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
@fn static int tirout(loginf *log, ringparms *rpm, int nrplts)
  @brief Produces one or two tirific logfiles containing the results

  @param log    (loginf *)    Properly configured loginf struct
  @param rpm    (ringparms *) Properly configured ringparms struct
  @param nrplts (int)         Number of plots as inquired with graphout()
  @return (success) int tirout: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int tirout(loginf *log, ringparms *rpm, int nrplts);

  

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void bubble(double *array, long length)
  @brief Inefficient sorting of the input array

  @param array  (double *) Input array
  @param length (long)     Length of input array
  @return void
*/
/* ------------------------------------------------------------ */
static void bubble(double *array, long length);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int histout(ringparms *rpm)
  @brief Produces the histogram output of tirific

  @param rpm  (ringparms *) Properly configured ringparms struct
  @return (success) int tirout: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int histout(ringparms *rpm);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int rectout(loginf *log, hdrinf *hdr, ringparms *rpm)
  @brief Produces the rectify output of tirific

  @param log  (loginf *)    Properly configured loginf struct
  @param hdr  (hdrinf *)    Properly configured hdrinf struct
  @param rpm  (ringparms *) Properly configured ringparms struct
  @return (success) int rectout: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int rectout(loginf *log, hdrinf *hdr, ringparms *rpm);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void rectout_a(FILE *stream)
  @brief Output of fixed stuff to a file

  @param stream  (FILE *) An open stream
  @return void
*/
/* ------------------------------------------------------------ */
static void rectout_a(FILE *stream);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void rectout_b(FILE *stream)
  @brief Output of fixed stuff to a file

  @param stream  (FILE *) An open stream
  @return void
*/
/* ------------------------------------------------------------ */
static void rectout_b(FILE *stream);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int tiltout(loginf *log, hdrinf *hdr, ringparms *rpm)
  @brief Produces the tiltogram output of tirific

  @param log  (loginf *)    Properly configured loginf struct
  @param hdr  (hdrinf *)    Properly configured hdrinf struct
  @param rpm  (ringparms *) Properly configured ringparms struct
  @return (success) int tiltout: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int tiltout(loginf *log, hdrinf *hdr, ringparms *rpm);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int briggsout(loginf *log, hdrinf *hdr, ringparms *rpm)
  @brief Produces a tip-lon diagram

  @param log  (loginf *)    Properly configured loginf struct
  @param hdr  (hdrinf *)    Properly configured hdrinf struct
  @param rpm  (ringparms *) Properly configured ringparms struct
  @return (success) int graphout: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int briggsout(loginf *log, hdrinf *hdr, ringparms *rpm);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int graphout(loginf *log, hdrinf *hdr, ringparms *rpm)
  @brief Produces the graphics output of tirific

  @param log  (loginf *)    Properly configured loginf struct
  @param hdr  (hdrinf *)    Properly configured hdrinf struct
  @param rpm  (ringparms *) Properly configured ringparms struct
  @return (success) int graphout: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int graphout(loginf *log, hdrinf *hdr, ringparms *rpm);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int get_graphnr(char *string)
  @brief Identifies a graphics output number

  @param string (char *) String to identify
  @return (success) int get_graphnr: Number of the graphics number as defined by _GRAPHNR plus NPARAMS
          (error)   0
*/
/* ------------------------------------------------------------ */
static int get_graphnr(char *string);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void gr_fillscaling(loginf *log, hdrinf *hdr, int ident, float *scale, float *zero)
  @brief Returns the scale for one unit to the alternative unit

  The plot output of tirific imposes two axis descriptions on the
  plots. The scales are connected via valright =
  scale*valleft+zero. This function returns these values.

  @param log   (loginf *) Properly configured loginf struct
  @param hdr  (hdrinf *)    Properly configured hdrinf struct
  @param ident (int)      Identification as output of ftstab_gtitln_ or get_graphnr
  @param scale (float *)  The scale from left hand border to right hand border of a plot (output)
   @param scale (float *) The zero from left hand border to right hand border of a plot (output)
 
  @return (success) int get_graphnr: Number of the graphics number as defined by _GRAPHNR plus NPARAMS
          (error)   0
*/
/* ------------------------------------------------------------ */
static void gr_fillscaling(loginf *log, hdrinf *hdr, int ident, float *scale, float *zero);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void gr_fillaxis(int ident, char *string)
  @brief Returns an axis descriptor string suitable for the use in the pgp module

  It is no error to pass NULL.

  @param ident  (int)    Identification as output of ftstab_gtitln_ or get_graphnr
  @param string (char *) String to fill (At least characters) or NULL

  @return void
*/
/* ------------------------------------------------------------ */
static void gr_fillaxis(int ident, char *string);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void gr_fillunit(int ident, char *string)
  @brief Returns an unit string suitable for the use in the pgp module

  It is no error to pass NULL.

  @param ident  (int)    Identification as output of ftstab_gtitln_ or get_graphnr
  @param string (char *) String to fill (At least characters) or NULL

  @return void
*/
/* ------------------------------------------------------------ */
static void gr_fillunit(int ident, char *string);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void gr_fillaltunit(int ident, char *string)
  @brief Returns an alternative unit string suitable for the use in the pgp module

  It is no error to pass NULL.

  @param ident  (int)    Identification as output of ftstab_gtitln_ or get_graphnr
  @param string (char *) String to fill (At least characters) or NULL

  @return void
*/
/* ------------------------------------------------------------ */
static void gr_fillaltunit(int ident, char *string);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static void gr_filllegend(int ident, char *string)
  @brief Returns a legend string suitable for the use in the pgp module

  It is no error to pass NULL.

  @param ident  (int)    Identification as output of ftstab_gtitln_ or get_graphnr
  @param string (char *) String to fill (At least characters) or NULL

  @return void
*/
/* ------------------------------------------------------------ */
static void gr_filllegend(int ident, char *string);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int fillgrapharray(hdrinf *hdr, ringparms *rpm, int ident, float *array, float *larray)
  @brief Fills two arrays for graphics use

  The arrays array and larray are filled with the values contained in
  rpm -> par and rpm -> modpar according to the parameter
  required. par and modpar should contain the values in user
  units. The parameter is decoded via an integer ident as returned by
  get_graphident(). array and larray should be large enough.

  @param hdr    (hdrinf *)    Properly configured hdrinf struct
  @param rpm    (ringparms *) Properly configured rinparms struct
  @param ident  (int)         Identity of the value asked for as given by get_graphident()
  @param array  (float *)     Array that contains the ring parameters
  @param errarr
  @param larray (float *)     Array containing the subring parameters
  
  @return (success) static int fillgrapharray: 1
          (error)   0
*/
/* ------------------------------------------------------------ */
static int fillgrapharray(hdrinf *hdr, ringparms *rpm, int ident, float *array, float *larray);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int get_graphident(char *string, char *axis, char *unit, char *altunit, char *legend)
  @brief Returns the identifyer of a graphics output

  The function returns the identifyer of a graphics output identifyer. The value is not negative if the string input is identified with a variable parameter, or with a valid other graphics output keystring. In case of a variable parameter identifyer, this is identical with the RADI, etc identifyer, otherways with the NPARAMS+WANGLE_GRAPHNR, ... . At the same time the strings axis unit and legend are filled with appropriate values to produce an output with the pgp module. If the value of axis, unit, and legend are NULL, this is no error. If, however, one of those is not NULL, the strings must have at least a minimum length as given below. 

  @param string  (char *) Input string that should be scanned
  @param axis    (char *) Output, axis descriptor string (at least 4 characters)
  @param unit    (char *) Output, unit string (at least 30 characters)
  @param altunit (char *) Output, Alternative unit string to the right (top) axis (at least 30 characters)
  @param legend  (char *) Output, legend string (at least 80 characters)

  @return (success) int get_graphident: Identification for a graphics output
          (error)   -1 In case of an invalid string
*/
/* ------------------------------------------------------------ */
static int get_graphident(char *string, char *axis, char *unit, char *altunit, char *legend);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int renzo(loginf *log, hdrinf *hdr, ringparms *rpm)
  @brief Produces a renzogram with the rings

  @param log  (loginf *)    Properly configured loginf struct
  @param hdr  (hdrinf *)    Properly configured hdrinf struct
  @param rpm  (ringparms *) Properly configured ringparms struct
  @return (success) int renzo: 0
          (error)   1
*/
/* ------------------------------------------------------------ */
static int renzo(loginf *log, hdrinf *hdr, ringparms *rpm);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static qfits_header *makerenzohdr(hdrinf *hdr, int planes, int refine)
  @brief Produces a header struct for renzogram output

  Produces a qfits_header object suitable for the renzogram output.

  @param  hdr    (hdrinf *) Properly configured hdrinf struct
  @param  planes (int)      Number of planes
  @param  refine (int)      How many pixels in the outcube fit in one pixel of the incube.

  @return (success) qfits_header *makecoolhdr: The properly configured header
          (error)   NULL
*/
/* ------------------------------------------------------------ */
static qfits_header *makerenzohdr(hdrinf *hdr, int planes, int refine);


/*************/
/* Addendums under construction */
/*************/
/* #include "constr.h" */
/*************/

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION CODE */
/* ------------------------------------------------------------ */

MAIN_PROGRAM_ENTRY
{
  loginf *log = NULL;
  hdrinf *hdr = NULL;
  ringparms *rpm = NULL;
  fitparms *fit = NULL;
  fint i;
  int j;
  int nrplts;
  char mes[81];

  /**************/
   /**************/ 
/*   fint obsint = 0; */
/*   char obsmes[80]; */
  /**************/
   
 /**************/
  /**************/
/*   sprintf(obsmes, "got here"); */
/*   anyout_c(&obsint, tofchar(obsmes));  */
  /**************/

   init_c();
  IDENTIFICATION("TIRIDEV", "1.0");

  if (!(log = get_loginf()))
    goto error;
  if (!(hdr = get_hdrinf(log)))
    goto error;

  if (!(rpm = get_ringparms(log, hdr)))
    goto error;

  if (!(fit = get_fitparms(log, hdr, rpm)))
    goto error;

  if ((j = open_hdu_3(log, hdr, rpm, fit)) == 1)
    goto error;
  else if (j == 2)
    ;
  else if (j == 0) {
    prepout(log, hdr, rpm);
    
    if (fit -> fitmode == METROPOLIS) { 
      if (!metropolis(log, hdr, rpm, fit)) {
	goto error;
      }
      if (!putmetresults(log, rpm, fit)) {
	goto error;
      }
    }
    else if (fit -> fitmode == GOLDEN_SECTION) { 
      if (!golden_section(log, hdr, rpm, fit))
	goto error;
    if (!putgoldresults(log, rpm, fit))
      goto error;
    }
  }

  /* Put the results in an ascii table */
  writeasctable(log, hdr, rpm, fit);

  /* Put the results for each subring in an ascii table */
  writebigasctable(log, hdr, rpm, fit);

  /* Graphics */
  nrplts = graphout(log, hdr, rpm);

  nrplts = ((nrplts))?nrplts:1;

  briggsout(log, hdr, rpm);

  /* Output of a def file */
  tirout(log, rpm, nrplts);

  /* Output of a histogram */
  histout(rpm);

  /* Rectify output */
  rectout(log, hdr, rpm);

  /* Tiltogram output */
  tiltout(log, hdr, rpm);

  /* Write the output cube */
  i = 1;
  if ((*hdr -> outset != '\0')) {

    /* We read all values into the par array */
    ftstab_get_grid_(log -> outarray);

    for (i = 0; i < rpm -> nur*NPARAMS+NSPARAMS; ++i)
      rpm -> oldpar[i] = log -> outarray[i];

    changetointern(rpm -> oldpar, rpm -> nur, hdr);

    /* Now we write it */
    writemodel(hdr, rpm);
    gds_close_c(tofchar(hdr -> outset), &i);
  }

  /* Renzo */
  renzo(log, hdr, rpm);

  /* Cool */
  coolgal(log, hdr, rpm);

  ftstab_putminmax_();
  ftstab_close_();
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();

  if ((log -> tstream))
    fclose(log -> tstream);
  log -> tstream = NULL;


  destroy_loginf(log);
  destroy_hdrinf(hdr);
  destroy_fitparms(fit);
  destroy_ringparms(rpm);
  finis_c();
  return 1;

 error:
  i = 0;
  sprintf(mes, "ABORTING: Memory problems, unwise parameters, user abort");
  anyout_c(&i, tofchar(mes));

  if ((log))
    destroy_loginf(log);
  if ((hdr))
    destroy_hdrinf(hdr);
  if ((rpm))
    destroy_ringparms(rpm);
  if ((fit))
    destroy_fitparms(fit);

  ftstab_close_();
  ftstab_flush_();

  finis_c();
  return 0;
}



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a fortran compatible char array */

static char *getfcharray(int length)
{
  char *getfcharray;
  if (!(getfcharray = (char *) malloc((length+1)*sizeof(char))))
    return NULL;

  getfcharray[length--] = '\0';
  while(length != 0)
    getfcharray[--length] = ' ';
  return getfcharray;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a loginf structure */

static loginf *create_loginf(void)
{
  loginf *log;
  
  /* Allocate the struct */
  if (!(log = (loginf *) malloc(sizeof(loginf))))
    return NULL;
  
  /* First set all pointers to 0 and initialise some pointers */
  log -> logname = NULL;
  log -> logpres = 1;
  log -> tstream = NULL;
  log -> textlog = NULL;
  log -> table = NULL;
  log -> outarray = NULL;
  log -> changes = 0;

  /* Allocate and terminate */
  if (!(log -> logname =  getfcharray(18)))
    goto error;
  if (!(log -> textlog =  getfcharray(18)))
    goto error;
  if (!(log -> table =  getfcharray(18)))
    goto error;
  
  return log;
  
 error:
  destroy_loginf(log);
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destroys a loginf structure */

static void destroy_loginf(loginf *log)
{
  /* Make it safer against unwarranted use */
  if (!(log))
    return;

  /* Deallocate */
  if (log -> logname) {
    free(log -> logname);
    log -> logname = NULL;

    if (!(log -> logpres)) {
      ftstab_flush_();
      ftstab_hdlreset_();
      hdl_init();
    }
  }
  if (log -> textlog != NULL) {
    free(log -> textlog);
    log -> textlog = NULL;
  }
    if (log -> table != NULL) {
    free(log -> table);
    log -> table = NULL;
  }
  if (log -> outarray != NULL) {
    free(log -> outarray);
    log -> outarray = NULL;
  }
  free(log);
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a hdrinf structure */

static hdrinf *create_hdrinf(void)
{
  hdrinf *create_hdrinf;

  /* Allocate the struct */
  if (!(create_hdrinf = (hdrinf *) malloc(sizeof(hdrinf))))
    return NULL;
  
  /* First set all pointers to 0 */
  create_hdrinf -> inset = NULL;
  create_hdrinf -> insubs = NULL;
  create_hdrinf -> cwlo = NULL;
  create_hdrinf -> cwhi = NULL;
  create_hdrinf -> ori = NULL;
  create_hdrinf -> model = NULL;
  create_hdrinf -> outset = NULL;
  create_hdrinf -> chi2 = DBL_MAX;
  create_hdrinf -> oldchi2 = DBL_MAX;

  /* Allocate and initialise the arrays */
  
  /* Allocate inset, we allow for 18 characters */
  if (!(create_hdrinf ->inset = getfcharray(18)))
    goto error;
  
  /* Allocate coordinate descriptor array */
  if (!(create_hdrinf -> insubs = (fint *) malloc(MAXNSUBS*sizeof(fint))))
    goto error;

  /* Allocate outset, we allow for 18 characters */
  if (!(create_hdrinf -> outset =  getfcharray(18)))
    goto error;

  return create_hdrinf;
  
 error:
  destroy_hdrinf(create_hdrinf);
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destroys a hdrinf structure */

static void destroy_hdrinf(hdrinf *hdr)
{
  /* Make it safer against unwarranted use */
  if (!(hdr))
    return;

  if (hdr -> inset !=  NULL)
    free(hdr -> inset);
  if (hdr ->insubs != NULL)
    free(hdr -> insubs);

  if (hdr -> cwhi != NULL)
    free(hdr -> cwhi);
  if (hdr -> cwlo != NULL)
    free(hdr -> cwlo);
  if (hdr -> ori != NULL)
    free_engalmod(hdr -> ori);
  if (hdr -> model != NULL)
    free_engalmod(hdr -> model);
  if (hdr -> outset != NULL)
    free(hdr -> outset);


  /* Deallocate the struct */
  free(hdr);
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Initialisation of the program concerning info from the dataset */
static loginf *get_loginf(void) 
{
  loginf *log;
  char mes[81];
  char key[9];
  char value[81];
  char version[21];
  fint def, nel;
  int mode = 1;
  int err;
  double adouble;

  /**************/
  /**************/
  /*  fint obsint = 0; */
  /*   char obsmes[80]; */
  /**************/

  int i;

  /* Try to allocate */
  if (!(log = create_loginf()))
    goto error;

  /* First thing to do is the logfile and the text logfile */

  /* The logfile */
  sprintf(mes, "Give logfile name.");
  sprintf(log -> logname, "                  ");

  /* Formerly def = 5 */
  def = 4;
  nel = 1;
  userchar_c(tofchar(log -> logname), &nel, &def, tofchar("LOGNAME="), tofchar(mes));

  /* This puts an \0 to the end of the text */
  termsinglestr(log -> logname);

  /* If there is no logfile specified we simply terminate the logname */
  if (*log -> logname == '\0') {
    free(log -> logname);
    log -> logname = NULL;
  }

  /* Initialise the table content object */
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();

  /* Now we try to open the table object with the logfile name */
  if ((log -> logname)) {

    /* Try to open the file to check if it is already present */
    log -> logpres = ftstab_fopen(log -> logname, 1, 2, 1);

    /* If yes, check if it is properly created, mode = 1 -> yes, mode = 0 -> no */
    if (!(log -> logpres)) {
      sprintf(key, "CREATOR");
      if (ftstab_getcard(0, key, value, 1)) {
 if (strcmp(value, "'TIRIFIC           '")){
   mode = 0;
 }
      }
      else 
 mode = 0;

      sprintf(key, "VERSION");
      if (ftstab_getcard(0, key, value, 1)) {
 sprintf(version,"'V%02i               '", VERSION_NUMBER);
 if (strcmp(value, version)){
   mode = 0;
 }
      }
      else 
 mode = 0;

      sprintf(key, "STATUS");
      if (ftstab_getcard(0, key, value, 1)) {
 if (strcmp(value, "'OK                '")){
   mode = 0;
 }
      }
      else
 mode = 0;
    }
    else if (log -> logpres == 2)
      mode = 1;
    else 
      mode = 0;


    if (!(mode)) {
    /* If there is something odd, ask the user wheter to proceed */
    sprintf(mes, "LOGFILE: wrong file type, CREATOR, VERSION, or STATUS, overwrite? [YES]");
    sprintf(key,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(key), &nel, &def, tofchar("PROCEED="), tofchar(mes));

    /* Not yes means no, stop things */
    if (strcmp(key,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));

    /* Furthermore we will simply overwrite the file */
    ftstab_flush_();  
    ftstab_hdlreset_();
    hdl_init();
    log -> logpres = 1;
    }
  }

  /***************/
  /***************/
  /***************/
  /***************/
/*   Checkit  */
/*   if (!(log -> logpres)) { */
/*     for (mode = 0; mode < PRIMHDN_SINGLE; ++mode) { */
/*       ftstab_get_value(1L, mode+1, &obsdouble); */
/*       sprintf(obsmes, "%i %s: %f", mode, ftstab_gtitl(NPARAMS+NSPARAMS+mode+1), obsdouble); */
/*       anyout_c(&obsint, tofchar(obsmes)); */
/*     } */

/*    Now the parameters  */
/*     for (mode = 1; mode <= NPARAMS; ++mode) { */
/*       for (i = 0; i < 3; ++i) { */
/*  ftstab_get_value(1L, PRIMHDN_SINGLE+(mode-1)*3+i+1, &obsdouble); */
/*       sprintf(obsmes, "%i %s: %f", mode, ftstab_gtitl(mode), obsdouble); */
/*       anyout_c(&obsint, tofchar(obsmes)); */

/*       } */
/*     } */
/*     for (param = 1; param <= NSPARAMS; ++param) { */
/*       ftstab_fillhd(PRIMHDN_SINGLE+NPARAMS*rpm -> nur+param-1, param+NPARAMS, COLTYPE_DOUBLE, COLRADI_DEFAULT, COLGRID_DEFAULT); */
/*     } */
/*   } */
  /***************/

  /* The text logfile */


  if ((log -> logname) && !(log -> logpres)) {
    sprintf(key, "TEXTLOG");
    sprintf(version, "'                  '");
    ftstab_getcard(0, key, version, 1);
    termsinglestr(version);
    version[19] = '\0';
    for (i = 1; i < 19; ++i) {
      if (i <  strlen(version))
	log -> textlog[i-1] = version[i];
      else
	log -> textlog[i-1] = ' ';
    }
    log -> textlog[19] = '\0';
    def = 2;
  }
  else {
    for (i = 0; i < 18; ++i)
      log -> textlog[i] = ' ';
    log -> textlog[19] = '\0';
    def = 2;
  }
  
  sprintf(mes, "Give text logfile name.");
  nel = 1;

  userchar_c(tofchar(log -> textlog), &nel, &def, tofchar("TEXTLOG="), tofchar(mes));

  /* This puts an \n to the end of the text */
  termsinglestr(log -> textlog);

  i = 0;
  /* Now we compare the textlog with the log and ask if it is ok */
  if ((log -> logname) && !(log -> logpres)) {
    if (strcmp(version+1, log -> textlog))
      i = 1;
  }

  if ((i)) {
    sprintf(mes, "TEXTLOG: logfile |%s| contains different name, proceed? [YES]", log -> textlog);
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;
    
    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));

    /* Moreover we change the name of the inset */
    ftstab_putcard(0, key, log -> textlog);
  }

  /*************/

  /* The result name */
  if ((log -> logname) && !(log -> logpres)) {
    sprintf(version, "'                  '");
    sprintf(key, "TABLE");
    ftstab_getcard(0, key, version, 1);
    termsinglestr(version);
    version[19] = '\0';
    for (i = 1; i < 19; ++i) {
      if (i <  strlen(version))
 log -> table[i-1] = version[i];
      else
 log -> table[i-1] = ' ';
    }
    log -> table[19] = '\0';
  }
  else {
    for (i = 0; i < 18; ++i)
      log -> table[i] = ' ';
    log -> table[19] = '\0';
  }
  
  sprintf(mes, "Give output table name.");
  nel = 1;
  def = 2;

  userchar_c(tofchar(log -> table), &nel, &def, tofchar("TABLE="), tofchar(mes));

  /* This puts an \0 to the end of the text */
  termsinglestr(log -> table);

  i = 0;
  /* Now we compare the textlog with the log and ask if it is ok */
  if ((log -> logname) && !(log -> logpres)) {
    if (strcmp(version+1, log -> table))
      i = 1;
  }

  if ((i)) {
    sprintf(mes, "TABLE: logfile contains different name, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;
    
    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));

    /* Moreover we change the name of the inset */
    ftstab_putcard(0, key, log -> table);
  }

  /* Now get the distance of the object */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, DISTANCE_PRIMPOS, &log -> distance);
    def = 2;
  }
  else {
    log -> distance = 10;
    def = 2;
  }

  sprintf(mes,"Distance in Mpc [10]");
  nel = 1;
  userdble_c(&log -> distance, &nel, &def, tofchar("DISTANCE="), tofchar(mes));
  while (log -> distance <= 0) {
    sprintf(mes,"DISTANCE must be greater than zero.");
    log -> distance = 10;
    cancel_c(tofchar("DISTANCE="));
    userdble_c(&log -> distance, &nel, &def, tofchar("DISTANCE="), tofchar(mes));
  }

      /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, DISTANCE_PRIMPOS, &adouble);
    if (maths_checkeq(adouble, log -> distance, DOUBLE_ACCURACY)) {
      err = 1;
    }
  }

  if ((err)) {
    sprintf(mes, "DISTANCE: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));
    log -> changes = 1;

    /* Furthermore we change the cflux*/
    ftstab_putval(1L, DISTANCE_PRIMPOS, log -> distance);
  }


  /**************/

  return log;
  
 error:
  if ((log)) {
    /* Stop the logfile io */
    ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();
    destroy_loginf(log);
  }
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Initialisation of the program concerning info from the dataset */
static hdrinf *get_hdrinf(loginf *log) 
{
  hdrinf *hdr; /* The output */

  fint dev;      /* Output device */
  fint def;      /* Any default mode */
  fint nel;      /* Number of elements */
  fint class;    /* A class for the input of a set */
  fint classdim; /* Some other thing necessary for io of datasets */
  fint option;   /* Input to gdsbox */
  fint err;      /* Error code */
  fint outerr;   /* Error heaviness for output */
  fint level;    /* Strange level thingy */
  char mes[81];  /* Any message */
  char manual = 0; /* Signal for manual input */

  char ciax[9]; /* Keyword holder */
  char value[21]; /* Value holder */ 
  int i,j;         /* Control variable */

  double deltsettouser[3]; /* Conversion factor from cuniti to userdeltunit */
  double setcdelt[3]; /* The cdelts in the set */
  double setcrval[3]; /* The reference values in the set */
  double userdeltcdelt[3]; /* The cdelt in delta user units */

  /* dummies */
  fint inaxcount[MAXNAX];
  fint outaxperm[MAXNAX];
  fint outaxcount[MAXNAX];
  fint outsubs[MAXNSUBS];
  fint blo[3]; /* Contains lower values for subset dimensions for 2 axes */
  fint bhi[3]; /* Contains higher values for subset dimensions for 2 axes */
  double vardouble; /* Any double */
  double adouble;

  /* Just to pass pointers (FORTRAN ...) */
  fint maxnsubs = MAXNSUBS;
  fint maxnax = MAXNAX;

  /**************/
  /* fint obsint = 0; */
  /* char obsmes[80]; */
  /*************/
  /*************/

  if (!(hdr = create_hdrinf()))
    goto error;

  /* Input set and subsets and box are in any case necessary, even with a present logfile */
  err = 0;
  sprintf(mes, "Give input set and subsets.");
  def = 0;
  dev = 0;
  class = 1;
  classdim = 2;
  
  /* Get information about input dataset */
  hdr -> nsubs = gdsinp_c(tofchar(hdr -> inset), hdr -> insubs, &maxnsubs, &def, tofchar("INSET="), tofchar(mes), &dev, hdr -> inaxperm, inaxcount, &maxnax, &class, &classdim);
  termsinglestr(hdr -> inset);

  /* A box has to be defined inside the specified set, on default whole dataset , not exactly understood */
  sprintf((mes), "Give area of operation.");
  def = 1;
  dev = 1;
  option = 1;
  gdsbox_c(blo, bhi, tofchar(hdr -> inset), hdr -> insubs, &def, tofchar("BOX="), tofchar(mes), &dev, &option);
  def = 0;
 
 /* The degree of error is not warning (1) but fatal (4) */
    outerr = 4;

  /* Check the dataset */
  for (i = 0; i < 3; ++i) {

    /* This is a simple check if CTYPEi is present in the header */
    err = 0;
    sprintf(ciax, "CTYPE%i", hdr -> inaxperm[i]);

    /* For level refer to the description */
    level = 0;
    for (j = 0; j < 20; ++j)
      value[j] = ' ';
    value[20] = '\0';
    gdsd_rchar_c(tofchar(hdr -> inset), tofchar(ciax), &level, tofchar(value), &err);
    if (err < 0) {
      sprintf(mes, "Header: CTYPE%i not found.", i);
      error_c(&outerr, tofchar(mes));
    }
    
    /* This is a simple check if CUNITi is present in the header */
    err = 0;
    sprintf(ciax, "CUNIT%i", hdr -> inaxperm[i]);
    for (j = 0; j < 20; ++j)
      value[j] = ' ';
    value[20] = '\0';
    gdsd_rchar_c(tofchar(hdr -> inset), tofchar(ciax), &(level), tofchar(value), &err);
    if (err < 0) {
      sprintf(mes, "Header: CUNIT%i not found.", i);
      error_c(&outerr, tofchar(mes));
    }
    
    /* This is a check whether the cunit can be converted to modelspacunit, modelmapunit, respectively. At the same time deltsettouser and  globsettouser is filled with that conversion factor */
    if (i < 2) {
      err = factor_c(tofchar(value), tofchar(userdeltunit), deltsettouser+i);
      if (err) {
	dev = 0;
	sprintf(mes, "Header: Invalid CUNIT%i", i);
	error_c(&outerr, tofchar(mes));
      }
      factor_c(tofchar(value), tofchar(userglobunit), hdr -> globsettouser+i);
    }
    else {
      err = factor_c(tofchar(value), tofchar(user3deltunit), deltsettouser+i);
      if (err) {
	sprintf(mes, "Header: Invalid CUNIT%i", i);
	error_c(&outerr, tofchar(mes));
      }
      factor_c(tofchar(value), tofchar(user3globunit), hdr -> globsettouser+i);
      err = 0;
    }
 

    /* Now check the cdelt */
    sprintf(ciax, "CDELT%i", hdr -> inaxperm[i]);
    for (j = 0; j < 20; ++j)
      value[j] = ' ';
    value[20] = '\0';

    level = 0;
    gdsd_rdble_c(tofchar(hdr -> inset), tofchar(ciax), &level, setcdelt+i, &err);
    if (err < 0) {
      sprintf(mes, "Header: CDELT%i not found.", i);
      error_c(&outerr, tofchar(mes));
    }
    err = 0;
    
    /* Now the crpix */
    sprintf(ciax, "CRPIX%i", hdr -> inaxperm[i]);
    for (j = 0; j < 20; ++j)
      value[j] = ' ';
    value[20] = '\0';
    
    /* For level refer to the description */
    level = 0;
    gdsd_rdble_c(tofchar(hdr -> inset), tofchar(ciax), &level, hdr -> setcrpix+i, &err);
    if (err < 0) {
      sprintf(mes, "Header: CRPIX%i not found.", i);
      error_c(&dev, tofchar(mes));
    }

    /* Now the crval */
    sprintf(ciax, "CRVAL%i", hdr -> inaxperm[i]);
    for (j = 0; j < 20; ++j)
      value[j] = ' ';
    value[20] = '\0';
    
    /* For level refer to the description */
    level = 0;
    gdsd_rdble_c(tofchar(hdr -> inset), tofchar(ciax), &level, setcrval+i, &err);
    if (err < 0) {
      sprintf(mes, "Header: CRVAL%i not found.", i);
      error_c(&dev, tofchar(mes));
    }


    /* The cdelt of the axis in user units, the size of a grid in user units */
    userdeltcdelt[i] = setcdelt[i]*deltsettouser[i];
    hdr -> userglobcdelt[i] = setcdelt[i]*hdr -> globsettouser[i];

    /* The conversion factors for the user */
    hdr -> deltgridtouser[i] = fabs(userdeltcdelt[i]);
    hdr -> globgridtouser[i] = fabs(hdr -> userglobcdelt[i]);

    /* The reference values of the axis in user units */
    hdr -> userglobcrval[i] = setcrval[i]*hdr -> globsettouser[i];
  }

  hdr -> signv = -setcdelt[2]/fabs(setcdelt[2]);
  
  /* Calculate the size of the cube in grids along axis 1 and 2 */
  hdr -> bsize1=bhi[0]-blo[0]+1;
  hdr -> bsize2=bhi[1]-blo[1]+1;
  hdr -> bcsize1= 2*(hdr -> bsize1/2+1);


  /* The size of the cube in grids along axis 3 is given by hdr -> nsubs, get the values of the max and min grid */
  i = 0;
  blo[2] = gdsc_grid_c(tofchar(hdr -> inset), hdr -> inaxperm+2, hdr -> insubs+i, &err);
  i = hdr -> nsubs-1;
  bhi[2] = gdsc_grid_c(tofchar(hdr -> inset), hdr -> inaxperm+2, hdr -> insubs+i, &err);

  /* We check if the inset name is consistent with the present header content */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    sprintf(ciax, "INSET");
    ftstab_getcard(0, ciax, value, 1);
    termsinglestr(value);
    value[18] = '\0';
    if (strcmp(value+1, hdr -> inset/* , strlen(hdr -> inset) */)){
      err = 1;
    }
  } 

  /* If the given name is new, we ask whether to proceed */
    if ((err)) {
    sprintf(mes, "INSET: logfile contains different name, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));

    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));

    log -> changes = 1;

    /* Moreover we change the name of the inset */
    ftstab_putcard(0, ciax, hdr -> inset);
    }
  
  /* Get beam properties */
    /* BUGFIX: removed the possibility to read beam properties from header */

    /* First check whether this goes automatic */

  /* If the cdelt is the same for both spatial axes, go on */ 
  if (fabs(hdr -> userglobcdelt[0]) == fabs(hdr -> userglobcdelt[1])) {
    err = 0;
    
    /* check if major axis can be read from the dataset */
    gdsd_rdble_c(tofchar(hdr -> inset), tofchar("BMAJ"), &level, &vardouble, &err);
    if (err < 0)

      /* This is a signal have it manually */
      manual = 1;
    else {
      outerr = 0;

      /* This is done under the assumption that the beam is given in set units */
      hdr -> bmaj = (float) vardouble/fabs(setcdelt[0]);
/*       sprintf(mes, "Beam major axis in arcsec: %f", hdr -> bmaj*fabs(setcdelt[0])); */
/*       anyout_c(&outerr, tofchar(mes)); */
    }
    err = 0;
    
    /* check if minor axis can be read from the dataset */
    gdsd_rdble_c(tofchar(hdr -> inset), tofchar("BMIN"), &level, &vardouble, &err);
    if (err < 0)
      
      /* This is a signal have it manually */
      manual = 1;
    else {
      outerr = 0;
      /* This is done under the assumption that the beam is given in set units */
      hdr -> bmin = (float) vardouble/fabs(setcdelt[1]);
/*       sprintf(mes, "Beam minor axis in arcsec: %f", hdr -> bmin*fabs(setcdelt[1])); */
/*       anyout_c(&outerr, tofchar(mes)); */
    }
    err = 0;
    
    /* check for the bpa */
    gdsd_rdble_c(tofchar(hdr -> inset), tofchar("BPA"), &level, &vardouble, &err);
    if (err < 0)
      
      /* This is a signal have it manually */
      manual = 1;
    else {
      outerr = 0;
      /* CAUTION !!!!! This is done under the assumption that the bpa is always in deg */
      hdr -> bpa = (float) vardouble;
/*       sprintf(mes, "Beam position angle in degrees: %f", hdr -> bpa); */
/*       anyout_c(&outerr, tofchar(mes)); */
    }
  }
  
  /* If the cdelts are different we pose a warning and enforce manual reading */
  else {
    outerr = 0;
    anyout_c(&outerr, tofchar("cdelt of axis1 and axis2 are different"));
    manual = 1;
  }

   /* BUGFIX: removed the possibility to read beam properties from header. This caused too much confusion */
  manual = 1;

  /* The beam major and minor axis has to be read in manually */
  if (manual) {
    /* If a proper logfile is present, we set a default and the beam properties are hidden */
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, BMAJ_PRIMPOS, &vardouble);
      hdr -> bmaj = (float) vardouble;
      ftstab_get_value(1L, BMIN_PRIMPOS, &vardouble);
      hdr -> bmin =  (float) vardouble;
      ftstab_get_value(1L, BPA_PRIMPOS, &vardouble);
      hdr -> bpa = (float) vardouble;
      def = 2;
    }
    else def = 4;

    sprintf(mes, "Give HPBW of the gaussian beam, major axis, in arcsec.");
    nel = 1;
    userreal_c(&hdr -> bmaj, &nel, &def, tofchar("BMAJ="), tofchar(mes));
    
    sprintf(mes, "Give HPBW of the gaussian beam, minor axis, in arcsec.");
    nel = 1;
    userreal_c(&hdr -> bmin, &nel, &def, tofchar("BMIN="), tofchar(mes));

    sprintf(mes, "Give BPA of the gaussian beam in degrees.");
    nel = 1;
    userreal_c(&hdr -> bpa, &nel, &def, tofchar("BPA="), tofchar(mes));

    /* Convert from arcsec to grids */
    hdr -> bmaj = hdr -> bmaj/hdr -> deltgridtouser[0];
    hdr -> bmin = hdr -> bmin/hdr -> deltgridtouser[0];
  }

  /* Now check if the beam properties are consistent with the log */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, BMAJ_PRIMPOS, &vardouble);
    if (maths_checkeq(hdr -> bmaj * hdr -> deltgridtouser[0], vardouble, FLOAT_ACCURACY))
      ++err;
    ftstab_get_value(1L, BMIN_PRIMPOS, &vardouble);
    if (maths_checkeq(hdr -> bmin * hdr -> deltgridtouser[0], vardouble, FLOAT_ACCURACY))
      ++err;
    ftstab_get_value(1L, BPA_PRIMPOS, &vardouble);
    if ( maths_checkeq(hdr -> bpa, vardouble, FLOAT_ACCURACY))
      ++err;
  }

  if ((err)) {
    sprintf(mes, "BEAM PROPERTIES: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    log -> changes = 1;
    
    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));

    /* Furthermore we change the values of the beam */
    vardouble = hdr -> bmaj * hdr -> deltgridtouser[0];
    ftstab_putval(1L, BMAJ_PRIMPOS, vardouble);
    vardouble = hdr -> bmin * hdr -> deltgridtouser[0];
    ftstab_putval(1L, BMIN_PRIMPOS, vardouble);
    vardouble = hdr -> bpa;
    ftstab_putval(1L, BPA_PRIMPOS, vardouble);
  }

  /* Check for the correct intensity units */
  err = 0;
  for (j = 0; j < 20; ++j)
    value[j] = ' ';
  value[20] = '\0';
  gdsd_rchar_c(tofchar(hdr -> inset), tofchar("BUNIT"), hdr -> insubs, tofchar(value), &err);
  if ((err == 0) || (err == hdr -> insubs[0])) {
    if(!strcmp(value, "JY/BEAM") || !strcmp(value, "jy/beam")) {
      sprintf(mes,"Units in the maps should be JY/BEAM, found: |%s|", value);
      dev = 0;
      anyout_c(&dev, tofchar(mes));
      outerr = 1;
      error_c(&outerr, tofchar("Check if that is ok."));
    }
  }
  else {
    outerr = 1;
    error_c(&outerr, tofchar("No units in the maps found."));
  }

  /* Allocate memory for cwlo and -hi */
  if (!(hdr -> cwhi = (fint *) malloc(hdr -> nsubs*sizeof(fint))))
   goto error;
  if (!(hdr -> cwlo = (fint *) malloc(hdr -> nsubs*sizeof(fint))))
    goto error;

  /* check the subset grid and set it: The grid value is the relative position with respect to the reference pixel as integer */
  for (i = 0; i < 0+hdr -> nsubs; ++i) {
    hdr -> cwlo[i] = gdsc_fill_c(tofchar(hdr -> inset),hdr -> insubs+i, blo);
    hdr -> cwhi[i] = gdsc_fill_c(tofchar(hdr -> inset),hdr -> insubs+i, bhi);
  }
  
  /* Input of rms */
  err = 0;
  level = 0 ;
  gdsd_rreal_c(tofchar(hdr -> inset), tofchar("RMS"), &level, &hdr -> rms, &err);
  if (err < 0) {
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, RMS_PRIMPOS, &vardouble);
      hdr -> rms = (float) vardouble;
      def = 2;
    }
    else {
      def = 4;
    }

    sprintf(mes, "Give sigma_rms for input map in map units. [Jy/beam]");
    nel = 1;
    userreal_c(&hdr -> rms, &nel, &def, tofchar("RMS="), tofchar(mes));
    while (hdr -> rms <= 0) {
      sprintf(mes, "Sigma must be positive");
      reject_c(tofchar("RMS="), tofchar(mes));
      sprintf(mes, "Give sigma_rms for input map in map units. [Jy/beam]");
      nel = 1;
      userreal_c(&hdr -> rms, &nel, &def, tofchar("RMS="), tofchar(mes));
    }
  }

  /* Now check for consistency */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, RMS_PRIMPOS, &vardouble);
    if (maths_checkeq(hdr -> rms, vardouble, FLOAT_ACCURACY))
      ++err;
  }

  if ((err)) {
    sprintf(mes, "RMS: logfile contains different value, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));

    log -> changes = 1;

    /* Furthermore we change the values of the beam */
    vardouble = hdr -> rms;
    ftstab_putval(1L, RMS_PRIMPOS, vardouble);
  }

  /*******************/
  /*******************/
  /*******************/
  /*******************/
  /* Determine conversion factor for HI column density => intensity */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, ITOU_PRIMPOS, &adouble);
    hdr -> itou = adouble;
  }
  else {
    hdr -> itou = HICONVERSION;
  }

  sprintf(mes, "Give intensity to surface density conversion");
  def = 2;
  nel = 1;
  err = 0;
  while (!(err)) {
    userdble_c(&hdr -> itou, &nel, &def, tofchar("ITOU="), tofchar(mes));
    if (hdr -> itou <= 0.0) {
      sprintf(mes, "Must be positive! %f",hdr -> itou);
      cancel_c(tofchar("ITOU="));
      def = 1;
    }
  else 
    err = 1;
  }

  /* Check that */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, ITOU_PRIMPOS, &adouble);
    if (maths_checkeq(hdr -> itou, adouble, DOUBLE_ACCURACY)) {
      sprintf(mes, "ITOU: logfile contains different values, proceed? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));log -> changes = 1;
      
      /* Furthermore we update the table */
      ftstab_putval(1L, ITOU_PRIMPOS, hdr -> itou);
    }
  }

  /* Get rest frequency */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, RFREQ_PRIMPOS, &adouble);
    hdr -> rfreq = adouble;
  }
  else {
    hdr -> rfreq = HIRESFREQ;
  }

  sprintf(mes, "Give rest frequency");
  def = 2;
  nel = 1;
  err = 0;
  while (!(err)) {
    userdble_c(&hdr -> rfreq, &nel, &def, tofchar("RFREQ="), tofchar(mes));
    if (hdr -> rfreq <= 0.0) {
      sprintf(mes, "Must be positive!");
      cancel_c(tofchar("RFREQ="));
      def = 1;
    }
  else 
    err = 1;
  }

  /* Check that */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, RFREQ_PRIMPOS, &adouble);
    if (maths_checkeq(hdr -> rfreq, adouble, DOUBLE_ACCURACY)) {
      sprintf(mes, "RFREQ: logfile contains different values, proceed? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));log -> changes = 1;
      
      /* Furthermore we update the table */
      ftstab_putval(1L, RFREQ_PRIMPOS, hdr -> rfreq);
    }
  }

  /*******************/
  /*******************/


  /* Don't try to do this again! */
  /*  hdr -> cd2i = 1.5147016e-21 + fabs(hdr -> cdelt3)*pow(hdr -> cdelt3*hdr -> midgrid/hdr -> freq0+2.9979246e5/hdr -> drval3, 2); */
  /* Determine conversion factor for Jy/arcsec^2 to Jy/pixel, deltgridtouser is in arcsec */
  hdr -> jygridtouser = hdr -> deltgridtouser[2]/fabs(hdr -> deltgridtouser[0]*hdr -> deltgridtouser[1]);

  
  /* This could in principle be done elsewhere..., but we can also place it here */
  hdr -> nprof = hdr -> bsize1*hdr -> bsize2;
  
  /* Reserve memory */
  if (!(hdr -> ori = (float *) malloc_engalmod(hdr -> bcsize1*hdr -> bsize2*hdr -> nsubs*sizeof(float)))) {
    dev = 0;
    anyout_c(&dev, tofchar("Not enough memory to hold a single cube"));
    goto error;
  }
  if (!(hdr -> model = (float *) malloc_engalmod(hdr -> bcsize1*hdr -> bsize2*hdr -> nsubs*sizeof(float)))) {
    anyout_c(&dev, tofchar("Not enough memory to hold two cubes"));
    goto error;
  }


  /* If a proper logfile is present, we set a default and the outset is hidden */
  if ((log -> logname) && !(log -> logpres)) {
    sprintf(ciax, "OUTSET");
    sprintf(value, "'                  '");
    ftstab_getcard(0, ciax, value, 1);
    termsinglestr(value);
    value[19] = '\0';
    for (i = 1; i < 19; ++i) {
      if (i <  strlen(value))
	hdr -> outset[i-1] = value[i];
      else
	hdr -> outset[i-1] = ' ';
    }
    hdr -> outset[19] = '\0';
    def = 2;
  }
  else {
    for (i = 0; i < 18; ++i)
      hdr -> outset[i] = ' ';
    hdr -> outset[19] = '\0';
    def = 5;
  }
  
  class = 1;
  i = 0;
  
  sprintf(mes, "Give output set [%s] %i", hdr -> outset, def);
  while(!(i)) {
    userchar_c(tofchar(hdr -> outset), &class, &def, tofchar("OUTSET="), tofchar(mes));
    if (!strcmp(hdr -> inset, hdr -> outset)) {
      dev = 0;
      sprintf(mes, "Must differ from inset name %s", hdr -> inset);
      anyout_c(&dev, tofchar(mes));
      cancel_c(tofchar("OUTSET="));
      def = 5;
    }
    else
      ++i;
  }
  termsinglestr(hdr -> outset);
  
  err = 0;
  /* Now we compare the outset with the log and ask if it is ok */
  if ((log -> logname) && !(log -> logpres)) {
    if (strcmp(value+1, hdr -> outset))
      err = 1;
  }
  
  if ((err)) {
    sprintf(mes, "OUTSET: logfile contains different name, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;
    
    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));
    
    /* Moreover we change the name of the inset */
    ftstab_putcard(0, ciax, hdr -> outset);
  }
  
  /* If there is an outset, we will open it, else we terminate it */
  if ((hdr -> outset[0])) {
    i = 1;
    /* Copy the information of inset to outset prior to reading it */
    gdsasn_c(tofchar("INSET="), tofchar("OUTSET"), &i);
    gdscss_c(tofchar("OUTSET"), blo, bhi);
    
    def = 102;
    class = 0;
    gdsout_c(tofchar(hdr -> outset), outsubs, &hdr -> nsubs, &def, tofchar("OUTSET"), tofchar("mes"), &class , outaxperm, outaxcount, &maxnax);
    
    /* We want to get the number to refresh the output cube */
    
    /* First from the log if present */
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, OUTCUBUP_PRIMPOS, &adouble);
      hdr -> outcubup = (int) adouble;
    }
    else
      hdr -> outcubup = 1000000;

    def = 2;
    nel = 1;
    class = 0;
    
    while (!(class)) {
      userint_c(&hdr -> outcubup, &nel, &def, tofchar("OUTCUBUP="), tofchar(mes));
      
      if (hdr -> outcubup < 1) {
	sprintf(mes, "Outcubup is least 1!");
	cancel_c(tofchar("OUTCUBUP="));
	def = 1;
	class = 0;
      }
      else {
	++class;
      }
    }
    
    /* Check if the user has changed something, but don't ask */
    err = 0;
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, OUTCUBUP_PRIMPOS, &adouble);
      if ((int) adouble != hdr -> outcubup) {
	ftstab_putval(1L, OUTCUBUP_PRIMPOS, (double) hdr -> outcubup);
      }
    }
    
  }

  /* Finished */
  return hdr;
  
 error:
  if (hdr)
    destroy_hdrinf(hdr);
  if (log)
    destroy_loginf(log);
  
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a ringparms structure */
static ringparms *create_ringparms(void)
{
  ringparms *create_ringparms;

  if (!(create_ringparms = (ringparms *) malloc(sizeof(ringparms))))
    return NULL;

  /* Put numbers in the size descriptors */

  /* Initialise all the pointers */
  create_ringparms -> par = NULL;
  create_ringparms -> oldpar = NULL;
  create_ringparms -> permrandstr = NULL;
  create_ringparms -> modpar = NULL;
  create_ringparms -> sd = NULL;

  /* Allocate the memory */
  if (!(create_ringparms -> permrandstr = (maths_rstrf *) malloc(sizeof(maths_rstrf))))
     goto error;

  return create_ringparms;

 error:
  destroy_ringparms(create_ringparms);
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destroys a ringparms structure */
void destroy_ringparms(ringparms *prm)
{  
  /**************/
  /**************/
  /* fint obsint = 0; */
  /* char obsmes[80]; */
  /**************/

  /******/
  /******/
  /* sprintf(obsmes, "got here"); */
  /* anyout_c(&obsint, tofchar(obsmes)); */
  /******/

  /* Check if it is there */
  if (!(prm))
    return;

  if ((prm -> par))
    free(prm -> par);
  if ((prm -> oldpar))
    free(prm -> oldpar);
  if((prm -> permrandstr))
    free(prm -> permrandstr);
 if (prm -> modpar != NULL)
    free(prm -> modpar);
 if (prm -> sd != NULL)
   destroy_srd(prm -> sd, prm -> nr);

  free(prm);

  return;
}

/* ------------------------------------------------------------ */




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a list of subring descriptors with n elements */
static srd *create_srd(int n)
{
  int i;

  srd *sd;
  if (!(sd = (srd *) malloc(n*sizeof(srd))))
    return NULL;

  for (i = 0; i < n; ++i)
    (sd+i) -> pl = NULL;
  return sd;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a list of subring descriptors with n elements */
static void destroy_srd(srd *sd, int n)
{
  int i;

  if (!(sd))
    return;

  for (i = 0; i < n; ++i)
    free(sd[i].pl);

  free(sd);

  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Fill the ringparms struct from the input */
static ringparms *get_ringparms(loginf *log, hdrinf *hdr)
{
  ringparms *rpm;
  double globin[3];  /* For the conversion of coordinates in map units */
  double globout[3]; /* For the conversion of coordinates in map units */
  
  /* Private control and changing variables */
  double adouble;
  fint def;      /* Any default mode */
  fint nel;      /* Number of elements */
  fint err;      /* Error code */
  char mes[81];  /* Any message */
  char value[4]; /* Check whether it's large enough */

  int i,j,k; /* Simple control variables */


  /* Read values that are needed only in this module */
  fint mode; /* For memory handling */

  /**************/
/*     fint obsint = 0;   */
/*     char obsmes[81];  */
  /**************/
  /**************/
  /******/   
  /******/  
/*    sprintf(obsmes, "got here"); */
/*    anyout_c(&obsint, tofchar(obsmes));  */
  /******/   


  /* Get the struct */
  if (!(rpm = create_ringparms())) 
    goto error;

  /* Get the number of rings */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, NUR_PRIMPOS, &adouble);
    rpm -> nur = (int) adouble;
    def = 2;
  }
  else {
    def = 0;
  }

  i = 0;
  sprintf(mes, "Give number of rings. (arcsec)");
  while (!(i)) {
    nel = 1;
    userint_c(&rpm -> nur, &nel, &def, tofchar("NUR="), tofchar(mes));

    if (rpm -> nur < 2) {
      sprintf(mes, "At least 2!");
      cancel_c(tofchar("NUR="));
      i = 0;
    }
    else {

      /* Do some allocation that hides some variables in this function */
      if (!(rpm -> par = (double *) malloc((rpm -> nur*NPARAMS+NSPARAMS)*sizeof(double))))
 goto error;
      /* Do some allocation that hides some variables in this function */
      if (!(rpm -> oldpar = (double *) malloc((rpm -> nur*NPARAMS+NSPARAMS)*sizeof(double))))
 goto error;

      ++i;
    }
  }

  /* Calculate the varpars */
  rpm -> varpars = rpm -> nur*NPARAMS-1;

  /* Check for the values in the log */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, NUR_PRIMPOS, &adouble);
    if (rpm -> nur != roundnormal(adouble)) {
      sprintf(mes, "NUMBER OF RINGS: logfile contains different values, overwrite? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));
      
      /* Furthermore we close the table and set the flag to produce a new one */
      ftstab_flush_();
      ftstab_hdlreset_();
      hdl_init();
      log -> logpres = 2;
    }
  }

  /* The output array contains rpm -> maxparnur + 3 fields (3 -> chisquare, accept, number) */
  if (!(log -> outarray = (double *) malloc ((NPARAMS*rpm -> nur+NSPARAMS+OUTTABNR) * sizeof(double))))
    goto error;

  /* Get the subring width in grid units */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, RADSEP_PRIMPOS, &adouble);
    rpm -> radsep = adouble;
  }
  else {
    rpm -> radsep = 0.75;
  }

  sprintf(mes, "Give subring width (grids)");
  def = 2;
  nel = 1;
  err = 0;
  while (!(err)) {
    userdble_c(&rpm -> radsep, &nel, &def, tofchar("RADSEP="), tofchar(mes));
    if (rpm -> radsep <= 0.0) {
      sprintf(mes, "Must be positive!");
      cancel_c(tofchar("RADSEP="));
      def = 1;
    }
  else 
    err = 1;
  }

  /* Check that */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, RADSEP_PRIMPOS, &adouble);
    if (maths_checkeq(rpm -> radsep, adouble, DOUBLE_ACCURACY)) {
      sprintf(mes, "RADSEP: logfile contains different values, proceed? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));log -> changes = 1;
      
      /* Furthermore we update the table */
      ftstab_putval(1L, RADSEP_PRIMPOS, rpm -> radsep);
    }
  }

  /* Get the radii and the number of rings */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PRADI+i+1, rpm -> par + rpm -> nur*PRADI+i);
    def = 6;
  }
  else {
    def = 4;
  }

  sprintf(mes, "Give radii of rings. (arcsec)");
  err = 0;
  while (!(err)) {
    userdble_c(rpm -> par, &rpm -> nur, &def, tofchar("RADI="), tofchar(mes));
    
    /* Enforce the first radius to be 0 */
    if (rpm -> par[0] != 0.0) {
      sprintf(mes, "First radius has to be 0.0");
      
      /* The difference to reject is unclear to me */  
      cancel_c(tofchar("RADI="));
    }
    else {
      
      /* Turn the parameters into grids */
      for (i = PRADI*rpm -> nur; i < (PRADI+1)*rpm -> nur; ++i)
 rpm -> par[i] = dparamtointern(rpm -> par[i], RADI, hdr);
      
      /* Now check whether the modpar array can be constructed */
      /* Identify the number of subrings, the max radius of a subring is the max radius in parameter struct plus the half of the width of a subring, which is ususally 0.75 pixels  */
      rpm -> nr = ((int) (rpm -> par[(PRADI+1)*rpm -> nur-1]/rpm -> radsep-0.5))+1;
      if (!(rpm -> modpar = (float *) malloc(NPARAMS*rpm -> nr*sizeof(float))))
 goto error;
      
      err = 1;
      for (i = 1; i < rpm -> nur; ++i) {
 
	/* Check if the choice of radii is sensible */
	if ((rpm -> par[PRADI*rpm -> nur+i-1]+rpm -> radsep) >= (rpm -> par[PRADI*rpm -> nur+i])) {
	  sprintf(mes, "Radius separation too small or radii not in increasing order.");
	  cancel_c(tofchar("RADI="));
	  err = 0;
	  free(rpm -> modpar);
	  rpm -> modpar = NULL;
	  break;
	}
      }
    }
  }


  /* Check the values */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i) {
      ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PRADI+i+1, &adouble);
      if (maths_checkeq(dparamtointern(adouble, RADI, hdr), rpm -> par[PRADI*rpm -> nur+i], DOUBLE_ACCURACY)) {
 err = 1;
 i = rpm -> nur;
      }
    }
  }

  if ((err)) {
    sprintf(mes, "RADI: %f logfile %f contains different values, proceed? [YES]", adouble, dinterntoparam(rpm -> par[RADI*rpm -> nur-2], RADI, hdr));
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the radii*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PRADI+i+1, dinterntoparam(rpm -> par[PRADI*rpm -> nur+i], RADI, hdr) );
  }

  /* Get the rotation velocities */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PVROT+i+1, rpm -> par + rpm -> nur*PVROT+i);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give circular velocities. (km/s)");
  
  /* This is the second parameter sequence */
  nel = userdble_c(rpm -> par +rpm ->nur, &rpm ->nur, &def, tofchar("VROT="), tofchar(mes));

  /* If def = 2, then the nel will for some reason be set to 0... */
   if (def == 2)
     nel = rpm -> nur;

  while (!(nel)) {
    sprintf(mes, "Give value");
    cancel_c(tofchar("VROT="));
    nel = userdble_c(rpm -> par +PVROT*rpm ->nur, &rpm ->nur, &def, tofchar("VROT="), tofchar(mes));
  }

  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i){
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PVROT+i+1, &adouble);
    if (maths_checkeq(adouble, rpm -> par[PVROT*rpm -> nur+i], DOUBLE_ACCURACY)) {
      err = 1;
      i = rpm -> nur;
    }
    }
  }

  if ((err)) {
    sprintf(mes, "VROT: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the vrot*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PVROT+i+1, rpm -> par[PVROT*rpm -> nur+i]);
  }

  /* Turn the parameters into grids */
  for (i = nel-1; i < rpm -> nur; ++i) {
    rpm -> par[PVROT*rpm -> nur+i] = rpm -> par[PVROT*rpm -> nur+nel-1];
  }
   for (i = PVROT*rpm -> nur; i < VROT*rpm -> nur; ++i)
     rpm -> par[i] = dparamtointern(rpm -> par[i], VROT, hdr);

    /* Get the scaleheight */
 
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PZ0+i+1, rpm -> par + rpm -> nur*PZ0+i);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give scale-height (Z0) of rings. (arcsec)");
  nel = 0;
  while (!nel) {
    /* This is the third parameter sequence */
    nel = userdble_c(rpm -> par+PZ0*rpm -> nur, &rpm -> nur, &def, tofchar("Z0="), tofchar(mes));

    /* If def = 2, then the nel will for some reason be set to 0... */
   if (def == 2)
     nel = rpm -> nur;
    /* Check for errors and extrapolate */
    for (i = 0; i < rpm -> nur; ++i) {
      if (i > nel-1)
 rpm -> par[PZ0*rpm -> nur+i] = rpm -> par[PZ0*rpm -> nur+nel-1];
      else
 rpm -> par[PZ0*rpm ->nur+i] =  dparamtointern(rpm -> par[PZ0*rpm ->nur+i], Z0, hdr);
/*       if (rpm -> par[PZ0*rpm ->nur+i] < 0) { */
/*  sprintf(mes, "Negative scale height not allowed."); */
/*  cancel_c(tofchar("Z0=")); */
/*  def = 0; */
/*  nel = 0; */
/*  i = rpm -> nur; */
/*       } */
    }
  }

    /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i) {
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PZ0+i+1, &adouble);
    if (maths_checkeq(dparamtointern(adouble, Z0, hdr), rpm -> par[PZ0*rpm -> nur+i], DOUBLE_ACCURACY)) {
      err = 1;
      i = rpm -> nur;
    }
    }
  }

  if ((err)) {
    sprintf(mes, "Z0: logfile contains different values%f, proceed? [YES]", rpm -> par[PZ0*rpm -> nur]);
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the z0*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PZ0+i+1, dinterntoparam(rpm -> par[PZ0*rpm -> nur+i], Z0, hdr));
  }

  /* Get the column densities */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PSBR+i+1, rpm -> par + rpm -> nur*PSBR+i);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give surface-brightness of rings. (Jy/(arcsec*arcsec))");
  nel = 0;
  while (!nel) {
    /* This is the fourth parameter sequence */
    nel = userdble_c(rpm -> par+PSBR*rpm -> nur, &rpm -> nur, &def, tofchar("SBR="), tofchar(mes));

      /* If def = 2, then the nel will for some reason be set to 0... */
   if (def == 2)
     nel = rpm -> nur;

    /* extrapolate */
    for (i = 0; i < rpm -> nur; ++i) {
      if (i > nel-1)
 rpm -> par[PSBR*rpm -> nur+i] = rpm -> par[PSBR*rpm -> nur+nel-1];
      else
 rpm -> par[PSBR*rpm ->nur+i] =  dparamtointern(rpm -> par[PSBR*rpm ->nur+i], SBR, hdr);
      /* We now allow for negatice SBR */
/*       if (rpm -> par[PSBR*rpm ->nur+i] < 0) { */
/*  sprintf(mes, "Negative surface brightness not allowed."); */
/*  cancel_c(tofchar("SBR=")); */
/*  nel = 0; */
/*  break; */
/*       } */
    }
  }

  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i) {
      ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PSBR+i+1, &adouble);
      if (maths_checkeq(dparamtointern(adouble, SBR, hdr), rpm -> par[PSBR*rpm -> nur+i], DOUBLE_ACCURACY)) {
 err = 1;
 i = rpm -> nur;
      }
    }
  }

  if ((err)) {
    sprintf(mes, "SBR: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the z0*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PSBR+i, dinterntoparam(rpm -> par[PSBR*rpm -> nur+i], SBR, hdr));
  }

  /* Inclination */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PINCL+i+1, rpm -> par + rpm -> nur*PINCL+i);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give inclinations of rings. (degree)");
  
  /* This is the fifth parameter sequence */
  nel = userdble_c(rpm -> par+PINCL*rpm -> nur, &rpm -> nur, &def, tofchar("INCL"), tofchar(mes));
   
 /* If def = 2, then the nel will for some reason be set to 0... */
   if (def == 2)
     nel = rpm -> nur;

  /* Check for errors and extrapolate */
  for (i = 0; i < rpm -> nur; ++i) {

    if (i > nel-1)
      rpm -> par[PINCL*rpm -> nur+i] = rpm -> par[PINCL*rpm -> nur+nel-1];
    else
      rpm -> par[PINCL*rpm ->nur+i] = dparamtointern(rpm -> par[PINCL*rpm ->nur+i], INCL, hdr);
}

  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i) {
      ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PINCL+i+1, &adouble);
      if (maths_checkeq(dparamtointern(adouble, INCL, hdr),rpm -> par[PINCL*rpm -> nur+i], DOUBLE_ACCURACY)) {
 err = 1;
 i = rpm -> nur;
      }
    }
  }
  
  if ((err)) {
    sprintf(mes, "INCL: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the incl*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PINCL+i+1, dinterntoparam(rpm -> par[PINCL*rpm -> nur+i], INCL, hdr));
  }

  /* Position angle */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PPA+i+1, rpm -> par + rpm -> nur*PPA+i);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give position angles of rings (minor axis). (degree)");
  
  /* This is the sixth parameter sequence */
  nel = userdble_c(rpm -> par+PPA*rpm -> nur, &rpm -> nur, &def, tofchar("PA="), tofchar(mes));
  
  /* If def = 2, then the nel will for some reason be set to 0... */
   if (def == 2)
     nel = rpm -> nur;

  /* Convert and extrapolate */
  for (i = 0; i < rpm -> nur; ++i) {
    if (i > nel-1)
      rpm -> par[PPA*rpm -> nur+i] = rpm -> par[PPA*rpm -> nur+nel-1];
    else
      rpm -> par[PPA*rpm ->nur+i] = dparamtointern(rpm -> par[PPA*rpm ->nur+i], PA, hdr);
  }
  
  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i) {
      ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PPA+i+1, &adouble);
    if (maths_checkeq(dparamtointern(adouble, PA, hdr), rpm -> par[PPA*rpm -> nur+i], DOUBLE_ACCURACY)) {
      err = 1;
      i = rpm -> nur;
    }
  }
  }

  if ((err)) {
    sprintf(mes, "PA: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the incl*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PPA+i+1, dinterntoparam(rpm -> par[PPA*rpm -> nur+i], PA, hdr));
  }


  /* Center x */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PXPOS+i+1, rpm -> par + rpm -> nur*PXPOS+i);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give x coordinates for central positions of rings. (degree)");
  
  /* This is the seventh parameter sequence */
  nel = userdble_c(rpm -> par+PXPOS*rpm -> nur, &rpm -> nur, &def, tofchar("XPOS="), tofchar(mes));
    
  /* If def = 2, then the nel will for some reason be set to 0... */
   if (def == 2)
     nel = rpm -> nur;

  /* Don't convert but extrapolate */
  for (i = nel; i < rpm -> nur; ++i) {
    rpm -> par[PXPOS*rpm -> nur+i] = rpm -> par[PXPOS*rpm -> nur+nel-1];
  }
  
  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i) {
      ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PXPOS+i+1, &adouble);
    if (maths_checkeq(adouble, rpm -> par[PXPOS*rpm -> nur+i], DOUBLE_ACCURACY)) {
      err = 1;
      i = rpm -> nur;
    }
  }
  }

  if ((err)) {
    sprintf(mes, "XPOS: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the incl*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PXPOS+i+1, rpm -> par[PXPOS*rpm -> nur+i]);
  }

  /* Center y */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PYPOS+i+1, rpm -> par + rpm -> nur*PYPOS+i);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give y coordinates for central positions of rings. (degree)");
  
  /* This is the eighth parameter sequence */
  nel = userdble_c(rpm -> par+PYPOS*rpm -> nur, &rpm -> nur, &def, tofchar("YPOS="), tofchar(mes));
    
  /* If def = 2, then the nel will for some reason be set to 0... */
   if (def == 2)
     nel = rpm -> nur;

  /* Convert and extrapolate */
  for (i = nel; i < rpm -> nur; ++i) {
    rpm -> par[PYPOS*rpm -> nur+i] = rpm -> par[PYPOS*rpm -> nur+nel-1];
  }
  
  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i) {
      ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PYPOS+i+1, &adouble);
    if (maths_checkeq(adouble, rpm -> par[PYPOS*rpm -> nur+i], DOUBLE_ACCURACY)) {
      err = 1;
      i = rpm -> nur;
    }
  }
  }
  
  if ((err)) {
    sprintf(mes, "YPOS: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the incl*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PYPOS+i+1, rpm -> par[PYPOS*rpm -> nur+i]);
  }

  /* vsys */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i)
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PVSYS+i+1, rpm -> par + rpm -> nur*PVSYS+i);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give systemic velocities of rings in (km/s).");
   
  /* This is the ninth parameter sequence */
  nel = userdble_c(rpm -> par+PVSYS*rpm -> nur, &rpm -> nur, &def, tofchar("VSYS="), tofchar(mes));
  
  /* If def = 2, then the nel will for some reason be set to 0... */
   if (def == 2)
     nel = rpm -> nur;

  /* Convert and extrapolate */
  for (i = nel; i < rpm -> nur; ++i) {
    rpm -> par[PVSYS*rpm -> nur+i] = rpm -> par[PVSYS*rpm -> nur+nel-1];
  }
  
  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    for (i = 0; i < rpm -> nur; ++i) {
      ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*PVSYS+i+1, &adouble);
      if (maths_checkeq(adouble, rpm -> par[PVSYS*rpm -> nur+i], DOUBLE_ACCURACY)) {
	err = i+1;
	i = rpm -> nur;
      }
    }
  }
  
  if ((err)) {
    sprintf(mes, "VSYS: logfile contains different values %e, proceed? [YES]", adouble);
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the incl*/
    for (i = 0; i < rpm -> nur; ++i)
      ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PVSYS+i+1, rpm -> par[PVSYS*rpm -> nur+i]);
  }

  /* Now, we have to convert the triplets into internal units */
  for (i = 0; i < rpm -> nur; ++i) {
    globin[0] = rpm -> par[PXPOS*rpm -> nur+i];
    globin[1] = rpm -> par[PYPOS*rpm -> nur+i];
    globin[2] = rpm -> par[PVSYS*rpm -> nur+i];

    globtointern(globin, globout, hdr);
   
    rpm -> par[PXPOS*rpm -> nur+i] = globout[0];
    rpm -> par[PYPOS*rpm -> nur+i] = globout[1];
    rpm -> par[PVSYS*rpm -> nur+i] = globout[2];
  }

  /* Global velocity dispersion */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*NPARAMS + NSPARAMS, rpm -> par + rpm -> nur*PCONDISP);
    def = 2;
  }
  else {
    def = 0;
  }

  sprintf(mes, "Give global velicity dipersion (km/s)");
  nel = 1;
  /* This is the ninth parameter sequence */
  userdble_c(rpm -> par+PCONDISP*rpm -> nur, &nel, &def, tofchar("CONDISP="), tofchar(mes));
  
  /* it should be positive */
  while (rpm -> par[PCONDISP*rpm -> nur] < 0) {
    sprintf(mes, "Negative velocity dispersion not allowed.");
    cancel_c(tofchar("CONDISP"));
    userdble_c(rpm -> par+PCONDISP*rpm -> nur, &nel, &def, tofchar("CONDISP="), tofchar(mes));
  }

  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, PRIMHDN_SINGLE+rpm -> nur*NPARAMS + NSPARAMS, &adouble);
    if (maths_checkeq(adouble, rpm -> par[PCONDISP*rpm -> nur], DOUBLE_ACCURACY)) {
      err = 1;
      i = rpm -> nur;
    }
  }
  
  if ((err)) {
    sprintf(mes, "CONDISP: logfile %f %f contains different values, proceed? [YES]", adouble, rpm -> par[PCONDISP*rpm -> nur]);
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the condisp*/
    ftstab_putval(1L, PRIMHDN_SINGLE+rpm -> nur*PCONDISP + NSPARAMS, rpm -> par[PCONDISP*rpm -> nur]);
  }

  /* Change the value to grid units */
  rpm -> par[PCONDISP*rpm ->nur] = dparamtointern(rpm -> par[PCONDISP*rpm ->nur], CONDISP, hdr);

  /* The layer type */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, LTYPE_PRIMPOS, &adouble);
    rpm -> ltype = (int) adouble;
    def = 3;
  }
  else {
    rpm -> ltype = 0;
    def = 5;
  }

  sprintf(mes, "Give type of layer. [list options]");
  nel = 1;
 
  while(!rpm -> ltype) {
    userint_c(&rpm -> ltype, &nel, &def, tofchar("LTYPE="), tofchar(mes));
    if((rpm -> ltype) < 2 || (rpm -> ltype > 5)) {
      rpm -> ltype = 0;
      anyout_c(&rpm -> ltype, tofchar(" Ltype:"));
      anyout_c(&rpm -> ltype, tofchar(" 1 -- Gaussian layer"));
anyout_c(&rpm -> ltype, tofchar(" 2 -- Sech2 layer"));
anyout_c(&rpm -> ltype, tofchar(" 3 -- Exponential layer"));
anyout_c(&rpm -> ltype, tofchar(" 4 -- Lorentzian layer"));
anyout_c(&rpm -> ltype, tofchar(" 5 -- Box layer"));
      cancel_c(tofchar("LTYPE="));
    }
  }
  
    /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, LTYPE_PRIMPOS, &adouble);
      if ((int) adouble != rpm -> ltype) {
      err = 1;
      i = rpm -> nur;
    }
  }
  
  if ((err)) {
    sprintf(mes, "LTYPE: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the ltype*/
    ftstab_putval(1L, LTYPE_PRIMPOS, (double) rpm -> ltype);
  }

  /* cloud flux */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, CFLUX_PRIMPOS, &rpm -> cflux);
    def = 2;
  }
  else {
    rpm -> cflux = 1e-5;
    def = 5;
  }

  sprintf(mes,"Cloud flux in (Jy*km/s) [1E-5]");
  nel = 1;
  userdble_c(&rpm -> cflux, &nel, &def, tofchar("CFLUX="), tofchar(mes));
  while (rpm ->cflux <= 0) {
    sprintf(mes,"CFLUX must be greater than zero.");
    rpm -> cflux = 1e-5;
    cancel_c(tofchar("CFLUX="));
    userdble_c(&rpm -> cflux, &nel, &def, tofchar("CFLUX="), tofchar(mes));
  }

      /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, CFLUX_PRIMPOS, &adouble);
    if (maths_checkeq(adouble, rpm -> cflux, FLOAT_ACCURACY)) {
      err = 1;
      i = rpm -> nur;
    }
  }

  if ((err)) {
    sprintf(mes, "CFLUX: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the cflux*/
    ftstab_putval(1L, CFLUX_PRIMPOS, rpm -> cflux);
  }


  /* Initialise the io */
 /* Now initialise the chisquare derivation (convolution) routines */

  /* Input noiseweight */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, WEIGHT_PRIMPOS, &adouble);
    rpm -> weight = (float) adouble;
    def = 2;
  }
  else {
    rpm -> weight = 1.0;
    def = 5;
  }

  sprintf(mes, "Give noise weighting (0.0 means inf). [%f]", rpm -> weight);
  nel = 1;
  userreal_c(&rpm -> weight, &nel, &def, tofchar("WEIGHT="), tofchar(mes));
  
  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, WEIGHT_PRIMPOS, &adouble);
    if (maths_checkeq(adouble, rpm -> weight, FLOAT_ACCURACY)) {
      err = 1;
    }
  }
  
  if ((err)) {
    sprintf(mes, "WEIGHT: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the cflux*/
    ftstab_putval(1L, WEIGHT_PRIMPOS, rpm -> weight);
  }


  /* Input PENALTY */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, PENALTY_PRIMPOS, &rpm -> penalty);
    def = 2;
  }
  else {
    rpm -> penalty = 1.0;
    def = 2;
  }
    sprintf(mes, "Give Penalty for outlyers [%f]", rpm -> penalty);
  nel = 1;
  userdble_c(&rpm -> penalty, &nel, &def, tofchar("PENALTY="), tofchar(mes));
  
  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, PENALTY_PRIMPOS, &adouble);
    if (maths_checkeq(adouble, rpm -> penalty, DOUBLE_ACCURACY)) {
      err = 1;
    }
  }
  
  if ((err)) {
    sprintf(mes, "PENALTY: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the penalty*/
    ftstab_putval(1L, PENALTY_PRIMPOS, rpm -> penalty);
  }

  /* Now we recalculate the penalty */
  rpm -> penalty = rpm -> cflux*rpm -> penalty*SQRTOFPIHALF*((double) hdr -> bmaj)*((double) hdr -> bmaj)*((double) hdr -> bmin)*((double) hdr -> bmin)*HPBWTOSIGMATOFORTH/((double)(hdr -> rms*hdr -> rms));

  /* Input inimode */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, INIMODE_PRIMPOS, &adouble);
    rpm -> inimode = (int) adouble;
    def = 2;
  }
  else {
    rpm -> inimode = 1;
    def = 5;
  }


  sprintf(mes, "Give initialisation time 0 short, 3 long [1]");
  nel = 1;
  err = 0;
  while (!(err)) {
    userint_c(&rpm -> inimode, &nel, &def, tofchar("INIMODE="), tofchar(mes));
    if (rpm -> inimode < 0 || rpm -> inimode > 3) {
      sprintf(mes, "Out of range %i", rpm -> inimode);
      cancel_c(tofchar("INIMODE="));
      rpm -> inimode = 1;
      def = 5;
    }
    else
      err = 1;
  }

  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, INIMODE_PRIMPOS, &adouble);
    if ((int) adouble != rpm -> inimode) {
      err = 1;
    }
  }
  
  if ((err)) {
    sprintf(mes, "INIMODE: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));

    /* Furthermore we change the cflux*/
    ftstab_putval(1L, INIMODE_PRIMPOS, rpm -> inimode);
  }

  /* Input mode */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, MODE_PRIMPOS, &adouble);
    rpm -> mode = (int) adouble;
    def = 2;
  }
  else {
    rpm -> mode = 3;
    def = 5;
  }


  sprintf(mes, "Give memory consumption mode. [list options]");
  nel = 1;
  i = 0;
  while (!(i)) {
    userint_c(&rpm -> mode, &nel, &def, tofchar("MEMMODE="), tofchar(mes));
    if (rpm -> mode < 0 || rpm -> mode > 3) {
      anyout_c(&i, tofchar(" MemMode:"));
      anyout_c(&i, tofchar("       0 -- in-place, no boost."));
      anyout_c(&i, tofchar("       1 -- in-place, using boost."));
      anyout_c(&i, tofchar("       2 -- out-place, no boost."));
      anyout_c(&i, tofchar("       3 -- out-place, using boost."));
      cancel_c(tofchar("MEMMODE="));
      rpm -> mode = 3;
      def = 5;
    }
    else
      i = 1;
  }
  mode = rpm -> mode*2;
  if ((rpm -> weight)) 
    ++mode;

  /* Try to initialise the chisquare machinery */
  while (mode >= 0 && mode < 8) {   
    if (!initchisquare_c(hdr -> ori, hdr -> model, hdr -> bsize1, hdr -> bsize2, hdr -> nsubs, hdr -> bmaj, hdr -> bmin, hdr -> bpa, 1, rpm -> cflux, hdr -> rms, mode, 2*(hdr -> bsize1/2+1), &hdr -> chi2, rpm -> weight, rpm -> inimode)) {
    mode = mode-2;
    j = 0;
    sprintf(mes, "MEMMODE seems too high, reducing to %i", mode/2);
    anyout_c(&j, tofchar(mes));
    }
    else {
      mode = 8;
    }
  }

  j = 4;
  if (mode < 8)
    error_c(&j,tofchar("Error initializing chi^2 derivation control."));
  
  /* Now we write the mode in the table */

  if ((log -> logname) && !(log -> logpres)) {
    ftstab_putval(1L, MODE_PRIMPOS, rpm -> mode);
  }

  /* Write inset data into ori array */
  nel = 0;
  def = 4;
  
  for (i = 0; i < hdr -> nsubs; ++i) {
    j=i*hdr -> nprof;
    gdsi_read_c(tofchar(hdr -> inset), hdr -> cwlo+i, hdr -> cwhi+i, hdr -> ori+j, &hdr -> nprof, &k, &nel);
    if ((nel)) {
      error_c(&def, tofchar("Unable to read inset."));
    }
  }
  

  /* close inset (not needed anymore ?) */
  gds_close_c(tofchar(hdr -> inset), &def);
  
  /* Now the cube has to be rearranged, because it is padded */
  for(k = hdr -> nsubs-1; k >= 0; --k) {
    for(j = hdr -> bsize2-1; j >= 0; --j) {
      for(i = hdr -> bsize1-1; i >= 0; --i) {
	hdr -> ori[i+2*(hdr -> bsize1/2+1)*(j+hdr -> bsize2*k)] = hdr -> ori[i+hdr -> bsize1*(j+hdr -> bsize2*k)];
      }
    }
  }

   /* The cube has changed, therefore we need to do this */
    engalmod_chflgs(); 

  /* Also, we change the nprof */
  hdr -> nprof = hdr -> bcsize1*hdr -> bsize2;
  
  /* We initialise the sd array */
  if (!(rpm -> sd = create_srd(rpm -> nr)))
    goto error;
     
  /* Get the info for the single-model random-number generator */
    /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, ISEED2_PRIMPOS, &adouble);
    rpm -> iseed2[0] = (int) adouble;
    def = 2;
  }
  else {
    rpm -> iseed2[0] = 1803;
    def = 5;
  }

  sprintf(mes, "Give one integer to initialize RNG. [1803]");

  nel = 1;
  userint_c(rpm -> iseed2, &nel, &def, tofchar("ISEED2="), tofchar(mes));
  while (*rpm -> iseed2 < 0 || *rpm -> iseed2 > 31328) {
    sprintf(mes, "Iseed out of range.");
    cancel_c(tofchar("ISEED2="));
    userint_c(rpm -> iseed2, &nel, &def, tofchar("ISEED2="), tofchar(mes));
  }

  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ISEED2_PRIMPOS, &adouble);
    if ((int) adouble != rpm -> iseed2[0]) {
      err = 1;
      i = rpm -> nur;
    }
  }
  
  if ((err)) {
    sprintf(mes, "ISEED2: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the cflux*/
    ftstab_putval(1L, ISEED2_PRIMPOS, rpm -> iseed2[0]);
  }

  return rpm;
  
 error:
  destroy_ringparms(rpm);
  if (hdr)
    destroy_hdrinf(hdr);
  if (log)
    destroy_loginf(log);
    
  return NULL;
  
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a fitparms structure */
static fitparms *create_fitparms(void)
{
  fitparms *fit;

  if (!(fit = (fitparms *) malloc(sizeof(fitparms))))
    return NULL;

  fit -> varylist = NULL;
  fit -> normrandstr = NULL;

  /* Allocate the memory */
  if (!(fit -> normrandstr = (maths_rstr *) malloc(sizeof(maths_rstr))))
     goto error;

  return fit;

 error:
  destroy_fitparms(fit);
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destroys a fitparms structure */
void destroy_fitparms(fitparms *fit)
{
  /* Check if it is there */
  if (!(fit))
    return;

  if ((fit -> varylist))
    destroyvarlel(fit -> varylist);
  if((fit -> normrandstr))
    free(fit -> normrandstr);

  free(fit);
    return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Fill the ringparms struct from the input */
static fitparms *get_fitparms(loginf *log, hdrinf *hdr, ringparms *rpm)
{
  fitparms *fit;

  /* Private control and changing variables */
  fint device; /* A device control thingy */
  fint def;      /* Any default mode */
  fint defaul;
  fint nel;      /* Number of elements */
  char mes[81];  /* Any message */
  char value[4];
  char key[9];
  fint err;      /* An error code */
  double adouble;

  int i,j,k,l; /* Simple control variables */
  int twoints[2]; /* Contains two integers */

  /* Private input lists */
  varlel **pointarray = NULL;
  double *parmax = NULL;
  double *parmin = NULL;
  int *moderate = NULL;
  double *delstart = NULL;
  double *delend = NULL;
  int *itestart = NULL;
  int *iteend = NULL;
  double *satdelt = NULL;
  double *mindelta = NULL;
  long varynum;

  char **varystr= NULL; /* An array of short strings to hold some input strings */
  char *varyhstr= NULL; /* An array of short strings to hold some input strings */
  int strnr; /* The number of words in the first varystr */
  inlistel *flistel = NULL, *listel;
  varlel *varele;
  varlel *varele2;
  varlel *varylist = NULL;
  int iseed[2];

  /******/
  /******/
  /* fint obsint = 0; */
  /* char obsmes[80]; */
  /******/   

  /******/   
  /******/   
  /* sprintf(obsmes, "got here"); */
  /* anyout_c(&obsint, tofchar(obsmes)); */
  /******/   

  long tabentries; /* The number of rows in the table */
  double *array = NULL; /* An array to contain a row */

  /* Get the struct */
  if (!(fit = create_fitparms())) {
    goto error;
  }

  /* Input fitmode */
  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, FITMODE_PRIMPOS, &adouble);
    fit -> fitmode = (int) adouble;
    def = 2;
  }
  else {
    fit -> fitmode = 0;
    def = 5;
  }

  sprintf(mes, "Give fitting mode 0: annealing, 1: golden section [0]");
  nel = 1;
  userint_c(&fit -> fitmode, &nel, &def, tofchar("FITMODE="), tofchar(mes));
  
  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, FITMODE_PRIMPOS, &adouble);
    if ((int) adouble != fit -> fitmode) {
      err = 1;
    }
  }
  
  if ((err)) {
    sprintf(mes, "FITMODE: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));log -> changes = 1;

    /* Furthermore we change the cflux*/
    ftstab_putval(1L, FITMODE_PRIMPOS, fit -> fitmode);
  }


  /* Input loops */

  /* First from the log if present */
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, LOOPS_PRIMPOS, &adouble);
    fit -> loops = (int) adouble;
    def = 2;
  }
  else {
    fit -> loops = 500000;
    def = 5;
  }

  sprintf(mes, "Give number of loops to process. [500000]");
  nel = 1;
  userint_c(&fit -> loops, &nel, &def, tofchar("LOOPS="), tofchar(mes));
  
  /* Check */
  err = 0;
  if ((log -> logname) && !(log -> logpres)) {
    ftstab_get_value(1L, LOOPS_PRIMPOS, &adouble);
    if ((int) adouble != fit -> loops) {
      err = 1;
    }
  }
  
  if ((err)) {
    sprintf(mes, "LOOPS: logfile contains different values, proceed? [YES]");
    sprintf(value,"YES");
    def = 5;
    nel = 1;
    userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
    
    /* Not yes means no, stop things */
    if (strcmp(value,"YES"))
      goto error;

    /* We proceed and at the moment reset PROCEED */
    cancel_c(tofchar("PROCEED="));

    /* Furthermore we change the cflux*/
    ftstab_putval(1L, LOOPS_PRIMPOS, fit -> loops);
  }

  /* This whole block is not of interest if we don't do annealing */
  if (fit -> fitmode == METROPOLIS) {
    
    /* stopanneal */
    /* First from the log if present */
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ANEND_PRIMPOS, &fit -> anend);
      def = 2;
    }
    else {
      fit -> anend = 1;
      def = 5;
    }
    
    sprintf(mes, "Give end annealing factor. [1]");
    
    nel = 1;
    i = 0;
    while ((!i)) {
      userdble_c(&fit -> anend, &nel, &def, tofchar("ANEND="), tofchar(mes));
      if (fit -> anend <= 0) {
 sprintf(mes, "It has to be higher than 0");
 cancel_c(tofchar("ANEND="));
      }
      else
 ++i;
    }
    
    /* Check */
    err = 0;
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ANEND_PRIMPOS, &adouble);
      if (maths_checkeq(adouble, fit -> anend, DOUBLE_ACCURACY)) {
 err = 1;
      }
    }
    
    if ((err)) {
      sprintf(mes, "ANEND: logfile contains different values, proceed? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
      
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));log -> changes = 1;
      
      /* Furthermore we change the cflux*/
      ftstab_putval(1L, ANEND_PRIMPOS, fit -> anend);
    }
    
    
    /* startanneal */
    
    /* First from the log if present */
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ANSTART_PRIMPOS, &fit -> anstart);
      def = 2;
    }
    else {
      fit -> anstart = 1;
      def = 5;
    }
    
    sprintf(mes, "Give start annealing factor. [1]");
    
    nel = 1;
    i = 0;
    while ((!i)) {
      userdble_c(&fit -> anstart, &nel, &def, tofchar("ANSTART="), tofchar(mes));
      if (fit -> anstart <= 0) {
 sprintf(mes, "It has to be higher than 0");
 cancel_c(tofchar("ANSTART="));
      }
      else
 ++i;
    }
    
    /* Check */
    err = 0;
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ANSTART_PRIMPOS, &adouble);
      if (maths_checkeq(adouble, fit -> anstart, DOUBLE_ACCURACY)) {
 err = 1;
      }
    }
    
    if ((err)) {
      sprintf(mes, "ANSTART: logfile contains different values, proceed? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
      
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));log -> changes = 1;
      
      /* Furthermore we change the cflux*/
      ftstab_putval(1L, ANSTART_PRIMPOS, fit -> anstart);
    }
    
    /* annealsteps */
    
    /* First from the log if present */
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ANSTEPS_PRIMPOS, &adouble);
      fit -> ansteps = (int) adouble;
      def = 2;
    }
    else {
      fit -> ansteps = 0;
      def = 5;
    }
    
    sprintf(mes, "Give number of annealing steps [0]");
    nel = 1;
    i = 0;
    while ((!i)) {
      userint_c(&fit -> ansteps, &nel, &def, tofchar("ANSTEPS="), tofchar(mes));
      if (fit -> ansteps < 0) {
 sprintf(mes, "Have to be higher than 0");
 cancel_c(tofchar("ANSTEPS="));
      }
      else
 ++i;
    }
    
    /* Check */
    err = 0;
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ANSTEPS_PRIMPOS, &adouble);
      if ((int) adouble != fit -> ansteps) {
 err = 1;
      }
    }
    
    if ((err)) {
      sprintf(mes, "ANSTEPS: logfile contains different values, proceed? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
      
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));log -> changes = 1;
      
      /* Furthermore we change the cflux*/
      ftstab_putval(1L, ANSTEPS_PRIMPOS, fit -> ansteps);
    }
    
    /* Initialize random number generators */
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ISEED_1_PRIMPOS, &adouble);
      fit -> iseed[0] = (int) adouble;
      ftstab_get_value(1L, ISEED_2_PRIMPOS, &adouble);
      fit -> iseed[1] = (int) adouble;
      def = 2;
    }
    else {
      fit -> iseed[0] = 1802;
      fit -> iseed[1] = 9373;
      def = 5;
    }
    
    sprintf(mes, "Give two integers to initialize RNG. [1802 9373]");
    nel = 2;
    userint_c(fit -> iseed, &nel, &def, tofchar("ISEED="), tofchar(mes));
    while (fit -> iseed[0] < 0 || fit -> iseed[0] > 31328 || fit -> iseed[1]<0 || fit -> iseed[1] > 30081) {
      sprintf(mes, "Iseed out of range.");
      cancel_c(tofchar("ISEED="));
      userint_c(fit -> iseed, &nel, &def, tofchar("ISEED="), tofchar(mes));
    }
    
    /* Check */
    err = 0;
    if ((log -> logname) && !(log -> logpres)) {
      ftstab_get_value(1L, ISEED_1_PRIMPOS, &adouble);
      if ((int) adouble != fit -> iseed[0]) {
 err = 1;
      }
      ftstab_get_value(1L, ISEED_2_PRIMPOS, &adouble);
      if ((int) adouble != fit -> iseed[1]) {
 err = 1;
      }
    }
    
    if ((err)) {
      sprintf(mes, "ISEED: logfile contains different values, proceed? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
      
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));log -> changes = 1;
      
      /* Furthermore we change the cflux*/
      ftstab_putval(1L, ISEED_1_PRIMPOS, fit -> iseed[0]);
      ftstab_putval(1L, ISEED_2_PRIMPOS, fit -> iseed[1]);
    }
    
    /* Initialize chi^2 derivation control */
    maths_rndm_init(iseed, fit -> normrandstr);
  }

  /* We are through with the first hdu, so it will be created if not already existent */
  if ((log -> logname) && (log -> logpres)) {

    if ((create_hdu_1(log, hdr, rpm, fit)))
      goto error;
  }
  ftstab_close_();

  /* Make a flush and don't forget to recreate the hdrlist */
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();

  /* Now open the second hdu, if possible and if we expect one */
  if ((log -> logname) && !(log -> logpres)) {

    /* Try to open the file to check if it is already present */
    log -> logpres = ftstab_fopen(log -> logname, 2, 2, 1);

    /* If yes, check if it is properly created, err = 1 -> yes, err = 0 -> no */
    err = 1;
    if ((!(log -> logpres)) && (ftstab_get_extnr_() == 2)) {
      sprintf(key, "STATUS");
      if (ftstab_getcard(0, key, value, 1)) {
 if (strcmp(value, "'OK                '")){
   err = 0;
 }
      }
      else {
 err = 0;
      }
    }
    else {
      err = 0;
    }

    if (!(err)) {
      /* If there is something odd, ask the user wheter to proceed */
      sprintf(mes, "LOGFILE: STATUS of hdu2 not proper, overwrite? [YES]");
      sprintf(key,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(key), &nel, &def, tofchar("PROCEED="), tofchar(mes));

      /* Not yes means no, stop things */
      if (strcmp(key,"YES"))
	goto error;

      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));

      /* Furthermore we will simply overwrite the extension */
      ftstab_close_();
      ftstab_flush_();  
      ftstab_hdlreset_();
      hdl_init();
      log -> logpres = 1;
    }
  }

  /* The complicated varystr */
  if (!(varystr = (char **) malloc(VARYSTRELES*sizeof(char *))))
    goto error;
  if (!(varyhstr = getfcharray(VARYHSTRELES)))
    goto error;

  /* Call this function just to get some identifiers */
  /*  ftstab_hdlreset_(); */
  /*   hdl_init(); */

  /* input values to vary individually */
  sprintf(mes, "Paramers to be varied for each ring");
  
  /* k counts the number of keywords */
  k= 0;

  /* This will be checked */
  nel = 0;

  if ((log -> logname) && !(log -> logpres))
    def = 2;
  else 
    def = 1;

  while(!nel) {

    nel = usertext_c(tofchar(varyhstr), &def, tofchar("VARYMULT="),tofchar(mes));
    varyhstr[nel] = '\0';
    
    /* Interlude: Change the case if it is lower case */
    i = 0;
    while (varyhstr[i]) {
      if (varyhstr[i] >= 'a' && varyhstr[i] <= 'z')
	varyhstr[i] = varyhstr[i]+'A'-'a';
      ++i;
    }
    
    /* Now compose the varyary, selecting whitespaces */
    nel = 0; /* In a word: 1, Outside a word: 0 */
    strnr = 0; /* The current number of words */
    i = 0;  
    while (varyhstr[i] != '\0') {
      if ((nel)) {
	if (varyhstr[i] == ' ' || varyhstr[i] == '\t') {
	  varyhstr[i] = '\0';
	  nel = !nel;
	}
      }
      else if (varyhstr[i] != ' ' && varyhstr[i] != '\t') {
	nel = !nel;
	if (strnr < VARYSTRELES)
	  varystr[strnr] = varyhstr+i;
	++strnr;
      }
      ++i;
    }
    
    /* i+1 is now the number of characters in varhstr that is already used */
    ++i;
    
    nel = 1;
    
    /* Now check varystr */
    for (j = 0; j < strnr; ++j) {
      if ((ftstab_gtitln_(varystr[j]) < 1) || (ftstab_gtitln_(varystr[j]) > NPARAMS+NSPARAMS)) {
	if (!(decodestr(varystr[j], twoints, rpm -> nur)) || (j == 0)) {
	  sprintf(mes, "There is an error in word %i", j+1);
	  cancel_c(tofchar("VARYMULT="));
	  /* refresh varyhstring */
	  for (j = 0; j < VARYHSTRELES; ++j) {
	    varyhstr[j] = ' ';
	  }
	  varyhstr[VARYHSTRELES] = '\0';
	  nel = 0;
	  def = 1;
	  break;
	}
      }
      else
	++k;
    }
  }
  
  
  /* input values to vary as a single parameter */
  sprintf(mes, "Values to be varied as a single parameter (group)");
  
  /* Again, this will be checked afterwards */
  nel = 0;
  l = i;

  if ((log -> logname) && !(log -> logpres))
    def = 2;
  else 
    def = 1;

  while (!(nel)) {
    i = l;
    nel = usertext_c(tofchar(varyhstr+i), &def, tofchar("VARYSING="),tofchar(mes));
    
    /* Again, terminate */
    varyhstr[i+nel] = '\0';
    
    /* Now, i stays the same, set nel to 0, but keep strnr */
    nel = 0;
    def = strnr; /* In this stage def is abused as a counter */
    
    while (varyhstr[i] != '\0') {
      if ((nel)) {
	if (varyhstr[i] == ' ' || varyhstr[i] == '\t') {
	  varyhstr[i] = '\0';
	  nel = !nel;
	}
      }
      else if (varyhstr[i] != ' ' && varyhstr[i] != '\t') {
	nel = !nel;
	if (def < VARYSTRELES)
	  varystr[def] = varyhstr+i;
	++def;
      }
      ++i;
    }
    
    nel = 1;
    
    for (j = strnr; j < def; ++j) {
      if ((ftstab_gtitln_(varystr[j]) < 1) || (ftstab_gtitln_(varystr[j]) > NPARAMS+NSPARAMS)) {
	if (!(decodestr(varystr[j], twoints, rpm -> nur)) || (j == strnr)) {
	  sprintf(mes, "There is an error in word %i", j-strnr+1);
	  cancel_c(tofchar("VARYSING="));
	  
	  /* We have to terminate */
	  for (j = l; j < VARYHSTRELES; ++j) {
	    varyhstr[j] = ' ';
	  }
	  varyhstr[VARYHSTRELES] = '\0';
	  nel = 0;
	  break;
	}
      }
      else
	++k;
    }
    varystr[def] = NULL;
    def = 1;
  }
  
  /* This is to comply with the original fortran code, strnr contains the number of the word in varystr with which the VARYSING values start */
  ++strnr;
  
  /* Check whether the logfile contains the same number of deltas */
  if ((log -> logname) && !(log -> logpres)) {
    if (!k)
      k = (int) ftstab_get_colgrd(ITESTART_SECPOS);
    else if ( ((int) ftstab_get_colgrd(ITESTART_SECPOS) != k)) {
      sprintf(mes, "VARYMULT, VARYSING: logfile has different item number, overwrite? [YES]");
      sprintf(value,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(value), &nel, &def, tofchar("PROCEED="), tofchar(mes));
      
      /* Not yes means no, stop things */
      if (strcmp(value,"YES"))
 goto error;
      
      /* We proceed and at the moment reset PROCEED */
      cancel_c(tofchar("PROCEED="));log -> changes = 1;
      
      /* Furthermore we kill the second hdu*/
      log -> logpres = 1;
    }
  }

  /* Now initialise varyary, there are no errors to be expected */

  /* Allocate the pointarray */
  if (!(pointarray = (varlel **) malloc(k*sizeof(varlel *))))
    goto error;

  /* Allocate the */
  if (!(parmax = (double *) malloc(k*sizeof(double))))
    goto error;

  /* Allocate the */
  if (!(parmin = (double *) malloc(k*sizeof(double))))
    goto error;

  /* Allocate the */
  if (!(moderate = (int *) malloc(k*sizeof(int))))
    goto error;

  /* Allocate the */
  if (!(delstart = (double *) malloc(k*sizeof(double))))
    goto error;

  /* Allocate the */
  if (!(delend = (double *) malloc(k*sizeof(double))))
    goto error;

  /* Allocate the */
  if (!(itestart = (int *) malloc(k*sizeof(int))))
    goto error;

  /* Allocate the */
  if (!(iteend = (int *) malloc(k*sizeof(int))))
    goto error;

  if (!(satdelt = (double *) malloc(k*sizeof(double))))
    goto error;

  if (!(mindelta = (double *) malloc(k*sizeof(double))))
    goto error;

  /* Read in all the defaults */
  if ((log -> logname) && !(log -> logpres)) {

    /* Get an array that contains a row */
    if (!(array = ftstab_get_dblarr()))
      goto error;

    tabentries = 1;
    array[ITESTART_SECPOS-1] = -1;

    for (i = 0; i < k; ++i) {
      while((int) array[ITESTART_SECPOS-1] == -1) {
 ftstab_get_row(tabentries, array);
 ++tabentries;
      }

      parmax[i] = array[PARMAX_SECPOS-1];
      parmin[i] = array[PARMIN_SECPOS-1];
      moderate[i] = (int) array[MODERATE_SECPOS-1];
      delstart[i] = array[DELSTART_SECPOS-1];
      delend[i] = array[DELEND_SECPOS-1];
      itestart[i] = (int) array[ITESTART_SECPOS-1];
      iteend[i] = (int) array[ITEEND_SECPOS-1];
      satdelt[i] = array[SATDELT_SECPOS-1];
      mindelta[i] = array[MINDELTA_SECPOS-1];
      array[ITESTART_SECPOS-1] = -1;
    }
  }

  nel = k;

  /* Get the steps */  
/*   sprintf(mes, "Give maximal variation deltas (in the same order)"); */
/*   def = 4; */
/*   userdble_c(steps, &nel, &def, tofchar("STEPS="), tofchar(mes)); */

  if ((log -> logname) && !(log -> logpres)) {
    def = 2;
    defaul = 2;
  }
  else {
    /* The default is +inf */
    for (i = 0; i < k; ++i) {
      parmax[i] = DBL_MAX;
      parmin[i] = -DBL_MAX;
      moderate[i] = 0;

    }
    def = 5;
    defaul = 4;
  }

  /* Get the parmax */
  sprintf(mes, "Give parameter maximum (in the same order)");
  userdble_c(parmax, &nel, &def, tofchar("PARMAX="), tofchar(mes));

  /* Get the parmin */
  sprintf(mes, "Give parameter minimum (in the same order)");
  userdble_c(parmin, &nel, &def, tofchar("PARMIN="), tofchar(mes));
  
  /* Get the moderating steps */
  sprintf(mes, "Give moderating steps (in the same order)");
  userint_c(moderate, &nel, &def, tofchar("MODERATE="), tofchar(mes));

  /* I have no patience programming a warning. If a negative value is
     given, it will be changed to positive */
  for (i = 0; i < k; ++i) {
    if (moderate[i] < 0)
      moderate[i] = -moderate[i];
  }

  /* Get the start delta */
  sprintf(mes, "Give the start delta (in the same order)");
  userdble_c(delstart, &nel, &defaul, tofchar("DELSTART"), tofchar(mes));

  /* Get the end delta */

  /* Defaults to startdela */
  if (def == 5) {
    for (i = 0; i < k; ++i)
      delend[i] = delstart[i];
  }
  sprintf(mes, "Give the end delta (in the same order)");
  userdble_c(delend, &nel, &def, tofchar("DELEND"), tofchar(mes));

  /* These are not required for fitmode metropolis */

  if (fit -> fitmode == GOLDEN_SECTION) {
    /* Get the itestart */
    sprintf(mes, "Give starting number of iterations (in the same order)");
    userint_c(itestart, &nel, &defaul, tofchar("ITESTART"), tofchar(mes));
    
    /* I have no patience programming a warning. If a negative value is
       given, it will be changed to positive and 0 will be changed to 1 */
    for (i = 0; i < k; ++i) {
      if (itestart[i] < 0)
	itestart[i] = -itestart[i];
      if (itestart[i] == 1)
	itestart[i] = 1;
    }
    
    /* Get the iteend */
    
    /* Defaults to itestart */
    if (def == 5) { 
      for (i = 0; i < k; ++i)
	iteend[i] = itestart[i];
    }
    sprintf(mes, "Give final number of iterations (in the same order)");
    userint_c(iteend, &nel, &def, tofchar("ITEEND"), tofchar(mes));
    
    /* I have no patience programming a warning. If a negative value is
       given, it will be changed to positive and 0 will be changed to 1 */
    for (i = 0; i < k; ++i) {
      if (iteend[i] < 0)
	iteend[i] = -iteend[i];
      if (iteend[i] == 1)
	iteend[i] = 1;
    }
    
    /* Get the satisfaction delta */
    sprintf(mes, "Give the satisfaction deltas (in the same order)");
    userdble_c(satdelt, &nel, &defaul, tofchar("SATDELT"), tofchar(mes));
    
    /* dito */
    for (i = 0; i < k; ++i) {
      if (satdelt[i] < 0)
	satdelt[i] = -satdelt[i];
    }
    
    /* Get the minimum deltas */
    /* Get the satisfaction delta */
    sprintf(mes, "Give the minimum deltas (in the same order)");
    userdble_c(mindelta, &nel, &defaul, tofchar("MINDELTA"), tofchar(mes));
    
    /* dito */
    for (i = 0; i < k; ++i) {
      if (mindelta[i] < 0)
	mindelta[i] = -mindelta[i];
    }
  }
  
  /* We will read it in, from file */
  if ((log -> logname) && !(log -> logpres)) {
    
    if (!array) {
      if (!(array = ftstab_get_dblarr()))
	goto error;
    }
    
    tabentries = 1;
    i = -1;
    varynum = -1;
    listel = NULL;
    
    while(ftstab_get_row(tabentries, array)) {
      /* If we encounter a next varlel , we create one */
      if ((int) array[ITEEND_SECPOS-1] != -1) {
	
	/* If there is a change in the parameters, we apply that */
	if ((int) array[ITESTART_SECPOS-1] != -1) {
	  ++i;
	}
	
	/* If it's the first we only create it and fill the global
	   values */
	if (!(varylist)) {
	  
	  /* Allocate the first element of the varylist */
	  if (!(varele = varylist = appendvarlel(NULL)))
	    goto error;
	  
	  if (fillhdvarele(varele, i, array, (((int) array[ELEMENTS_SECPOS-1])/rpm -> nur < NPARAMS)?((int) array[ELEMENTS_SECPOS-1])/rpm -> nur+1:((int) array[ELEMENTS_SECPOS-1])%rpm -> nur+NPARAMS+1, parmax, parmin, moderate, delstart, delend, itestart, iteend, satdelt, mindelta, hdr, log))
	    goto error;
	}
	
	else {
	  
	  /* We have to fill the elements array first */
	  
	  varynum = 1;
	  listel = flistel;
	  while ((listel = listel -> next))
	    ++varynum;
	  
	  varele -> nelem = varynum;
	  if (!(varele -> elements = (int *) malloc(varynum*sizeof(int))))
	    goto error;
	  
	  varynum = 0;
	  listel = flistel;
	  
	  while((listel)) {
	    varele -> elements[varynum] = listel -> i;
	    listel = listel -> next;
	    ++varynum;
	  }
	  
	  destroyinlistel(flistel);
	  flistel = listel = NULL;
	  
	  /* Then we proceed to the next varele */
	  varele = appendvarlel(varele);
	  
	  if (fillhdvarele(varele, i, array, (((int) array[ELEMENTS_SECPOS-1])/rpm -> nur < NPARAMS)?((int) array[ELEMENTS_SECPOS-1])/rpm -> nur+1:((int) array[ELEMENTS_SECPOS-1])%rpm -> nur+NPARAMS+1, parmax, parmin, moderate, delstart, delend, itestart, iteend, satdelt, mindelta, hdr, log))
	    goto error;
	}
      }

      listel = appendinlistel(listel);
      if (!flistel) 
 flistel = listel;

      listel -> i =  (int) array[ELEMENTS_SECPOS-1];
       pointarray[i] = varele;

      ++tabentries;
    }

    /* There might be a last flistel to put in the file */
    if ((flistel)) {
      varynum = 1;
      listel = flistel;
      while ((listel = listel -> next))
     ++varynum;
      
      varele -> nelem = varynum;
      if (!(varele -> elements = (int *) malloc(varynum*sizeof(int))))
 goto error;
      
      varynum = 0;
      listel = flistel;
      
      while((listel)) {
 varele -> elements[varynum] = listel -> i;
 listel = listel -> next;
 ++varynum;
      }

      destroyinlistel(flistel);
    }    
    flistel = NULL;
    listel = NULL;
  }
  

  /* Scan the all-variable array */
  i = 0;
  j = -1;
  nel = 0;
 /* As long as there are any items in the varystr go ahead */
 while (i < strnr-1) {

   /* Check if we are at a valid keyword */ 
   if ((ftstab_gtitln_(varystr[i]) < 1) || (ftstab_gtitln_(varystr[i]) > NPARAMS+NSPARAMS)) {
     
     /* If not we fill twoints */
       decodestr(varystr[i], twoints, rpm -> nur);
   }
   else {
     
     /* If yes, we change the key */
     device = ftstab_gtitln_(varystr[i]);
     
     /* And the adress in the delta array */
     ++j;
     /* And we check if the keyword is "lone" */

     /* !!!BUGFIX: included " !(varystr[i+1])) || " !!! */
     if ((!(varystr[i+1])) || ((i+1) == strnr) || ((ftstab_gtitln_(varystr[i+1]) > 0) && (ftstab_gtitln_(varystr[i+1]) <= NPARAMS+NSPARAMS))) {
       twoints[0] = 1;
       twoints[1] = rpm -> nur;
     }
     else {
       twoints[0] = 0;
       twoints[1] = -1;
     }
   }
   if (device == CONDISP && (twoints[0])) {
     twoints[0] = twoints[1] = 1;
   }
   /* Now, we have to compose as many varlels as there are entries with one element */
   for (k = twoints[0]-1; k < twoints[1]; ++k) {
     
     /* if we are at the start, we will create the first varele */
     if (!(fit -> varylist)) {
       
       /* Allocate the first element of the varylist */
       if (!(varele = fit -> varylist = appendvarlel(NULL)))
	 goto error;
     }
     else
       varele = appendvarlel(varele);
     
     if (!(varele -> elements = (int *) malloc(sizeof(int))))
       goto error;
     varele -> nelem = 1;
     varele -> parmax   = simpleglobtointern(parmax[j], device, hdr);
     varele -> parmin   = simpleglobtointern(parmin[j], device, hdr);
     varele -> moderate = moderate[j];
     varele -> delstart = dparamtointern(delstart[j], device, hdr);
     varele -> delend   = dparamtointern(delend[j], device, hdr);
     varele -> itestart = itestart[j];
     varele -> iteend   = iteend[j];
     varele -> satdelt  = dparamtointern(satdelt[j], device, hdr);
     varele -> mindelta  = dparamtointern(mindelta[j], device, hdr);
     
     /* We point the jth element of the pointarray to the present varele */
     pointarray[j] = varele;
     
     /* The adress of the parameter is par[*varlel -> elements], NOT par[*varlel -> elements-1] */
     *varele -> elements = (device-1)*rpm -> nur+k;
   }
   ++i;
 }
 
  /* We are through with the first array, it follows the second */
  while (varystr[i] != NULL) {
      
    /* Check if we are at a valid keyword */ 
    if ((ftstab_gtitln_(varystr[i]) < 1) || (ftstab_gtitln_(varystr[i]) > NPARAMS+NSPARAMS)) {
      
      /* If not we fill twoints */
      decodestr(varystr[i], twoints, rpm -> nur);
    }
    else {
      
      /* If yes, we change the key, but first fill the next element of the list */
      if ((flistel)) {
 if (!(fit -> varylist)) {
   /* Allocate the first element of the varylist */
   if (!(varele = fit -> varylist = appendvarlel(NULL)))
     goto error;
 }
 else
   varele = appendvarlel(varele);
 
 l = 1;
 /* count the number of elements of flistel */
 listel = flistel;
 while ((listel = listel -> next))
   ++l;
 
 /* Allocate the space */
 if (!(varele -> elements = (int *) malloc(l*sizeof(int))))
   goto error;
 
 varele -> nelem = l;
 varele -> parmax   = simpleglobtointern(parmax[j], device, hdr);
 varele -> parmin   = simpleglobtointern(parmin[j], device, hdr);
 varele -> moderate = moderate[j];
 varele -> delstart = dparamtointern(delstart[j], device, hdr);
 varele -> delend   = dparamtointern(delend[j], device, hdr);
 varele -> itestart = itestart[j];
 varele -> iteend   = iteend[j];
 varele -> satdelt  = dparamtointern(satdelt[j], device, hdr);
 varele -> mindelta  = dparamtointern(mindelta[j], device, hdr);
 
 /* We point the jth element of the pointarray to the present varele */
 pointarray[j] = varele;
 
 /* Put the content of flistel in the array */
 l = 0;
 listel = flistel;
 while ((listel)) {
   varele -> elements[l] = listel -> i;
   ++l;
   listel = listel -> next;
 }
 
 /* destroy flistel */
 destroyinlistel(flistel);
 flistel = NULL;
 
 /* At the end append a varlel */
 /*    varele = appendvarlel(varele); */
      }
      
      device = (ftstab_gtitln_(varystr[i]) > NPARAMS+NSPARAMS)?0:ftstab_gtitln_(varystr[i]);
      
      /* And the adress in the delta array */
      ++j;
      
      /* And we check if the keyword is "lone" */
      if (!(varystr[i+1]) || ((ftstab_gtitln_(varystr[i+1]) > 0) &&  (ftstab_gtitln_(varystr[i+1]) <= NPARAMS+NSPARAMS)) ) {
 twoints[0] = 1;
 twoints[1] = rpm -> nur;
      }
      else 
 twoints[1] = -1;
    }
    
    if (device == CONDISP) {
      twoints[0] = twoints[1] = 1;
    }
    /* Now, we have to compose the flistel */
    for (k = twoints[0]-1; k < twoints[1]; ++k) {
      
      /* Check if the variable is existent already */
      if (!flistel) {
 listel = flistel = appendinlistel(NULL);
 listel -> i = ((device-1)*rpm->nur+k);
      }
      else {
 listel = flistel;
 while((listel)) {
   if (listel -> i == ((device-1)*rpm->nur+k))
     break;
   listel = listel -> next;
 }
 
 /* if we broke, listel is not NULL, so if it is, we append an element */
 if (!listel) {
   listel = flistel;
   while((listel -> next)) {
     listel = listel -> next;
   }
   listel = appendinlistel(listel);
   listel -> i = (device-1)*rpm->nur+k;
 }
      }
    }
    
    ++i;
  }
    
    
  /* At the end we append one listel */
  if (flistel) {
    if (!(fit -> varylist)) {
      /* Allocate the first element of the varylist */
      if (!(varele = fit -> varylist = appendvarlel(NULL)))
 goto error;
    }
    else
      varele = appendvarlel(varele);
    l = 1;
    /* count the number of elements of flistel */
    listel = flistel;
    while ((listel = listel -> next))
      ++l;
      
    /* Allocate the space */
    if (!(varele -> elements = (int *) malloc(l*sizeof(int))))
      goto error;
      
    varele -> nelem = l;
    varele -> parmax   = simpleglobtointern(parmax[j], device, hdr);
    varele -> parmin   = simpleglobtointern(parmin[j], device, hdr);
    varele -> moderate = moderate[j];
    varele -> delstart = dparamtointern(delstart[j], device, hdr);
    varele -> delend   = dparamtointern(delend[j], device, hdr);
    varele -> itestart = itestart[j];
    varele -> iteend   = iteend[j];
    varele -> satdelt  = dparamtointern(satdelt[j], device, hdr);
    varele -> mindelta  = dparamtointern(mindelta[j], device, hdr);
      
    /* We point the jth element of the pointarray to the present varele */
    pointarray[j] = varele;
      
    
    /* Put the content of flistel in the array */
    l = 0;
    listel = flistel;
    while ((listel)) {
      varele -> elements[l] = listel -> i;
      ++l;
      listel = listel -> next;
    }
      
    /* destroy flistel */
    destroyinlistel(flistel);
    flistel = NULL;
  }
    /*******************/   
  /*******************/   
  /*******************/   
  /*******************/   
/*    Check that */
/*   l = 0; */
/*   n = 0; */
/*   def = 0; */
/*   varele2 = varylist; */
/*   while((varele2)) { */

/*       *obsolete ='\0'; */

/*     ++l; */
/*     for (k = 0; k < varele2 -> nelem; ++k) */
/*       sprintf(obsolete, "%s %i", obsolete, varele2 -> elements[k]); */

/*     sprintf(mes,"element %i of list, %i elements, delta: %i, list: %s", l, varele2 -> nelem, varele2 -> moderate, obsolete); */
/*     anyout_c(&def, tofchar(mes)); */
/*     varele2 = varele2 -> next; */
/*   } */


/*    sprintf(mes,"    "); */
/*     anyout_c(&def, tofchar(mes)); */
/*   l = 0; */
/*   n = 0; */
/*   def = 0; */
/*   varele = fit -> varylist; */
/*   while((varele)) { */
/*     if (pointarray[n] == varele) { */
/*       sprintf(obsolete, "*"); */
/*       ++n; */
/*     } */
/*     else */
/*       *obsolete ='\0'; */
/*     ++l; */
/*     for (k = 0; k < varele -> nelem; ++k) */
/*       sprintf(obsolete, "%s %i", obsolete, varele -> elements[k]); */

/*     sprintf(mes,"element %i of list, %i elements, delta: %i, list: %s", l, varele -> nelem, varele -> moderate, obsolete); */
/*     anyout_c(&def, tofchar(mes)); */
/*     varele = varele -> next; */
/*   } */
/*******************************/
  
  /* Now we have to go through the arrays again, comparing */
  cancel_c(tofchar("PROCEED="));

  if ((log -> logname) && !(log -> logpres)) {
    sprintf(key,"NON");
      
    /* First check if we are through anyway */
    if (!(fit -> varylist))
           fit -> varylist = varylist;
    else {
      varele = varylist;
      varele2 = fit -> varylist;
      while(varele) {
 if (comparevarlel(varele, varele2) > 0) {
     
   /* This is fatal */
   sprintf(mes, "VARYSING or VARYMULT: Values differ from logfile, overwrite?");
   sprintf(key,"YES");
   def = 5;
   nel = 1;
   userchar_c(tofchar(key), &nel, &def, tofchar("OVERWRITE="), tofchar(mes));
     
   /* Not yes means no, stop things */
   if (strcmp(key,"YES"))
     goto error;
     
   /* We will delete the header */
   log -> logpres = 1;
   break;
 }
 else if (comparevarlel(varele, varele2) < 0) {
     
   /* This is not exactly fatal */
   sprintf(mes, "VARYSING or VARYMULT: Values differ from logfile, once for all: proceed?");
   sprintf(key,"YES");
   def = 5;
   nel = 1;
   userchar_c(tofchar(key), &nel, &def, tofchar("PROCEED="), tofchar(mes));
     
   /* Not yes means no, stop things */
   if (strcmp(key,"YES"))
     goto error;

   log -> changes = 1;
 }
 varele = varele -> next;
 varele2 = varele2 -> next;
      }
    }
  }
    /* Now we have to go through the arrays again, comparing */
  cancel_c(tofchar("PROCEED="));
  
/* This is really not elegant, but we'll simply do it like that */
  if ((log -> logname) && !(log -> logpres)) {
    change_hdu_2(fit -> varylist, pointarray, rpm -> nur, hdr);
  }

  /* These are now not necessary anymore, they exist in any case */
  free(parmax);
  parmax = NULL;
  free(parmin);
  parmin = NULL;
  free(moderate);
  moderate = NULL;
  free(delstart);
  delstart = NULL;
  free(delend);
  delend = NULL;
  free(itestart);
  itestart = NULL;
  free(iteend);
  iteend = NULL;
  free(satdelt);
  satdelt = NULL;
  free(mindelta);
  mindelta = NULL;
  if (array)
    free(array);
  array = NULL;

  /* Now write the second hdu if warranted */
  /* We are thru with the second hdu, so it will be created if not already existent */
  if ((log -> logname) && (log -> logpres)) {
    if ((create_hdu_2(log -> logname, fit -> varylist, pointarray, rpm -> nur, hdr)))
      goto error;
  }
  ftstab_close_();
    
  /* Make a flush and don't forget to recreate the hdrlist */
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();

  /* Deallocate things */
  if ((pointarray))
    free(pointarray);
    
  if (varylist && varylist != fit -> varylist)
    destroyvarlel(varylist);
    
  if ((varystr)) {
    free(varystr);
  }

  if ((varyhstr))
    free(varyhstr);

  if ((flistel))
    destroyinlistel(flistel);

  return fit;
    
 error:
  destroy_fitparms(fit);
    
  if (varylist)
    destroyvarlel(varylist);
    
  if ((flistel))
    destroyinlistel(flistel);
    
  if ((varystr)) {
    free(varystr);
  }
  if ((varyhstr))
    free(varyhstr);
    
  /* Allocate the pointarray */
  if ((pointarray))
    free(pointarray);
   
  /* Allocate the */
  if ((parmax))
    free(parmax);
    
  /* Allocate the */
  if ((parmin))
    free(parmin);
    
  /* Allocate the */
  if ((moderate))
    free(moderate);
    
  /* Allocate the */
  if ((delstart))
    free(delstart);
    
  /* Allocate the */
  if ((delend))
    free(delend);
    
  /* Allocate the */
  if ((itestart))
    free(itestart);
    
  /* Allocate the */
  if ((iteend))
    free(iteend);
    
  if ((satdelt))
    free(satdelt);
    
  if ((mindelta))
    free(mindelta);
    
  if ((array))
    free(array);
    
  /*   if ((elements)) */
  /*     free(elements); */
    
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Decodes an input string */
static int decodestr(char *string, int *array, int max)
{
  size_t lengthofstr;
  char *brpos;

  if (max < 1)
    return 0;

  /* !!!BUGFIX: will return full range but still report an error for NULL passed */
  if (!string) {
    array[0] = 1;
    array[1] = max;
    return 0;
  }

  /* Get the length of the string */
  if (!(lengthofstr = strlen(string))) {

    /* If it is an empty string, then return the default */
    array[0] = 1;
    array[1] = max;
    return 1;
  }  

  /* First check if the string contains only integers and in-between
     a ':' */
  if (strspn(string, "0123456789:") != lengthofstr)
    return 0;
  
  /* : may only occur once */
  if (strchr(string, ':') != strrchr(string, ':'))
    return 0;

  /* Now get the position of the : */
  if ((brpos = strchr(string, ':')) && (lengthofstr == 1))
    return 0;

  /* If there is no : a is b and the number */
  if (!brpos) {
    sscanf(string, "%d", array);
    array[1] = array[0];
    if ((array[0] < 1) || (array[1] > max))
      return 0;
  }
  
  /* if it is at the start, then a is 1 */
  else if (string == brpos) {
    array[0] = 1;

    /* b is the rest */
    sscanf(string+1, "%d", array+1);
    
    /* check if it is ok */
    if (array[1] > max)
      return 0;
  }
  
  /* if it is at the end, then b is max */
  else if (string+lengthofstr-1 == brpos) {
    array[1] = max;

    /* temporarily make the : an 0 */
    *brpos = '\0';
    
    /* a is the rest */
    sscanf(string, "%d", array);
    
    *brpos = ':';
    
    /* check if it is ok */
    if (array[0] < 1) {
      return 0;
    }
  }
  
  /* if it is in the middle */
  else {
    
    /* temporarily make the : an 0 */
    *brpos = '\0';

    /* a is at the start */
    sscanf(string, "%d", array);

    /* b is at the end */
    sscanf(brpos+1, "%d", array+1);
    
    *brpos = ':';
    
    /* check if it is ok */
    if ((array[0] < 1) || (array[1] > max))
      return 0;
  }
  
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Conversion of some units */
static double simpleglobtointern(double value, int par, hdrinf *hdr)
{
  switch(par) {
    case RADI: 
    return value/hdr -> deltgridtouser[0];
  case VROT:
    /* Formerly: deltgridtouser[0]; */
    return value/hdr -> deltgridtouser[2];
  case Z0:    
     /* Formerly: deltgridtouser[2]; */
    return value/hdr -> deltgridtouser[0];
  case SBR:
    return value/hdr -> jygridtouser;
  case INCL:
    return DEGTORAD*value;
  case PA: 
    return DEGTORAD*(value);
    /* globtointern */
  case XPOS:   
    return (value - hdr -> userglobcrval[0])/hdr -> userglobcdelt[0]+(hdr -> setcrpix[0]-1.0);
  case YPOS:   
    return (value - hdr -> userglobcrval[1])/hdr -> userglobcdelt[1]+(hdr -> setcrpix[1]-1.0);
  case VSYS:
    return (value - hdr -> userglobcrval[2])/hdr -> userglobcdelt[2]+(hdr -> setcrpix[2]-1.0);
  case CONDISP:
    return value/hdr -> deltgridtouser[2];

  default:
    return value;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Conversion of some units */
static double simpleinterntoglob(double value, int par, hdrinf *hdr)
{
  switch(par) {
    case RADI:
    return value*hdr -> deltgridtouser[0];
  case VROT:   
    return value*hdr -> deltgridtouser[2];
  case Z0:     
    return value*hdr -> deltgridtouser[1];
  case SBR:
    return value*hdr -> jygridtouser;
  case INCL:
    return RADTODEG*value;
  case PA: 
    return RADTODEG*value;
  case XPOS:   
    return (value-hdr -> setcrpix[0]+1.0)*hdr -> userglobcdelt[0]+hdr -> userglobcrval[0];
  case YPOS:   
    return (value-hdr -> setcrpix[1]+1.0)*hdr -> userglobcdelt[1]+hdr -> userglobcrval[1];
  case VSYS:
    return (value-hdr -> setcrpix[2]+1.0)*hdr -> userglobcdelt[2]+hdr -> userglobcrval[2];
  case CONDISP:
    return value*hdr -> deltgridtouser[2];
  default:
    return value;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Conversion of some units */
static double dparamtointern(double value, int par, hdrinf *hdr)
{
  switch(par) {
  case RADI:
    return value/hdr -> deltgridtouser[0];
  case VROT:


    /* Formerly: deltgridtouser[0]; */
    return value/hdr -> deltgridtouser[2];
  case Z0:    

     /* Formerly: deltgridtouser[2]; */

    return value/hdr -> deltgridtouser[0];
  case SBR:
    return value/hdr -> jygridtouser;
  case INCL:
    return DEGTORAD*value;
  case PA: 
    return DEGTORAD*value;
  case XPOS:   
    return value/hdr -> globgridtouser[0];
  case YPOS:   
    return value/hdr -> globgridtouser[1];
  case VSYS:
    return value/hdr -> globgridtouser[2];
  case CONDISP:
    return value/hdr -> deltgridtouser[2];
  default:
    return value;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Conversion of some units */
static double dinterntoparam(double value, int par, hdrinf *hdr)
{
  switch(par) {
  case RADI:
    return value*hdr -> deltgridtouser[0];
  case VROT:   
    return value*hdr -> deltgridtouser[2];
  case Z0:     
    return value*hdr -> deltgridtouser[1];
  case SBR:
    return value*hdr -> jygridtouser;
  case INCL:
    return RADTODEG*value;
  case PA: 
    return RADTODEG*value;
  case XPOS:   
    return value*hdr -> globgridtouser[0];
  case YPOS:   
    return value*hdr -> globgridtouser[1];
  case VSYS:
    return value*hdr -> globgridtouser[2];
  case CONDISP:
    return value*hdr -> deltgridtouser[2];
  default:
    return value;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* conversion of map units */
static void globtointern(double *invalue, double *outvalue, hdrinf *hdr)
{
  int transformation = 0;
  double dbldbl[2];
  int vint;

  /* Transform the map units into grids */
  dbldbl[0] = invalue[0]/hdr -> globsettouser[0];
  dbldbl[1] = invalue[1]/hdr -> globsettouser[1];

  /* Get the map unit belonging to velocity */
  outvalue[2] = (invalue[2] - hdr -> userglobcrval[2])/hdr -> userglobcdelt[2]+(hdr -> setcrpix[2]-1.0);

  /* We assign this to a grid position */
  vint = roundnormal(outvalue[2]);

  /* There are maximal and minimal values that can be set */
  if (vint < 0)
    vint = 0;
  if (vint >= hdr -> nsubs)
    vint =  hdr -> nsubs-1;

  /* Now do the transformation, it should work */
  cotrans_c(tofchar(hdr -> inset), &hdr -> insubs[vint], dbldbl, outvalue, &transformation);
 
 /* Now we have grids that we have to transform to maps */
  outvalue[0] = outvalue[0]+hdr -> setcrpix[0]-1;
  outvalue[1] = outvalue[1]+hdr -> setcrpix[1]-1;

  /* Again, the map unit belonging to velocity, because cotrans does a nasty thing */
  outvalue[2] = (invalue[2] - hdr -> userglobcrval[2])/hdr -> userglobcdelt[2]+(hdr -> setcrpix[2]-1.0);

  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* conversion of map units */
static void interntoglob(double *invalue, double *outvalue, hdrinf *hdr)
{
  int transformation = 1;
  double dbldbl[2];
  int vint;

  /* Transform the map units into grid units */
  dbldbl[0] = invalue[0]-hdr -> setcrpix[0]+1;
  dbldbl[1] = invalue[1]-hdr -> setcrpix[1]+1;

  /* We assign the velocity to a map position */
  vint = roundnormal(invalue[2]);

  /* There are maximal and minimal values that can be set */
  if (vint < 0)
    vint = 0;
  if (vint >= hdr -> nsubs)
    vint =  hdr -> nsubs-1;

  /* Now do the transformation, it should work */
  cotrans_c(tofchar(hdr -> inset), &hdr -> insubs[vint], dbldbl, outvalue, &transformation);

  /* Get the user unit belonging to velocity */
  outvalue[0] = outvalue[0]*hdr -> globsettouser[0];
    outvalue[1] = outvalue[1]*hdr -> globsettouser[1];
  outvalue[2] = (invalue[2]-hdr -> setcrpix[2]+1)*hdr -> userglobcdelt[2]+hdr -> userglobcrval[2];

  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Change the parameter list params to internal units as if being user units */
static void changetointern(double *params, int nur, hdrinf *hdr)
{
  int i;
  double globin[3];
  double globout[3];

  /* This is all very simple */
  for (i = 0; i < nur; ++i) {

    /* Some of the easily convertable thingies */
     params[PRADI*nur+i] = dparamtointern(params[PRADI*nur+i], RADI, hdr);
     params[PVROT*nur+i] = dparamtointern(params[PVROT*nur+i], VROT, hdr);
     params[PZ0*nur+i]   = dparamtointern(params[PZ0*nur+i], Z0, hdr);
     params[PSBR*nur+i]  = dparamtointern(params[PSBR*nur+i], SBR, hdr);
     params[PINCL*nur+i] = dparamtointern(params[PINCL*nur+i], INCL, hdr);
     params[PPA*nur+i]   = dparamtointern(params[PPA*nur+i], PA, hdr);

 /* Now, we have to convert the triplets into internal units */
    globin[0] = params[PXPOS*nur+i];
    globin[1] = params[PYPOS*nur+i];
    globin[2] = params[PVSYS*nur+i];

    globtointern(globin, globout, hdr);
   
    params[PXPOS*nur+i] = globout[0];
    params[PYPOS*nur+i] = globout[1];
    params[PVSYS*nur+i] = globout[2];
  }

  params[PCONDISP*nur] = dparamtointern(params[PCONDISP*nur], CONDISP, hdr);

  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Constructor of an element of the varlel list */
static varlel *appendvarlel(varlel *last)
{
  varlel *out;

  if (!(out = (varlel *) malloc(sizeof(varlel))))
    return NULL;

  if ((last))
    last -> next = out;

  /* "Terminate" */
  out -> nelem = 0;
  out -> next = NULL;

  return out;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destructor of a varlel list */
static void destroyvarlel(varlel *first)
{
  varlel *next;

  while ((first)) {
    /* Convention is that elements is dynamically allocated */
    if ((first -> nelem))
      free(first -> elements);
    next = first -> next;
    free(first);
    first = next;
  }
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Constructor of an element of the inlistel list */
static inlistel *appendinlistel(inlistel *last)
{
  inlistel *out;

  if (!(out = (inlistel *) malloc(sizeof(inlistel))))
    return NULL;

  if ((last))
    last -> next = out;

  /* "Terminate" */
  out -> next = NULL;

  return out;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* write the output cube */

static int writemodel(hdrinf *origin, ringparms *rpm)
{
  int i=0,j,k,l;
  char mes[81];
 /*****************/
  /*****************/
/*   fint obsint = 0; */
/*   char obsmes[80]; */
  /*****************/
  
  /**********/
  /**********/
/*    sprintf(obsmes,"got here");  */
/*    anyout_c(&obsint, tofchar(obsmes));  */
  /**********/

  /* If outset is not defined, we stop here */
  if (*origin -> outset == '\0') {
    return 1;
  }

  /* We have to put the current best values to the cube */
  for (i = 0; i < rpm -> nur*NPARAMS+NSPARAMS; ++i)
    rpm -> par[i] = rpm -> oldpar[i];

  /* Then we generate the cube and convolve it */
  galmod(origin, rpm, 1, NULL);
  getchisquare_c(rpm -> par[PCONDISP*rpm -> nur]);

  /* Correct the chisquare taking into account the outliers, don't know if that is necessary here... */
  origin -> chi2 = origin -> chi2+((double) rpm -> outpoints)*rpm -> penalty;

  /* Now rearrange the cube */
  for(k = 0; k < origin -> nsubs; ++k)
    for(j = 0; j < origin -> bsize2; ++j)
      for(i = 0; i < origin -> bsize1; ++i)
	origin -> model[i+origin -> bsize1*(j+origin -> bsize2*k)] = origin -> model[i+2*(origin -> bsize1/2+1)*(j+origin -> bsize2*k)];

  /* Write the cube plane by plane, really too lazy to track min and max */

  /* change this first */
  origin -> nprof = origin -> bsize1*origin -> bsize2;

 for (i = 0; i < origin -> nsubs; ++i) {
   j=i*origin -> nprof;

   /* My god, this has to be set, otherways: crash... */
   l = 0;
   gdsi_write_c(tofchar(origin -> outset), origin -> cwlo+i, origin -> cwhi+i, origin -> model+j, &origin -> nprof, &k, &l);
   if (l) {
     i = 1;
     sprintf(mes, "Unable to write outset with error %i.", l);
     error_c(&i, tofchar(mes));
     return 0;
   }
 }

 /* Now change this back */
 origin -> nprof = origin -> bcsize1*origin -> bsize2;

 return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destructor of a inlistel list */
static void destroyinlistel(inlistel *first)
{
  inlistel *next;

  while ((first)) {
    /* Convention is that elements is dynamically allocated */
    next = first -> next;
    free(first);
    first = next;
  }
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Opens a file and puts an old-style ascii header to the top */

static void prepout(loginf *log, hdrinf *hdr, ringparms *rpm)
{
  int i, j;
  char key[21];

  /* Start with the usual check */
  if (*log -> textlog == '\0')
    return;

  /* We try to open write append without header if the file exists,
     without checking the content */
  if (!(log -> tstream = fopen(log -> textlog, "r"))) {

    /* If the file doesn't exist we compose a header */
    if ((log -> tstream = fopen(log -> textlog, "w"))) {

    /* Turn off the buffering for tstream */
    setbuf(log -> tstream, NULL);

      fprintf(log -> tstream, " MODEL# ");

      /* We now compose a header entry for each keyword including radius */
      for (i = 1; i <= NPARAMS; ++i) {
 for (j = 0; j < rpm -> nur; ++j) {
   /* Put the title */
   ftstab_putcoltitl(key, i);
   fprintf(log -> tstream, "%6s", key);
   
   /* Now with an underscore the radius */
   fprintf(log -> tstream, "_%04.1f ", dinterntoparam(rpm -> par[j], RADI, hdr));
 }
      }
      for (i = 1; i <= NSPARAMS; ++i) {
 ftstab_putcoltitl(key, i+NPARAMS);
 fprintf(log -> tstream, "%11s", key);
      }

      /* The reduced chisquare and acceptance */
      ftstab_putcoltitl(key, NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI+RCHISQ_TABNR);
      fprintf(log -> tstream, "%23s", key);
      ftstab_putcoltitl(key, NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI+ACCEPT_TABNR);
      fprintf(log -> tstream, "%10s", key);

      fprintf(log -> tstream,"\n");
    }
  }
  else {
    log -> tstream = fopen(log -> textlog, "a");

    /* Turn off the buffering for tstream */
    setbuf(log -> tstream, NULL);
  }

  return;
}




/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Replaces the first occurence of  ' ' in string with '\0' */
void termsinglestr(char *string)
{
  int i = 0;
  while (string[i] != '\0' && string[i] != ' ')
    ++i;
  string[i] = '\0';
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* The working horse */
int metropolis(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
{
  int dof; /* Degrees of freedom */
  int i;
  varlel *nextvarlel;
  char mes[160]; /* Any message */
  double proba; /* Probability of a model in dependence of the previous */
  double anneal;
  char accept; /* Simple marker whether a model has been accepted or not */
  long checkbadattempts = 0;  
  double delta;
  fint dev = 1;
  
  /*****************/
  /*****************/
/*   fint obsint = 0; */
/*   char obsmes[80]; */
  /*****************/
  
  /**********/
  /**********/
/*    sprintf(obsmes,"got here");  */
/*    anyout_c(&obsint, tofchar(obsmes));  */
  /**********/

/* Count the number of entries in the varylist */
  i = 0;
  nextvarlel = fit -> varylist;
  while ((nextvarlel)) {
    ++i;
    nextvarlel = nextvarlel -> next;
  }
  
  /* The degrees of freedom are determined by the amount of variable
     parameters, we do it VERY roughly. If there is a parameter varied
     twice, this is not true anymore */
  dof = (hdr -> bsize1-1)*hdr -> bsize2* hdr -> nsubs-i;
  
  /* When starting make one run of interpover */
  interpover(rpm, rpm -> radsep, 0, NULL);

  /* Start the loop */
  while (fit -> loopnr <= fit -> loops) {
    sprintf(mes, "Calculating model %li of %i", fit -> loopnr, fit -> loops);
    status_c(tofchar(mes));
    
    /* The actual annealing factor is given by */
    if ((fit -> loopnr-fit -> ansteps) <= 0) {
      anneal = (fit -> loopnr)?(fit -> loopnr-1)*(fit -> anend-fit -> anstart)/fit -> ansteps+fit -> anstart:1.0;
    }
    else {
      anneal = fit -> anend;
    }
    
    /* Do it */
    fit -> npoints = galmod(hdr, rpm, 0, fit -> varylist);
    
    /* Get the chisquare */
    getchisquare_c(rpm -> par[PCONDISP*rpm -> nur]);
    
    /* Correct the chisquare taking into account the outliers, don't know if that is necessary here... */
    hdr -> chi2 = hdr -> chi2+((double) rpm -> outpoints)*rpm -> penalty;
    
    /* Now decide whether to accept or not */
    /* We accept if this is the case, and in this case only we have to do something  */
    
    accept = 0;
    if (((proba = exp((hdr -> oldchi2-hdr -> chi2)/(2*anneal))) > (maths_rndm(fit -> normrandstr))) && (fit -> outofrange)) {
      for (i = 0; i <= rpm -> nur*NPARAMS; ++i)
	rpm -> oldpar[i] = rpm -> par[i];
      hdr -> oldchi2 = hdr -> chi2;
      accept = 1;
    }
    
    /* Report some things */
    
    sprintf(mes, 
	    "TM:%li "      /* loops is identical with total models */
	    "NP:%d "       /* Number of pointsources */
	    "TF:%.2E "     /* Total flux */
	    "CC:%E "       /* current minimum chisquare */
	    "PR:%+.1E "    /* Probability */
	    "SW:%+.2E "     /* Current stepwidth */
	    "AC:%i "      /* Acceptance flag */                                          
	    "RA:%i "      /* Out of range flag */
	    "AN:%f ",      /* Annealing factor */                                 
	    fit -> loopnr,                                                                 /* Keyword loops */        
	    fit -> npoints,                                                                /* Number of pointsources */       
	    fit -> npoints*rpm -> cflux,                                                   /* Total flux */        
	    hdr -> oldchi2,                                                                /* current minimum chisquare */       
	    proba,                                                                         /* Probability */        
	    dinterntoparam(delta, ftstab_get_coltit(*(fit -> varylist) -> elements+1), hdr),          /* Current maximum stepwidth of very first list */        
	    accept,                 /* Acceptance flag */ 
	    fit -> outofrange,                                                             /* Out of range flag */
	    anneal                                                                         /* Annealing factor */
	    );    
    anyout_c(&dev, tofchar(mes));
    
    /* Write the output */
    writeoutput(log, hdr, rpm, fit, accept, dof, fit -> loopnr, proba);
    
    ++fit -> loopnr;
    
    /* Write an output cube */
    if ((*hdr -> outset != '\0')) {
      if (!(fit -> loopnr%hdr -> outcubup)) {
	writemodel(hdr, rpm);
      }
    }
    
    fit -> outofrange = 1;    
    
    /* This is for monitoring, does the same as chprm_metro for the first element, maybe an unnecessary overhead */
    if (fit -> loopnr - fit -> varylist -> moderate <= 0)
      delta = (fit -> loopnr-1)*((fit -> varylist) -> delend-(fit -> varylist) -> delstart)/fit ->varylist -> moderate+(fit -> varylist) -> delstart;
    else
      delta = fit -> varylist -> delend;
    
    /* Now change the parameters */
    if (chprm_metro(fit -> varylist, rpm -> oldpar, rpm -> par, fit -> normrandstr, fit -> loopnr)) {
      
      /* If they get out of range, the next approximation will always fail, because we enforce zero probability */
      fit -> outofrange = 0;
      ++checkbadattempts;
    }
    
    
    if (checkbadattempts > EXMAXMETRO)
      goto error;
  }

   return 1;

 error:
  return 0;
}


/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Interpolate over the par list to get the modpar */

static void interpover(ringparms *rpm, double radsep, int fitmode, varlel *varele)
{
  int i,j,k;
  float width;
  float dpardr[NPARAMS];
  float dr;
  int n1, n2;
  /**********/
  /**********/
  /* fint obsint = 0; */
  /* char obsmes[81]; */
  /*********/
  
  /******/
  /******/
  /* sprintf(obsmes, "got here"); */
  /* anyout_c(&obsint, tofchar(obsmes)); */
  /******/

  /* Check if we initialise */
  if (!(varele)) {
    interpinit(rpm, radsep);
    return;
  }

  /* Check if there was a global parameter, then touch the lists */
  if (varele -> elements[0] > rpm -> varpars) {
    for (i = 0; i < rpm -> nr; ++i) {
      if ((rpm -> sd[i].pl)) {
	free(rpm -> sd[i].pl);
	rpm -> sd[i].pl = NULL;
      }
    }
    return;
  }

  k = 0; 
  
  /* In the modpar array interpolate over all rings */
  for (i = 1; i < rpm -> nur; ++i) {
    
    /* If yes, we need these */
    if (chkchange(varele, fitmode, i, rpm -> nur)) {
      
      /* This is the actual width between two radii */
      width = rpm -> par[PRADI*rpm -> nur+i] - rpm -> par[PRADI*rpm -> nur+i-1];
      
      /* These are the subrings to be calculated */
      n2 = (int) (rpm -> par[PRADI*rpm -> nur+i]/radsep-0.5); 
      n1 = ((int) (rpm -> par[PRADI*rpm -> nur+i-1]/radsep+0.5)); 
      
      
      /* in-between two rings, the slope is determined, should start with 1 */
      for (j = 1; j < NPARAMS; ++j) {
	
	/* If the parameter is in the list */
	if (chkchangep(varele, fitmode, j*rpm -> nur+i, rpm -> nur)) {
          dpardr[j]= (rpm -> par[j*rpm -> nur+i]-rpm -> par[j*rpm -> nur+i-1])/width;
	  
	  for (k = n1; k <= n2; ++k) {
	    dr = rpm -> modpar[PRADI*rpm -> nr+k]-rpm -> par[PRADI*rpm -> nur+i-1];
	    
	    /* for each parameter the intepolation is done */
	    rpm -> modpar[j*rpm -> nr+k] = rpm -> par[j*rpm -> nur+i-1]+dpardr[j]*dr;
	  }
        }
      }

      /* Now change the pre-processed parameters and terrminate the pointsource lists */
      for (k = n1; k <= n2; ++k)
	srprep(rpm, k, 0);
    }
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Generation of a pointsource list */
static void srprep(ringparms *rpm, int srnr, long mode)
{
  float ringflux;

  /**************/
  /**************/
/*   fint obsint = 0; */
/*   char obsmes[80]; */
  /**************/
  /**************/
  /**************/
/*   sprintf(obsmes, "got here"); */
/*   anyout_c(&obsint, tofchar(obsmes));  */
  /**************/
  /**************/

  /* Calculate the ringflux */
  ringflux = TWOPI*rpm -> modpar[PRADI*rpm -> nr+srnr]*rpm -> radsep*rpm -> modpar[PSBR*rpm -> nr+srnr];
  
  /* Calculate the cloudnumber, rounded down */
  rpm -> sd[srnr].n = (long) (ringflux/rpm -> cflux);

  /* We allow for a negative pointsource flux, even if it makes no sense */
  if (rpm -> sd[srnr].n < 0)
    rpm -> sd[srnr].n = -rpm -> sd[srnr].n;

  /* We decide to change the cloudflux a bit instead of accepting an error in the ringflux */
  rpm -> sd[srnr].pf = ringflux/rpm -> sd[srnr].n;

  if (rpm -> sd[srnr].n > 0) {
    
    /* We calculate cos's and sins and reset the random number generator */
    rpm -> sd[srnr].sini=sinf(rpm -> modpar[PINCL*rpm -> nr+srnr]);
    rpm -> sd[srnr].cosi=cosf(rpm -> modpar[PINCL*rpm -> nr+srnr]);;
    rpm -> sd[srnr].sinp=sinf(rpm -> modpar[PPA*rpm -> nr+srnr]);
    rpm -> sd[srnr].cosp=cosf(rpm -> modpar[PPA*rpm -> nr+srnr]);
  }

  /* free the pointsource list */
  if ((rpm -> sd[srnr].pl)) {
    free(rpm -> sd[srnr].pl);
    rpm -> sd[srnr].pl = NULL;
  }
  return;
}
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grids a point to a pointsource list */
static void gridpoint(hdrinf *hdr, ringparms *rpm, int srnr, int *pnr, float *pp, long mode)
{
  int grid[3];
  /****************/
  /****************/
/*    fint obsint = 1; */
/*    char obsmes[81];  */
  /****************/
  /******/
  /******/
/*       sprintf(obsmes, "got here");   */
/*      anyout_c(&obsint, tofchar(obsmes));   */
  /******/

  /* of course we could make it even shorter, but we'll leave it at that. Next thingy is to grid the pointsource */
  grid[0] = roundnormal(rpm -> modpar[PXPOS*rpm -> nr+srnr]+pp[0]);
  
  if (grid[0] >= 0 && grid[0] < hdr -> bsize1) {
    
    grid[1] = roundnormal(rpm -> modpar[PYPOS*rpm -> nr+srnr]+pp[1]);
    if (grid[1] >= 0 && grid[1] < hdr -> bsize2) {
      /* For the sake of clarity, we kill the subsnuma operation in the source, in principle thus allowing only for the radio convention for velocity, but gaining an understanding of the code. What is seen here should not be done. It's really not what anyone should wish for. */
      grid[2] = roundnormal((rpm -> modpar[PVSYS*rpm -> nr+srnr]+hdr -> signv*pp[5]));
      if (grid[2] >= 0 && grid[2] < hdr -> nsubs) {
	
	/* This is the position in the linear cube array */
	rpm -> sd[srnr].pl[*pnr] = hdr -> model+(grid[0]+ hdr -> bcsize1*(grid[1])+hdr -> nprof*(grid[2]));
	++(*pnr);
      }
      else {
	--rpm -> sd[srnr].n;
	++rpm -> sd[srnr].outn;
      }
    }
    else {
      --rpm -> sd[srnr].n;
      ++rpm -> sd[srnr].outn;
    }
  }
  else {
    --rpm -> sd[srnr].n;
    ++rpm -> sd[srnr].outn;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Grids a point to a pointsource list */
static int srput(ringparms *rpm, int srnr)
{
  int i;
  for (i = 0; i < rpm -> sd[srnr].n; ++i)
    *(rpm -> sd[srnr].pl[i]) += rpm -> sd[srnr].pf;

  /* Don't need that anymore, but it would be good to have) */
  forget((void **) &rpm -> sd[srnr].pl);

  /* Return number of pointsources */
  return rpm -> sd[srnr].n;
}

/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Generation of a pointsource list */
static long srconst(hdrinf *hdr, ringparms *rpm, int srnr, long mode)
{
  int j;
  float r; /* A radius */
  float az; /* Azimuth of pointsource */
  float cosaz; /* The cos of the az (memory wasting) */
  float sinaz; /* The sin of the az (memory wasting) */
  float pp[6]; /* Cartesian coordinates in phase-space, x,y,z,vx,vy,vz */
  char mes[80];
  fint err = 4;
  
  /****************/
  /****************/
  /*    fint obsint = 1; */
  /*    char obsmes[81]; */
  /****************/
  /******/
  /******/
  /*    sprintf(obsmes, "got here");  */
  /*    anyout_c(&obsint, tofchar(obsmes));  */
  /******/
  
  
  /* First check if we do anything but remembering */
  if (rpm -> sd[srnr].pl) {
    remember((void **) &rpm -> sd[srnr].pl);
    return rpm -> sd[srnr].outn;
  }

  /* Now we try to allocate */
  if ((rpm -> sd[srnr].n)){
    if (!(rpm -> sd[srnr].pl = (float **) malloc(rpm -> sd[srnr].n*sizeof(float *)))) {
      /* Catastrophy, simply stop */
      sprintf(mes, "Too many pointsources, increase PFLUX or reduce MEMMODE");
      error_c(&err, tofchar(mes));
    }
  }
  
  /* If there's no pointsource we allocate nevertheless for the smallest thing possible */
  else {
    if (!(rpm -> sd[srnr].pl = (float **) malloc(sizeof(float *)))) {
      
      /* Catastrophy, simply stop */
      sprintf(mes, "Too many pointsources, increase PFLUX or reduce MEMMODE");
      error_c(&err, tofchar(mes));
    }
    rpm -> sd[srnr].outn = 0;
    return 0;
  }
  
  /* Initialise random generators */
  rpm -> iseed2[1] = srnr;
  maths_rndmf_init(rpm -> iseed2, rpm -> permrandstr);
  
  /* reset the  zprof */ 
  zprof(6, rpm -> permrandstr);
  
  /* Reset the counters */
  j = 0;
  rpm -> sd[srnr].outn = 0;

  while (j < rpm -> sd[srnr].n) {
    /* The probability for the radius is weighted by r, and this is no approximation */
    r = sqrtf((rpm -> modpar[PRADI*rpm -> nr+srnr]-0.5*rpm -> radsep)*(rpm -> modpar[PRADI*rpm -> nr+srnr]-0.5*rpm -> radsep)+2*rpm -> radsep*rpm -> modpar[PRADI*rpm -> nr+srnr]*maths_rndmf(rpm -> permrandstr));
    
    /* Azimuth is easy */
    az = TWOPI*maths_rndmf(rpm -> permrandstr);
    cosaz = cosf(az);
    sinaz = sinf(az);
    
    /* Now, these are the cartesian coordinates, if you look face-on at the ring in the system of the ring, x eastwards, y to the north, z along los from you to the source */
    /*       x = cosaz*r; */
    /*       y = sinaz*r; */
    /*       z = zprof(ltype)*modpar[PZ0*rpm -> nr+srnr]; */
    /*       vx = -sinaz*modpar[PVROT*rpm -> nr+srnr]; */
    /*       vy = cosaz*modpar[PVROT*rpm -> nr+srnr]; */
    /*       vz = 0; */
    
    /* Now, the whole system will be rotated about the x-axis with the amount of the inclination */
    /*       xp  = x; */
    /*       yp  = cosinc*y-sininc*z; */
    /*       zp  = sininc*y+cosinc*z; */
    /*       vxp = vx; */
    /*       vyp = cosinc*vy-sininc*vz; */
    /*       vzp = sininc*vy+cosinc*vz; */
    
    
    /*  Now we rotate about the z-axis with pa, because in this module the pa is defined as the angle with the minor axis */
    /*       x = xp*cos(pa)-yp*sin(pa)    or x = xp*cospa-yp*sinpa;      */
    /*       y = xp*sin(pa)+yp*cos(pa)    or y = xp*sinpa+yp*cospa;     */
    /*       z = zp;                        or z = zp;                     */         
    /*       vx = vxp*cos(pa)-vyp*sin(pa) or vx = vxp*cospa-vyp*sinpa;   */
    /*       vy = vxp*sin(pa)+vyp*cos(pa) or vy = vxp*sinpa+vyp*cospa;  */
    /*       pp[5] = vzp;                      or vz = vzp;                   */
    
    pp[2] = zprof(rpm -> ltype, rpm -> permrandstr)*rpm -> modpar[PZ0*rpm -> nr+srnr];
    pp[0] = (cosaz*r)*rpm -> sd[srnr].cosp-(rpm -> sd[srnr].cosi*(sinaz*r)-rpm -> sd[srnr].sini*pp[2])*rpm -> sd[srnr].sinp; 
    pp[1] = (cosaz*r)*rpm -> sd[srnr].sinp+(rpm -> sd[srnr].cosi*(sinaz*r)-rpm -> sd[srnr].sini*pp[2])*rpm -> sd[srnr].cosp;
    pp[5] = (rpm -> sd[srnr].sini*cosaz*rpm -> modpar[PVROT*rpm -> nr+srnr]);
    
    gridpoint(hdr, rpm, srnr, &j, pp, mode);
  }
  return rpm -> sd[srnr].outn;
}


/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Help function to interpover: Check if the modpar array in the range
   of a ring has to be changed */
static int chkchange(varlel *varele, int fitmode, int ringnr, int nur)
{
  int ring,element;
  /**********/
  /**********/
  /*   fint obsint = 0; */
  /*   char obsmes[81]; */
  /*********/
  /******/
  /******/
  /*    sprintf(obsmes, "got here"); */
  /*    anyout_c(&obsint, tofchar(obsmes)); */
  /******/

  /* If fitmode is Golden Section, we check only one varelement */
  if (fitmode) {
    for (element = 0; element < varele -> nelem; ++element) {
      /* If the ring itself or the ting before has been changed, we return */
      if (ringnr == (ring = varele -> elements[element]%nur)) {
	return 1;
      }
      if (ringnr == ring+1) {
	return 1;
      }
    }
  }
  
  /* Fitmode is Metropolis, we check the whole list */
  else {
    while ((varele)) {
      for (element = 0; element < varele -> nelem; ++element) {
	
	/* If the ring itself or the ting before has been changed, we return */
	if (ringnr == (ring = varele -> elements[element]%nur))
	  return 1;
	if (ringnr == ring+1)
	  return 1;
      }
      varele = varele -> next;
    }
  }
  
  /* The ring is not in there */
  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Help function to interpover: Check if the modpar array in the range
   of a ring has to be changed */
static int chkchangep(varlel *varele, int fitmode, int parnr, int nur)
{
  int i;
  int param;
  
  /* If fitmode is Golden Section, we check only one ring */
  if ((fitmode)) {
    for (i = 0; i < varele -> nelem; ++i) {
      
      /* If the ring itself or the ting before has been changed, we return */
      if (parnr == (param = varele -> elements[i]))
	return 1;

      /* Don't know whether the second logical is a good idea */
      if ((parnr == param+1) && ((param+1)%nur))
	return 1;
    }
  }
  
  /* Fitmode is Metropolis, we check the whole list */
  else {
    while ((varele)) {
      for (i = 0; i < varele -> nelem; ++i) {
	
	/* If the ring itself or the ting before has been changed, we return */
	if (parnr == (param = varele -> elements[i]))
	  return 1;
	if ((parnr == param+1) && ((param+1)%nur))
	  return 1;
      }
      varele = varele -> next;
    }
  }
  
  /* The parameter is not in there */
  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Interpolate over the par list to get the modpar */

static void interpinit(ringparms *rpm, double radsep)
{
  int i,j,k;
  float width;
  float dpardr[NPARAMS];
  float dr;
  int n2, n1;
  
  /**********/
  /**********/
  /* fint obsint = 0; */
  /* char obsmes[81]; */
  /*********/
  
  /******/
  /******/
  /* sprintf(obsmes, "got here"); */
  /* anyout_c(&obsint, tofchar(obsmes)); */
  /******/
  
  /* In the modpar array interpolate over all rings */
  for (i = 1; i < rpm -> nur; ++i) {
    
    /* This is the actual width between two radii */
    width = rpm -> par[PRADI*rpm -> nur+i] - rpm -> par[PRADI*rpm -> nur+i-1];
    
    /* These are the rings to be calculated */
    n2 = (int) (rpm -> par[PRADI*rpm -> nur+i]/radsep-0.5); 
    n1 = ((int) (rpm -> par[PRADI*rpm -> nur+i-1]/radsep+0.5)); 
    
    
    /* in-between two rings, the slope is determined */
    for (j = 1; j < NPARAMS; ++j) {
      
      /* If the parameter is in the list */
      dpardr[j]= (rpm -> par[j*rpm -> nur+i]-rpm -> par[j*rpm -> nur+i-1])/width;
      
      for (k = n1; k <= n2; ++k) {
	/* for each parameter the intepolation is done */
	rpm -> modpar[PRADI*rpm -> nr+k] = ((float) k)*radsep+radsep/2.0;
	dr = rpm -> modpar[PRADI*rpm -> nr+k]-rpm -> par[PRADI*rpm -> nur+i-1]; 
	rpm -> modpar[j*rpm -> nr+k] = rpm -> par[j*rpm -> nur+i-1]+dpardr[j]*dr; 
      }
    }
    /* Now change the pre-processed parameters and terrminate the pointsource lists */
    for (k = n1; k <= n2; ++k)
      srprep(rpm, k, 0);
  } 
}


/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Core to construct a pointsource cube from a parameter list */
static int galmod(hdrinf *hdr, ringparms *rpm, int fitmode, varlel *varele)
{
  int i;
  int totflux = 0;
  
  /****************/
  /****************/
  /* fint obsint = 1; */
  /* char obsmes[81]; */
  /****************/
  
  /******/
  /******/
  /* sprintf(obsmes, "got here"); */
  /* anyout_c(&obsint, tofchar(obsmes)); */
  /******/
  
  interpover(rpm, rpm -> radsep, fitmode, varele);
  
  /* Initialise the model array */
  /*   for (i = 0; i < hdr -> bcsize1*hdr -> bsize2*hdr -> nsubs; ++i) */
  
  for (i = 0; i < hdr -> nprof*hdr -> nsubs; ++i)
    hdr -> model[i] = 0;
  
  /* Initialise the chisquare */
  /*    hdr -> chi2 = 0; */
  
  rpm -> outpoints = 0;

  /* Do all the loops */
  for (i = 0; i < rpm -> nr; ++i) {
    rpm -> outpoints += srconst(hdr, rpm, i, 0);
    
    /* now create the clouds and grid them */
    totflux += srput(rpm, i);
  }
  
  
  /* We return the number of clouds */
  return totflux;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Changes the parameters in par according to varylist */
static int chprm_metro(varlel *varylist, double *oldpar, double *newpar, maths_rstr *rnd, long loopnr)
{
  int i;
  double change;
  double delta;
  int outofrange = 0;

  /* As long as there is any element of varylist we continue */
  while ((varylist)) {

    /* First calculate the delta */
    if (loopnr - varylist -> moderate <= 0)
      delta = (loopnr-1)*(varylist -> delend-varylist -> delstart)/varylist -> moderate+varylist -> delstart;
    else
      delta = varylist -> delend;

    change = 2*maths_rndm(rnd)-1;

    /* Every adressant of elements will be changed by the same amount */
    for (i = 0; i < varylist -> nelem; ++i) {
      newpar[varylist -> elements[i]] = oldpar[varylist -> elements[i]]+change*delta;

      /* And it will be checked whether on of them is out of range */
      if (maths_checkinbetw(varylist -> parmax, varylist -> parmin, newpar[varylist -> elements[i]]))
 ++outofrange;
    }
    varylist = varylist -> next;
  }

  return outofrange;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Writes the information contained in rpm -> par to the output */
static void writeoutput(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit, char accept, int dof, int modcount, double proba)
{
  int i;
/*   char mes[80]; */
/*   fint dev = 0; */

  writeoutarray(log, hdr, rpm, accept, hdr -> oldchi2, modcount, dof);
 
  if ((log -> tstream)) {
    fprintf(log -> tstream, "%7i ",  (int) log -> outarray[NPARAMS*rpm -> nur+LOOPNR_TABNR]); 
    for (i = 0; i < NPARAMS*rpm -> nur + NSPARAMS; ++i) {
      fprintf(log -> tstream, "%12.9e ", log -> outarray[i]);
    }
    fprintf(log -> tstream, "%.16e ", log -> outarray[NPARAMS*rpm -> nur+NSPARAMS-1+RCHISQ_TABNR]);
    fprintf(log -> tstream, "%9i\n", (int) log -> outarray[NPARAMS*rpm -> nur+NSPARAMS-1+ACCEPT_TABNR]);
  }
  
  if (log -> logname) {
    ftstab_appendrow_(log -> outarray);
  }

  /* Comment on it */
/*   dev = 0; */
/*   if (fit -> fitmode == METROPOLIS) */
/*     sprintf(mes, "Model %i, chisquare %E, relative probability: %E", (int) log -> outarray[NPARAMS*rpm -> nur+LOOPNR_TABNR], hdr -> chi2, proba); */
/*   else if (fit -> fitmode == GOLDEN_SECTION) */
/*     sprintf(mes, "Loop %i, %i iterations since start, chisquare %E", (int) log -> outarray[NPARAMS*rpm -> nur+LOOPNR_TABNR],  (int) proba, hdr -> oldchi2); */
/*   anyout_c(&dev, tofchar(mes)); */
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Writes the information contained in rpm -> par to the output array of rpm */
void writeoutarray(loginf *log, hdrinf *hdr, ringparms *rpm, char accept, double chisquare, int modcount, int dof)
{
  int i;
  double globin[3];
  double globout[3];

  /************/
  /************/
  /* fint obsint = 0; */
  /* char obsmes[80]; */
  /************/

  /* Fill the output array */
  for (i = 0; i < rpm -> nur; ++i) {
    log -> outarray[PRADI*rpm -> nur+i] = dinterntoparam(rpm -> oldpar[PRADI*rpm -> nur+i], RADI, hdr);
    log -> outarray[PVROT*rpm -> nur+i] = dinterntoparam(rpm -> oldpar[PVROT*rpm -> nur+i], VROT, hdr);
    log -> outarray[PZ0*rpm -> nur+i] = dinterntoparam(rpm -> oldpar[PZ0*rpm -> nur+i], Z0, hdr);
    log -> outarray[PSBR*rpm -> nur+i] = dinterntoparam(rpm -> oldpar[PSBR*rpm -> nur+i], SBR, hdr);
    log -> outarray[PINCL*rpm -> nur+i] = dinterntoparam(rpm -> oldpar[PINCL*rpm -> nur+i], INCL, hdr);
    log -> outarray[PPA*rpm -> nur+i] = dinterntoparam(rpm -> oldpar[PPA*rpm -> nur+i], PA, hdr);

 /* Now, we have to convert the triplets into internal units */
    globin[0] = rpm -> oldpar[PXPOS*rpm -> nur+i];
    globin[1] = rpm -> oldpar[PYPOS*rpm -> nur+i];
    globin[2] = rpm -> oldpar[PVSYS*rpm -> nur+i];

    interntoglob(globin, globout, hdr);
   
    log -> outarray[PXPOS*rpm -> nur+i] = globout[0];
    log -> outarray[PYPOS*rpm -> nur+i] = globout[1];
    log -> outarray[PVSYS*rpm -> nur+i] = globout[2];
  }

  log -> outarray[PCONDISP*rpm -> nur] = dinterntoparam(rpm -> oldpar[PCONDISP*rpm -> nur], CONDISP, hdr);

  /* Chisquare */
  log -> outarray[NPARAMS*rpm -> nur+NSPARAMS-1+CHISQ_TABNR] = chisquare;
  log -> outarray[NPARAMS*rpm -> nur+NSPARAMS-1+RCHISQ_TABNR] = chisquare/dof;

  /* Acceptance */
  log -> outarray[NPARAMS*rpm -> nur+NSPARAMS-1+ACCEPT_TABNR] = (double) accept;

  /* model number */
  log -> outarray[NPARAMS*rpm -> nur+NSPARAMS-1+LOOPNR_TABNR] = (double) modcount;

  return;
}
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Delivers a random variable according to a profile identifyer */
static float zprof(int option, maths_rstrf *permrandstr)
{
  float  x1, x2, w, y1;
  static float y2;

  switch (option) {
  case 1:
    if (y2 < -1000.0) {

    /* According to http://www.taygeta.com/random/gaussian.html a gaussian distribution, unfortunately two independent numbers are generated */
    do {
      x1 = 2.0*maths_rndmf(permrandstr)-1.0;
      x2 = 2.0*maths_rndmf(permrandstr)-1.0;
      w = x1*x1+x2*x2;
    } while (w >= 1.0);
    
    w = sqrtf((-2.0*logf(w))/w);
    y1 = x1*w;
    y2 = x2*w;
    }
    else {
      y1 = y2;
      y2 = -1001.0;
    }
    break;

    /* Sech2 */
  case 2:
    while (!((x1 = 2.0*maths_rndmf(permrandstr)-1.0)-1.0))
      ;
    y1 = atanhf(x1);
    break;

    /* exponential */
  case 3:
    while (!((x1 = 2.0*maths_rndmf(permrandstr)-1.0)))
      ;
    if (x1 > 0.0) 
      y1 = -logf(x1);
    else if (x1 < 0.0) 
      y1 = logf(-x1);
    break;

  case 4:
    while (!((x1 = 2.0*maths_rndmf(permrandstr)-1.0)-1.0))
      ;
    y1 = tanf(PIHALF*x1);
    break;

  case 6:
    y2 = -1001.0;
    break;

  default:
    y1 = 2.0*maths_rndmf(permrandstr)-1.0;
    break;
  }

  return y1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Initializes the standard header context table */
static int create_hdu_1(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
{
  int column, param, i;
  char key[9], value[21];
  double *array = NULL;

  /************/
  /************/
  /* fint obsint = 0; */
  /* char obsmes[80]; */
  /************/

  /* First calculate how many columns will be there and initialise */
  if (!ftstab_inithd(NPARAMS*rpm -> nur+NSPARAMS+PRIMHDN_SINGLE))
    goto error;
  
  /* Now the header will be filled with the items that are no parameters */
  for (column = 0; column < PRIMHDN_SINGLE; ++column)
    ftstab_fillhd(column, NPARAMS+NSPARAMS+column+1, primpos_numtype(column+1), COLRADI_DEFAULT, COLGRID_DEFAULT);

  /* Now add the parameters */
  for (param = 1; param <= NPARAMS; ++param) {
    for (i = 0; i < rpm -> nur; ++i) {
      ftstab_fillhd(PRIMHDN_SINGLE+(param-1)*rpm -> nur+i, param, COLTYPE_DOUBLE, COLRADI_DEFAULT, COLGRID_DEFAULT);
    }
  }
  for (param = 1; param <= NSPARAMS; ++param) {
      ftstab_fillhd(PRIMHDN_SINGLE+NPARAMS*rpm -> nur+param-1, param+NPARAMS, COLTYPE_DOUBLE, COLRADI_DEFAULT, COLGRID_DEFAULT);
  }

  /* So much for the normal header, add the informational stuff */
  if (!ftstab_genhd(0))
    goto error;

  sprintf(key, "CREATOR");
  sprintf(value, "TIRIFIC");
  ftstab_putcard(0, key, value);

  sprintf(key, "VERSION");
  sprintf(value, "V%02i", VERSION_NUMBER);
  ftstab_putcard(0, key, value);

  sprintf(key, "STATUS");
  sprintf(value, "NOT OK");
  ftstab_putcard(0, key, value);

  sprintf(key, "INSET");
  sprintf(value, "'%-18s'", hdr -> inset);
  ftstab_putcard(0, key, value);

  sprintf(key, "OUTSET");
  sprintf(value, "'%-18s'", hdr -> outset);
  ftstab_putcard(0, key, value);

  sprintf(key, "TEXTLOG");
  sprintf(value, "'%-18s'", log -> textlog);
  ftstab_putcard(0, key, value);

  sprintf(key, "TABLE");
  sprintf(value, "'%-18s'", log -> table);
  ftstab_putcard(0, key, value);

  /* Now create the table, overwriting everything */
  if ((ftstab_fopen(log -> logname, 1, 1, 1))) {
    goto error;
  }

  /* Now get the double array */
  if (!(array = ftstab_get_dblarr()))
    goto error;

  /* Now, I fear, we have to fill the array */
  /* Now the header will be filled with the items that are no parameters */
  for (column = 0; column < PRIMHDN_SINGLE; ++column) {
    array[column] = primpos_value(column+1, log, hdr, rpm, fit);
  }
  /* Now fill the rest of the array, copy the par array into the oldpar list and then call writeoutarray first */
  for (i = 0; i < NPARAMS*rpm -> nur + NSPARAMS; ++i) {
    rpm -> oldpar[i] = rpm -> par[i];
  }

  writeoutarray(log, hdr, rpm, 1, 1.0, 1, 1);

  /* Then copy the start of outarray to the end of the array */
  for (i = 0; i < NPARAMS*rpm -> nur + NSPARAMS; ++i) {
    array[PRIMHDN_SINGLE+i] = log -> outarray[i];
  }

  ftstab_appendrow_(array);
  ftstab_putminmax_();
  free(array);

  sprintf(key, "STATUS");
  sprintf(value, "OK");
  ftstab_putcard(0, key, value);

  /* That's it */
  return 0;

 error:
  if ((array))
    free(array);
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/*  Returns the ftstab numerical type of a PRIMPOS identifyer */
static int primpos_numtype(int ident)
{
  switch (ident) {
  case BMAJ_PRIMPOS:
    return COLTYPE_FLOAT;
  case BMIN_PRIMPOS:
    return COLTYPE_FLOAT;
  case BPA_PRIMPOS:
    return COLTYPE_FLOAT;
  case RMS_PRIMPOS:
    return COLTYPE_FLOAT;
  case NUR_PRIMPOS:
    return COLTYPE_INT;
  case RADSEP_PRIMPOS:
    return COLTYPE_DOUBLE;
  case LTYPE_PRIMPOS:
    return COLTYPE_INT;
  case CFLUX_PRIMPOS:
    return COLTYPE_DOUBLE;
  case WEIGHT_PRIMPOS:
    return COLTYPE_FLOAT;
  case MODE_PRIMPOS:
    return COLTYPE_INT;
  case ISEED2_PRIMPOS:
    return COLTYPE_INT;
  case LOOPS_PRIMPOS:
    return COLTYPE_INT;
  case ISEED_1_PRIMPOS:
    return COLTYPE_INT;
  case ISEED_2_PRIMPOS:
    return COLTYPE_INT;
  case ANSTART_PRIMPOS:
    return COLTYPE_DOUBLE;
  case ANEND_PRIMPOS:
    return COLTYPE_DOUBLE;
  case ANSTEPS_PRIMPOS:
    return COLTYPE_INT;
  case INIMODE_PRIMPOS:
    return COLTYPE_INT;
  case FITMODE_PRIMPOS:
    return COLTYPE_INT;
  case OUTCUBUP_PRIMPOS:
    return COLTYPE_INT;
  case DISTANCE_PRIMPOS:
    return COLTYPE_DOUBLE;
  case PENALTY_PRIMPOS:
    return COLTYPE_DOUBLE;
  case RFREQ_PRIMPOS:
    return COLTYPE_DOUBLE;
  case ITOU_PRIMPOS:
    return COLTYPE_DOUBLE;

    /* Second header */
  case PARMAX_PRIMPOS:
    return COLTYPE_DOUBLE;
  case PARMIN_PRIMPOS:
    return COLTYPE_DOUBLE;
  case MODERATE_PRIMPOS:
    return COLTYPE_INT;
  case DELSTART_PRIMPOS:
    return COLTYPE_DOUBLE;
  case DELEND_PRIMPOS:
    return COLTYPE_DOUBLE;
  case ITESTART_PRIMPOS:
    return COLTYPE_INT;
  case ITEEND_PRIMPOS:
    return COLTYPE_INT;
  case SATDELT_PRIMPOS:
    return COLTYPE_DOUBLE;
  case MINDELTA_PRIMPOS:
    return COLTYPE_DOUBLE;
  case ELEMENTS_PRIMPOS:
    return COLTYPE_INT;

    /* Third header */
  case CHISQ_PRIMPOS:
    return COLTYPE_DOUBLE;
  case RCHISQ_PRIMPOS:
    return COLTYPE_DOUBLE;
  case LOOPNR_PRIMPOS:
    return COLTYPE_INT;
  case ACCEPT_PRIMPOS:
    return COLTYPE_CHAR;

  default:
    return COLTYPE_DEFAULT;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/*  Returns the ftstab value of a PRIMPOS identifyer */
static double secpos_value(int ident, varlel *varlist, int nur, hdrinf *hdr, int element)
{
  int type;

  /* First get the type from the first element of the varlist */
  if ((varlist -> nelem))
    type = varlist -> elements[0]/nur+1;
  else
    return 0.0;

  switch (ident) {
  case PARMAX_SECPOS:
    return simpleinterntoglob(varlist -> parmax, type, hdr);
  case PARMIN_SECPOS:
    return simpleinterntoglob(varlist -> parmin, type, hdr);
  case MODERATE_SECPOS:
    return varlist -> moderate;
  case DELSTART_SECPOS:
    return dinterntoparam(varlist -> delstart, type, hdr);
  case DELEND_SECPOS:
    return dinterntoparam(varlist -> delend, type, hdr);
  case ITESTART_SECPOS:
      return varlist -> itestart;
  case ITEEND_SECPOS:
    return varlist -> iteend;
  case SATDELT_SECPOS:
    return dinterntoparam(varlist -> satdelt, type, hdr);
  case MINDELTA_SECPOS:
    return dinterntoparam(varlist -> mindelta, type, hdr);
  case ELEMENTS_SECPOS:
    return varlist -> elements[element];
  default:
    return 0.0;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/*  Returns the ftstab value of a PRIMPOS identifyer */
static double primpos_value(int ident, loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
{
  switch (ident) {
  case BMAJ_PRIMPOS:
    return hdr -> bmaj * hdr -> deltgridtouser[0];
  case BMIN_PRIMPOS:
    return hdr -> bmin * hdr -> deltgridtouser[0];
  case BPA_PRIMPOS:
    return hdr -> bpa;
  case RMS_PRIMPOS:
    return hdr -> rms ;
  case NUR_PRIMPOS:
    return rpm -> nur;
  case RADSEP_PRIMPOS:
    return rpm -> radsep;
  case LTYPE_PRIMPOS:
      return rpm -> ltype;
  case CFLUX_PRIMPOS:
    return rpm -> cflux;
  case WEIGHT_PRIMPOS:
    return rpm -> weight;
  case MODE_PRIMPOS:
    return rpm -> mode;
  case ISEED2_PRIMPOS:
    return rpm -> iseed2[0];
  case LOOPS_PRIMPOS:
    return fit -> loops;
  case ISEED_1_PRIMPOS:
    return fit -> iseed[0];
  case ISEED_2_PRIMPOS:
    return fit -> iseed[1];
  case ANSTART_PRIMPOS:
    return fit -> anstart;
  case ANEND_PRIMPOS:
    return fit -> anend;
  case ANSTEPS_PRIMPOS:
    return fit -> ansteps;
  case INIMODE_PRIMPOS:
    return rpm -> inimode;
  case FITMODE_PRIMPOS:
    return fit -> fitmode;
  case OUTCUBUP_PRIMPOS:
    return hdr -> outcubup;
  case DISTANCE_PRIMPOS:
    return log -> distance;
  case PENALTY_PRIMPOS:
    return rpm -> penalty/(rpm -> cflux*SQRTOFPIHALF*((double) hdr -> bmaj)*((double) hdr -> bmaj)*((double) hdr -> bmin)*((double) hdr -> bmin)*HPBWTOSIGMATOFORTH/((double)(hdr -> rms*hdr -> rms)));
  case RFREQ_PRIMPOS:
    return hdr -> rfreq;
  case ITOU_PRIMPOS:
    return hdr -> itou;
  default:
    return 0.0;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Initializes the standard header context table */
static int hdl_init(void)
{
  if (ftstab_hdladditem("RADI", "ANGLE", "arcsec", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("VROT", "VELO", "km/s", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("Z0", "ANGLE", "arcsec", 0.0, 1.0) < 0)
    return 0;

  /* Sorry, ridicuous, but it's not easy to put the things into 18 chars */
  if (ftstab_hdladditem("SBR", "FLUX", "Jy*m/(s*arcsec**2)", 0.0, 1000.0) < 0)
    return 0;
  if (ftstab_hdladditem("INCL", "ANGLE", "deg", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("PA", "ANGLE", "deg", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("XPOS", "ANGLE", "deg", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("YPOS", "ANGLE", "deg", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("VSYS", "VELO", "km/s", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("CONDISP", "VELO", "km/s", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("BMAJ", "ANGLE", "arcsec", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("BMIN", "ANGLE", "arcsec", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("BPA", "ANGLE", "deg", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("RMS", "FLUX", "Jy*km/s*beam", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("NUR", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("RADSEP", "ANGLE", "arcsec", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("LTYPE", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("CFLUX", "FLUX", "Jy*km/s", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("WEIGHT", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("MODE", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ISEED2", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("LOOPS", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ISEED_1", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ISEED_2", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ANSTART", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ANEND", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ANSTEPS", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("INIMODE", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("FITMODE", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("OUTCUBUP", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("DISTANCE", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("PENALTY", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("RFREQ", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ITOU", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;

  /* Second hdu */
  if (ftstab_hdladditem("PARMAX", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("PARMIN", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("MODERATE", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("DELSTART", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("DELEND", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ITESTART", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ITEEND", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("SATDELT", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("MINDELTA", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ELEMENTS", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;

  /* Third hdu */
  if (ftstab_hdladditem("CHISQ", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("RCHISQ", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("LOOPNR", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  if (ftstab_hdladditem("ACCEPT", "NATURAL", " ", 0.0, 1.0) < 0)
    return 0;
  return 1;
}

/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a second hdu of a fits table and puts the fit information
   contained in the varlel ll to the fits table */

static int create_hdu_2(char *logname, varlel *varylist, varlel **pointarray, int nur, hdrinf *hdr) 
{
  int column, same_input = 0, same_varlel = 0, dnum = 0, i, j;
  char key[9], value[21];
  double *array = NULL;

  /**************/
  /**************/
  /* fint obsint = 0; */
  /* char obsmes[80]; */
  /**************/
  
  /* First make sure that no second hdu is present */
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();
  if ((ftstab_fopen(logname, 1, 2, 1))) {
    goto error;
  }
  ftstab_deleterest_();
  ftstab_close_();
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();
  
  /* Initialise the numbr of columns, in this case static number */
  if (!ftstab_inithd(SECHDN_MULTI))
    goto error;

  /* Now the header will be filled with the items */
  for (column = 0; column < SECHDN_MULTI; ++column)
    ftstab_fillhd(column, NPARAMS+NSPARAMS+PRIMHDN_SINGLE+column+1, primpos_numtype(PRIMHDN_SINGLE+column+1), COLRADI_DEFAULT, COLGRID_DEFAULT);

  /* So much for the normal header, add the informational stuff */
  if (!ftstab_genhd(0))
    goto error;
  
  sprintf(key, "STATUS");
  sprintf(value, "NOT OK");
  ftstab_putcard(0, key, value);

  /* Now we can start to write */
  if ((ftstab_fopen(logname, 2, 4, 1))) {
    goto error;
  }

  /* Now get the double array */
  if (!(array = ftstab_get_dblarr()))
    goto error;
  
  /* We scan through the varylist */
  while ((varylist)) {

    for (j = 0; j < varylist -> nelem; ++j) {
      for (i = 0; i < SECHDN_MULTI; ++i)
 array[i] = secpos_value(i+1, varylist, nur, hdr, j);
      
      /* However, we have to change this according to the pointarray,
  pointarray always pointing to the last varylist belonging to
  a group of max, min, ... */
      if ((same_input))
 array[ITESTART_SECPOS-1] = -1.0;
      if ((same_varlel))
 array[ITEEND_SECPOS-1] = -1.0;
      
      /* Put the array to the table */
      ftstab_appendrow_(array);
      
      /* The consequent outputs are of the same varlel and the same
  input of max, min, ... */
      same_input = 1;
      same_varlel = 1;
    }

    /* If we encounter the last element of a group of max and min, the
       next output should contain these values */
    if (varylist == pointarray[dnum]) {
      same_input = 0;
      ++dnum;
    }
    varylist = varylist -> next;

    /* We are in any case at the start of a next varlel */
      same_varlel = 0;
  }

  /* We safe the number of group descriptors in the grid such that it can easily be read again */
  ftstab_fillhd(ITESTART_SECPOS-1, NPARAMS+NSPARAMS+PRIMHDN_SINGLE+ITESTART_SECPOS, primpos_numtype(PRIMHDN_SINGLE+ITESTART_SECPOS), 0.0, dnum);
  ftstab_clearhd(0);

  /* We are through now and return */
  free(array);

  sprintf(key, "STATUS");
  sprintf(value, "OK");
  ftstab_putcard(0, key, value);
  
  return 0;
  
 error:
  if ((array))
    free(array);
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Changes a second hdu of a fits table and puts the fit information
   contained in the varlel ll to the fits table */

static int change_hdu_2(varlel *varylist, varlel **pointarray, int nur, hdrinf *hdr) 
{
  int column, same_input = 0, same_varlel = 0, dnum = 0, i, j;
  char key[9], value[21];
  double *array = NULL;
  long rownumber = 1;

  /* Now the header will be filled with the items */
  for (column = 0; column < SECHDN_MULTI; ++column)
    ftstab_fillhd(column, NPARAMS+NSPARAMS+PRIMHDN_SINGLE+column+1, primpos_numtype(PRIMHDN_SINGLE+column+1), COLRADI_DEFAULT, COLGRID_DEFAULT);

  sprintf(key, "STATUS");
  sprintf(value, "NOT OK");
  ftstab_putcard(0, key, value);

  /* Now get the double array */
  if (!(array = ftstab_get_dblarr()))
    goto error;
  
  /* We scan through the varylist */
  while ((varylist)) {

    for (j = 0; j < varylist -> nelem; ++j) {
      for (i = 0; i < SECHDN_MULTI; ++i)
 array[i] = secpos_value(i+1, varylist, nur, hdr, j);
      
      /* However, we have to change this according to the pointarray,
  pointarray always pointing to the last varylist belonging to
  a group of max, min, ... */
      if ((same_input))
 array[ITESTART_SECPOS-1] = -1.0;
      if ((same_varlel))
 array[ITEEND_SECPOS-1] = -1.0;
      
      /* Put the array to the table */
      ftstab_putrow(rownumber, array);
      ++rownumber;

      /* The consequent outputs are of the same varlel and the same
  input of max, min, ... */
      same_input = 1;
      same_varlel = 1;
    }

    /* If we encounter the last element of a group of max and min, the
       next output should contain these values */
    if (varylist == pointarray[dnum]) {
      same_input = 0;
      ++dnum;
    }
    varylist = varylist -> next;

    /* We are in any case at the start of a next varlel */
      same_varlel = 0;
  }

  /* We safe the number of group descriptors in the grid such that it can easily be read again */
  ftstab_fillhd(ITESTART_SECPOS-1, NPARAMS+NSPARAMS+PRIMHDN_SINGLE+ITESTART_SECPOS, primpos_numtype(PRIMHDN_SINGLE+ITESTART_SECPOS), 0.0, dnum);
  ftstab_clearhd(0);

  /* We are through now and return */
  free(array);

  sprintf(key, "STATUS");
  sprintf(value, "OK");
  ftstab_putcard(0, key, value);
  
  return 0;
  
 error:
  if ((array))
    free(array);
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Puts the values of the arrays into varele, checking for mismatch with array */
static int fillhdvarele(varlel *varele, int i, double *array, int parameter, double *parmax, double *parmin, int *moderate, double *delstart, double *delend, int *itestart, int *iteend, double *satdelt, double *mindelta, hdrinf *hdr, loginf *log)
{
  char mes[81];
  char key[4];
  char place[69];
  fint def = 1;
  fint nel;

  /* First check the array */
  if (array[ITESTART_SECPOS-1] != -1.0) {
    place[0] = '\0';
     if (maths_checkeq(array[PARMAX_SECPOS-1], parmax[i], DOUBLE_ACCURACY))
      sprintf(place,"PARMAX");
    if (maths_checkeq(array[PARMIN_SECPOS-1], parmin[i]  , DOUBLE_ACCURACY))
      sprintf(place,"PARMIN");
    if ((int) array[ITESTART_SECPOS-1]!= itestart[i])
      sprintf(place,"ITESTART");
    if ((int) array[ITEEND_SECPOS-1]!= iteend[i])
      sprintf(place,"ITEEND");
    if (maths_checkeq(array[MINDELTA_SECPOS-1], mindelta[i], DOUBLE_ACCURACY))
      sprintf(place,"MINDELTA");
    if ((int) array[MODERATE_SECPOS-1] !=  moderate[i])
      sprintf(place,"MODERATE");
    if (maths_checkeq(array[DELSTART_SECPOS-1], delstart[i], DOUBLE_ACCURACY))
      sprintf(place,"DELSTART");
    if (maths_checkeq(array[DELEND_SECPOS-1], delend[i], DOUBLE_ACCURACY))
      sprintf(place,"DELEND %i %f %f", i, array[DELEND_SECPOS-1], delend[i]);
    if (maths_checkeq(array[SATDELT_SECPOS-1], satdelt[i], DOUBLE_ACCURACY))
      sprintf(place,"SATDELT");

    if (place[0] != '\0') {
      sprintf(mes, "%s: Values differ from logfile, proceed?", place);
      sprintf(key,"YES");
      def = 5;
      nel = 1;
      userchar_c(tofchar(key), &nel, &def, tofchar("PROCEED="), tofchar(mes));
      
      /* Not yes means no, stop things */
      if (strcmp(key,"YES"))
 return 1;

      log -> changes = 1;

      /* We proceed and don't reset PROCEED */
      /*     cancel_c(tofchar("PROCEED=")); */
    }
  }
  /* Now we just fill the varele */
  varele -> parmax   = simpleglobtointern(parmax[i], parameter, hdr);
  varele -> parmin   = simpleglobtointern(parmin[i], parameter, hdr);
  varele -> moderate = moderate[i];
  varele -> delstart = dparamtointern(delstart[i], parameter, hdr);
  varele -> delend   = dparamtointern(delend[i], parameter, hdr);
  varele -> itestart = itestart[i];
  varele -> iteend   = iteend[i];
  varele -> satdelt  = dparamtointern(satdelt[i], parameter, hdr);
  varele -> mindelta  = dparamtointern(mindelta[i], parameter, hdr);

  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Checks if the varlels are identical */
static int comparevarlel(varlel *varlel1, varlel *varlel2)
{
  int i;

  /* If they are identical we are ready */
  if (varlel1 == varlel2)
    return 0;

  /* If one is NULL and the other one isn't this is fatal */
  if ((varlel1)) {
    if (!varlel2)
      return 1;
  }

  if ((varlel2)) {
    if (!varlel1)
      return 1;
  }

  /* If the number of elements is different, this is fatal */
  if (varlel2 -> nelem != varlel1 -> nelem)
    return 1;

  /* Now we compare the other global variables */
    if (maths_checkeq(varlel1 -> parmax, varlel2 -> parmax, DOUBLE_ACCURACY))
      return -1;
    if (maths_checkeq(varlel1 -> parmin,  varlel2 -> parmin  , DOUBLE_ACCURACY))
      return -1;
    if ((int) varlel1 -> moderate !=   varlel2 -> moderate)
      return -1;
    if (maths_checkeq(varlel1 -> delstart,  varlel2 -> delstart, DOUBLE_ACCURACY))
      return -1;
    if (maths_checkeq(varlel1 -> delend,  varlel2 -> delend, DOUBLE_ACCURACY))
      return -1;
    if ((int) varlel1 -> itestart !=  varlel2 -> itestart)
      return -1;
    if ((int) varlel1 -> iteend !=  varlel2 -> iteend)
      return -1;
    if (maths_checkeq(varlel1 -> satdelt, varlel2 -> satdelt, DOUBLE_ACCURACY))
      return -1;
    if (maths_checkeq(varlel1 -> mindelta, varlel2 -> mindelta, DOUBLE_ACCURACY))
      return -1;

    /* Now we compare the content of the elements array */
    for (i = 0; i < varlel1 -> nelem; ++i) {
      if (varlel1 -> elements[i] != varlel2 -> elements[i])
 return -1;
    }

    /* Finished */
    return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Opens if necessary creat the third hdu */
static int open_hdu_3(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
{
  double *array = NULL;
  fint def;
  fint nel;
  char mes[81];
  int overwrite, restart, i, j;
  varlel *varele;

  /* Try to open the third hdu, all arrangements have been made */
  if (ftstab_fopen(log -> logname, 3, 2, 1)) {
    /* If it's not there, we create it */
    if ((create_hdu_3(log, hdr, rpm, fit)))
      goto error;
  }


  /* Now we have a table in any case that has the proper format, check if there were any former results */
  if (ftstab_get_colgrd(NPARAMS*rpm -> nur+NSPARAMS+LOOPNR_TABNR) > 0.0) {
    def = 1;
    sprintf(mes, "There have been results...");
    anyout_c(&def, tofchar(mes));
    sprintf(mes, "omit: 0");
    anyout_c(&def, tofchar(mes));
    sprintf(mes, "overwrite present start values: 1");
    anyout_c(&def, tofchar(mes));
    sprintf(mes, "produce output: 2");
    anyout_c(&def, tofchar(mes));
    sprintf(mes, "stop: 3");
    anyout_c(&def, tofchar(mes));
  }
  else
    def = 2;

  /* Now the user will be prompted how to proceed */
  overwrite = 0;
  nel = 1;
  sprintf(mes, "React:");
  userint_c(&overwrite, &nel, &def, tofchar("RESULTREACT="), tofchar(mes));
  
  if (!overwrite) {
    ftstab_fillhd(NPARAMS*rpm -> nur+NSPARAMS+LOOPNR_TABNR-1, NPARAMS+NSPARAMS+LOOPNR_TABNR, primpos_numtype(NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI+LOOPNR_TABNR), 0.0, -1.0);
  }

  /* This is not exactly easy */
  else if (overwrite == 1) {
    
     /* We read in the values */ 
    ftstab_get_grid_(log -> outarray);
 
     /* We close this extension */ 
    ftstab_close_();
    ftstab_flush_();
    ftstab_hdlreset_();
    hdl_init();
    
    /* We delete this extension */ 
    if ((ftstab_fopen(log -> logname, 2, 2, 1))) {
      goto error;
    }
    ftstab_deleterest_();
    ftstab_close_();
    ftstab_flush_();
    ftstab_hdlreset_();
    hdl_init();
    
     /* We open the first extension */ 
    if ((ftstab_fopen(log -> logname, 1, 2, 1))) {
      goto error;
    }
    
    /* We put the values into the list and update the parameter list */
     for (i = 0; i < NPARAMS*rpm -> nur + NSPARAMS; ++i) {
      ftstab_putval(1L, PRIMHDN_SINGLE+i+1, log -> outarray[i]);
      rpm -> par[i] = log -> outarray[i];
    }
 
    /* Convert the read parameter list to internal units */
    changetointern(rpm -> par, rpm -> nur, hdr);
    
    /* We close the file */
    ftstab_close_();
    ftstab_flush_();
    ftstab_hdlreset_();
    hdl_init();

    /* We open it again, repeating the stuff above */
    create_hdu_3(log, hdr, rpm, fit);
  }
  else if (overwrite == 2) {
    return 2;
  }
  else
    goto error;

  /* Next question is how to react if there was a change in the parameters */
  if ((log -> changes))
    def = 1;
  else
    def = 2;
  
  restart = 0;
  nel = 1;
  sprintf(mes, "There have been changes in the input, continue at old stage: 0, restart: 1 [0]");
  userint_c(&restart, &nel, &def, tofchar("RESTART="), tofchar(mes));
  
  /* If the user wants a restart, we recreate the header */
  if ((restart)) {
    if (overwrite != 1) {
      ftstab_close_();
      ftstab_flush_();
      ftstab_hdlreset_();
      hdl_init();

      /* We delete this extension */
      if ((ftstab_fopen(log -> logname, 2, 2, 1))) {
 goto error;
      }
      ftstab_deleterest_();
      ftstab_close_();
      ftstab_flush_();
      ftstab_hdlreset_();
      hdl_init();

      /* And reopen it */
      create_hdu_3(log, hdr, rpm, fit);
    }
  }

  /* And we care without prompting for a not-so-long file */
  if ((fit -> loops-ftstab_get_rownr_() > 0)) {
    if (fit -> fitmode == METROPOLIS) {
      ;
/*       if (LONG_MAX-(fit -> loops-fit -> loopnr)*ftstab_get_byteperow_()-ftstab_get_curlength_() < 0) */
/*  fit -> loops = (LONG_MAX-ftstab_get_curlength_()+fit -> loopnr*ftstab_get_byteperow_())/ftstab_get_byteperow_(); */
    }
    else if (fit -> fitmode == GOLDEN_SECTION) {
      /* Get the number of varlels */
      varele = fit -> varylist;
      
      i = 0;
      while (varele) {
 ++i;
 varele = varele -> next;
      }
    
 /*      if (LONG_MAX-((fit -> loops*i)-fit -> loopnr)*ftstab_get_byteperow_()-ftstab_get_curlength_() < 0) */
/*  fit -> loops = ((LONG_MAX-ftstab_get_curlength_()+fit -> loopnr*ftstab_get_byteperow_())/ftstab_get_byteperow_())/i-1; */
    }
  }

  /* In any case, upload the last parameter list */
  if (ftstab_get_row(ftstab_get_rownr_(), log -> outarray)) {
    for (i = 0; i < NPARAMS*rpm -> nur + NSPARAMS; ++i) {
      rpm -> oldpar[i] = log -> outarray[i];
    }
    
    /*     Convert the read parameter list to internal units */
    changetointern(rpm -> oldpar, rpm -> nur, hdr);
  }
 
  /* In case of mode metropolis, we also initialise the permanent rng */
  if (fit -> fitmode == METROPOLIS) {
    fit -> loopnr = ftstab_get_rownr_();

    /* Now we get the number of loops */
    fit -> outofrange = 1;

    /* Get the number of varlels */
    varele = fit -> varylist;

    i = 0;
    while (varele) {
      ++i;
      varele = varele -> next;
    }

    /* The rng has been run the number of loops times this number plus one */
    for (j = 0; j < (i+1)*fit -> loopnr; ++j) {
      maths_rndm(fit -> normrandstr);
    }

    /* Now change the parameters if we are in a loop */
    if (fit -> loopnr) {
      if (chprm_metro(fit -> varylist, rpm -> oldpar, rpm -> par, fit -> normrandstr, fit -> loopnr))
 ++fit -> outofrange;
      hdr -> oldchi2 = log -> outarray[NPARAMS*rpm -> nur+NSPARAMS+CHISQ_TABNR-1];
    }
  }
  else if (fit -> fitmode == GOLDEN_SECTION) {
    /* Now we get the number of loops */
      fit -> loopnr = ftstab_get_rownr_();
  }
  else
    goto error;

  return 0;

 error:
  if ((array))
    free(array);

  ftstab_close_();
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Will Create a third hdu of the logfile. */

int create_hdu_3(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
{ 
  int param, i;

  if (!log -> logname)
    goto error;

  /* First calculate how many columns will be there and initialise */
  if (!ftstab_inithd(NPARAMS*rpm -> nur+NSPARAMS+OUTTABNR))
    goto error;
  
  /* Now add the parameters */
  for (param = 1; param <= NPARAMS; ++param) {
    for (i = 0; i < rpm -> nur; ++i) {
 ftstab_fillhd((param-1)*rpm -> nur+i, param, COLTYPE_DOUBLE, 0.0, -1.0);
    }
  }
  for (param = 1; param <= NSPARAMS; ++param) {
    ftstab_fillhd(NPARAMS*rpm -> nur+param-1, param+NPARAMS, COLTYPE_DOUBLE, 0.0, -1.0);
  }
  
  /* At the end we put some other thingies */
  for (param = 0; param < OUTTABNR; ++param)
    ftstab_fillhd(NPARAMS*rpm -> nur+NSPARAMS+param, NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI+param+1, primpos_numtype(NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI+param+1), 0.0, -1.0);
  
  /* This is not exactly necessary, but we do it anyway */
  if (!ftstab_genhd(0))
    goto error;
  
  /* Now create the table */
  if ((ftstab_fopen(log -> logname, 3, 2, 1))) {
    goto error;
  }

  return 0;

 error:
  ftstab_close_();
  ftstab_flush_();
  ftstab_hdlreset_();
  hdl_init();
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Calculates and puts the results of the fitting procedure */
static int putmetresults(loginf *log, ringparms *rpm, fitparms *fit)
{
  fint def, nel, err;
  double fraction;
  char mes[81];
  double *minima;
  int i;
  
  /***************/
  /***************/
  /* char obsmes[160]; */
  /* fint obsint = 0; */
  /***************/
  /**************/
  /**************/
/* sprintf(obsmes, "got here"); */
/* anyout_c(&obsint, tofchar(obsmes));  */
  /**************/
  
  if (fit -> loopnr < 1)
    return 1;
  
  /* We hide the variable fraction */
  def = 2;
  nel = 1;
  err = 0;

  fraction = 0.6826;
  sprintf(mes, "Give the fraction to derive the errors [0.6826]");
  while (!(err)) {
    userdble_c(&fraction, &nel, &def, tofchar("FRACTION="), tofchar(mes));
    if (fraction <= 0.0 || fraction >= 1.0) {
      sprintf (mes, "FRACTION has to be in-between 0 and 1");
      cancel_c(tofchar("FRACTION="));
      def = 1;
    }
    else {
      err = 1;
    }
  }

  /* If the loopnumber is equal or less than the annealing steps, we simply put the best result into grid */
  if (fit -> loopnr <= fit -> ansteps) {

    ftstab_heapsort(NPARAMS*rpm -> nur+NSPARAMS+CHISQ_TABNR, 2, fit -> loopnr);

    /* The best value is at the start */
    ftstab_get_row(2, log -> outarray);

    /* Put it to the grid */
    for (i = 0; i < NPARAMS*rpm -> nur+NSPARAMS+OUTTABNR; ++i)
      ftstab_fillhd(i, ftstab_get_coltit(i+1), ftstab_get_coltyp(i+1), 0.0, log -> outarray[i]);

    /* Apply the changes */
    if (!ftstab_clearhd(0)) {
    goto error;
    }
  }

  /* If the annealing steps are finished, we sort the table at the end and calculate errors that are put to radii */
  else {

    ftstab_heapsort(NPARAMS*rpm -> nur+NSPARAMS+CHISQ_TABNR, fit -> ansteps+1, fit -> loopnr);
    ftstab_findminmax(fit -> ansteps+1, fit -> ansteps+1+fraction*(fit -> loopnr - fit -> ansteps-1));

    /* Now we fetch the min and the max, and put the errors and the best values */
    if (!(minima = ftstab_get_dblarr()))
      goto error;
    ftstab_get_maxi_(log -> outarray);
    ftstab_get_mini_(minima);

     for (i = 0; i < NPARAMS*rpm -> nur+NSPARAMS+OUTTABNR; ++i)
      ftstab_fillhd(i, ftstab_get_coltit(i+1), ftstab_get_coltyp(i+1), fabs(log -> outarray[i]-minima[i])/2, log -> outarray[i] = (log -> outarray[i]+minima[i])/2);

   /* Apply the changes */
    if (!ftstab_clearhd(0))
      goto error;

    free(minima);
  }

    /* Now sort back */
  ftstab_heapsort(NPARAMS*rpm -> nur+NSPARAMS+LOOPNR_TABNR-1, 1, fit -> loopnr);

  return 1;

 error:
  if ((minima))
    free(minima);
  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* A golden section iteration */
static int golden_section(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
{
  int i,j;
  int search = 1;
  int accept = 1;
  long bigloops;
  varlel *varele;
  double delta;
  double delta_start;
  int maxiter;
  int curiter;
  int dof;
  int satisfied;
  int globiter = 0;
  int globiter_old;
  fint def = 1;
  char mes[300];
  char key[20];
  double *prevresult;
  int nmax = 0;
  double chi2_old;
  double mdelt;
  
  /**************/
  /**************/
/*   fint obsint = 0; */
/*   char obsmes[80]; */
  /**************/
  
  /******/
  /******/
/*   sprintf(obsmes, "got here"); */
/*   anyout_c(&obsint, tofchar(obsmes)); */
  /******/
  
  /* Get the number of elements in the varlist */
  varele = fit -> varylist;
  
  i = 0;
  while (varele) {
    ++i;
    nmax = (nmax > varele -> nelem) ? nmax: varele -> nelem;
    varele = varele -> next;
  }
  
  /* The degrees of freedom are determined by the amount of variable
     parameters, we do it VERY roughly. If there is a parameter varied
     twice, this is not true anymore */
  dof = (hdr -> bsize1-1)*hdr -> bsize2* hdr -> nsubs-i;
  
  /* We allocate the prevresult array */
  if (!(prevresult = (double *) malloc(nmax*sizeof(double))))
    return 0;
  
  /* Now get the number of big loops */
  if (ftstab_get_rownr_())
    bigloops = (fit -> loopnr)/i+1+!((fit -> loopnr)%i);
  else {
    bigloops = 0;
  }
  bigloops = (fit -> loopnr != 0)?(fit -> loopnr-1)/i+1:0;
  
  /* Now put the pointer to the next element in the varlel */
  if ((fit -> loopnr))
    i = (fit -> loopnr-1)%i;
  else
    i = 0;
  
  varele = fit -> varylist;
  for (j = 0; j < i; ++j)
    varele = varele -> next;
  
  /* The new parameter list will be created */
  if (!(fit -> loopnr)) {
    for (i = 0; i < rpm -> nur*NPARAMS+NSPARAMS; ++i)
      rpm -> oldpar[i] = rpm -> par[i];
  }
  else {
    for (i = 0; i < rpm -> nur*NPARAMS+NSPARAMS; ++i)
      rpm -> par[i] = rpm -> oldpar[i];
  }
  
  /* When starting make one run of interpover */
  interpover(rpm, rpm -> radsep, 1, NULL);
  
  /* Get the old chisqare or initialise */
  if ((fit -> loopnr)) {
    hdr -> oldchi2 = log -> outarray[NPARAMS*rpm -> nur+NSPARAMS+CHISQ_TABNR-1];
    satisfied = log -> outarray[NPARAMS*rpm -> nur+NSPARAMS+ACCEPT_TABNR-1];
  }  
  else {
    
    /* Do it */
    fit -> npoints = galmod(hdr, rpm, 1, varele);
    
    /* Get the chisquare */
    getchisquare_c(rpm -> par[PCONDISP*rpm -> nur]);
      
    /* Correct the chisquare taking into account the outliers, don't know if that is necessary here... */
    hdr -> chi2 = hdr -> chi2+((double) rpm -> outpoints)*rpm -> penalty;

    /* Copy it */
    hdr -> oldchi2 = hdr -> chi2;
    
    /* Write the output */
    satisfied = 1;
    
    /* Starting */
    sprintf(mes, "START");
    
    anyout_c(&def, tofchar(mes));
    writeoutput(log, hdr, rpm, fit, satisfied, dof, bigloops, globiter);
    ++fit -> loopnr;
    ++bigloops;
  }
  
  
  /* This will run until the bigloops is reached */
  while (bigloops <= fit -> loops) {
    
    /* We go through the varylist */
    while(varele) {
       
      /* Record where we started */
	for (i = 0; i < varele -> nelem; ++i)
	  prevresult[i] = rpm -> oldpar[varele -> elements[i]];

	/* Reset the old chisquare */
	chi2_old = hdr -> oldchi2 ;

      globiter_old = globiter;
      
      /* Calculate the delta */
      if (bigloops - varele -> moderate <= 0)
	delta = (bigloops-1)*(varele -> delend-varele -> delstart)/varele -> moderate+varele -> delstart;
      else
	delta = varele -> delend;
      
      
      delta_start = delta;
      
      /* Calculate the number of steps */
      if (bigloops - varele -> moderate <= 0)
	maxiter = ((bigloops-1)*(varele -> iteend-varele -> itestart))/varele -> moderate+varele -> itestart;
      else
	maxiter = varele -> iteend;
      
      /* The first iteration */
      curiter = 0;
      accept = 1;
      
      /* We go on searching until we find a lower chisquare and then a higher chisquare */
      while (1) {
	
	/* If the maximum number of iterations is reached break out, deeply disappointed */
	if (curiter == maxiter) {
	  accept = 0;
	  satisfied = 0;
	  break;
	}
	
	/* Change the params */
	for (i = 0; i < varele -> nelem; ++i)
	  rpm -> par[varele -> elements[i]] = rpm -> oldpar[varele -> elements[i]] + delta;
	
	/* Do it */
	fit -> npoints = galmod(hdr, rpm, 1, varele);
	
	++globiter;
	
	/* Get the chisquare */
	getchisquare_c(rpm -> par[PCONDISP*rpm -> nur]);
	
	/* Correct the chisquare taking into account the outliers, don't know if that is necessary here... */
	hdr -> chi2 = hdr -> chi2+((double) rpm -> outpoints)*rpm -> penalty;
	
	ftstab_putcoltitl(key, ftstab_get_coltit(*varele -> elements+1));
	/* Report Search minimum, big loops, keyword loops, total models, keyword, first ringnumber, keyword models/maxmodels, number of pointsources, total flux, current minimum chisquare, trial chisquare, difference, current stepwidth, start stepwidth. In principle, this should be a status report, but gipsy... crashes when you interrupt the task if you change the length MSGLEN of the status line in taskcom.h */
	sprintf(mes, 
		"SM "         /* Searching minimum */
		"BL:%li "       /* Big loops */
		"KL:%li "       /* Keyword loops */
		"TM:%i "     /* Total models */
		"KW:%s "       /* Keyword */ 
		"FR:%i "       /* First ringnumber */
		"KM:%i"        /* Keyword models */
		"/%i "         /* Keyword maxmodels */
		"NP:%d "       /* Number of pointsources */
		"TF:%.2E "     /* Total flux */
		"CC:%E "       /* current minimum chisquare */
		"DC:%+.1E "       /* Difference */
		"SW:%+.2E"       /* Current stepwidth */
		"/%.2E "         /* Start stepwidth */
		"AC:%i",      /* Acceptance flag */                                          
		bigloops,                /* Big loops */         
		fit -> loopnr,                       /* Keyword loops */        
		globiter,                /* Total models */        
		key,                 /* Keyword */ 
		(*varele -> elements/rpm -> nur < NPARAMS)?*varele -> elements%rpm -> nur+1:1,                  /* First ringnumber */  
		globiter-globiter_old,                      /* Keyword models */        
		maxiter,                /* Keyword maxmodels */        
		fit -> npoints,               /* Number of pointsources */       
		fit -> npoints*rpm -> cflux,              /* Total flux */ 
		hdr -> oldchi2,               /* current minimum chisquare */       
		hdr -> oldchi2-hdr -> chi2,                                                     /* Difference */ 
		dinterntoparam(delta, ftstab_get_coltit(*varele -> elements+1), hdr),         /* Current stepwidth */        
		dinterntoparam(delta_start, ftstab_get_coltit(*varele -> elements+1), hdr),   /* Start stepwidth */           
		satisfied               /* Acceptance flag */           
		);                              
	anyout_c(&def, tofchar(mes));
	
	/* Now compare */
	if (hdr -> chi2 >= hdr -> oldchi2) {
	  
	  /* If the number of iterations is larger than 1, we stop it here */
	  if (curiter > 0) {
	    delta = BFAC*delta;
	    ++curiter;
	    break;
	  }
	  /* If not we search in the other direction */
	  else {
	    delta = -delta;
  	  }
	}
	else {
	  
	  /* Now overwrite the oldparams */
	  for (i = 0; i < varele -> nelem; ++i)
	    rpm -> oldpar[varele -> elements[i]] = rpm -> oldpar[varele -> elements[i]] + delta;
	  
	  /* Now enlarge the delta and accept the chisquare */
	  hdr -> oldchi2 = hdr -> chi2;
 	  if (curiter < MAGNIFICNR) 
	    delta = AFAC*delta;
	}
	
	++curiter;
      }
      
      search = 1;
      
      if ((accept)) {
	/* We go on searching to find the minimum in the knowledge that we are nearly there */
	while (1) {
	  
	  /* If the maximum number of iterations is reached break out, deeply disappointed */
	  if (curiter == maxiter) {
	    satisfied = 0;
	    break;
	  }
	  
	  /* Change the delta */
	  delta = BFAC * delta;
	  
	  /* Check if we break out because of too small deltas*/
	  if (fabs(delta) < varele -> mindelta)
	    break;
	  
	  for (i = 0; i < varele -> nelem; ++i)
	    rpm -> par[varele -> elements[i]] = rpm -> oldpar[varele -> elements[i]] + delta;
	  
	  /* We don't have to check whether we broke out of range */
	  
	  /* Do it */
	  fit -> npoints = galmod(hdr, rpm, 1, varele);
	  ++globiter;
	  
	  /* Get the chisquare */
	  getchisquare_c(rpm -> par[PCONDISP*rpm -> nur]);
	  
	  /* Correct the chisquare taking into account the outliers, don't know if that is necessary here... */
	  hdr -> chi2 = hdr -> chi2+((double) rpm -> outpoints)*rpm -> penalty;
	  
	  /* Report Found minimum, big loops,  total models, keyword loops, keyword, first ringnumber, keyword models/maxmodels, number of pointsources, total flux, current minimum chisquare, trial chisquare, difference, current stepwidth, start stepwidth */
	  
	  /* Report Search minimum, big loops, keyword loops, total models, keyword, first ringnumber, keyword models/maxmodels, number of pointsources, total flux, current minimum chisquare, trial chisquare, difference, current stepwidth, start stepwidth */
	  sprintf(mes, 
		  "FM "         /* Found minimum */
		  "BL:%li "       /* Big loops */
		  "KL:%li "       /* Keyword loops */
		  "TM:%i "     /* Total models */
		  "KW:%s "       /* Keyword */ 
		  "FR:%i "       /* First ringnumber */
		  "KM:%i"        /* Keyword models */
		  "/%i "         /* Keyword maxmodels */
		  "NP:%d "       /* Number of pointsources */
		  "TF:%.2E "       /* Total flux */
		  "CC:%E "       /* current minimum chisquare */
		  "DC:%+.1E "       /* Difference */
		  "SW:%+.2E"       /* Current stepwidth */
		  "/%.2E "         /* Start stepwidth */
		  "AC:%i",      /* Acceptance flag */                                          
		  bigloops,                /* Big loops */         
		  fit -> loopnr,                       /* Keyword loops */        
		  globiter,                /* Total models */        
		  key,                 /* Keyword */ 
		  (*varele -> elements/rpm -> nur < NPARAMS)?*varele -> elements%rpm -> nur+1:1,                 /* First ringnumber */  
		  globiter-globiter_old,                      /* Keyword models */        
		  maxiter,                /* Keyword maxmodels */        
		  fit -> npoints,               /* Number of pointsources */       
		  fit -> npoints*rpm -> cflux,              /* Total flux */
		  hdr -> oldchi2,               /* current minimum chisquare */       
		  hdr -> oldchi2-hdr -> chi2,                                                     /* Difference */  
		  dinterntoparam(delta, ftstab_get_coltit(*varele -> elements+1), hdr),         /* Current stepwidth */        
		  dinterntoparam(delta_start, ftstab_get_coltit(*varele -> elements+1), hdr),   /* Start stepwidth */           
		  satisfied               /* Acceptance flag */           
		  );                              
	  anyout_c(&def, tofchar(mes));
	  
	  /* Now compare */
	  if (hdr -> chi2 >= hdr -> oldchi2) {
	    delta = -delta;
	  }
	  else {
	    /* Now overwrite the oldparams */
	    
	    for (i = 0; i < varele -> nelem; ++i)
	      rpm -> oldpar[varele -> elements[i]] = rpm -> oldpar[varele -> elements[i]] + delta;
	    hdr -> oldchi2 = hdr -> chi2;
	  }
	  ++curiter;
	}
      }

      /* We have to check whether we have changed too much to be satisfied */
      if ((satisfied)) {
	
	/* We only have to check one variable */
	if (fabs(rpm -> oldpar[varele -> elements[0]]-prevresult[0]) > varele -> satdelt) {
	  satisfied = 0;
	}
      }
      
      /* Check the range of the params */
      for (i = 0; i < varele -> nelem; ++i) {
	if (maths_checkinbetw(varele -> parmax, varele -> parmin, rpm -> oldpar[varele -> elements[i]])) {

	  /* Comment on that */
	  sprintf(mes, "Parameter out of range, interpolating");
	  anyout_c(&def, tofchar(mes));

	  /***************/
	  /* This is new */
	  /***************/

	  /* Find out what has happened */

	  mdelt = 0.0;
	  if (varele -> parmax > varele -> parmin) {
	    if (rpm -> oldpar[varele -> elements[i]] < varele -> parmin) {
	      while (i < varele -> nelem) {
		mdelt = (((prevresult[i]-varele -> parmin)/2.0) < mdelt)?((prevresult[i]-varele -> parmin)/2.0):mdelt;
		++i;
	      }
	      mdelt = -mdelt;
	    }
	    else {
	      while (i < varele -> nelem) {
		mdelt = (((varele -> parmax-prevresult[i])/2.0) < mdelt)?(((varele -> parmax-prevresult[i])/2.0)/2.0):mdelt;
		  ++i;
	      }
	    }
	  }
	  else {
	    if (rpm -> oldpar[varele -> elements[i]] < varele -> parmax) {
	      while (i < varele -> nelem) {
		mdelt = (((prevresult[i]-varele -> parmax)/2.0) < mdelt)?((prevresult[i]-varele -> parmax)/2.0):mdelt;
		++i;
	      }
	      mdelt = -mdelt;
	    }
	    else {
	      while (i < varele -> nelem) {
		mdelt = (((varele -> parmin-prevresult[i])/2.0) < mdelt)?(((varele -> parmin-prevresult[i])/2.0)/2.0):mdelt;
		  ++i;
	      }
	    }
	  }

	    /* change all the values: new */
	    for (i = 0; i < varele -> nelem; ++i)
	      rpm -> par[varele -> elements[i]] = rpm -> oldpar[varele -> elements[i]] = prevresult[i]+mdelt;
	    
	  /* write back all the values: old */
/* 	  for (i = 0; i < varele -> nelem; ++i) */
/* 	    rpm -> par[varele -> elements[i]] = rpm -> oldpar[varele -> elements[i]] = prevresult[i]; */

	  /* This is crucial at that point */
	  interpover(rpm, rpm -> radsep, 1, varele);

	  hdr -> oldchi2 = chi2_old;
	  satisfied = 0;
	  break;
	}
      }
      
      /* BUGFIXED? The following lines were not present in the previous version */
      /* Write oldpar into par */
      for (i = 0; i < varele -> nelem; ++i)
	rpm -> par[varele -> elements[i]] = rpm -> oldpar[varele -> elements[i]];
      
      /* BUGFIX: This seems to be very important in order not to loose pointsources; if not done, a pointsource list might be terminated the wrong way */
      interpover(rpm, rpm -> radsep, 1, varele);
      
      writeoutput(log, hdr, rpm, fit, satisfied, dof, fit -> loopnr, globiter);
      varele = varele -> next;
      
      /* Now we document on the results */
      ++fit -> loopnr;
      
      if ((*hdr -> outset != '\0')) {
	if (!(fit -> loopnr%hdr -> outcubup)) {
	  writemodel(hdr, rpm);
	}
      }
    }
    
    /* If we are still satisfied, we break, because we have results, which is documented also in outarray[NPARAMS*rpm -> nur+NSPARAMS-1+ACCEPT_TABNR] */
    if ((satisfied)) {
      break;
    }

    /* We start at the start of the varylist again */
    varele = fit -> varylist;
   
    ++bigloops;
    satisfied = 1;
  }
  
  free(prevresult);
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Calculates and puts the results of the fitting procedure */
static int putgoldresults(loginf *log, ringparms *rpm, fitparms *fit)
{
  int i;
  
  /* The best value is at the end */
  ftstab_get_row(fit -> loopnr, log -> outarray);
  
  /* Put it to the grid */
  for (i = 0; i < NPARAMS*rpm -> nur+NSPARAMS+OUTTABNR; ++i)
    ftstab_fillhd(i, ftstab_get_coltit(i+1), ftstab_get_coltyp(i+1), COLRADI_DEFAULT, log -> outarray[i]);
  
  /* Apply the changes */
  if (!ftstab_clearhd(0))
    goto error;
  
  return 1;
  
 error:
  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Writes an ascii table with the results */
static int writeasctable(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
{
  int def = 2;
  int nel = 1;
  int rring;
  int err = 1;
  char mes[81];

  FILE *stream;
  int i, j;
  char key[21];
  char key2[26];
  double value;
  double delta;
  double vsys;
  double nu;
  double nv[3];
  double nvtot[3];
  double nrefr[3];

  double cosp;
  double sinp;
  double sini;
  double cosi;
  double pp[3];
  double posin[3];
  double posout[3];


  /**********/
  /**********/
  /* fint obsint; */
  /* char obsmes[81]; */
  /*********/

  /* First check if there was an input */
  if (*log -> table == '\0')
    return 1;
  
  /* Also check if there was a logfile and stop if there wasn't */
  if (*log -> logname == '\0')
    return 0;
  
  rring = rpm -> nur >= 5?5:rpm -> nur;

  /* Get the reference ring */
  sprintf(mes, "Give reference ring for warp angle calculation");
  while ((err)) {
    userint_c(&rring, &nel, &def, tofchar("REFRING="), tofchar(mes));
    if (rring <= 0 || rring > rpm -> nur) {
      sprintf(mes, "REFRING: impossible number");
      cancel_c(tofchar("REFRING="));
      def = 4;
    } 
    else
      err = 0;
  }

  /* Try to open the output file */
  if (!(stream = fopen(log -> table, "r"))) {
    
    /* If the file doesn't exist we compose a header */
    if (!(stream = fopen(log -> table, "w"))) {
      return 0;
    }
  }
  else {
    if (!(stream = fopen(log -> table, "a")))
      return 0;
    fprintf(stream, "\n");
  }
  
  /* Now we put some general information, commented */
  fprintf(stream, "# tirific version 1\n");
  fprintf(stream, "# logfile: %s\n", log -> logname);
  
  
  if (fit -> fitmode) {
    fprintf(stream, "# fitmode was golden section\n");
    fprintf(stream, "# last acceptance was (1 accepted, 0 not accepted): %f\n", log -> outarray[NPARAMS*rpm -> nur+NSPARAMS+ACCEPT_TABNR-1]);
  }  
  else {
    fprintf(stream, "# fitmode was metropolis\n");
  }
  /* The chisquare makes only sense in case of zero errors */
  if (ftstab_get_colrad((PRADI)*rpm -> nur+1) == 0.0) {
    fprintf(stream, "# Chisquare: %f\n# Reduced Chisquare: %f\n", ftstab_get_colgrd(NPARAMS*rpm -> nur+NSPARAMS+CHISQ_TABNR), ftstab_get_colgrd(NPARAMS*rpm -> nur+NSPARAMS+RCHISQ_TABNR));
  }
  
  /* We comment the header */
  fprintf(stream, "# ");

  /* We now compose a header entry for each keyword including radius */
  for (i = 1; i <= NPARAMS+NSPARAMS; ++i) {
    /* Put the title */
    ftstab_putcoltitl(key, i);
    fprintf(stream, "%19s ", key);
    sprintf(key2, "DELTA%s", key);
    fprintf(stream, "%19s ", key2);
  }

  /* Now we include some specials */

    sprintf(key, "RADI/kpc");
    fprintf(stream, "%19s ", key);
    sprintf(key2, "DELTA%s", key);
    fprintf(stream, "%19s ", key2);

    sprintf(key, "SBR/cm^(-2)");
    fprintf(stream, "%19s ", key);
    sprintf(key2, "DELTA%s", key);
    fprintf(stream, "%19s ", key2);

    sprintf(key, "SBR/(msol/(pc^2))");
    fprintf(stream, "%19s ", key);
    sprintf(key2, "DELTA%s", key);
    fprintf(stream, "%19s ", key2);

    sprintf(key, "WA_old (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "WA_new (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LON_ASC_RA (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LON_ASC_DEC (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LON_DSC_RA (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LON_DSC_DEC (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LMV_APP_RA (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LMV_APP_DEC (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LMV_REC_RA (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LMV_REC_DEC (deg)");
    fprintf(stream, "%19s ", key);

    fprintf(stream, "\n");
    fprintf(stream, "  ");

    /* We read all values into the outarray */
    ftstab_get_grid_(log -> outarray);

    for (j = 0; j < rpm -> nur*NPARAMS+NSPARAMS; ++j)
      rpm -> par[j] = log -> outarray[j];

    /* We convert to internal units and interpolate over */
    changetointern(rpm -> par, rpm -> nur, hdr);

    interpover(rpm, rpm -> radsep, 0, NULL);

    for (i = 0; i < 3; ++i) {
      nvtot[i] = 0;
    }

    /* Now we calculate the direction of the total angular momentum of the observed component */
    for (j = 0; j < rpm -> nr; ++j) {
      /* We don't do a relativistic correction */
      value = pow(rpm -> modpar[PRADI*rpm -> nr+j],2)*rpm -> modpar[PVROT*rpm -> nr+j]*rpm -> modpar[PSBR*rpm -> nr+j];
      nvtot[0] = nvtot[0]+(double) value*sin(rpm -> modpar[PINCL*rpm -> nr+j])*sin(rpm -> modpar[PPA*rpm -> nr+j]);
      nvtot[1] = nvtot[1]-(double) value*sin(rpm -> modpar[PINCL*rpm -> nr+j])*cos(rpm -> modpar[PPA*rpm -> nr+j]);
      nvtot[2] = nvtot[2]+(double) value*cos(rpm -> modpar[PINCL*rpm -> nr+j]);
    }

    value = sqrt(pow(nvtot[0],2)+pow(nvtot[1],2)+pow(nvtot[2],2));
    nvtot[0] = nvtot[0]/value;
    nvtot[1] = nvtot[1]/value;
    nvtot[2] = nvtot[2]/value;

    /* Now get the normal vector of the reference ring */
    nrefr[0] = sinf(rpm -> par[PINCL*rpm -> nur+rring-1])*sinf(rpm -> par[PPA*rpm -> nur+rring-1]);
    nrefr[1] = -sinf(rpm -> par[PINCL*rpm -> nur+rring-1])*cosf(rpm -> par[PPA*rpm -> nur+rring-1]);
    nrefr[2] = cosf(rpm -> par[PINCL*rpm -> nur+rring-1]);

    /* Now we read in the values, we should have a third extension opened */
    for (j = 1; j <= rpm -> nur; ++j) {
      for (i = 0; i < NPARAMS; ++i) {
	/* Put the title */
	value = ftstab_get_colgrd(i*rpm -> nur+j);
	delta = ftstab_get_colrad(i*rpm -> nur+j);
	fprintf(stream, "%+.12E %+.12E ", value, delta);
      }
      
      /* The single parameters */
      for (i = 0; i < NSPARAMS; ++i) {
	value = ftstab_get_colgrd((NPARAMS)*rpm -> nur+i+1);
	delta = ftstab_get_colrad((NPARAMS)*rpm -> nur+i+1);
	fprintf(stream, "%+.12E %+.12E ", value, delta);
      }

      /* Now the specials */
      
      /* Calculate the radius in kpc */
      value = ftstab_get_colgrd(PRADI*rpm -> nur+j);
      delta = ftstab_get_colrad(PRADI*rpm -> nur+j);

      /* Let's be slow, as this is only output */
      value = value*1000*log -> distance*TWOPI/(360*60*60);
      delta = delta*1000*log -> distance*TWOPI/(360*60*60);
      fprintf(stream, "%+.12E %+.12E ", value, delta);
      
      /* Calculate the approximate frequency */
      vsys = ftstab_get_colgrd(PVSYS*rpm -> nur+j);
      nu = (SPEEDOFLIGHT-vsys)*hdr -> rfreq/SPEEDOFLIGHT;

      value = ftstab_get_colgrd(PSBR*rpm -> nur+j);
      delta = ftstab_get_colrad(PSBR*rpm -> nur+j);

      /* The intensity in the restframe scales like */
      value = hdr -> itou*value*pow(hdr -> rfreq/nu,4);
      delta = hdr -> itou*delta*pow(hdr -> rfreq/nu,4);
      fprintf(stream, "%+.12E %+.12E ", value, delta);
 
      /* Now we convert to Msol/pc^2 */
      value = UTOSOLAR*value;
      delta = UTOSOLAR*delta;
      fprintf(stream, "%+.12E %+.12E ", value, delta);
      fprintf(stream, "   ");

      /* Get the normal vector of the current ring */
      nv[0] = sin(rpm -> par[PINCL*rpm -> nur+j-1])*sin(rpm -> par[PPA*rpm -> nur+j-1]);
      nv[1] = -sin(rpm -> par[PINCL*rpm -> nur+j-1])*cos(rpm -> par[PPA*rpm -> nur+j-1]);
      nv[2] = cos(rpm -> par[PINCL*rpm -> nur+j-1]);
      
      /* Here is the scalar product with the reference ring */
      value = nv[0]*nrefr[0]+nv[1]*nrefr[1]+nv[2]*nrefr[2];

      /* This is the arcus */
      value = value>1?0.0:RADTODEG*acos(value);
      fprintf(stream, "%+.12E ", value);

      /* Here is the scalar product with the reference frame */
      value = nv[0]*nvtot[0]+nv[1]*nvtot[1]+nv[2]*nvtot[2];

      /* This is the arcus */
      value = value>1?0.0:RADTODEG*acos(value);
      fprintf(stream, "%+.12E ", value);

      /* LON and maximum velocity coordinates */
      cosi = cos(rpm -> par[PINCL*rpm -> nur+j-1]);
      sini = sin(rpm -> par[PINCL*rpm -> nur+j-1]);
      cosp = cos(rpm -> par[PPA*rpm -> nur+j-1]);
      sinp = sin(rpm -> par[PPA*rpm -> nur+j-1]);

      /* Ascending LON */

      /* Position */
      posin[0] = 0;
      posin[1] = rpm -> par[PRADI*rpm -> nur+j-1];
      posin[2] = 0;

      /* Velocity will not be regarded*/

      /* Rotate about x-axis */
      maths_rotax(cosi, sini, posin, pp);

      /* Rotate about z-axis */
      maths_rotaz(cosp, sinp, pp, posout);

      /* Add central coordinates */
      posout[0] = posout[0]+rpm -> par[PXPOS*rpm -> nur+j-1];
      posout[1] = posout[1]+rpm -> par[PYPOS*rpm -> nur+j-1];
      posout[2] = rpm -> par[PVSYS*rpm -> nur+j-1];

      /* Change into user coordinates */
      interntoglob(posout, pp, hdr);

      /* Print */
      fprintf(stream, "%+.12E ", pp[0]);
      fprintf(stream, "%+.12E ", pp[1]);

      /* Descending LON */

      /* Position */
      posin[0] = 0;
      posin[1] = -rpm -> par[PRADI*rpm -> nur+j-1];
      posin[2] = 0;

      /* Velocity will not be regarded*/

      /* Rotate about x-axis */
      maths_rotax(cosi, sini, posin, pp);

      /* Rotate about z-axis */
      maths_rotaz(cosp, sinp, pp, posout);

      /* Add central coordinates */
      posout[0] = posout[0]+rpm -> par[PXPOS*rpm -> nur+j-1];
      posout[1] = posout[1]+rpm -> par[PYPOS*rpm -> nur+j-1];
      posout[2] = rpm -> par[PVSYS*rpm -> nur+j-1];

      /* Change into user coordinates */
      interntoglob(posout, pp, hdr);

      /* Print */
      fprintf(stream, "%+.12E ", pp[0]);
      fprintf(stream, "%+.12E ", pp[1]);

      /* Approaching Maximum Velocity */

      /* Position */
      posin[0] = -rpm -> par[PRADI*rpm -> nur+j-1];
      posin[1] = 0;
      posin[2] = 0;

      /* Velocity will not be regarded*/

      /* Rotate about x-axis */
      maths_rotax(cosi, sini, posin, pp);

      /* Rotate about z-axis */
      maths_rotaz(cosp, sinp, pp, posout);

      /* Add central coordinates */
      posout[0] = posout[0]+rpm -> par[PXPOS*rpm -> nur+j-1];
      posout[1] = posout[1]+rpm -> par[PYPOS*rpm -> nur+j-1];
      posout[2] = rpm -> par[PVSYS*rpm -> nur+j-1];

      /* Change into user coordinates */
      interntoglob(posout, pp, hdr);

      /* Print */
      fprintf(stream, "%+.12E ", pp[0]);
      fprintf(stream, "%+.12E ", pp[1]);

      /* Receding Maximum Velocity */

      /* Position */
      posin[0] = rpm -> par[PRADI*rpm -> nur+j-1];
      posin[1] = 0;
      posin[2] = 0;

      /* Velocity will not be regarded*/

      /* Rotate about x-axis */
      maths_rotax(cosi, sini, posin, pp);

      /* Rotate about z-axis */
      maths_rotaz(cosp, sinp, pp, posout);

      /* Add central coordinates */
      posout[0] = posout[0]+rpm -> par[PXPOS*rpm -> nur+j-1];
      posout[1] = posout[1]+rpm -> par[PYPOS*rpm -> nur+j-1];
      posout[2] = rpm -> par[PVSYS*rpm -> nur+j-1];

      /* Change into user coordinates */
      interntoglob(posout, pp, hdr);

      /* Print */
      fprintf(stream, "%+.12E ", pp[0]);
      fprintf(stream, "%+.12E ", pp[1]);

      fprintf(stream, "\n  ");
    }
    
  fclose(stream);
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Writes an ascii table with the results */
static int writebigasctable(loginf *log, hdrinf *hdr, ringparms *rpm, fitparms *fit)
{
  int def = 2;
  int nel = 1;
  int rring = 5;
  int err = 1;
  char mes[81];

  FILE *stream;
  int i, j;
  char key[21];
  double value;
  double vsys;
  double nu;
  double nv[3];
  double nvtot[3];
  double nrefr[3];

  double cosp;
  double sinp;
  double sini;
  double cosi;
  double pp[3];
  double posin[3];
  double posout[3];

  /**********/
  /**********/
  /* fint obsint = 0; */
  /* char obsmes[81]; */
  /*********/

  /******/
  /******/
  /* sprintf(obsmes, "got here"); */
  /* anyout_c(&obsint, tofchar(obsmes)); */
  /******/

  /* Check if the bigtable is asked for */
  sprintf(key, "                  ");
  sprintf(mes, "Give big table name");
  userchar_c(tofchar(key), &nel, &def, tofchar("BIGTABLE="), tofchar(mes));
  termsinglestr(key);

  /* If there is no input we stop here */
  if (*key == '\0')
    return 1;

  /* Check if there was a logfile and stop if there wasn't */
  if (*log -> logname == '\0')
    return 0;
  
  /* Get the reference ring */
  sprintf(mes, "Give reference ring for warp angle calculation");
  while ((err)) {
    userint_c(&rring, &nel, &def, tofchar("REFRING="), tofchar(mes));
    if (rring <= 0 || rring > rpm -> nur) {
      sprintf(mes, "REFRING: impossible number");
      cancel_c(tofchar("REFRING="));
      def = 4;
    } 
    else
      err = 0;
  }

  /* Try to open the output file */
  if (!(stream = fopen(key, "r"))) {
    
    /* If the file doesn't exist we compose a header */
    if (!(stream = fopen(key, "w"))) {
      return 0;
    }
  }
  else {
    if (!(stream = fopen(key, "a")))
      return 0;
    fprintf(stream, "\n");
  }
  
  /* Now we put some general information, commented */
  fprintf(stream, "# tirific version 1\n");
  fprintf(stream, "# logfile: %s\n", log -> logname);
  
  
  if (fit -> fitmode) {
    fprintf(stream, "# fitmode was golden section\n");
    fprintf(stream, "# last acceptance was (1 accepted, 0 not accepted): %f\n", log -> outarray[NPARAMS*rpm -> nur+NSPARAMS+ACCEPT_TABNR-1]);
  }  
  else {
    fprintf(stream, "# fitmode was metropolis\n");
  }
  /* The chisquare makes only sense in case of zero errors */
  if (ftstab_get_colrad((PRADI)*rpm -> nur+1) == 0.0) {
    fprintf(stream, "# Chisquare: %f\n# Reduced Chisquare: %f\n", ftstab_get_colgrd(NPARAMS*rpm -> nur+NSPARAMS+CHISQ_TABNR), ftstab_get_colgrd(NPARAMS*rpm -> nur+NSPARAMS+RCHISQ_TABNR));
  }

  /* We comment the header */
  fprintf(stream, "# ");

  /* We now compose a header entry for each keyword including radius */
  for (i = 1; i <= NPARAMS+NSPARAMS; ++i) {
    /* Put the title */
    ftstab_putcoltitl(key, i);
    fprintf(stream, "%19s ", key);
  }

  /* Now we include some specials */

    sprintf(key, "RADI/kpc");
    fprintf(stream, "%19s ", key);

    sprintf(key, "SBR/cm^(-2)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "SBR/(msol/(pc^2))");
    fprintf(stream, "%19s ", key);

    sprintf(key, "WA_old (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "WA_new (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LON_ASC_RA (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LON_ASC_DEC (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LON_DSC_RA (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LON_DSC_DEC (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LMV_APP_RA (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LMV_APP_DEC (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LMV_REC_RA (deg)");
    fprintf(stream, "%19s ", key);

    sprintf(key, "LMV_REC_DEC (deg)");
    fprintf(stream, "%19s ", key);

    fprintf(stream, "\n");
    fprintf(stream, "  ");

    /* We read all values into the par array */
    ftstab_get_grid_(log -> outarray);

    for (j = 0; j < rpm -> nur*NPARAMS+NSPARAMS; ++j)
      rpm -> par[j] = log -> outarray[j];

    /* We con't convert to internal units and interpolate over */
/*     changetointern(rpm -> par, rpm -> nur, hdr); */

    interpover(rpm, dinterntoparam(rpm -> radsep, RADI, hdr), 0, NULL);

    for (i = 0; i < 3; ++i) {
      nvtot[i] = 0;
    }

    /* Now we calculate the direction of the total angular momentum of the observed component */
    for (j = 0; j < rpm -> nr; ++j) {

      /* We don't do a relativistic correction for this */
      value = pow(rpm -> modpar[PRADI*rpm -> nr+j],2)*rpm -> modpar[PVROT*rpm -> nr+j]*rpm -> modpar[PSBR*rpm -> nr+j];
      nvtot[0] = nvtot[0]+(double) value*sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*sin(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
      nvtot[1] = nvtot[1]-(double) value*sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*cos(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
      nvtot[2] = nvtot[2]+(double) value*cos(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j]);
    }

    value = sqrt(pow(nvtot[0],2)+pow(nvtot[1],2)+pow(nvtot[2],2));
    nvtot[0] = nvtot[0]/value;
    nvtot[1] = nvtot[1]/value;
    nvtot[2] = nvtot[2]/value;

    /* Now get the normal vector of the reference ring */
    nrefr[0] = sinf(DEGTORAD*rpm -> par[PINCL*rpm -> nur+rring-1])*sinf(DEGTORAD*rpm -> par[PPA*rpm -> nur+rring-1]);
    nrefr[1] = -sinf(DEGTORAD*rpm -> par[PINCL*rpm -> nur+rring-1])*cosf(DEGTORAD*rpm -> par[PPA*rpm -> nur+rring-1]);
    nrefr[2] = cosf(DEGTORAD*rpm -> par[PINCL*rpm -> nur+rring-1]);
 
    /* Now we read in the values */
    for (j = 0; j < rpm -> nr; ++j) {
      for (i = 0; i < NPARAMS; ++i) {
	value = rpm -> modpar[i*rpm -> nr+j];
	fprintf(stream, "%+.12E ", value);
      }
      /* The single parameters */
      for (i = 0; i < NSPARAMS; ++i) {
	value = ftstab_get_colgrd((NPARAMS)*rpm -> nur+i+1);
	fprintf(stream, "%+.12E ", value);
      }
      /* Now the specials */
      
      /* Calculate the radius in kpc */
      value = rpm -> modpar[PRADI*rpm -> nr+j];
      
      /* Let's be slow, as this is only output */
      value = value*1000*log -> distance*TWOPI/(360*60*60);
      fprintf(stream, "%+.12E ", value);
      
      /* Calculate the approximate frequency */
      vsys = rpm -> modpar[PVSYS*rpm -> nr+j];
      nu = (SPEEDOFLIGHT-vsys)*hdr -> rfreq/SPEEDOFLIGHT;
      
      value = rpm -> modpar[PSBR*rpm -> nr+j];

      /* The intensity in the restframe scales like */
      value = hdr -> itou*value*pow(hdr -> rfreq/nu,4);
      fprintf(stream, "%+.12E ", value);
 
      /* Now we convert to Msol/pc^2 */
      value = UTOSOLAR*value;
      fprintf(stream, "%+.12E ", value);
    
      /* Get the normal vector of the current ring */
      nv[0] = sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*sin(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
      nv[1] = -sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*cos(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
      nv[2] = cos(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j]);
      
      /* Here is the scalar product with the reference ring */
      value = nv[0]*nrefr[0]+nv[1]*nrefr[1]+nv[2]*nrefr[2];

      /* This is the arcus */
      value = value>1?0.0:RADTODEG*acos(value);
      fprintf(stream, "%+.12E ", value);

      /* Here is the scalar product with the reference frame */
      value = nv[0]*nvtot[0]+nv[1]*nvtot[1]+nv[2]*nvtot[2];

      /* This is the arcus */
      value = value>1?0.0:RADTODEG*acos(value);
      fprintf(stream, "%+.12E ", value);

      /* LON and maximum velocity coordinates */
      cosi = cos(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j]);
      sini = sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j]);
      cosp = cos(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
      sinp = sin(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);

      /* Ascending LON */

      /* Position */
      posin[0] = 0;
      posin[1] = dparamtointern(rpm -> modpar[PRADI*rpm -> nr+j], RADI, hdr);
      posin[2] = 0;

      /* Velocity will not be regarded*/

      /* Rotate about x-axis */
      maths_rotax(cosi, sini, posin, pp);

      /* Rotate about z-axis */
      maths_rotaz(cosp, sinp, pp, posout);

      /* Get central coordinates */
      posin[0] = rpm -> modpar[PXPOS*rpm -> nr+j];
      posin[1] = rpm -> modpar[PYPOS*rpm -> nr+j];
      posin[2] = rpm -> modpar[PVSYS*rpm -> nr+j];
      globtointern(posin, pp, hdr);

      /* Add central coordinates */
      posout[0] = posout[0]+pp[0];
      posout[1] = posout[1]+pp[1];
      posout[2] = pp[2];

      /* Change into user coordinates */
      interntoglob(posout, pp, hdr);

      /* Print */
      fprintf(stream, "%+.12E ", pp[0]);
      fprintf(stream, "%+.12E ", pp[1]);

      /* Descending LON */

      /* Position */
      posin[0] = 0;
      posin[1] = -dparamtointern(rpm -> modpar[PRADI*rpm -> nr+j], RADI, hdr);
      posin[2] = 0;

      /* Velocity will not be regarded*/

      /* Rotate about x-axis */
      maths_rotax(cosi, sini, posin, pp);

      /* Rotate about z-axis */
      maths_rotaz(cosp, sinp, pp, posout);

      /* Get central coordinates */
      posin[0] = rpm -> modpar[PXPOS*rpm -> nr+j];
      posin[1] = rpm -> modpar[PYPOS*rpm -> nr+j];
      posin[2] = rpm -> modpar[PVSYS*rpm -> nr+j];
      globtointern(posin, pp, hdr);

      /* Add central coordinates */
      posout[0] = posout[0]+pp[0];
      posout[1] = posout[1]+pp[1];
      posout[2] = pp[2];

      /* Change into user coordinates */
      interntoglob(posout, pp, hdr);

      /* Print */
      fprintf(stream, "%+.12E ", pp[0]);
      fprintf(stream, "%+.12E ", pp[1]);

      /* Approaching Maximum Velocity */
      posin[0] = -dparamtointern(rpm -> modpar[PRADI*rpm -> nr+j], RADI, hdr);;
      posin[1] = 0;
      posin[2] = 0;

      /* Velocity will not be regarded*/

      /* Rotate about x-axis */
      maths_rotax(cosi, sini, posin, pp);

      /* Rotate about z-axis */
      maths_rotaz(cosp, sinp, pp, posout);

      /* Get central coordinates */
      posin[0] = rpm -> modpar[PXPOS*rpm -> nr+j];
      posin[1] = rpm -> modpar[PYPOS*rpm -> nr+j];
      posin[2] = rpm -> modpar[PVSYS*rpm -> nr+j];
      globtointern(posin, pp, hdr);

      /* Add central coordinates */
      posout[0] = posout[0]+pp[0];
      posout[1] = posout[1]+pp[1];
      posout[2] = pp[2];

      /* Change into user coordinates */
      interntoglob(posout, pp, hdr);

      /* Print */
      fprintf(stream, "%+.12E ", pp[0]);
      fprintf(stream, "%+.12E ", pp[1]);

      /* Receding Maximum Velocity */
      posin[0] = dparamtointern(rpm -> modpar[PRADI*rpm -> nr+j], RADI, hdr);;
      posin[1] = 0;
      posin[2] = 0;

      /* Velocity will not be regarded*/

      /* Rotate about x-axis */
      maths_rotax(cosi, sini, posin, pp);

      /* Rotate about z-axis */
      maths_rotaz(cosp, sinp, pp, posout);

      /* Get central coordinates */
      posin[0] = rpm -> modpar[PXPOS*rpm -> nr+j];
      posin[1] = rpm -> modpar[PYPOS*rpm -> nr+j];
      posin[2] = rpm -> modpar[PVSYS*rpm -> nr+j];
      globtointern(posin, pp, hdr);

      /* Add central coordinates */
      posout[0] = posout[0]+pp[0];
      posout[1] = posout[1]+pp[1];
      posout[2] = pp[2];

      /* Change into user coordinates */
      interntoglob(posout, pp, hdr);

      /* Print */
      fprintf(stream, "%+.12E ", pp[0]);
      fprintf(stream, "%+.12E ", pp[1]);

      fprintf(stream, "\n  ");
    }
  fclose(stream);

  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Make a qfits header suitable for coolgal output */
static qfits_header *makecoolhdr(hdrinf *hdr, double beamsizeindeg) 
{
  char key[9], value[21];
  int j;
  fint level = 0;
  fint err = 0;
  int sizez;
  qfits_header *header = NULL;

  /* The bitpix is -32 */
  if (!(header = ftsout_putcard(header, "BITPIX","-32"))) 
    goto error;

  /* The number of axes is set to three */
  if (!ftsout_putcard(header, "NAXIS","3")) 
    goto error;

  /* Now get the axis numbers */
  sprintf(value, "%i", hdr -> bsize1);
  if (!ftsout_putcard(header, "NAXIS1",value))
    goto error;
  sprintf(value, "%i", hdr -> bsize2);
  if (!ftsout_putcard(header, "NAXIS2",value))
    goto error;

  /* The third axis is simply the maximum spatial size */
  sprintf(value, "%i", sizez = (hdr -> bsize2 > hdr -> bsize1)?hdr -> bsize2:hdr -> bsize1);
  if (!ftsout_putcard(header, "NAXIS3",value))
    goto error;

  /* May contain an extension */
  if (!ftsout_putcard(header, "EXTEND","T"))
    goto error;
  
  /* These are clear */
  if (!ftsout_putcard(header, "BSCALE","1"))
    goto error;
  if (!ftsout_putcard(header, "BZERO","0"))
    goto error;

  /* The bunit is Jy*km/s/beam, while this is the 3d beam */
  if (!ftsout_putcard(header, "BUNIT","'JY*(KM/S)/BEAM'"))
    goto error;

  /* The cdelt is taken from the hdr struct, this should be ok with the unit being DEGREE*/  
  sprintf(value, "%.12E", hdr -> userglobcdelt[0]);
  if (!ftsout_putcard(header, "CDELT1", value))
    goto error;

  /* The crpix is copied from the header of the inset */
  sprintf(value, "%.12E", hdr -> setcrpix[0]);
  if (!ftsout_putcard(header, "CRPIX1", value))
    goto error;

  /* The crval in user units -> degree */
  sprintf(value, "%.12E", hdr -> userglobcrval[0]);
  if (!ftsout_putcard(header, "CRVAL1", value))
    goto error;

  /* This is nasty, because we have to re-read the info */
  sprintf(key, "CTYPE%i", hdr -> inaxperm[0]);
  for (j = 0; j < 20; ++j)
    value[j] = ' ';
  value[20] = '\0';
  gdsd_rchar_c(tofchar(hdr -> inset), tofchar(key), &(level), tofchar(value), &err);
  if (!ftsout_putcard(header, "CTYPE1", value))
    goto error;
  if (!ftsout_putcard(header, "CUNIT1", "'DEGREE            '"))
    goto error;
  
  /* The cdelt is taken from the hdr struct, this should be ok with the unit being DEGREE*/  
  sprintf(value, "%.12E", hdr -> userglobcdelt[1]);
  if (!ftsout_putcard(header, "CDELT2", value))
    goto error;

  /* The crpix is copied from the header of the inset */
  sprintf(value, "%.12E", hdr -> setcrpix[1]);
  if (!ftsout_putcard(header, "CRPIX2", value))
    goto error;

  /* The crval in user units -> degree */
  sprintf(value, "%.12E", hdr -> userglobcrval[1]);
  if (!ftsout_putcard(header, "CRVAL2", value))
    goto error;

  /* This is nasty, because we have to re-read the info */
  sprintf(key, "CTYPE%i", hdr -> inaxperm[1]);
  for (j = 0; j < 20; ++j)
    value[j] = ' ';
  value[20] = '\0';
  gdsd_rchar_c(tofchar(hdr -> inset), tofchar(key), &(level), tofchar(value), &err);
  if (!ftsout_putcard(header, "CTYPE2", value))
    goto error;
  if (!ftsout_putcard(header, "CUNIT2", "'DEGREE            '"))
    goto error;

  /* The third axis is the artificial one */

  /* The cdelt is copied from the inset */
  sprintf(value, "%.12E", fabs(hdr -> userglobcdelt[0]));
  if (!ftsout_putcard(header, "CDELT3", value))
    goto error;

  /* crpix is in the middle */
  sprintf(value, "%.12E", ((double) sizez)/2.0);
  if (!ftsout_putcard(header, "CRPIX3", value))
    goto error;

  /* This is exactly 0 */
  if (!ftsout_putcard(header, "CRVAL3", "0.0"))
    goto error;

  /* The type is somthing without projection, this should do */
  if (!ftsout_putcard(header, "CTYPE3", "'ANGLE             '"))
    goto error;

  /* This is DEGREE again */
  if (!ftsout_putcard(header, "CUNIT3", "'DEGREE            '"))
    goto error;

  /* Fourth axis is velocity, one pixel with the width of the whole cube to give plotting programs an orientation */
/*   if (!ftsout_putcard(header, "CDELT4", "1.0")) */
/*     goto error; */
/*   if (!ftsout_putcard(header, "CRPIX4", "1.0")) */
/*     goto error; */
/*   if (!ftsout_putcard(header, "CRVAL4", "0.0")) */
/*     goto error; */
/*   if (!ftsout_putcard(header, "CTYPE4", "' '")) */
/*     goto error; */
/*   if (!ftsout_putcard(header, "CUNIT4", "'Y'")) */
/*     goto error; */

/* Now we just put the beam properties, symmetric beam */
  sprintf(value, "%.12E", beamsizeindeg);
  if (!ftsout_putcard(header, "BMAJ", value))
    goto error;
  sprintf(value, "%.12E", beamsizeindeg);
  if (!ftsout_putcard(header, "BMIN", value))
    goto error;
  if (!ftsout_putcard(header, "BPA", "0"))
    goto error;

  return header;
  
 error:
  if ((header)) 
    ftsout_header_destroy(header);
  header = NULL;
  return header;
}

/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Produces a 3d fits image of the model */
static int coolgal(loginf *log, hdrinf *hdr, ringparms *rpm)
{
  int i;
  char coolname[21];
  char mes[81];
  fint def;
  fint nel;
  int err;
  qfits_header *header;
  Cube thecube;
  double beam;
  float *expfcs;
  float sincosofangle[2];
    
  /* First check if the user wants a coolgal output */
  sprintf(mes, "Give cool name.");
  sprintf(coolname, "                  ");
  def = 2;
  nel = 1;
  
  userchar_c(tofchar(coolname), &nel, &def, tofchar("COOLGAL="), tofchar(mes));
  termsinglestr(coolname);
  
  /* The default is to do nothing */
  if (*coolname == '\0')
    return 1;
  
  /* Now ask if the user wants a specific kind of beam, the default being the max beam */
  sprintf(mes, "Give 3d beam size (arcsec)");
  beam = hdr -> deltgridtouser[0]*((double) hdr -> bmaj);
  def = 2;
  nel = 1;
  err = 1;
  while((err)) {
    userdble_c(&beam, &nel, &def, tofchar("COOLBEAM="), tofchar(mes));
    if (beam >= 0.0) {
      err = 0;
    }
    else {
      sprintf(mes, "COOLBEAM should be >= 0");
      cancel_c(tofchar("COOLBEAM"));
      beam = hdr -> deltgridtouser[0]*((double) hdr -> bmaj);
      def = 1;
    }
  } 
  
  /* Transfer the beam into deg */
  beam = hdr -> globgridtouser[0]*beam/hdr -> deltgridtouser[0];
  
  /* Make a header, if the beam is 0, we normalise everything such that the units get right */
  if (!(header = makecoolhdr(hdr, ((beam))?beam:sqrt(TWOPI)/(hdr -> globgridtouser[0]*0.42466090014401))))
    return 1;
  
  /* Transfer the beam back to grid units */
  beam = beam/hdr -> globgridtouser[0];
    
  /* Now arrange the cube */
  thecube.refpix_x = 0;
  thecube.refpix_y = 0;
  thecube.refpix_v = 0;
  thecube.size_x = hdr -> bsize1;
  thecube.size_y = hdr -> bsize2;
  thecube.size_v = (thecube.size_x > thecube.size_y)?thecube.size_x:thecube.size_y;
  thecube.scale = 1.0;
  thecube.padding = 0;
  
  /* After that, we can deallocate to get some memory, but first I try
     not to do so and see how that works. */
  
  /* Next, get the parameters into par */
  if ((log -> logname) && !(log -> logpres)) {
  /* We read in the values, this should be possible and make sense */ 
  ftstab_get_grid_(log -> outarray);

  for (i = 0; i < rpm -> nur*NPARAMS+NSPARAMS; ++i)
    rpm -> par[i] = log -> outarray[i];

  /*     Convert the read parameter list to internal units */
  changetointern(rpm -> par, rpm -> nur, hdr);
  }

  /* Now we allocate the cube, not caring for the padding, this will be done automatically */
  if (!(thecube.points = (float *) malloc(thecube.size_x*thecube.size_y*thecube.size_v*sizeof(float)))) {
    ftsout_header_destroy(header);
    return 1;
  }
  
  /* Make the cube */
  makecoolpoints(&thecube, hdr, rpm);
  
  /* Convolve it */
  sincosofangle[0] = 0;
  sincosofangle[1] = 1;
  
  if (!(expfcs = expofacsfft(0.42466090014401*beam, 0.42466090014401*beam, 0.42466090014401*beam, sincosofangle))) {
    ftsout_header_destroy(header);
    free(thecube.points);
    return 1;
  }
  
  /* Now, the normalisation is the fifth factor, we multiply it with this */
  expfcs[4] = expfcs[4]*sqrtf(TWOPI)*0.42466090014401*beam;

  /* This is the actual convolution */
  if ((beam))
    convolgaussfft(&thecube, expfcs);

  /* Output it */
  ftsout_writecube(coolname, &thecube, header);

  /* Deallocate everything */
    ftsout_header_destroy(header);
    free(thecube.points);
    free(expfcs);

  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Makes a 3d pointsource model and packs in on cube */
static int makecoolpoints(Cube *cube, hdrinf *hdr, ringparms *rpm)
{
  int i,j,k;
  float ringflux; /* Total flux of a subring */
  int nc; /* Cloudnumber of a subring */
  float cfluxcorr; /* The correct flux of a pointsource */
  float sininc;
  float cosinc;
  float sinpa;
  float cospa;
  float r; /* A radius */
  float az; /* Azimuth of pointsource */
  float cosaz; /* The cosine of the az (memory wasting) */
  float sinaz; /* The sine of the az (memory wasting) */
  float x,y,z/*,vx,vy,vz*/; /* Cartesian coordinates */
  /*   double xp,yp,zp,vxp,vyp,vzp; Cartesian coordinates  */
  fint grid[3]; /* Grid positions */
  int totflux = 0;
  float z0; /* The central plane for the z */

  z0 = ((float) cube -> size_v)/2;

  interpover(rpm, rpm -> radsep, 0, NULL);
  
  /* Initialise the model array */
  cuberase(cube); 
  
  /* Do all the loops */
  for (i = 0; i < rpm -> nr; ++i) {
    
    /* Calculate the ringflux */
    ringflux = TWOPI*rpm -> modpar[PRADI*rpm -> nr+i]*rpm -> radsep*rpm -> modpar[PSBR*rpm -> nr+i];
    /* Calculate the cloudnumber, rounded down */
    nc = (int) (ringflux/rpm -> cflux);
    
    
    /* We decide to change the cloudflux a bit instead of accepting an error in the ringflux */
    cfluxcorr = ringflux/nc;
    if (nc > 0) {
      
      /* We calculate cos's and sins and reset the random number generator */
      sininc=sinf(rpm -> modpar[PINCL*rpm -> nr+i]);
      cosinc=cosf(rpm -> modpar[PINCL*rpm -> nr+i]);;
      sinpa=sinf(rpm -> modpar[PPA*rpm -> nr+i]);
      cospa=cosf(rpm -> modpar[PPA*rpm -> nr+i]);
      rpm -> iseed2[1] = i;
      maths_rndmf_init(rpm -> iseed2, rpm -> permrandstr);
      /* reset the  zprof */ 
      zprof(6, rpm -> permrandstr);
      
      /* now create the clouds and grid them */
      for (j = 0; j < nc; ++j) {
	
	/* The probability for the #radius is weighted by r, and this is no approximation */
	r = sqrtf((rpm -> modpar[PRADI*rpm -> nr+i]-0.5*rpm -> radsep)*(rpm -> modpar[PRADI*rpm -> nr+i]-0.5*rpm -> radsep)+2*rpm -> radsep*rpm -> modpar[PRADI*rpm -> nr+i]*maths_rndmf(rpm -> permrandstr));
	
	/* Azimuth is easy */
	az = TWOPI*maths_rndmf(rpm -> permrandstr);
	cosaz = cosf(az);
	sinaz = sinf(az);
	
	/* Now, these are the cartesian coordinates, if you look face-on at the ring in the system of the ring, x eastwards, y to the north, z along los from you to the source */
	/*       x = cosaz*r; */
	/*       y = sinaz*r; */
	/*       z = zprof(ltype)*modpar[PZ0*rpm -> nr+i]; */
	/*       vx = -sinaz*modpar[PVROT*rpm -> nr+i]; */
	/*       vy = cosaz*modpar[PVROT*rpm -> nr+i]; */
	/*       vz = 0; */
	
	/* Now, the whole system will be rotated about the x-axis with the amount of the inclination */
	/*       xp  = x; */
	/*       yp  = cosinc*y-sininc*z; */
	/*       zp  = sininc*y+cosinc*z; */
	/*       vxp = vx; */
	/*       vyp = cosinc*vy-sininc*vz; */
	/*       vzp = sininc*vy+cosinc*vz; */
	
	
	/*  Now we rotate about the z-axis with pa, because in this module the pa is defined as the angle with the minor axis */
	/*       x = xp*cos(-pa)-yp*sin(-pa)    or x = xp*cospa-yp*sinpa;      */
	/*       y = xp*sin(-pa)+yp*cos(-pa)    or y = xp*sinpa+yp*cospa;     */
	/*       z = zp;                        or z = zp;                     */         
	/*       vx = vxp*cos(-pa)-vyp*sin(-pa) or vx = vxp*cospa-vyp*sinpa;   */
	/*       vy = vxp*sin(-pa)+vyp*cos(-pa) or vy = vxp*sinpa+vyp*cospa;  */
	/*       vz = vzp;                      or vz = vzp;                   */
	
	z = zprof(rpm -> ltype, rpm -> permrandstr)*rpm -> modpar[PZ0*rpm -> nr+i];
	x = (cosaz*r)*cospa-(cosinc*(sinaz*r)-sininc*z)*sinpa; 
	y = (cosaz*r)*sinpa+(cosinc*(sinaz*r)-sininc*z)*cospa;
	/* Instead of vz this is the z component in the middle of the cube */
	z = sininc*sinaz*r+cosinc*z;
	/*  vz = (sininc*cosaz*rpm -> modpar[PVROT*rpm -> nr+i]); */
	
	/* of course we could make it even shorter, but we'll leave it at that. Next thingy is to grid the pointsource */
	grid[0] = roundnormal(rpm -> modpar[PXPOS*rpm -> nr+i]+x);
	
	if (grid[0] >= 0 && grid[0] < cube -> size_x) {
	  
	  grid[1] = roundnormal(rpm -> modpar[PYPOS*rpm -> nr+i]+y);
	  if (grid[1] >= 0 && grid[1] < cube -> size_y) {
	    /* For the sake of clearity, we kill the subsnuma operation in the source, in principle thus allowing only for the radio convention for velocity, but gaining an understanding of the code. What is seen here should not be done. It's really not what anyone should wish for. */
	    grid[2] = roundnormal((z0+z));
	    if (grid[2] >= 0 && grid[2] < cube -> size_v) {
	      ++totflux;
	      /* This is the position in the linear cube array */
	      k = grid[0]+ cube -> size_x*(grid[1]+cube -> size_y*grid[2]);
	      
	      cube -> points[k] = cube -> points[k]+cfluxcorr;
	    }
	  }
	}
      }
    }
  }

  /* We return the number of clouds */
  return totflux;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Produces one or two tirific logfiles containing the results */
static int tirout(loginf *log, ringparms *rpm, int nrplts)
{
  int i, j, k, l, m;
  int def = 2;
  int nel = 1;
  int acc;
  int len;
  char defname[21];
  char defintername[21];
  char key[9];
  char *currentname;
  char mes[81];
  FILE *stream;
  char input[VARYHSTRELES]; /* Has the length of the maximum input */
  char format[8];
  char format2[8];
  double *smarray = NULL;
  char inqstr[13];

  int nrings;
  int ringnr;
  double *radii = NULL;
  int givrad;
  double dpdr;

    /**************/
  /**************/
/*     fint obsint = 0; */
/*     char obsmes[80];  */
  /**************/

  /**************/
  /**************/
/*    sprintf(obsmes, "got here"); */
/*    anyout_c(&obsint, tofchar(obsmes));  */
  /**************/

  /* Initialise the input arrays */
  for (i = 0; i < 19; ++i) {
    defname[i] = ' ';
    defintername[i] = ' ';
  }
  defname[i] = '\0';
  defintername[i] = '\0';
  
  /* Ask the user what to do */
  sprintf(mes, "Give a .def file name for best results output");
  userchar_c(tofchar(defname), &nel, &def, tofchar("TIRDEF="), tofchar(mes));
  termsinglestr(defname);
  
  sprintf(mes, "Give a file name for smoothed results output");
  userchar_c(tofchar(defintername), &nel, &def, tofchar("TIRSMO="), tofchar(mes));
  termsinglestr(defintername);
  
  sprintf(mes, "Give accuracy of def file output [2]");
  i = 1;
  acc = 2;
  while ((i)) {
    userint_c(&acc, &nel, &def, tofchar("TIRACC="), tofchar(mes));
    if (acc < 1 || acc > 99) {
      sprintf(mes, "TIRACC: Must be larger than 0");
      def = 4;
      cancel_c(tofchar("TIRACC="));
    }
    else 
      --i;
  }
  
  if (*defintername != '\0') {
    sprintf(mes, "Give length of smoothing kernel [3]");
    i = 1;
    len = 3;
    while ((i)) {
      userint_c(&len, &nel, &def, tofchar("TIRLEN="), tofchar(mes));
      if (len < 1 || len > 99) {
	sprintf(mes, "TIRLEN: Must be larger than 0");
	def = 4;
	cancel_c(tofchar("TIRLEN="));
      }
      else 
	--i;
    }
    
    /* Allocate the array for smoothing */
    if (!(smarray = (double *) malloc(len*sizeof(double))))
      goto error;
  }

  /* Query the number of rings */
  sprintf(mes, "Give number of rings [%i]", rpm -> nur);
  i = 1;
  def = 2;
  nel = 1;
  nrings = rpm -> nur;
  while ((i)) {
    userint_c(&nrings, &nel, &def, tofchar("TIRNR="), tofchar(mes));
    if (nrings < 2) {
      sprintf(mes, "TIRNR: Must be larger than 1");
      def = 4;
	cancel_c(tofchar("TIRNR="));
    }
    else 
      --i;
  }
  
  /* Now allocate the radius array */
  if (!(radii = (double *) malloc(nrings*sizeof(double))))
    goto error;
  
  /* We read all values into the outarray */
  ftstab_get_grid_(log -> outarray);

  /* BUGFIX: We copy that to the par array */
  for (i = 0; i < rpm -> nur*NPARAMS+NSPARAMS; ++i)
    rpm -> par[i] = log -> outarray[i];

  /* Now ask the user to give the radii */
  sprintf(mes, "Give radii");
  i = 1;
  def = 2;
  nel = nrings;

  while ((i)) {

    /* Fill it with the old values */
    for (ringnr = 0; (ringnr < nrings) && (ringnr < rpm -> nur); ++ringnr) {
      radii[ringnr] = rpm -> par[PRADI*rpm -> nur+ringnr];
    }
    
    /* Fill the rest, extrapolating with the last stepwidth, this should work */
    while (ringnr < nrings) {
      radii[ringnr] = 2*radii[ringnr-1]-radii[ringnr-2];
      ++ringnr;
    }

    /* Check if we can interpolate */
    givrad = userdble_c(radii, &nel, &def, tofchar("TIRRAD="), tofchar(mes));
    if ((givrad < 2) && (givrad != 0)) {
      sprintf(mes, "TIRRAD: give more than 1 element");
      def = 4;
	cancel_c(tofchar("TIRRAD="));
    }
    else {

    /* Check the first radius */
      if (radii[0] != 0.0) {
	sprintf(mes, "TIRRAD: First radius has to be 0.0");
	def = 4;
	cancel_c(tofchar("TIRRAD="));
      }
      else {

	/* Extrapolate */
	if ((givrad))
	  while (givrad < nrings) {
	    radii[givrad] = 2*radii[givrad-1]-radii[givrad-2];
	    ++givrad;
	}

	/* Check if the radii are in ascending order */
	for (ringnr = 1; ringnr < nrings; ++ringnr) {
	  if (radii[ringnr] <= radii[ringnr-1]) {
	    i = 2;
	    break;
	  }
	}
	if (i == 2) {
	  sprintf(mes, "TIRRAD: Radii must be in ascending order %i %f %f %f", ringnr, radii[ringnr], radii[ringnr-1], radii[ringnr-2]);
	  def = 4;
	  i = 1;
	  cancel_c(tofchar("TIRRAD="));
	}
	else
	i = 0;
      }
    }
  }
  


  /* Now we should have a proper array with radii */


  /* Construct the format strings, a bit tricky */
  *format = '%';
  sprintf(format+1, "+.%iE", acc);
  if (acc > 9)
    sprintf(format+6, " ");
  else 
    sprintf(format+5, " ");
  *format2 = '%';
  sprintf(format2+1, "+.%iE", acc+3);
  if (acc > 6)
    sprintf(format2+6, " ");
  else 
    sprintf(format2+5, " ");
  
  i = 0;
  currentname = defname;
  while (i < 2) {
    
    if (*currentname != '\0') {
      
      /* Try to open the output, we overwrite */
      if (!(stream = fopen(currentname, "w")))
	goto error;
      
      /* Now put the first line, copy from input */
      tirout_a(stream, "LOGNAME=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "INSET=", input);
      tirout_a(stream, "BOX=", input);
      tirout_a(stream, "OUTSET= ", input);
      tirout_a(stream, "OUTCUBUP= ", input);
      fprintf(stream, "\n");
      tirout_a(stream, "OKAY=", input);
      tirout_a(stream, "TEXTLOG=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "BMIN=", input);
      tirout_a(stream, "BMAJ=", input);
      tirout_a(stream, "BPA=", input);
      tirout_a(stream, "RMS=", input);
      fprintf(stream, "\n");
      fprintf(stream, "NUR= %i", nrings);
      fprintf(stream, "\n");
 
      /* Now it depends on the file we are outputting */
      if (currentname == defname) {
	for (j = 0; j < NPARAMS; ++j) {
	  
	  /* Put the title */
	  ftstab_putcoltitl(key, j+1);
	  fprintf(stream, "%8s= ", key);
	  if (j == PXPOS || j == PYPOS) {
	    for (m = 0; m < nrings; ++m) {

	      /* Search the first radius that is greater than the current, don't care about efficiency */
	      for (k = 1; k < rpm -> nur; ++k) {
		if (radii[m] < rpm -> par[PRADI*rpm -> nur+k])
		  break;
	      }

	      /* Now we can interpolate or extrapolate */
	      /* Check for radius here */
	      if (k < rpm -> nur) {
		dpdr = (rpm -> par[j*rpm -> nur+k]-rpm -> par[j*rpm -> nur+k-1])/(rpm -> par[PRADI*rpm -> nur+k]-rpm -> par[PRADI*rpm -> nur+k-1]);
	      }
	      else {
		  dpdr = 0;
	      }

	      fprintf(stream, format2, log -> outarray[j*rpm -> nur+k-1]+dpdr*(radii[m]-rpm -> par[PRADI*rpm -> nur+k-1]));
	    }
	  }
	  else {
	    for (m = 0; m < nrings; ++m) {

	      /* Search the first radius that is greater than the current, don't care about efficiency */
	      for (k = 1; k < rpm -> nur; ++k) {
		if (radii[m] < rpm -> par[PRADI*rpm -> nur+k])
		  break;
	      }

	      /* Now we can interpolate or extrapolate */
	      /* Check for radius here */
	      if (k < rpm -> nur) {
		dpdr = (rpm -> par[j*rpm -> nur+k]-rpm -> par[j*rpm -> nur+k-1])/(rpm -> par[PRADI*rpm -> nur+k]-rpm -> par[PRADI*rpm -> nur+k-1]);
	      }
	      else {
		if (j == PRADI)
		  dpdr = 1;
		else
		  dpdr = 0;
	      }
	      fprintf(stream, format, log -> outarray[j*rpm -> nur+k-1]+dpdr*(radii[m]-rpm -> par[PRADI*rpm -> nur+k-1]));
	    }
	  }

	  fprintf(stream, "\n");
	}
	
	for (j = 0; j < NSPARAMS; ++j) {
	  ftstab_putcoltitl(key, NPARAMS+j+1);
	  fprintf(stream, "%8s= ", key);
	  fprintf(stream, format, log -> outarray[NPARAMS*rpm -> nur+j]);
	}
      }
      else {
	/* Here, we have to filter */
	for (j = 0; j < NPARAMS; ++j) {
	  
	  /* Put the title */
	  ftstab_putcoltitl(key, j+1);
	  fprintf(stream, "%8s= ", key);
	  
	  for (k = 0; k < rpm -> nur; ++k) {
	    for (l = 0; l < len; ++l) {
	      /* if we exceed the ringnumbers, we take in the values at
		 the border */
	      if ((k+l-(len-1)/2) < 0)
		smarray[l] = log -> outarray[j*rpm -> nur];
	      else if ((k+l-(len-1)/2) > rpm -> nur - 1)
		smarray[l] = log -> outarray[(j+1)*rpm -> nur-1];
	      else
		smarray[l] = log -> outarray[j*rpm -> nur+k+l-(len-1)/2];
	    }
	    
	    /* Sort the array */
	    bubble(smarray, len);
	    
	    if (j == PXPOS || j == PYPOS)
		fprintf(stream, format2, smarray[(len-1)/2]);
	    else
	      fprintf(stream, format, smarray[(len-1)/2]);
	  }
	  fprintf(stream, "\n");
	}
	
	for (j = 0; j < NSPARAMS; ++j) {
	  ftstab_putcoltitl(key, NPARAMS+j+1);
	  fprintf(stream, "%8s= ", key);
	  fprintf(stream, format, log -> outarray[NPARAMS*rpm -> nur+j]);
	}
	
	/* We don't needd the smarray anymore */
	free(smarray);
      }
      fprintf(stream, "\n");
      tirout_a(stream, "LTYPE=", input);

      /* Now put the rest of the input to the file */
      fprintf(stream, "\n");
      tirout_a(stream, "CFLUX=", input);
      tirout_a(stream, "PENALTY=", input);
      tirout_a(stream, "WEIGHT=", input);
      tirout_a(stream, "RADSEP=", input);
      tirout_a(stream, "MEMMODE=", input);
      tirout_a(stream, "INIMODE=", input);
      tirout_a(stream, "ISEED2=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "FITMODE=", input);
      tirout_a(stream, "LOOPS=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "ANSTART=", input);
      tirout_a(stream, "ANEND=", input);
      tirout_a(stream, "ANSTEPS=", input);
      tirout_a(stream, "ISEED=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "VARYMULT=", input);
      tirout_a(stream, "VARYSING= ", input);
      tirout_a(stream, "PARMAX=", input);
      tirout_a(stream, "PARMIN=", input);
      tirout_a(stream, "MODERATE=", input);
      tirout_a(stream, "DELSTART=", input);
      tirout_a(stream, "DELEND=", input);
      tirout_a(stream, "ITESTART=", input);
      tirout_a(stream, "ITEEND=", input);
      tirout_a(stream, "SATDELT=", input);
      tirout_a(stream, "MINDELTA=", input);
      tirout_a(stream, "TABLE=", input);
      tirout_a(stream, "DISTANCE=", input);
      tirout_a(stream, "REFRING=", input);
      tirout_a(stream, "BIGTABLE=", input);
      tirout_a(stream, "FRACTION=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "TIRDEF=", input);
      tirout_a(stream, "TIRSMO=", input);
      tirout_a(stream, "TIRACC=", input);
      tirout_a(stream, "TIRLEN=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "HISNAME=", input);
      tirout_a(stream, "HISTARTROW=", input);
      tirout_a(stream, "HISTENDROW=", input);
      tirout_a(stream, "HISKEY1=", input);
      tirout_a(stream, "HISRING1=", input);
      tirout_a(stream, "HISMIN1=", input);
      tirout_a(stream, "HISMAX1=", input);
      tirout_a(stream, "HISBINS1=", input);
      tirout_a(stream, "HISDELTA1=", input);
      tirout_a(stream, "HISKEY2=", input);
      tirout_a(stream, "HISRING2=", input);
      tirout_a(stream, "HISMIN2=", input);
      tirout_a(stream, "HISMAX2=", input);
      tirout_a(stream, "HISBINS2=", input);
      tirout_a(stream, "HISDELTA2=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "COOLGAL=", input);
      tirout_a(stream, "COOLBEAM=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "RECT=", input);
      tirout_a(stream, "BIGRECT=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "TILT=", input);
      tirout_a(stream, "BIGTILT=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "INCLINO=", input);   
      tirout_a(stream, "IN_REFINE=", input);
      fprintf(stream, "\n");
      tirout_a(stream, "GR_DEVICE=", input);
      tirout_a(stream, "GR_MR=", input);
      tirout_a(stream, "GR_ML=", input);
      tirout_a(stream, "GR_TXHT=", input);
      tirout_a(stream, "GR_SBHT=", input);
      tirout_a(stream, "GR_LGND=", input);
      tirout_a(stream, "GR_SBRP=", input);
      tirout_a(stream, "GR_PARMS=", input);
      tirout_a(stream, "GR_XMIN=", input);
      tirout_a(stream, "GR_XMAX=", input);

      for (j = 1; j <= nrplts; ++j) {
	fprintf(stream, "\n");
	sprintf(inqstr, "GR_COL_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_LINES_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_ERRB_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_YMIN_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_YMAX_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_NPAD_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_XPAD_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_YPAD_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_ERAD_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_EBAD_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_COAD_%i=", j);
	tirout_a(stream, inqstr, input);
	sprintf(inqstr, "GR_LIAD_%i=", j);
	tirout_a(stream, inqstr, input);
      }
      fclose(stream);
    }
    currentname = defintername;
    ++i;
  }

  free(radii);
  return 1;
  
 error:
  if (smarray)
    free(smarray);
  if ((radii))
    free(radii);
  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Copies a part of the gipsy input to a stream */
static void tirout_a(FILE *stream, char *keyword, char *input)
{
  int def = 2;
  int length;
  char mes[2];
  int i;

  sprintf(mes, "A");

  /* Initialise */
  {
    for (i = 0; i < VARYHSTRELES-2; ++i) {
      input[i] = ' ';
    }
    input[i] = '\0';
    
    /* Get the value */
    length = usertext_c(tofchar(input), &def, tofchar(keyword),tofchar(mes));
    input[length] = '\0';
    
    /* Copy it into the file */
    fprintf(stream, "%s %s\n", keyword, input);
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Inefficiently sorts the input arry */
static void bubble(double *array, long length)
{
  char satisfied = 1;
  double holder;
  long i;
  while (satisfied) {
    satisfied = 0;
    for (i = 0; i < length - 1; ++i) {
      if (array[i] > array[i+1]) {
	holder = array[i+1];
	array[i+1] = array[i];
	array[i] = holder;
	satisfied = 1;
      }
    }
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Produces the histogram output of tirific */
static int histout(ringparms *rpm)
{
  int i;

  int def = 2;
  int nel = 1;
  char mes[81];
  int err;

  char key1[9];
  int keyident1;
  char key2[9];
  int keyident2;
  int ring1;
  int ring2;

  char filename[21];
  int startrow;
  int endrow;
  int column1;
  double min1;
  double max1;
  int bins1;
  double delta1;
  int column2;
  double min2;
  double max2;
  int bins2;
  double delta2;

  /* Get the filename */

  /* Initialise the input array */
  for (i = 0; i < 19; ++i) {
    filename[i] = ' ';
  }
  filename[i] = '\0';

  nel = 1;
  def = 2;

  sprintf(mes, "Give a filename for a histogram");
  userchar_c(tofchar(filename), &nel, &def, tofchar("HISNAME="), tofchar(mes));
  termsinglestr(filename);

  /* If there is no input, we finish here */
  if (*filename == '\0')
    return 1;

  /* Check the first keyword */

  /* Initialise the keyword array, per default this is vrot, but we check later */
  sprintf(mes, "Give first keyword for histogram");
  sprintf(key1, "        ");
  nel = 1;
  def = 2;
  err = 1;
  while (err) {
    userchar_c(tofchar(key1), &nel, &def, tofchar("HISKEY1="), tofchar(mes));
    termsinglestr(key1);
    if ((keyident1 = ftstab_gtitln_(key1)) >= 1) {
      if (keyident1 <= NPARAMS+NSPARAMS)
	break;
      else if (keyident1 > NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI)
	break;
    }
    
    sprintf(mes, "HISKEY1: Invalid keyword");
    cancel_c(tofchar("HISKEY1="));
    def = 4;
  }

  /* Check the ringnumber */
  if (keyident1 <= NPARAMS+NSPARAMS) {
  sprintf(mes, "Give ringnumber 1 for histogram [1]");
  ring1 = 1;
  err = 1;
  def = 2;
  while (err) {
    userint_c(&ring1, &nel, &def, tofchar("HISRING1="), tofchar(mes));
    if (ring1 < 1 || ring1 > rpm -> nur) {
      sprintf(mes, "HISRING1: Out of range");
      cancel_c(tofchar("HISRING1="));
      def = 4;
    }
    else 
      err = 0;
  }
  }
  else
    ring1 = 1;

  /* Check the column number */
  if (keyident1 <= NPARAMS+NSPARAMS)
    column1 = (keyident1-1)*rpm -> nur+ring1-1;
  else
    column1 = NPARAMS*rpm -> nur+NSPARAMS+keyident1-(NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI);

  /* Check the second keyword, by default empty */
  sprintf(mes, "Give second keyword for histogram");
  sprintf(key2, "        ");
  nel = 1;
  def = 2;
  userchar_c(tofchar(key2), &nel, &def, tofchar("HISKEY2="), tofchar(mes));
  termsinglestr(key2);
  keyident2 = ftstab_gtitln_(key2);
  if (keyident2 > NPARAMS+NSPARAMS) {
    if (keyident2 <= NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI)
      keyident2 = -1;
  }

  if (keyident2 > 0 && keyident2 <= NPARAMS+NSPARAMS) {
    /* Check the ringnumber */
    sprintf(mes, "Give ringnumber 2 for histogram [1]");
    ring2 = 1;
    err = 1;
    def = 2;
    while (err) {
      userint_c(&ring1, &nel, &def, tofchar("HISRING2="), tofchar(mes));
      if (ring2 < 1 || ring2 > rpm -> nur) {
	sprintf(mes, "HISRING2: Out of range");
	cancel_c(tofchar("HISRING2="));
	def = 4;
      }
      else
	err = 0;
    }
  }

  /* Check the column number */
  if (keyident2 <= NPARAMS+NSPARAMS)
    column2 = (keyident2-1)*rpm -> nur+ring2-1;
  else
    column2 = NPARAMS*rpm -> nur+NSPARAMS+keyident2-(NPARAMS+NSPARAMS+PRIMHDN_SINGLE+SECHDN_MULTI);

  /* Check the startrow, by default this is 1 */
  sprintf(mes, "Give start row for histogram");
  startrow = 1;
  err = 1;
  def = 2;
  while (err) {
    userint_c(&startrow, &nel, &def, tofchar("HISTART="), tofchar(mes));
    if (startrow < 0 || startrow > ftstab_get_rownr_()-1) {
      sprintf(mes, "STARTROW: Out of range");
      cancel_c(tofchar("HISTART="));
      def = 4;
    }
    else
      err = 0;
  }

  /* Check the endrow, per default the end */
  sprintf(mes, "Give end row for histogram");
  endrow = ftstab_get_rownr_()-1;
  err = 1;
  def = 2;
  while (err) {
    userint_c(&endrow, &nel, &def, tofchar("HISTEND="), tofchar(mes));
    if (endrow < startrow || endrow > ftstab_get_rownr_()-1) {
      sprintf(mes, "ENDROW: Out of range");
      cancel_c(tofchar("HISTEND="));
      def = 4;
    }
    else
      err = 0;
  }

  ++endrow;
  ++startrow;

  /* Check the mins and maxs */
  def = 2;
  sprintf(mes, "Give minimum of key 1 for histogram");
  min1 = 1.0;
  userdble_c(&min1, &nel, &def, tofchar("HISMIN1="), tofchar(mes));
  sprintf(mes, "Give maximum of key 1 for histogram");
  max1 = -1.0;
  userdble_c(&max1, &nel, &def, tofchar("HISMAX1="), tofchar(mes));
  sprintf(mes, "Give minimum of key 2 for histogram");
  min2 = 1.0;
  userdble_c(&min2, &nel, &def, tofchar("HISMIN2="), tofchar(mes));
  sprintf(mes, "Give maximum of key 2 for histogram");
  max2 = -1.0;
  userdble_c(&max2, &nel, &def, tofchar("HISMAX2="), tofchar(mes));

  /* Check the bins of key 1*/
  def = 2;
  err = 1;
  bins1 = 100;
  sprintf(mes, "Give number of bins for key 1 of histogram [100]");
  while (err) {
    userint_c(&bins1, &nel, &def, tofchar("HISBINS1="), tofchar(mes));
    if (bins1 < 0) {
      sprintf(mes, "HISBINS1: Must be >= 0");
      cancel_c(tofchar("HISBINS1="));
      def = 4;
    }
    else
      err = 0;
  }

  /* Check whether an input of delta 1 is needed */
  def = 2;
  err = 1;
  delta1 = 0.1;
  sprintf(mes, "Give bin size for key 1 of histogram [0.1]");
  while (err) {
    userdble_c(&delta1, &nel, &def, tofchar("HISDELTA1="), tofchar(mes));
    if (bins1 == 0 || max1-min1 == 0.0) {
      if (delta1 < 0) {
	sprintf(mes, "HISDELTA1: Must be >= 0");
	cancel_c(tofchar("HISDELTA1="));
	def = 4;
      }
    }
    else
      err = 0;
  }

  def = 2;
  err = 1;
  bins2 = 100;
  sprintf(mes, "Give number of bins for key 2 of histogram [100]");
  while (err) {
    userint_c(&bins2, &nel, &def, tofchar("HISBINS2="), tofchar(mes));
    if (bins2 < 0) {
      sprintf(mes, "HISBINS2: Must be >= 0");
      cancel_c(tofchar("HISBINS2="));
      def = 4;
    }
    else
      err = 0;
  }

  /* Check whether an input of delta 1 is needed */
  def = 2;
  err = 1;
  delta2 = 0.1;
  sprintf(mes, "Give bin size for key 2 of histogram [0.1]");
  while (err) {
    userdble_c(&delta2, &nel, &def, tofchar("HISDELTA2="), tofchar(mes));
    if (bins2 == 0 || max2-min2 == 0.0) {
      if (delta2 < 0) {
	sprintf(mes, "HISDELTA2: Must be >= 0");
	cancel_c(tofchar("HISDELTA2="));
	def = 4;
      }
    }
    else
      err = 0;
  }

  /* This should do */
  if (keyident2 > 0) {
    if (!ftstab_histogram_2d(filename, startrow, endrow, column1, min1, max1, bins1, delta1, column2, min2, max2, bins2, delta2))
      return 0;
  }  
  else {
    if (!ftstab_histogram(filename, column1, startrow, endrow, min1, max1, bins1, delta1, 2))
      return 0;
  }

  /* We know that the file is not sorted at the end, so we sort back */
  ftstab_heapsort(NPARAMS*rpm -> nur+NSPARAMS+LOOPNR_TABNR-1, 1, ftstab_get_rownr_());

  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Produces the rectify output of tirific */
static int rectout(loginf *log, hdrinf *hdr, ringparms *rpm)
{
  int i,j;

  int def = 2;
  int nel = 1;
  char mes[81];

  char filename[21];
  FILE *stream;

  /* First ask for the small rectify */

  /* Initialise the input array */
  for (i = 0; i < 19; ++i) {
    filename[i] = ' ';
  }
  filename[i] = '\0';

  sprintf(mes, "Give a filename for rectify output");
  userchar_c(tofchar(filename), &nel, &def, tofchar("RECT="), tofchar(mes));
  termsinglestr(filename);

  /* If there is no input, we finish here */
  if (*filename != '\0') {

    /* Open the stream overwriting */
    if (!(stream = fopen(filename, "w")))
      goto error;

    /* Now write a skeleton */
    rectout_a(stream);

   /* We read all values into the outarray */
    ftstab_get_grid_(log -> outarray);

    /* Now we read the results into the par array without doing a conversion, central position from the first ring */
    fprintf(stream, "\nPOSITION= U %.12E U %.12E", log -> outarray[PXPOS*rpm -> nur]/hdr -> globsettouser[0], log -> outarray[PYPOS*rpm -> nur]/hdr -> globsettouser[1]);

   /* The radii are all but the first one */
    fprintf(stream, "\nRADII=       ");

    for (j = 1; j < rpm -> nur; ++j) 
      fprintf(stream, "%.12E ", log -> outarray[PRADI*rpm -> nur+j]);

    /* For the orientational parameters we interpolate */
    fprintf(stream, "\nPOSANG=      ");
    for (j = 1; j < rpm -> nur; ++j) 
      fprintf(stream, "%.12E ", (log -> outarray[PPA*rpm -> nur+j]+log -> outarray[PPA*rpm -> nur+j-1])/2-90);
    fprintf(stream, "\nINCLINATION= ");
    for (j = 1; j < rpm -> nur; ++j) 
      fprintf(stream, "%.12E ", (log -> outarray[PINCL*rpm -> nur+j]+log -> outarray[PINCL*rpm -> nur+j-1])/2);
    fprintf(stream, "\nZ0=          ");
    for (j = 1; j < rpm -> nur; ++j) 
      fprintf(stream, "%.12E ", (log -> outarray[PZ0*rpm -> nur+j]+log -> outarray[PZ0*rpm -> nur+j-1])/2);

    /* The last thing we can do is to put the type */
    fprintf(stream, "\nPROFILE=    %i", rpm -> ltype);

   /* Finish the skeleton */
    rectout_b(stream);

    fclose(stream);
  }

  /* Now ask for the big rectify */

  /* Initialise the input array */
  for (i = 0; i < 19; ++i) {
    filename[i] = ' ';
  }
  filename[i] = '\0';

  sprintf(mes, "Give a filename for a big rectfy output");
  userchar_c(tofchar(filename), &nel, &def, tofchar("BIGRECT="), tofchar(mes));
  termsinglestr(filename);

  /* If there is no input, we finish here */
  if (*filename != '\0') {

    /* Open the stream overwriting */
    if (!(stream = fopen(filename, "w")))
      goto error;

    /* Now write a skeleton */
    rectout_a(stream);

   /* Finish the skeleton, it is probably sensible to do that here */
    rectout_b(stream);

   /* We read all values into the par and interpolate over */
    ftstab_get_grid_(log -> outarray);
    for (j = 0; j < rpm -> nur*NPARAMS+NSPARAMS; ++j)
      rpm -> par[j] = log -> outarray[j];
    interpover(rpm, dinterntoparam(rpm -> radsep, RADI, hdr), 0, NULL);
 
   /* Now we read the results into the par array without doing a conversion, central position from the first ring */
    fprintf(stream, "\nPOSITION= U %.12E U %.12E", log -> outarray[PXPOS*rpm -> nur]/hdr -> globsettouser[0], log -> outarray[PYPOS*rpm -> nur]/hdr -> globsettouser[1]);

   /* The radii are all but the first one */
    fprintf(stream, "\nRADII=       ");

    for (j = 1; j < rpm -> nr; ++j) 
      fprintf(stream, "%.12E ", rpm -> modpar[PRADI*rpm -> nr+j]);

    /* For the orientational parameters we start with the first ring */
    fprintf(stream, "\nPOSANG=      ");
    for (j = 0; j < rpm -> nr; ++j) 
      fprintf(stream, "%.12E ", rpm -> modpar[PPA*rpm -> nr+j]-90);
    fprintf(stream, "\nINCLINATION= ");
    for (j = 0; j < rpm -> nr; ++j) 
      fprintf(stream, "%.12E ", rpm -> modpar[PINCL*rpm -> nr+j]);
    fprintf(stream, "\nZ0=          ");
    for (j = 0; j < rpm -> nr; ++j) 
      fprintf(stream, "%.12E ", rpm -> modpar[PZ0*rpm -> nr+j]);

    /* The last thing we can do is to put the type */
    fprintf(stream, "\nPROFILE=    %i", rpm -> ltype);

    fclose(stream);
  }

  return 1;

 error:
  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Output of fixed stuff to a file */
void rectout_a(FILE *stream)
{
  
  fprintf(stream, "INSET=  \n");
  fprintf(stream, "BOX=    \n");
  fprintf(stream, "OUTSET= \n");
  fprintf(stream, "PROSET= \n\n");
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Output of fixed stuff to a file */
void rectout_b(FILE *stream)
{
fprintf(stream, "SEGMENTS=  1\n");
fprintf(stream, "\n");
fprintf(stream, "ISEED=      \n");
fprintf(stream, "MAXCLOUDS=  \n");
fprintf(stream, "EQDENS=     \n");
fprintf(stream, "\n");
fprintf(stream, "GRDEVICE=   \n");
fprintf(stream, "MOSAIC=     \n");
fprintf(stream, "LINEWIDTH=  \n");
fprintf(stream, "RADPLOT=    \n");
fprintf(stream, "PLOTMODEL=  \n");
fprintf(stream, "MCPLOT=     \n");
fprintf(stream, "TRPLOT=     \n");
fprintf(stream, "DRPLOT=     \n");
fprintf(stream, "COMPVALS=   \n");
fprintf(stream, "\n");
fprintf(stream, "DISTANCE=   \n");
fprintf(stream, "RHO=        \n");
fprintf(stream, "THETA=      \n");
fprintf(stream, "PHI=        \n");
fprintf(stream, "REPEAT=     \n");
fprintf(stream, "\n");
fprintf(stream, "TABSET=     \n");
fprintf(stream, "TABNAME=    \n");
fprintf(stream, "PLOTSEG=    \n");
fprintf(stream, "\n");
fprintf(stream, "TABNAME=    \n");
fprintf(stream, "OVERTAB=    \n");
  return; 
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Produces the tiltogram output of tirific */
static int tiltout(loginf *log, hdrinf *hdr, ringparms *rpm)
{
  int i,j;

  int def = 2;
  int nel = 1;
  char mes[81];
  char filename[21];
  qfits_header *header = NULL;
  float *array = NULL;
  double nrefr[3];
  double nr[3];
  char value[21];

  /**************/
  /**************/
/*    fint obsint = 0; */
/*    char obsmes[80]; */
  /**************/

  /**************/
  /**************/
/*    sprintf(obsmes, "got here"); */
/*    anyout_c(&obsint, tofchar(obsmes));  */
  /**************/


  /* Initialise the input array */
  for (i = 0; i < 19; ++i) {
    filename[i] = ' ';
  }
  filename[i] = '\0';
  
  sprintf(mes, "Give a filename for a tiltogram output");
  userchar_c(tofchar(filename), &nel, &def, tofchar("TILT="), tofchar(mes));
  termsinglestr(filename);
  
  if (*filename != '\0') {
    
    if (rpm -> nur < 2)
      return 1;
    
    /* Read in the values */
    ftstab_get_grid_(log -> outarray);
    
    /* Make a header */
    /* The bitpix is -32 */
    if (!(header = ftsout_putcard(header, "BITPIX","-32"))) 
      goto error;
    
    /* The number of axes is set to three */
    if (!ftsout_putcard(header, "NAXIS","2")) 
      goto error;
    
    /* Now get the axis numbers */
    sprintf(value, "%i", rpm -> nur);
    if (!ftsout_putcard(header, "NAXIS1",value))
      goto error;
    sprintf(value, "%i", rpm -> nur);
    if (!ftsout_putcard(header, "NAXIS2",value))
      goto error;
    
    /* May contain an extension */
    if (!ftsout_putcard(header, "EXTEND","T"))
      goto error;
    
    /* These are clear */
    if (!ftsout_putcard(header, "BSCALE","1"))
      goto error;
    if (!ftsout_putcard(header, "BZERO","0"))
      goto error;
    
    /* The bunit is Jy*km/s/beam, while this is the 3d beam */
    if (!ftsout_putcard(header, "BUNIT","'deg               '"))
      goto error;
    
    /* The cdelt is the difference between the first two rings */  
    sprintf(value, "%.12E", log -> outarray[PRADI*rpm -> nur+1]-log -> outarray[PRADI*rpm -> nur]);
    if (!ftsout_putcard(header, "CDELT1", value))
      goto error;
    
    /* The crpix is 1 */
    sprintf(value, "%.12E", 1.0);
    if (!ftsout_putcard(header, "CRPIX1", value))
      goto error;
    
    /* The crval in user units -> arcsec is 0 */
    sprintf(value, "%.12E", 0.0);
    if (!ftsout_putcard(header, "CRVAL1", value))
      goto error;
    
    /* ctype is angle ... */
    if (!ftsout_putcard(header, "CTYPE1", "'ANGLE   '"))
      goto error;
    if (!ftsout_putcard(header, "CUNIT1", "'arcsec            '"))
      goto error;
    
    /* The cdelt is the difference between the first two rings */  
    sprintf(value, "%.12E", log -> outarray[PRADI*rpm -> nur+1]-log -> outarray[PRADI*rpm -> nur]);
    if (!ftsout_putcard(header, "CDELT2", value))
      goto error;
    
    /* The crpix is 1 */
    sprintf(value, "%.12E", 1.0);
    if (!ftsout_putcard(header, "CRPIX2", value))
      goto error;
    
    /* The crval in user units -> arcsec is 0 */
    sprintf(value, "%.12E", 0.0);
    if (!ftsout_putcard(header, "CRVAL2", value))
      goto error;
    
    /* ctype is angle ... */
    if (!ftsout_putcard(header, "CTYPE2", "'ANGLE   '"))
      goto error;
    if (!ftsout_putcard(header, "CUNIT2", "'arcsec            '"))
      goto error;
    
    /* After that allocate the memory */
    if (!(array = (float *) malloc(rpm -> nur*rpm -> nur*sizeof(float))))
      goto error;
    
    /* Convert to internal units (radian) */
    for (i = 0; i < NPARAMS*rpm -> nur + NSPARAMS; ++i) {
      rpm -> par[i] = log -> outarray[i];
    }
    changetointern(rpm -> par, rpm -> nur, hdr);

    /* Now fill the array */
    for (i = 0; i < rpm -> nur; ++i) {
      /* Now get the normal vector of the reference ring */
      nrefr[0] = sin(rpm -> par[PINCL*rpm -> nur+i])*sinf(rpm -> par[PPA*rpm -> nur+i]);
      nrefr[1] = -sin(rpm -> par[PINCL*rpm -> nur+i])*cosf(rpm -> par[PPA*rpm -> nur+i]);
      nrefr[2] = cos(rpm -> par[PINCL*rpm -> nur+i]);
      
      /* Now we read in the values */
      for (j = 0; j < rpm -> nur; ++j) {
	nr[0] = sin(rpm -> par[PINCL*rpm -> nur+j])*sinf(rpm -> par[PPA*rpm -> nur+j]);
	nr[1] = -sin(rpm -> par[PINCL*rpm -> nur+j])*cosf(rpm -> par[PPA*rpm -> nur+j]);
	nr[2] = cos(rpm -> par[PINCL*rpm -> nur+j]);

	/* This is the arcus */
	array[i+rpm -> nur*j] = (nr[0]*nrefr[0]+nr[1]*nrefr[1]+nr[2]*nrefr[2]) > 1?0.0:RADTODEG*acos(nr[0]*nrefr[0]+nr[1]*nrefr[1]+nr[2]*nrefr[2]);
      }
    }

    /* Put it to the disk */
    ftsout_writeimage(filename, array, header, rpm -> nur, rpm -> nur);

    /* Clear things */
    ftsout_header_destroy(header);
    free(array);
  }
  /* Initialise the input array */
  for (i = 0; i < 19; ++i) {
    filename[i] = ' ';
  }
  filename[i] = '\0';
  
  sprintf(mes, "Give a filename for a big tiltogram output");
  userchar_c(tofchar(filename), &nel, &def, tofchar("BIGTILT="), tofchar(mes));
  termsinglestr(filename);
  
  if (*filename != '\0') {
    
    if (rpm -> nr < 2)
      return 1;
    
    /* Make a header */
    /* The bitpix is -32 */
    header = NULL;

    if (!(header = ftsout_putcard(header, "BITPIX","-32"))) 
      goto error;
    
    /* The number of axes is set to three */
    if (!ftsout_putcard(header, "NAXIS","2")) 
      goto error;
    
    /* Now get the axis numbers */
    sprintf(value, "%i", rpm -> nr);
    if (!ftsout_putcard(header, "NAXIS1",value))
      goto error;
    sprintf(value, "%i", rpm -> nr);
    if (!ftsout_putcard(header, "NAXIS2",value))
      goto error;
    
    /* May contain an extension */
    if (!ftsout_putcard(header, "EXTEND","T"))
      goto error;
    
    /* These are clear */
    if (!ftsout_putcard(header, "BSCALE","1"))
      goto error;
    if (!ftsout_putcard(header, "BZERO","0"))
      goto error;
    
    /* The bunit is Jy*km/s/beam, while this is the 3d beam */
    if (!ftsout_putcard(header, "BUNIT","'deg     '"))
      goto error;
    
    /* The cdelt is the width of one ring */  
    sprintf(value, "%.12E", dinterntoparam(rpm -> radsep, RADI, hdr));
    if (!ftsout_putcard(header, "CDELT1", value))
      goto error;
    
    /* The crpix is 1 */
    sprintf(value, "%.12E", 1.0);
    if (!ftsout_putcard(header, "CRPIX1", value))
      goto error;
    
    /* The crval in user units -> arcsec is 1/2 radsep */
    sprintf(value, "%.12E", dinterntoparam(rpm -> radsep, RADI, hdr)/2);
    if (!ftsout_putcard(header, "CRVAL1", value))
      goto error;
    
    /* ctype is angle ... */
    if (!ftsout_putcard(header, "CTYPE1", "'ANGLE             '"))
      goto error;
    if (!ftsout_putcard(header, "CUNIT1", "'arcsec            '"))
      goto error;
    
    /* The cdelt is the width of one ring */  
    sprintf(value, "%.12E", dinterntoparam(rpm -> radsep, RADI, hdr));
    if (!ftsout_putcard(header, "CDELT2", value))
      goto error;
    
    /* The crpix is 1 */
    sprintf(value, "%.12E", 1.0);
    if (!ftsout_putcard(header, "CRPIX2", value))
      goto error;
    
    /* The crval in user units -> arcsec is 1/2 radsep */
    sprintf(value, "%.12E", dinterntoparam(rpm -> radsep, RADI, hdr)/2);
    if (!ftsout_putcard(header, "CRVAL2", value))
      goto error;
    
    /* ctype is angle ... */
    if (!ftsout_putcard(header, "CTYPE2", "'ANGLE             '"))
      goto error;
    if (!ftsout_putcard(header, "CUNIT2", "'arcsec            '"))
      goto error;
    
    /* After that allocate the memory */
    if (!(array = (float *) malloc(rpm -> nr*rpm -> nr*sizeof(float))))
      goto error;

    /* Read in the values */
    ftstab_get_grid_(log -> outarray);

    /* Convert to internal units (radian) */
    for (i = 0; i < NPARAMS*rpm -> nur + NSPARAMS; ++i) {
      rpm -> par[i] = log -> outarray[i];
    }
    changetointern(rpm -> par, rpm -> nur, hdr);
    interpover(rpm, rpm -> radsep, 0, NULL);

    /* Now fill the array */
    for (i = 0; i < rpm -> nr; ++i) {
      /* Now get the normal vector of the reference ring */
      nrefr[0] = sin(rpm -> modpar[PINCL*rpm -> nr+i])*sinf(rpm -> modpar[PPA*rpm -> nr+i]);
      nrefr[1] = -sin(rpm -> modpar[PINCL*rpm -> nr+i])*cosf(rpm -> modpar[PPA*rpm -> nr+i]);
      nrefr[2] = cos(rpm -> modpar[PINCL*rpm -> nr+i]);
      
      /* Now we read in the values */
      for (j = 0; j < rpm -> nr; ++j) {
	nr[0] = sin(rpm -> modpar[PINCL*rpm -> nr+j])*sinf(rpm -> modpar[PPA*rpm -> nr+j]);
	nr[1] = -sin(rpm -> modpar[PINCL*rpm -> nr+j])*cosf(rpm -> modpar[PPA*rpm -> nr+j]);
	nr[2] = cos(rpm -> modpar[PINCL*rpm -> nr+j]);

	/* This is the arcus */
	array[i+rpm -> nr*j] = (nr[0]*nrefr[0]+nr[1]*nrefr[1]+nr[2]*nrefr[2]) > 1?0.0:RADTODEG*acos(nr[0]*nrefr[0]+nr[1]*nrefr[1]+nr[2]*nrefr[2]);
      }
    }

    /* Put it to the disk */
    ftsout_writeimage(filename, array, header, rpm -> nr, rpm -> nr);

    /* Clear things */
    ftsout_header_destroy(header);
    free(array);
  }

  return 1;

 error:
  if ((header))
    ftsout_header_destroy(header);
  if ((array))
    free(array);
  return 0;
}

/* ------------------------------------------------------------ */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Produces the tip-lon output of tirific  */

static int briggsout(loginf *log, hdrinf *hdr, ringparms *rpm)
{  
  char mes[81];
  int j, ok, nel, def, dev;

  char br_device[21];
  double br_pa;
  float pa_float;
  double br_incl;
  double pa;
  double inc;
  int br_annr;
  float rmax;
  float *br_angl = NULL;

  int br_swdth;
  int br_cwdth;
  int br_lwdth;
  int br_col = 1;
  int br_refl;

  float *xarray = NULL;
  float *xlarray = NULL;
  float *yarray = NULL;
  float *ylarray = NULL;

  double nrefr[3];
  double rota[3];

  /**************/
   /**************/ 
    fint obsint = 0;  
    char obsmes[80];  
  /**************/
  /**************/
  /**************/
/* sprintf(obsmes, "graph: x: %.2f y: %.2f", x,y); */
/* anyout_c(&obsint, tofchar(obsmes)); */
  /**************/

  /* Keywords:
     BR_DEVICE= pgplot device
     BR_PA= position angle of reference ring
     BR_INCL= inclination of reference ring
     BR_ANNR= circles to plot
     BR_ANGL= circle radii in deg
     BR_SWDTH= dot width
     BR_CWDTH= circle width
     BR_LWDTH= line width
     BR_REFL= Plot reference line?
     BR_COL= Colour of dots and lines
  */


  /* Ask the user for the output device */
  for (j = 0; j < 20; ++j) {
    br_device[j] = ' ';
  }
  br_device[j] = '\0';
  
  sprintf(mes, "Give graphics (pgplot) device:");
  def = 2;
  nel = 1;
  userchar_c(tofchar(br_device), &nel, &def, tofchar("BR_DEVICE="), tofchar(mes));
  termsinglestr(br_device);
  
  /* If there was no input we return */
  if (*br_device == '\0') 
    return 0;
  
  /* Check if there was a logfile and stop if there wasn't */
  if (*log -> logname == '\0')
    return 0;
  
  /* Ask for the reference position angle, default 0 */
  sprintf(mes, "Give Briggs reference position angle");
  br_pa = 0;
  def = 2;
  nel = 1;
  userdble_c(&br_pa, &nel, &def, tofchar("BR_PA="), tofchar(mes));

  /* Ask for the reference inclination, default 0 */
  sprintf(mes, "Give Briggs reference position angle");
  br_incl = 0;
  def = 2;
  nel = 1;
  userdble_c(&br_incl, &nel, &def, tofchar("BR_INCL="), tofchar(mes));

  /* Then get the stuff in radian */
  inc = DEGTORAD*br_incl;
  pa = DEGTORAD*br_pa;

  /* Ask for the angles to plot rings for */
  ok = 0;
  def = 2;

  while (ok == 0) {
    sprintf(mes, "Give number of Briggs angles");
    br_annr = 0;
    nel = 1;
    userint_c(&br_annr, &nel, &def, tofchar("BR_ANNR="), tofchar(mes));

    if (br_annr < 0) {
      dev = 0;
      sprintf(mes, "Must be a positive number");
      anyout_c(&dev,tofchar(mes));
      cancel_c(tofchar("BR_ANNR="));
      def = 0;
    }
    else 
      ok = 1;
  }

  /* Symbol width */
  ok = 0;
  def = 2;
  while (ok == 0) {
    sprintf(mes, "Give width of dots (1-201) [5]");
    br_swdth = 10;
    nel = 1;
    userint_c(&br_swdth, &nel, &def, tofchar("BR_SWDTH="), tofchar(mes));

    if ((br_swdth < 1) || (br_swdth > 201)) {
      dev = 0;
      sprintf(mes, "Must be in-between 1 and 201");
      anyout_c(&dev,tofchar(mes));
      cancel_c(tofchar("BR_SWDTH="));
      def = 1;
    }
    else 
      ok = 1;
  }

  /* circle width */
  ok = 0;
  def = 2;
  while (ok == 0) {
    sprintf(mes, "Give width of circles (1-201) [1]");
    br_cwdth = 2;
    nel = 1;
    userint_c(&br_cwdth, &nel, &def, tofchar("BR_CWDTH="), tofchar(mes));

    if ((br_cwdth < 1) || (br_cwdth > 201)) {
      dev = 0;
      sprintf(mes, "Must be in-between 1 and 201");
      anyout_c(&dev,tofchar(mes));
      cancel_c(tofchar("BR_CWDTH="));
      def = 1;
    }
    else 
      ok = 1;
  }

  /* line width */
  ok = 0;
  def = 2;
  while (ok == 0) {
    sprintf(mes, "Give width of lines (1-201) [1]");
    br_lwdth = 2;
    nel = 1;
    userint_c(&br_lwdth, &nel, &def, tofchar("BR_LWDTH="), tofchar(mes));

    if ((br_lwdth < 1) || (br_lwdth > 201)) {
      dev = 0;
      sprintf(mes, "Must be in-between 1 and 201");
      anyout_c(&dev,tofchar(mes));
      cancel_c(tofchar("BR_LWDTH="));
      def = 1;
    }
    else 
      ok = 1;
  }

  /* Ask whether to plot the reference line */
    sprintf(mes, "Plot reference line? [1]");
    def = 2;
    br_refl = 1;
    nel = 1;
    userint_c(&br_refl, &nel, &def, tofchar("BR_REFL="), tofchar(mes));

  /* Ask for colour */
    sprintf(mes, "Colour of dots and lines");
    br_col = 1;
    def = 2;
    nel = 1;
    userint_c(&br_col, &nel, &def, tofchar("BR_COL="), tofchar(mes));

  /* Allocate memory */
  if (!(xarray = (float *) malloc(rpm -> nur*sizeof(float))))
    goto error;
  
  if (!(yarray = (float *) malloc(rpm -> nur*sizeof(float))))
    goto error;

  if (!(xlarray = (float *) malloc(rpm -> nr*sizeof(float))))
    goto error;
  
  if (!(ylarray = (float *) malloc(rpm -> nr*sizeof(float))))
    goto error;

  /* We read all values into the outarray */
  ftstab_get_grid_(log -> outarray);

  /* And then into the par array */
  for (j = 0; j < rpm -> nur*NPARAMS+NSPARAMS; ++j)
    rpm -> par[j] = log -> outarray[j];
  
  /* Interpolate over */
  interpover(rpm, dinterntoparam(rpm -> radsep, RADI, hdr), 0, NULL);

  /* Now fill the arrays */
  for (j = 0; j < rpm -> nur; ++j) {

    /* Normal vector of current ring */
    nrefr[0] = sin(DEGTORAD*rpm -> par[PINCL*rpm -> nur+j])*sin(DEGTORAD*rpm -> par[PPA*rpm -> nur+j]);
    nrefr[1] = -sin(DEGTORAD*rpm -> par[PINCL*rpm -> nur+j])*cos(DEGTORAD*rpm -> par[PPA*rpm -> nur+j]);
    nrefr[2] = cos(DEGTORAD*rpm -> par[PINCL*rpm -> nur+j]);
    
    /* Rotate the ring clockwise about the LOS */
    rota[0] = cos(pa)*nrefr[0]+sin(pa)*nrefr[1];
    rota[1] = -sin(pa)*nrefr[0]+cos(pa)*nrefr[1];
    rota[2] = nrefr[2];

    /* Then rotate the ring about the x axis, clockwise */
    rota[1] = cos(inc)*rota[1]+sin(inc)*rota[2];

    /* Finally get back to the original position with a clockwise rotation about the LOS */
    xarray[j] = rota[0];
    yarray[j] = rota[1];

  /**************/
 sprintf(obsmes, "graph: x: %.2f y: %.2f",  xarray[j],yarray[j]);
 anyout_c(&obsint, tofchar(obsmes));
  /**************/

/*      xarray[j] = cos(pa)*rota[0]-sin(pa)*rota[1];  */
/*      yarray[j] = sin(pa)*rota[0]+cos(pa)*rota[1];  */
  }

  /* Do the same with the large array */
  for (j = 0; j < rpm -> nr; ++j) {

    /* Normal vector of current ring */
    nrefr[0] = sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*sin(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
    nrefr[1] = -sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*cos(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
    nrefr[2] = cos(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j]);
    
    /* Rotate the ring clockwise about the LOS */
    rota[0] = cos(pa)*nrefr[0]+sin(pa)*nrefr[1];
    rota[1] = -sin(pa)*nrefr[0]+cos(pa)*nrefr[1];
    rota[2] = nrefr[2];

    /* Then rotate the ring about the x axis, clockwise */
    rota[1] = cos(inc)*rota[1]+sin(inc)*rota[2];

    /* Finally get back to the original position with a clockwise rotation about the LOS */
     xlarray[j] = cos(pa)*rota[0]-sin(pa)*rota[1]; 
     ylarray[j] = sin(pa)*rota[0]+cos(pa)*rota[1]; 
     xlarray[j] = rota[0];
     ylarray[j] = rota[1];



}

  /* In order to provide the user with some suggestion */
  rmax = 0;
  for (j = 0; j < rpm -> nur; ++j) {
    if (rmax < sqrt(xarray[j]*xarray[j]+yarray[j]*yarray[j]))
      rmax = sqrt(xarray[j]*xarray[j]+yarray[j]*yarray[j]);
  }
  for (j = 0; j < rpm -> nr; ++j) {
    if (rmax < sqrt(xlarray[j]*xlarray[j]+ylarray[j]*ylarray[j]))
      rmax = sqrt(xlarray[j]*xlarray[j]+ylarray[j]*ylarray[j]);
  }
  if (rmax > 1.0)
    rmax = 1.0;
  rmax = asin(rmax)/DEGTORAD;

  if ((br_annr)) {
    if (!(br_angl = (float *) malloc(br_annr*sizeof(float))))
      goto error;

    /* Now get the numbers */
    sprintf(mes, "Give %i Briggs angles, calculated max: %.1f",br_annr,rmax);
    def = 5;
    nel = br_annr;
    userreal_c(br_angl, &nel, &def, tofchar("BR_ANGL="), tofchar(mes));
  }

  /* Calculate the proper radii for the rings */
  for (j = 0; j < br_annr; ++j)
    br_angl[j] = sin(DEGTORAD*br_angl[j]);

  /* Now pass it to the graphics */
  pgp_opendev(br_device);


  pa_float = br_pa;
  pgp_polar(rpm -> nur, xarray, yarray, rpm -> nr, xlarray, ylarray, br_annr, br_angl, (br_refl)?(&pa_float):NULL, br_lwdth, br_cwdth, br_swdth, br_col);

  /* Once we got here, we ask the user if to continue */
  sprintf(mes, "Continue (Press return)?");
  def = 1;
  nel = 1;
  userint_c(&br_swdth, &nel, &def, tofchar("BR_CONT="), tofchar(mes));

  /* Then we stop it */
  pgp_end();

    free(xarray);
    free(xlarray);
    free(yarray);
    free(ylarray);
    if ((br_angl))
      free(br_angl);

  return 0;

 error:
  if ((br_angl))
    free(br_angl);
  if ((xarray))
    free(xarray);
  if ((xlarray))
    free(xlarray);
  if ((yarray))
    free(yarray);
  if ((ylarray))
    free(ylarray);

  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Produces the graphics output of tirific  */

static int graphout(loginf *log, hdrinf *hdr, ringparms *rpm)
{
  pgp_gdsc *gdsc = NULL;
  float *xarray = NULL;
  float *yarray = NULL;
  float *yerrarray = NULL;
  float *xlarray = NULL;
  float *ylarray = NULL;
  float xmin;
  float xmax;
  float ymin;
  float ymax;
  int bars;
  float barwidth;
  int posrefr;
  double xrefp;
  double yrefp;
  
  char **varystr = NULL;
  char *varyhstr = NULL;
  char *strbef = NULL;
  
  int i, j, k, dev, def, nel, inword, nrplts;
  char mes[81];
  char pgdevice[21];
  
  char inqstr[13];
  int colour;
  int lines;
  int errbars;
  int symb;
  int fill;
  float sizer;
  
  char leftdeschi[5];
  char rightdeschi[5];
  char leftdesclo[30];
  char rightdesclo[30];
  char bottomdeschi[5];
  char bottomdesclo[30];
  char topdesclo[30];
  char topdeschi[30];
  
  float lrzero;
  float lrscale;
  float btzero;
  float btscale;
  int xlog;
  int ylog;
  
  char legend[80];
  
  int pltlegend;
  
  int nradd = 0;
  int *npadd = NULL;
  float **xval = NULL;
  float **yval = NULL;
  float **errb = NULL;
  int *erad = NULL;
  int *adcol = NULL;
  int *adfill = NULL;
  int *adsymb = NULL;
  int *adlines = NULL;
  float *adsizer = NULL; 

  int verln, horln;
  float *vertarray = NULL, *horarray = NULL;
  int *vertcarray = NULL, *horcarray = NULL;
  float vhlxs[2],vhlys[2];

  /**************/
  /**************/ 
/*        fint obsint = 0;  */
/*  char obsmes[280];  */
  /**************/
  /**************/

  /**************/
  /**************/
/*     sprintf(obsmes, "got here: %f %f", horarray[0], horarray[1]); */
/*     anyout_c(&obsint, tofchar(obsmes)); */
  /**************/
  /**************/


  /* Ask the user for the output device */
  for (i = 0; i < 20; ++i) {
    pgdevice[i] = ' ';
  }
  pgdevice[i] = '\0';
  
  sprintf(mes, "Give graphics (pgplot) device:");
  def = 2;
  nel = 1;
  userchar_c(tofchar(pgdevice), &nel, &def, tofchar("GR_DEVICE="), tofchar(mes));
  termsinglestr(pgdevice);
  
  /* If there was no input we return */
  if (*pgdevice == '\0') 
    return 0;
  
  /* Check if there was a logfile and stop if there wasn't */
  if (*log -> logname == '\0')
    return 0;
  
  /* Allocate the complicated varystr */
  if (!(varystr = (char **) malloc(MAXGRAPHS*sizeof(char *))))
    goto error;
  if (!(varyhstr = getfcharray(VARYHSTRELES)))
    goto error;
  
  /* Then ask for the things to plot */
  sprintf(mes, "Give parameters to plot");
  def = 0;
  nel = usertext_c(tofchar(varyhstr), &def, tofchar("GR_PARMS="),tofchar(mes));
  
  /* Terminate the string */
  varyhstr[nel] = '\0';
  
  /* Change the case if it is lower case */
  i = 0;
  while (varyhstr[i]) {
    if (varyhstr[i] >= 'a' && varyhstr[i] <= 'z')
      varyhstr[i] = varyhstr[i]+'A'-'a';
    ++i;
  }
  
  /* Now hack it into peaces, fill varystr, ignoring wrong parameters */
  inword = 0;
  i = 0;
  nrplts = 0;
  
  while (varyhstr[i] != '\0') {
    if ((inword)) {
      if (varyhstr[i] == ' ' || varyhstr[i] == '\t') {
	varyhstr[i] = '\0';
	if (get_graphident(strbef, NULL, NULL, NULL, NULL) > 0) {
	  varystr[nrplts] = strbef;
	  ++nrplts;
	}
	inword = 0;
      }
      else if (varyhstr[i+1] == '\0') {
	if (get_graphident(strbef, NULL, NULL, NULL, NULL) > 0) {
	  varystr[nrplts] = strbef;
	  ++nrplts;
	}
      }
    }
    else if (varyhstr[i] != ' ' && varyhstr[i] != '\t') {
      if (nrplts < MAXGRAPHS)
	strbef = varyhstr+i;
      inword = 1;
    }
    ++i;
  }

  dev = 1;
  if (nrplts < 2) {
    sprintf(mes, "Something wrong with GR_PARMS=, no output");
    anyout_c(&dev, tofchar(mes));
  }

  /* Allocate memory for the output */
  if (!(xarray = (float *) malloc(rpm -> nur*sizeof(float))))
    goto error;
  
  if (!(yarray = (float *) malloc(rpm -> nur*sizeof(float))))
    goto error;
  
  if (!(yerrarray = (float *) malloc(rpm -> nur*sizeof(float))))
    goto error;
  
  if (!(xlarray = (float *) malloc(rpm -> nr*sizeof(float))))
    goto error;
  
  if (!(ylarray = (float *) malloc(rpm -> nr*sizeof(float))))
    goto error;
  
  /* We read all values into the outarray */
  ftstab_get_grid_(log -> outarray);
  
  /* Then into the par array */
  for (j = 0; j < rpm -> nur*NPARAMS+NSPARAMS; ++j)
    rpm -> par[j] = log -> outarray[j];
  
  /* Central coordinates get the head cut off */
/*   for (j = 0; j < rpm -> nur; ++j) { */
/*     rpm -> par[PXPOS*rpm -> nur+j] = rpm -> par[PXPOS*rpm -> nur+j]-((int) rpm -> par[(PXPOS+1)*rpm -> nur-1]); */
/*     rpm -> par[PYPOS*rpm -> nur+j] = rpm -> par[PYPOS*rpm -> nur+j]-((int) rpm -> par[(PYPOS+1)*rpm -> nur-1]); */
/*   } */

  /* Get the reference positions */

  /* First ask for the reference ring */
  sprintf(mes, "Position reference ring [1]");
  def = 2;
  nel = 1;
  posrefr = 1;
  userint_c(&posrefr, &nel, &def, tofchar("GR_PRFR="), tofchar(mes));
  if ((posrefr < 1) || (posrefr >  rpm -> nur))
    posrefr = 1;
  else
    --posrefr;

  /* Then this will be a default for the reference position */
  sprintf(mes, "Reference Right Ascension [%.3f]",rpm -> par[PXPOS*rpm -> nur+posrefr]);
  def = 2;
  nel = 1;
  xrefp = rpm -> par[PXPOS*rpm -> nur+posrefr];
  userdble_c(&xrefp, &nel, &def, tofchar("GR_PRFX="), tofchar(mes));

  /* Export this to log */
  log -> xref = xrefp;

  sprintf(mes, "Reference Declination [%.3f]",rpm -> par[PYPOS*rpm -> nur+posrefr]);
  def = 2;
  nel = 1;
  yrefp = rpm -> par[PYPOS*rpm -> nur+posrefr];
  userdble_c(&yrefp, &nel, &def, tofchar("GR_PRFY="), tofchar(mes));

  /* Export this to log */
  log -> yref = yrefp;

  /* Interpolate over */
  interpover(rpm, barwidth = dinterntoparam(rpm -> radsep, RADI, hdr), 0, NULL);

  /* Now prepare the arrays for x */
  fillgrapharray(hdr, rpm, get_graphident(varystr[0], NULL, NULL, NULL, NULL), xarray, xlarray);
  
  /* Get the scale and the identity card */
  gr_fillscaling(log, hdr, get_graphident(varystr[0], bottomdeschi, bottomdesclo, topdesclo, legend), &btscale, &btzero);

  /* Inquire whether to plot subrings */
  sprintf(mes, "Plot values for subrings 1/0? [1]");
  def = 2;
  nel = 1;
  bars = 1;
  userint_c(&bars, &nel, &def, tofchar("GR_SBRP="), tofchar(mes));
  
  /* Get min */
  xmin = xarray[0];
  for (i = 1; i < rpm -> nur; ++i)
    xmin = (xmin > xarray[i])?xarray[i]:xmin;
  if ((bars))
    for (i = 0; i < rpm -> nr; ++i)
      xmin = (xmin > xlarray[i])?xlarray[i]:xmin;
  
  /* Get max */
  xmax = xarray[0];
  for (i = 1; i < rpm -> nur; ++i)
    xmax = (xmax < xarray[i])?xarray[i]:xmax;
  if ((bars))
    for (i = 0; i < rpm -> nr; ++i)
      xmax = (xmax < xlarray[i])?xlarray[i]:xmax;
  
  /* Inquire min and max */
  sprintf(mes, "Give minimum of x-axis [%f]", xmin);
  def = 2;
  nel = 1;
  userreal_c(&xmin, &nel, &def, tofchar("GR_XMIN="), tofchar(mes));
  sprintf(mes, "Give maximum of x-axis [%f]", xmax);
  def = 2;
  nel = 1;
  userreal_c(&xmax, &nel, &def, tofchar("GR_XMAX="), tofchar(mes));

  /* Inquire x-axis style */
  sprintf(mes, "Logarithmic scaling of x-axis? (1/0)");
  xlog = 0;
  def = 2;
  nel = 1;
  userint_c(&xlog, &nel, &def, tofchar("GR_XLOG="), tofchar(mes));
  
  if ((xlog))
    xlog = 1;

  /* In case of SBR, the right hand is SD */
  if (get_graphident(varystr[0], NULL, NULL, NULL, NULL) == SBR)
    gr_fillaxis(DENS_GRAPHNR, topdeschi);
  else if (get_graphident(varystr[0], NULL, NULL, NULL, NULL) == XPOS) {
    gr_fillaxis(RASH_GRAPHNR, topdeschi);
    xlog = 2;
  }
  else if (get_graphident(varystr[0], NULL, NULL, NULL, NULL) == YPOS) {
    gr_fillaxis(DESH_GRAPHNR, topdeschi);
    xlog = 3;
  }
  else {
    gr_fillaxis(get_graphident(varystr[0], NULL, NULL, NULL, NULL), topdeschi);
  }
  
/* Ask whether to plot a legend */
  sprintf(mes, "Plot legend (1/0)?");
  def = 2;
  nel = 1;
  pltlegend = 1;
  userint_c(&pltlegend, &nel, &def, tofchar("GR_LGND="), tofchar(mes));
  
  /* Now initialise the graphics */
  pgp_opendev(pgdevice);
  
  /* Generate the standard frame information */
  gdsc = pgp_gdsc_default(nrplts-1, 2, (pltlegend)?((nrplts+1)/2):0, 1.0);
  
  /* Make the adjustment of left and right frame possible */
  sprintf(mes, "Give right hand margin");
  def = 2;
  nel = 1;
  userreal_c(&gdsc -> rightmargin, &nel, &def, tofchar("GR_MR="), tofchar(mes));
  sprintf(mes, "Give left hand margin");
  def = 2;
  nel = 1;
  userreal_c(&gdsc -> leftmargin, &nel, &def, tofchar("GR_ML="), tofchar(mes));
  
  /* Ask for the height of text and symbols */
  sprintf(mes, "Give height of Text");
  def = 2;
  nel = 1;
  userreal_c(&gdsc -> numberheight, &nel, &def, tofchar("GR_TXHT="), tofchar(mes));
  
  sprintf(mes, "Give height of symbols");
  def = 2;
  nel = 1;
  userreal_c(&gdsc -> symbolheight, &nel, &def, tofchar("GR_SBHT="), tofchar(mes));
  
  /* Legendheight and axdescheight are 1 by default, we leave it at that */
  
  /* Put the x axis descriptor */
  if ((pltlegend))
    pgp_legend(gdsc, 1, 1, legend);
  
  /* Plot everything */
  for (i = 1; i < nrplts; ++i) {
    def = 2;
    nel = 1;

    /* Inquire colour */
    colour = i;
    sprintf(inqstr, "GR_COL_%i=", i);
    sprintf(mes, "Give Colour of plot %i", i);
    userint_c(&colour, &nel, &def, tofchar(inqstr), tofchar(mes));
    
    /* Inquire symbol */
    symb = -1;
    sprintf(inqstr, "GR_SYMB_%i=", i);
    sprintf(mes, "Give symbol for plot %i", i);
    userint_c(&symb, &nel, &def, tofchar(inqstr), tofchar(mes));
    
    /* Inquire fill */
    fill = 0;
    sprintf(inqstr, "GR_EMTY_%i=", i);
    sprintf(mes, "Fill symbol for plot %i? (0)", i);
    userint_c(&fill, &nel, &def, tofchar(inqstr), tofchar(mes));
    
    /* Inquire sizer */
    sizer = 1.0;
    sprintf(inqstr, "GR_SIZE_%i=", i);
    sprintf(mes, "Relative size of symbol for plot %i? (0)", i);
    userreal_c(&sizer, &nel, &def, tofchar(inqstr), tofchar(mes));
    
    /* Inquire lines */
    lines = 0;
    sprintf(inqstr, "GR_LINES_%i=", i);
    sprintf(mes, "Plot lines 1/0? [0]");
    userint_c(&lines, &nel, &def, tofchar(inqstr), tofchar(mes));
    
    /* Inquire errorbars */
    errbars = 0;
    sprintf(inqstr, "GR_ERRB_%i=", i);
    sprintf(mes, "Plot errorbars 1/0? [0]");
    userint_c(&errbars, &nel, &def, tofchar(inqstr), tofchar(mes));

    /* Inquire logarithmic scaling */
    ylog = 0;
    sprintf(inqstr, "GR_YLOG_%i=", i);
    sprintf(mes, "y-axis logarithmic scaling 1/0? [0]");
    userint_c(&ylog, &nel, &def, tofchar(inqstr), tofchar(mes));

    
    if ((ylog))
      ylog = 1;
    
    /* Get number of vertical lines */
    verln = 0;
    nel = 1;
    sprintf(inqstr, "GR_VERL_%i=", i);
    sprintf(mes, "How many vertical lines for plot %i?", i);
    userint_c(&verln, &nel, &def, tofchar(inqstr), tofchar(mes));
    verln = verln > 0 ? verln : -verln;

    if ((verln)) {
      
      /* allocate */
      if (!(vertarray = (float *) malloc(verln*sizeof(float))))
	goto error;
      
      if (!(vertcarray = (int *) malloc(verln*sizeof(int))))
	goto error;
      
      for (j = 0; j < verln; ++j)
	vertarray[j] = 0.0;
      
      for (j = 0; j < verln; ++j)
	vertcarray[j] = 1;
      
      sprintf(mes, "Give values for vertical lines");
      def = 2;
      nel = verln;
      sprintf(inqstr, "GR_VLVA_%i=", i);
      userreal_c(vertarray, &nel, &def, tofchar(inqstr), tofchar(mes));
      
      sprintf(mes, "Give colours for vertical lines");
      def = 2;
      nel = verln;
      sprintf(inqstr, "GR_VLCA_%i=", i);
      userint_c(vertcarray, &nel, &def, tofchar(inqstr), tofchar(mes));
      
      for (j = 0; j < verln; ++j)
	vertcarray[j] = vertcarray[j] > 0 ?  vertcarray[j] : - vertcarray[j];
    }

    /* Get number of horizontal lines */
    horln = 0;
    nel = 1;
    sprintf(inqstr, "GR_HORL_%i=", i);
    sprintf(mes, "How many horizontal lines for plot %i?", i);
    userint_c(&horln, &nel, &def, tofchar(inqstr), tofchar(mes));
    horln = horln > 0 ? horln : -horln;

    if ((horln)) {
      
      /* allocate */
      if (!(horarray = (float *) malloc(horln*sizeof(float))))
	goto error;
      
      if (!(horcarray = (int *) malloc(horln*sizeof(int))))
	goto error;
      
      for (j = 0; j < horln; ++j)
	horarray[j] = 0.0;
      
      for (j = 0; j < horln; ++j)
	horcarray[j] = 1;
      
      sprintf(mes, "Give values for horizontal lines of plot %i",i);
      sprintf(inqstr, "GR_HLVA_%i=", i);
      def = 2;
      nel = horln;
      userreal_c(horarray, &nel, &def, tofchar(inqstr), tofchar(mes));
      
      sprintf(mes, "Give colours for horizontal lines of plot %i", i);
      def = 2;
      nel = horln;
      sprintf(inqstr, "GR_HLCA_%i=", i);
      userint_c(horcarray, &nel, &def, tofchar(inqstr), tofchar(mes));
      
      for (j = 0; j < verln; ++j)
	horcarray[j] = horcarray[j] > 0 ?  horcarray[j] : - horcarray[j];
    }

    /* Fill yerrarray */
    if ((errbars)) {
      
      /* We read all values into the outarray */
      ftstab_get_radi_(log -> outarray);
      
      for (j = 0; j < rpm -> nur*NPARAMS+NSPARAMS; ++j)
	rpm -> par[j] = log -> outarray[j];
      
      fillgrapharray(hdr, rpm, get_graphident(varystr[0], NULL, NULL, NULL, NULL), yerrarray, ylarray);

      /* Give the user the possibility to put own errorbars */
      def = 2;
      nel = rpm -> nur;
      sprintf(mes, "Give own errorbars");
      sprintf(inqstr, "GR_ERRV_%i=", i);
      userreal_c(yerrarray, &nel, &def, tofchar(inqstr), tofchar(mes));
    }
    else {
      for (j = 0; j < rpm -> nur; ++j)
	yerrarray[j] = 0;
    }      
    
    /* Fill yarray */
    
    /* We read all values into the outarray */
    ftstab_get_grid_(log -> outarray);
    
    for (j = 0; j < rpm -> nur*NPARAMS+NSPARAMS; ++j)
      rpm -> par[j] = log -> outarray[j];
    
    /* Central coordinates get the head cut off */
/*     for (j = 0; j < rpm -> nur; ++j) { */
/*       rpm -> par[PXPOS*rpm -> nur+j] = rpm -> par[PXPOS*rpm -> nur+j]-((int) rpm -> par[(PXPOS+1)*rpm -> nur-1]); */
/*       rpm -> par[PYPOS*rpm -> nur+j] = rpm -> par[PYPOS*rpm -> nur+j]-((int) rpm -> par[(PYPOS+1)*rpm -> nur-1]); */
/*     } */

    fillgrapharray(hdr, rpm, get_graphident(varystr[i], NULL, NULL, NULL, NULL), yarray, ylarray);

    /* Inquire number of additional arrays */
    sprintf(mes, "Give number of additional rows for plot %i: [0]", i);
    sprintf(inqstr, "GR_NRAD_%i=", i);
    def = 2;
    nel = 1;
    nradd = 0;
    userint_c(&nradd, &nel, &def, tofchar(inqstr), tofchar(mes));

    /* Reserve memory */
    if (nradd > 0) {
      if (!(npadd = (int *) malloc(nradd*sizeof(int))))
	goto error;
      if (!(erad = (int *) malloc(nradd*sizeof(int))))
	goto error;
      if (!(adcol = (int *) malloc(nradd*sizeof(int))))
	goto error;
      if (!(adsymb = (int *) malloc(nradd*sizeof(int))))
	goto error;
      if (!(adfill = (int *) malloc(nradd*sizeof(int))))
	goto error;
      if (!(adlines = (int *) malloc(nradd*sizeof(int))))
	goto error;
      if (!(adsizer = (float *) malloc(nradd*sizeof(float))))
	goto error;
      if (!(xval = (float **) malloc(nradd*sizeof(float *))))
	goto error;
      for (k = 0; k < nradd; ++k) {
	xval[k] = NULL;
      }
      if (!(yval = (float **) malloc(nradd*sizeof(float *))))
	goto error;
      for (k = 0; k < nradd; ++k) {
	yval[k] = NULL;
      }
      if (!(errb = (float **) malloc(nradd*sizeof(float *))))
	goto error;
      for (k = 0; k < nradd; ++k) {
	errb[k] = NULL;
      }
    }

    /* Now get the info about all the additional points */
    for (k = 0; k < nradd; ++k) {
      
      /* Inquire number of additional points */
      sprintf(mes, "Give number of additional points for plot %i (%i): [0]", i, k+1);
      sprintf(inqstr, "GR_NPAD_%i_%i=", i, k+1);

      npadd[k] = -1;
      while(npadd[k] < 0) {
	def = 4;
	nel = 1;
	npadd[k] = 0;
	userint_c(npadd+k, &nel, &def, tofchar(inqstr), tofchar(mes));
	if (npadd[k] < 0) {
	  sprintf(mes, "Must be at least 0");
	  anyout_c(&nel, tofchar(mes));
	  cancel_c(tofchar(inqstr));
	}
      }

      if ((npadd[k])) {
	
	/* Reserve memory */
	if (!(xval[k] = (float *) malloc(npadd[k]*sizeof(float))))
	  goto error;
	if (!(yval[k] = (float *) malloc(npadd[k]*sizeof(float))))
	  goto error;
	if (!(errb[k] = (float *) malloc(npadd[k]*sizeof(float))))
	  goto error;
	
	/* Inquire points */
	sprintf(mes, "Give additional points, x axis for plot %i (%i):", i, k+1);
	sprintf(inqstr, "GR_XPAD_%i_%i=", i, k+1);
	def = 4;
	nel = npadd[k];
	userreal_c(xval[k], &nel, &def, tofchar(inqstr), tofchar(mes));

	sprintf(mes, "Give additional points, y axis for plot %i (%i):", i, k+1);
	sprintf(inqstr, "GR_YPAD_%i_%i=", i, k+1);
	userreal_c(yval[k], &nel, &def, tofchar(inqstr), tofchar(mes));
	
	/* Inquire errorbars */
	sprintf(mes, "Errorbars to additional points of plot %i (%i) (1/0)?", i, k+1);
	sprintf(inqstr, "GR_ERAD_%i_%i=", i, k+1);
	def = 2;
	nel = 1;
	erad[k] = 0;
	userint_c(&erad[k], &nel, &def, tofchar(inqstr), tofchar(mes));
	
	if ((erad[k])) {
	  
	  /* Get the errorbars */
	  sprintf(mes, "Give errorbars for additional points of plot %i (%i):", i, k+1);
	  sprintf(inqstr, "GR_EBAD_%i_%i=", i, k+1);
	  def = 4;
	  nel = npadd[k];
	  userreal_c(errb[k], &nel, &def, tofchar(inqstr), tofchar(mes));
	}
	else {
	  for (j = 0; j < npadd[k]; ++j)
	    (errb[k])[j] = 0;
	}
	
	/* Inquire colour */
	sprintf(mes, "Give colour of additional points of plot %i (%i):", i, k+1);
	sprintf(inqstr, "GR_COAD_%i_%i", i, k+1);
	def = 2;
	nel = 1;
	adcol[k] = i;
	userint_c(adcol+k, &nel, &def, tofchar(inqstr), tofchar(mes));
	
	/* Inquire symbol */
	sprintf(mes, "Give symbol of additional points of plot %i (-1):", i);
	sprintf(inqstr, "GR_SYAD_%i_%i", i, k+1);
	def = 2;
	nel = 1;
	adsymb[k] = -1;
	userint_c(adsymb+k, &nel, &def, tofchar(inqstr), tofchar(mes));
	
	/* Inquire emptyness */
	sprintf(mes, "Symbols of additional points of plot %i empty: (1)", i);
	sprintf(inqstr, "GR_EMAD_%i_%i", i, k+1);
	def = 2;
	nel = 1;
	adfill[k] = 1;
	userint_c(adfill+k, &nel, &def, tofchar(inqstr), tofchar(mes));
	
	/* Inquire sizer */
	sprintf(mes, "Size of additional points relative to standard size");
	sprintf(inqstr, "GR_SIAD_%i_%i", i, k+1);
	def = 2;
	nel = 1;
	adsizer[k] = 1.0;
	userreal_c(adsizer+k, &nel, &def, tofchar(inqstr), tofchar(mes));
	
	/* Inquire lines */
	sprintf(mes, "Draw lines between additional points of plot %i (%i) (1/0)?", i, k+1);
	sprintf(inqstr, "GR_LIAD_%i_%i", i, k+1);
	def = 2;
	nel = 1;
	adlines[k] = 0;
	userint_c(adlines+k, &nel, &def, tofchar(inqstr), tofchar(mes));
      }
    }
    
    /* Inquire min and max */
    ymin = yarray[0]-fabs(yerrarray[0]);
    for (j = 1; j < rpm -> nur; ++j)
      ymin = (ymin > (yarray[j]-fabs(yerrarray[j])))?(yarray[j]-fabs(yerrarray[j])):ymin;
    if ((bars))
      for (j = 0; j < rpm -> nr; ++j)
	ymin = (ymin > ylarray[j])?ylarray[j]:ymin;
    for (k = 0; k < nradd; ++k) {
      for (j = 0; j < npadd[k]; ++j)
	ymin = (ymin > ((yval[k])[j]-fabs((errb[k])[j])))?((yval[k])[j]-fabs((errb[k])[j])):ymin;
    }

    ymax = yarray[0]+fabs(yerrarray[0]);
    for (j = 1; j < rpm -> nur; ++j)
      ymax = (ymax < (yarray[j]+fabs(yerrarray[j])))?(yarray[j]+fabs(yerrarray[j])):ymax;
    if ((bars))
      for (j = 0; j < rpm -> nr; ++j)
	ymax = (ymax < ylarray[j])?ylarray[j]:ymax;
    for (k = 0; k < nradd; ++k) {
      for (j = 0; j < npadd[k]; ++j)
	ymax = (ymax < ((yval[k])[j]+fabs((errb[k])[j])))?((yval[k])[j]+fabs((errb[k])[j])):ymax;
    }
    /* Ask */
    sprintf(inqstr, "GR_YMIN_%i=", i);
    sprintf(mes, "Give minimum of y-axis %i: [%f]", i, ymin);
    def = 2;
    nel = 1;
    userreal_c(&ymin, &nel, &def, tofchar(inqstr), tofchar(mes));
    sprintf(inqstr, "GR_YMAX_%i=", i);
    sprintf(mes, "Give maximum of y-axis %i: [%f]", i, ymax);
    def = 2;
    nel = 1;
    userreal_c(&ymax, &nel, &def, tofchar(inqstr), tofchar(mes));
    
    /* Fill the y axis descriptors and scalings */
    /* Get the scale and the identity card */
    gr_fillscaling(log, hdr, get_graphident(varystr[i], leftdeschi, leftdesclo, rightdesclo, legend), &lrscale, &lrzero);
    
    /* In case of SBR, the right hand is SD */
    if (get_graphident(varystr[i], NULL, NULL, NULL, NULL) == SBR)
      gr_fillaxis(DENS_GRAPHNR, rightdeschi);
    else if (get_graphident(varystr[i], NULL, NULL, NULL, NULL) == XPOS) {
      gr_fillaxis(RASH_GRAPHNR, rightdeschi);
      ylog = 2;
    }
    else if (get_graphident(varystr[i], NULL, NULL, NULL, NULL) == YPOS) {
      gr_fillaxis(DESH_GRAPHNR, rightdeschi);
      ylog = 3;
    }
    else
      gr_fillaxis(get_graphident(varystr[i], NULL, NULL, NULL, NULL), rightdeschi);

    /* Plot the box */
    pgp_openbox(gdsc, i, xmin, xmax, ymin, ymax, leftdeschi, leftdesclo, rightdeschi, rightdesclo, bottomdeschi, bottomdesclo, topdeschi, topdesclo, lrzero, lrscale, btzero, btscale, xlog, ylog);

    /* Plot additional points */
    if (nradd > 0) {
      for (k = 0; k < nradd; ++k) {
	if ((npadd[k])) {

	  pgp_marker(gdsc, npadd[k], xval[k], yval[k], adcol[k], adfill[k], adsymb[k], adsizer[k]);
	  
	  /* Plot errorbars */
	  if ((erad[k]))
	    pgp_errby(gdsc, npadd[k], xval[k], yval[k], errb[k], adcol[k]);
	  
	  /* Plot lines */
	  if ((adlines[k]))
	    pgp_lines(gdsc, npadd[k], xval[k], yval[k], adcol[k]);
	  
	  /* Free memory */
	  free(xval[k]);
	  xval[k] = NULL;
	  free(yval[k]);
	  yval[k] = NULL;
	  free(errb[k]);
	  errb[k] = NULL;
	}
      }

    /* free stuff */
      free(npadd);
      free(erad);
      free(adcol);
      free(adlines);
      free(xval);
      free(yval);
      free(errb);
    }

    /* Plot bars */
    if ((bars)) 
      pgp_bars(gdsc, rpm -> nr, xlarray, ylarray, barwidth, colour);
    
    /* Plot errorbars */
    if ((errbars))
      pgp_errby(gdsc, rpm -> nur, xarray, yarray, yerrarray, colour);
    
    /* Plot lines */
    if ((lines))
      pgp_lines(gdsc, rpm -> nur, xarray, yarray, colour);

    /* Plot the points */
    pgp_marker(gdsc, rpm -> nur, xarray, yarray, colour, fill, symb, sizer);

     /* plot horizontal lines */
    if ((horln)) {
      for (j = 0; j < horln; ++j) {
	vhlys[0] = vhlys[1] = horarray[j];

	if (xmin == xmax) { 
	  vhlxs[0] = 1000000.0*xarray[0]+0.1;
	  vhlxs[1] = -1000000.0*xarray[0]-0.1;
	}
	else {
	  vhlxs[0] = (xmin+xmax)/2.0-1000000.0*(xmax-xmin);
	  vhlxs[1] = (xmin+xmax)/2.0+1000000.0*(xmax-xmin);
	}
	pgp_lines(gdsc, 2, vhlxs, vhlys, horcarray[j]);
      }
      free(horarray);
      free(horcarray);
    }

    /* plot vertical lines */
    if ((verln)) {
      for (j = 0; j < verln; ++j) {
	vhlxs[0] = vhlxs[1] = vertarray[j];
	if (ymin == ymax) { 
	  vhlys[0] = 1000000.0*yarray[0]+0.1;
	  vhlys[1] = -1000000.0*yarray[0]-0.1;
	}
	else {
	vhlys[0] = (ymin+ymax)/2.0-1000000.0*(ymax-ymin);
	vhlys[1] = (ymin+ymax)/2.0+1000000.0*(ymax-ymin);
	}
	pgp_lines(gdsc, 2, vhlxs, vhlys, vertcarray[j]);
      }
      free(vertarray);
      free(vertcarray);
    }

    /* Put the legend line */
    if ((pltlegend))
      pgp_legend(gdsc, i%2+1, i/2+1, legend);
  }

  /* Free memory */
  free(varystr);
  free(varyhstr);
  free(xarray);
  free(yarray);
  free(yerrarray);
  free(xlarray);
  free(ylarray);


  /* Once we got here, we ask the user if to continue */
  sprintf(mes, "Continue (Press return)?");
  def = 1;
  nel = 1;
  userint_c(&pltlegend, &nel, &def, tofchar("GR_CONT="), tofchar(mes));
  

  /* Then we stop it */
  pgp_end();
  
  return nrplts-1;
  
 error:
  if ((varystr))
    free(varystr);
  if ((varyhstr))
    free(varyhstr);
  if ((xarray))
    free(xarray);
  if ((yarray))
    free(yarray);
  if ((yerrarray))
    free(yerrarray);
  if ((xlarray))
    free(xlarray);
  if ((ylarray))
    free(ylarray);

  if ((npadd))
    free(npadd);
  if ((erad))
    free(erad);
  if ((adcol))
    free(adcol);
  if ((adsymb))
    free(adsymb);
  if ((adfill))
    free(adfill);
  if ((adlines))
    free(adlines);
  if ((adsizer))
    free(adsizer);
  if ((vertarray))
    free(vertarray);
  if ((horarray))
    free(horarray);
  if ((vertcarray))
    free(vertcarray);
  if ((horcarray))
    free(horcarray);

  if ((xval)) {
    for (i = 0; i < nradd; ++i) {
      if ((xval[i]))
	free(xval[i]);
    }
    free(xval);
  }

  if ((yval)) {
    for (i = 0; i < nradd; ++i) {
      if ((yval[i]))
	free(yval[i]);
    }
    free(yval);
  }

  if ((errb)) {
    for (i = 0; i < nradd; ++i) {
      if ((errb[i]))
	free(errb[i]);
    }
    free(errb);
  }

  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns the identifyer of a graphics output */
static int get_graphident(char *string, char *axis, char *unit, char *altunit, char *legend)
{
  int ident;
  
  /* First check if there is a string */
  if (!string)
    return -1;
  
  /* Now check if it can be identified with a variable parameter itself */
  if(((ident = ftstab_gtitln_(string)) <= 0))
    ident = get_graphnr(string);
  else if (ident > NPARAMS)
    return -1;
  
  if (ident == 0)
    return -1;
  
  /* Now fill the strings */
  gr_fillaxis(ident, axis);
  gr_fillunit(ident, unit);
  gr_fillaltunit(ident, altunit);
  gr_filllegend(ident, legend);
  
  /* Finis */
  return ident;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Identifies a graphics output number */
static int get_graphnr(char *string)
{
  if (!strcmp(string, "WA"))
    return WA_GRAPHNR;
  if (!strcmp(string, "DENS"))
    return DENS_GRAPHNR;
  if (!strcmp(string, "WOLD"))
    return WOLD_GRAPHNR;
  if (!strcmp(string, "TIP"))
    return TIP_GRAPHNR;
  if (!strcmp(string, "LON"))
    return LON_GRAPHNR;
  return -1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns an axis descriptor string suitable for the use in the pgp module */
static void gr_fillaxis(int ident, char *string)
{
  if ((string))
    switch (ident) {
    case RADI:
      sprintf(string, "R");
      return;
    case VROT:
      sprintf(string, "VROT");
      return;
    case Z0:
      sprintf(string, "SCHT");
      return;
    case SBR:
      sprintf(string, "SBR");
      return;
    case INCL:
      sprintf(string, "INCL");
      return;
    case PA:
      sprintf(string, "PA");
      return;
    case XPOS:
      sprintf(string, "RA");
      return;
    case YPOS:
      sprintf(string, "DEC");
      return;
    case VSYS:
      sprintf(string, "VSYS");
      return;
    case WA_GRAPHNR:
      sprintf(string, "WA");
      return;
    case DENS_GRAPHNR:
      sprintf(string, "SD");
      return;
    case WOLD_GRAPHNR:
      sprintf(string, "WAOL");
      return;
    case TIP_GRAPHNR:
      sprintf(string, "TIP");
      return;
    case LON_GRAPHNR:
      sprintf(string, "LON");
      return;
    case DESH_GRAPHNR:
      sprintf(string, "DESH");
      return;
    case RASH_GRAPHNR:
      sprintf(string, "RASH");
      return;
    }
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns an unit string suitable for the use in the pgp module */
void gr_fillunit(int ident, char *string)
{
  if ((string))
    switch (ident) {
    case RADI:
      sprintf(string, "arcsec");
      return;
    case VROT:
      sprintf(string, "km\\.s\\u-1");
      return;
    case Z0:
      sprintf(string, "arcsec");
      return;
    case SBR:
      sprintf(string, "Jy\\.km\\.s\\u-1\\d\\.arcsec\\u-2");
      return;
    case INCL:
      sprintf(string, "degree");
      return;
    case PA:
      sprintf(string, "degree");
      return;
    case XPOS:
      sprintf(string, "hh mm ss.s");
      return;
    case YPOS:
      sprintf(string, "dd mm ss.s");
      return;
    case VSYS:
      sprintf(string, "km\\.s\\u-1");
      return;
    case WA_GRAPHNR:
      sprintf(string, "degree");
      return;
    case DENS_GRAPHNR:
      sprintf(string, "cm\\u-2");
      return;
    case WOLD_GRAPHNR:
      sprintf(string, "degree");
      return;
    case TIP_GRAPHNR:
      sprintf(string, "degree");
      return;
    case LON_GRAPHNR:
      sprintf(string, "degree");
      return;
    }
  
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns an alternative unit string suitable for the use in the pgp module */
static void gr_fillaltunit(int ident, char *string)
{
  if ((string))
    switch (ident) {
    case RADI:
      sprintf(string, "kpc");
      return;
    case VROT:
      sprintf(string, "km\\.s\\u-1");
      return;
    case Z0:
      sprintf(string, "pc");
      return;
    case SBR:
      sprintf(string, "cm\\u-2");
      return;
    case INCL:
      sprintf(string, "rad");
      return;
    case PA:
      sprintf(string, "rad");
      return;
    case XPOS:
      sprintf(string, "kpc");
      return;
    case YPOS:
      sprintf(string, "kpc");
      return;
    case VSYS:
      sprintf(string, "km\\.s\\u-1");
      return;
    case WA_GRAPHNR:
      sprintf(string, "degree");
      return;
    case DENS_GRAPHNR:
      sprintf(string, "M\\d\\(2281)\\u\\.pc\\u-2");
      return;
    case WOLD_GRAPHNR:
      sprintf(string, "degree");
      return;
    case TIP_GRAPHNR:
      sprintf(string, "degree");
      return;
    case LON_GRAPHNR:
      sprintf(string, "degree");
      return;
    }
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Fills two arrays for graphics use */
static int fillgrapharray(hdrinf *hdr, ringparms *rpm, int ident, float *array, float *larray)
{
  int i, j;
  
  int def = 2;
  int nel = 1;
  int rring = 5;
  int err = 1;
  int gr_tlr = 0;
  char mes[81];
  
  double br_incl;
  double br_pa;
  double gr_tll;
  double nv[3];
  double nrefr[3];
  double value;
  double vsys, nu;
  double rescval;
  double x,y;
  
  /**************/
   /**************/ 
/* fint obsint = 0; */
/* char obsmes[80]; */
  /**************/

  /**************/
  /**************/
/*   sprintf(obsmes, "got here"); */
/*   anyout_c(&obsint, tofchar(obsmes));  */
  /**************/
      

  /* Check if it can be done */
  if (ident > 0) {
    if (ident <= NPARAMS) {
      
      /* Simply put the values into the arrays */
      for (i = 0; i < rpm -> nur; ++i)
	array[i] = rpm -> par[(ident-1)*rpm -> nur+i];
      for (i = 0; i < rpm -> nr; ++i)
	larray[i] = rpm -> modpar[(ident-1)*rpm -> nr+i];
    }
    else if (ident == WA_GRAPHNR || ident == WOLD_GRAPHNR) {
      if (ident == WA_GRAPHNR) {
	
	/* Calculate the normal vector of the reference */
	for (i = 0; i < 3; ++i) {
	  nrefr[i] = 0;
	}
	
	/* Now we calculate the direction of the total angular momentum of the observed component */
	for (j = 0; j < rpm -> nr; ++j) {
	  
	  /* We don't do a relativistic correction for this */
	  value = pow(rpm -> modpar[PRADI*rpm -> nr+j],2)*rpm -> modpar[PVROT*rpm -> nr+j]*rpm -> modpar[PSBR*rpm -> nr+j];
	  nrefr[0] = nrefr[0]+(double) value*sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*sin(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
	  nrefr[1] = nrefr[1]-(double) value*sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*cos(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
	  nrefr[2] = nrefr[2]+(double) value*cos(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j]);
	}
	
	value = sqrt(pow(nrefr[0],2)+pow(nrefr[1],2)+pow(nrefr[2],2));
	nrefr[0] = nrefr[0]/value;
	nrefr[1] = nrefr[1]/value;
	nrefr[2] = nrefr[2]/value;
      }
      
      else {
	
	/* Get the reference ring */
	sprintf(mes, "Give reference ring for warp angle calculation");
	while ((err)) {
	  userint_c(&rring, &nel, &def, tofchar("REFRING="), tofchar(mes));
	  if (rring <= 0 || rring > rpm -> nur) {
	    sprintf(mes, "REFRING: impossible number");
	    cancel_c(tofchar("REFRING="));
	    def = 4;
	  } 
	  else
	    err = 0;
	}
	
	/* Now get the normal vector of the reference ring */
	nrefr[0] = sinf(DEGTORAD*rpm -> par[PINCL*rpm -> nur+rring-1])*sinf(DEGTORAD*rpm -> par[PPA*rpm -> nur+rring-1]);
	nrefr[1] = -sinf(DEGTORAD*rpm -> par[PINCL*rpm -> nur+rring-1])*cosf(DEGTORAD*rpm -> par[PPA*rpm -> nur+rring-1]);
	nrefr[2] = cosf(DEGTORAD*rpm -> par[PINCL*rpm -> nur+rring-1]);
      }
      
      /* Now calculate the inclination of the rings with the refring */
      for (j = 0; j < rpm -> nur; ++j) {
	nv[0] = sin(DEGTORAD*rpm -> par[PINCL*rpm -> nur+j])*sin(DEGTORAD*rpm -> par[PPA*rpm -> nur+j]);
	nv[1] = -sin(DEGTORAD*rpm -> par[PINCL*rpm -> nur+j])*cos(DEGTORAD*rpm -> par[PPA*rpm -> nur+j]);
	nv[2] = cos(DEGTORAD*rpm -> par[PINCL*rpm -> nur+j]);
	
	/* Here is the scalar product with the reference ring */
	value = nv[0]*nrefr[0]+nv[1]*nrefr[1]+nv[2]*nrefr[2];
	
	/* This is the arcus */
	array[j] = value>1?0.0:RADTODEG*acos(value);
      }
      
      /* Now calculate the inclination of the subrings with the refring */
      for (j = 0; j < rpm -> nr; ++j) {
	nv[0] = sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*sin(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
	nv[1] = -sin(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j])*cos(DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j]);
	nv[2] = cos(DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j]);
	
	/* Here is the scalar product with the reference ring */
	value = nv[0]*nrefr[0]+nv[1]*nrefr[1]+nv[2]*nrefr[2];
	
	/* This is the arcus */
	larray[j] = value>1?0.0:RADTODEG*acos(value);
      }
    }
    else if (ident == DENS_GRAPHNR){

      /* We do it properly */
      for (j = 0; j < rpm -> nur; ++j) {
	vsys = rpm -> par[PVSYS*rpm -> nur+j];
	nu = (SPEEDOFLIGHT-vsys)*HIRESFREQ/SPEEDOFLIGHT;
	value = rpm -> par[PSBR*rpm -> nur+j];
	
	/* The intensity in the restframe scales like */
	array[j] = hdr -> itou*value*pow(HIRESFREQ/nu,4);
      }
      for (j = 0; j < rpm -> nr; ++j) {
	vsys = rpm -> modpar[PVSYS*rpm -> nr+j];
	nu = (SPEEDOFLIGHT-vsys)*HIRESFREQ/SPEEDOFLIGHT;
	value = rpm -> modpar [PSBR*rpm -> nr+j];
	
	/* The intensity in the restframe scales like */
	larray[j] = hdr -> itou*value*pow(HIRESFREQ/nu,4);
      }
    }
    else if (ident == TIP_GRAPHNR || ident == LON_GRAPHNR) {

      /* Ask for the reference position angle, default 0 */
      sprintf(mes, "Give Briggs reference position angle");
      br_pa = 0;
      def = 2;
      nel = 1;
      userdble_c(&br_pa, &nel, &def, tofchar("BR_PA="), tofchar(mes));
      
      /* Ask for the reference inclination, default 0 */
      sprintf(mes, "Give Briggs reference inclination");
      br_incl = 0;
      def = 2;
      nel = 1;
      userdble_c(&br_incl, &nel, &def, tofchar("BR_INCL="), tofchar(mes));

      /* Ask for the angle range, 0: 10-360, 1:-180-180 */
      sprintf(mes, "Give range for tiplon diagram 0: 10-360, 1:-180-180");
      gr_tlr = 0;
      def = 2;
      nel = 1;
      userint_c(&gr_tlr, &nel, &def, tofchar("GR_TLR="), tofchar(mes));

      
      /* Then get the stuff in radian */
      br_incl = DEGTORAD*br_incl;
      br_pa = DEGTORAD*br_pa;

      if (ident == TIP_GRAPHNR) {
	for (j = 0; j < rpm -> nur; ++j) {
	  
	  /* We get the radian position angle and the radian inclination */
	  nrefr[0] = DEGTORAD*rpm -> par[PINCL*rpm -> nur+j];
	  nrefr[1] = DEGTORAD*rpm -> par[PPA*rpm -> nur+j];
	  
	  /* Then we do this: */
	  value = sin(br_incl)*sin(nrefr[0])*cos(nrefr[1]-br_pa)+cos(br_incl)*cos(nrefr[0]);
	  array[j] = value>1?0.0:RADTODEG*acos(value);
  /**************/
  /**************/
/*  	  sprintf(obsmes, "tip: %.2f",array[j]);  */
/*     anyout_c(&obsint, tofchar(obsmes));  */
  /**************/

	}
	for (j = 0; j < rpm -> nr; ++j) {
	  
	  /* We get the radian position angle and the radian inclination */
	  nrefr[0] = DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j];
	  nrefr[1] = DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j];
	  
	  /* Then we do this: */
	  value = sin(br_incl)*sin(nrefr[0])*cos(nrefr[1]-br_pa)+cos(br_incl)*cos(nrefr[0]);
	  larray[j] = value>1?0.0:RADTODEG*acos(value);
	}
      }
      else {
	
	/* First scan for the first point where pa and incl are different */
	rescval = 0.0;
 	for (j = 0; j < rpm -> nr; ++j) { 
 	  nrefr[0] = DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j]; 
 	  nrefr[1] = DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j];

if (maths_checkeq(nrefr[0], br_incl, 1.0E-6) || maths_checkeq(nrefr[1], br_pa, FLOAT_ACCURACY)) {

	    x = sin(nrefr[0])*sin(nrefr[1]-br_pa);
	    y = -cos(br_incl)*sin(nrefr[0])*cos(nrefr[1]-br_pa)+sin(br_incl)*cos(nrefr[0]);

	    if (y == 0)
	      y = 1E-15;

	    rescval = (x/y);
	  
	    if ((x<=0) && (y > 0))
	      rescval = -atan(rescval);
	    if ((x>=0) && (y > 0))
	      rescval = TWOPI-atan(rescval);

	    if ((x>=0) && (y < 0))
	      rescval = TWOPI/2-atan(rescval);
	    if ((x<=0) && (y < 0))
	      rescval = TWOPI/2-atan(rescval);
	    break; 
	  }
	}

	/* Ask for the reference LON */
	sprintf(mes, "Give value for indefinite LON");
	gr_tll = RADTODEG*rescval;
	def = 2;
	nel = 1;
	userdble_c(&gr_tll, &nel, &def, tofchar("GR_TLL="), tofchar(mes));
	rescval = DEGTORAD*gr_tll;
/* sprintf(obsmes, "graph: %.2f", gr_tll); */
/* anyout_c(&obsint, tofchar(obsmes)); */


	for (j = 0; j < rpm -> nr; ++j) {
	  
	  /* We get the radian position angle and the radian inclination */
	  nrefr[0] = DEGTORAD*rpm -> modpar[PINCL*rpm -> nr+j];
	  nrefr[1] = DEGTORAD*rpm -> modpar[PPA*rpm -> nr+j];
	  
	  /* Then we do this: */
	  if (maths_checkeq(nrefr[0], br_incl, 1.0E-6) || maths_checkeq(nrefr[1], br_pa, FLOAT_ACCURACY)) {

	    x = sin(nrefr[0])*sin(nrefr[1]-br_pa);
	    y = -cos(br_incl)*sin(nrefr[0])*cos(nrefr[1]-br_pa)+sin(br_incl)*cos(nrefr[0]);

	    if (y == 0.0)
	      y = 1E-15;

	    value = (x/y);
	  
	    if ((x<=0) && (y > 0))
	      value = -atan(value);
	    if ((x>=0) && (y > 0))
	      value = TWOPI-atan(value);
	    if ((x>=0) && (y < 0))
	      value = TWOPI/2-atan(value);
	    if ((x<=0) && (y < 0))
	      value = TWOPI/2-atan(value);
	    else if ((x<=0) && (y == 0)) 
	      value = TWOPI/4;
	    else if ((x>=0) && (y == 0)) 
	      value = 3*TWOPI/4;
	  }
	  else 
	    value = rescval;

	  larray[j] = RADTODEG*value;
	  if ((gr_tlr)) {
	    if ((larray[j] > 180))
	      larray[j] = larray[j]-360.0;
	  }

	}
	for (j = 0; j < rpm -> nur; ++j) {
	  
	  /* We get the radian position angle and the radian inclination */
	  nrefr[0] = DEGTORAD*rpm -> par[PINCL*rpm -> nur+j];
	  nrefr[1] = DEGTORAD*rpm -> par[PPA*rpm -> nur+j];
	  
	  /* Then we do this: */
	  if (maths_checkeq(nrefr[0], br_incl, 1.0E-6) || maths_checkeq(nrefr[1], br_pa, FLOAT_ACCURACY)) {

	    x = sin(nrefr[0])*sin(nrefr[1]-br_pa);
	    y = -cos(br_incl)*sin(nrefr[0])*cos(nrefr[1]-br_pa)+sin(br_incl)*cos(nrefr[0]);


	    value = (x/y);

  /**************/
  /**************/
/* sprintf(obsmes, "graph: x: %.2f y: %.2f", x,y); */
/* anyout_c(&obsint, tofchar(obsmes)); */
  /**************/

	    if ((x<=0) && (y > 0))
	      value = -atan(value);
	    else if ((x>=0) && (y > 0))
	      value = TWOPI-atan(value);
	    else if ((x>=0) && (y < 0))
	      value = TWOPI/2-atan(value);
	    else if ((x<=0) && (y < 0))
	      value = TWOPI/2-atan(value);
	    else if ((x<=0) && (y == 0)) 
	      value = TWOPI/4;
	    else if ((x>=0) && (y == 0)) 
	      value = 3*TWOPI/4;
	  }
	  else 
	    value = rescval;
	  
	  array[j] = RADTODEG*value;

	  if ((gr_tlr)) {
	    if ((array[j] > 180))
	      array[j] = array[j]-360.0;
	  }
  /**************/
  /**************/
/* 	  sprintf(obsmes, "lon: %.2f",array[j]); */
/*    anyout_c(&obsint, tofchar(obsmes)); */
  /**************/

   

	}
      }
    }
  }
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a legend string suitable for the use in the pgp module */
static void gr_filllegend(int ident, char *string)
{
  if ((string))
    switch (ident) {
    case RADI:
      sprintf(string, "R: Radius");
      return;
    case VROT:
      sprintf(string, "VROT: Rotation velocity");
      return;
    case Z0:
      sprintf(string, "SCHT: Scaleheight");
      return;
    case SBR:
      sprintf(string, "SBR: Surface brightness");
      return;
    case INCL:
      sprintf(string, "INCL: Inclination");
      return;
    case PA:
      sprintf(string, "PA: Position angle");
      return;
    case XPOS:
      sprintf(string, "RA: Right ascension of centre");
      return;
    case YPOS:
      sprintf(string, "DEC: Declination of centre");
      return;
    case VSYS:
      sprintf(string, "VSYS: Systemic velocity");
      return;
    case WA_GRAPHNR:
      sprintf(string, "WA: Warp angle");
      return;
    case DENS_GRAPHNR:
      sprintf(string, "SD: Surface density");
      return;
    case WOLD_GRAPHNR:
      sprintf(string, "WAOL: Warp angle, old definition");
      return;
    case TIP_GRAPHNR:
      sprintf(string, "TIP: Tip angle");
      return;
    case LON_GRAPHNR:
      sprintf(string, "LON: LON angle");
      return;
    }
  
  return;
}

/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns the scale for one unit to the alternative unit */
static void gr_fillscaling(loginf *log, hdrinf *hdr, int ident, float *scale, float *zero)
{
  switch (ident) {
  case RADI:
    *scale = 1000.0*log -> distance*TWOPI/(360*60*60);
    *zero = 0.0;
    return;
  case VROT:
    *scale = 1.0;
    *zero = 0.0;
    return;
  case Z0:
    *scale = log -> distance*TWOPI/(360.0*60.0*60.0)*1000000.0;
    *zero = 0.0;
    return;
  case SBR:
    *scale = hdr -> itou;
    *zero = 0.0;
    return;
  case INCL:
    *scale = DEGTORAD;
    *zero = 0.0;
    return;
  case PA:
    *scale = DEGTORAD;
    *zero = 0.0;
    return;
  case XPOS:
    *scale = 1000.0*log -> distance*TWOPI*cos(fabs(log -> yref)*TWOPI/360.0)/360.0;
    *zero =  1000.0*(-log -> xref)*log -> distance*TWOPI*cos(fabs(log -> yref)*TWOPI/360.0)/360.0;
    return;
  case YPOS:
    *scale = 1000.0*log -> distance*TWOPI/360.0;
    *zero = 1000.0*(-log -> yref)*log -> distance*TWOPI/360.0;
    return;
  case VSYS:
    *scale = 1.0;
    *zero = 0.0;
    return;
  case WA_GRAPHNR:
    *scale = 1.0;
    *zero = 0.0;
    return;
  case DENS_GRAPHNR:
    *scale = UTOSOLAR;
    *zero = 0.0;
    return;
  case WOLD_GRAPHNR:
    *scale = 1.0;
    *zero = 0.0;
    return;
  case TIP_GRAPHNR:
    *scale = 1.0;
    *zero = 0.0;
    return;
  case LON_GRAPHNR:
    *scale = 1.0;
    *zero = 0.0;
    return;
  default:
    *scale = 1.0;
    *zero = 0.0;
  }
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Produces a renzogram with the rings */
static int renzo(loginf *log, hdrinf *hdr, ringparms *rpm)
{
  int i,j,k;
  char renzoname[21];
  char mes[81];
  fint def;
  fint nel;
  qfits_header *header = NULL;
  Cube thecube;
  int refine;

  double majhax;
  double minhax;
  double point[3];

  /**************/
   /**************/ 
/*   fint obsint = 0; */
/*   char obsmes[80]; */
  /**************/
    /**************/
    /**************/
/*     sprintf(obsmes, "got here"); */
/*     anyout_c(&obsint, tofchar(obsmes));  */
    /**************/

  /* First check if the user wants a renzogram output */
  sprintf(mes, "Give inclinogram name:");
  sprintf(renzoname, "                  ");
  def = 2;
  nel = 1;
  
  userchar_c(tofchar(renzoname), &nel, &def, tofchar("INCLINO="), tofchar(mes));
  termsinglestr(renzoname);
  
  /* The default is to do nothing */
  if (*renzoname == '\0')
    return 1;

  /* Ask for refinement */
  sprintf(mes, "Give inclinogram refinement:");
  def = 2;
  nel = 1;
  refine = 0;
  while (refine <= 0) {
    refine = 1;
    userint_c(&refine, &nel, &def, tofchar("IN_REFINE="), tofchar(mes));
    if (refine <= 0) {
      sprintf(mes, "IN_REFINE= must be greater than 0");
      def = 4;
    }
  }

  if (!(header = makerenzohdr(hdr, rpm -> nur, refine)))
    return 1;

  /* Now arrange the cube */
  thecube.refpix_x = 0;
  thecube.refpix_y = 0;
  thecube.refpix_v = 0;
  thecube.size_x = hdr -> bsize1*refine;
  thecube.size_y = hdr -> bsize2*refine;
  thecube.size_v = rpm -> nur;
  thecube.scale = 1.0;
  thecube.padding = 0;
  thecube.points = NULL;

  /* Allocate the cube */
  if (!(thecube.points = (float *) malloc(thecube.size_x*thecube.size_y*thecube.size_v*sizeof(float))))
    goto error;

  /* Now get the best-fit values and turn them into internal units */

  /* We read all values into the par array */
  ftstab_get_grid_(log -> outarray);

  for (j = 0; j < rpm -> nur*NPARAMS+NSPARAMS; ++j)
    rpm -> par[j] = log -> outarray[j];
  
  /* We convert to internal units and interpolate over */
  changetointern(rpm -> par, rpm -> nur, hdr);

  /* Now se go through the planes, and hence the rings */
  for (i = 0; i < thecube.size_v; ++i) {
    
    /* First calculate the major and the minor half axis */
    majhax = rpm -> par[PRADI*rpm -> nur+i]*refine;
    minhax = fabs(cos(rpm -> par[PINCL*rpm -> nur+i]))*majhax;

    /* Each point in the plane will be put to the origin, then be rotated back */
    for (j = 0; j < thecube.size_x; ++j) {
      for (k = 0; k < thecube.size_y; ++k) {
	point[0] = cos(rpm -> par[PPA*rpm -> nur+i])*(((double) j) - ((rpm -> par[PXPOS*rpm -> nur+i]+0.5)*refine-0.5))+sin(rpm -> par[PPA*rpm -> nur+i])*(((double) k) - ((rpm -> par[PYPOS*rpm -> nur+i]+0.5)*refine-0.5));
	point[1] = -sin(rpm -> par[PPA*rpm -> nur+i])*(((double) j) - ((rpm -> par[PXPOS*rpm -> nur+i]+0.5)*refine-0.5))+cos(rpm -> par[PPA*rpm -> nur+i])*(((double) k) - ((rpm -> par[PYPOS*rpm -> nur+i]+0.5)*refine-0.5));
	
	if ((minhax > 0.5)) {
	/* Now check if the position is inside an ellipse, if yes, the point is 1, if not 0 */
	if (((minhax*point[0])*(minhax*point[0])+(majhax*point[1])*(majhax*point[1])) > (minhax*minhax*majhax*majhax))
	  thecube.points[j+thecube.size_x*(k+thecube.size_y*i)] = 0;
	else
	  thecube.points[j+thecube.size_x*(k+thecube.size_y*i)] = 1;
	}
	else {

	/* We want to prevent that nothing is drawn, so we plot a line if minhax is 0 */
	  if (!maths_checkinbetw(1,-1,point[1]) && (point[0]*point[0] <= majhax*majhax))
	    thecube.points[j+thecube.size_x*(k+thecube.size_y*i)] = 1;
	  else
	    thecube.points[j+thecube.size_x*(k+thecube.size_y*i)] = 0;
	}
      }

    }

    /* If the major axis is 0, we draw a point */
    if (majhax < 1)
      thecube.points[roundnormal((rpm -> par[PXPOS*rpm -> nur+i]+0.5)*refine-0.5)+thecube.size_x*(roundnormal((rpm -> par[PYPOS*rpm -> nur+i]+0.5)*refine-0.5)+thecube.size_y*i)] = 1;
  }
  
  /* Output it */
  ftsout_writecube(renzoname, &thecube, header);
  
  /* Deallocate everything */
    ftsout_header_destroy(header);
    free(thecube.points);

    /* Return, deeply satisfied */
    return 0;

 error:
  if ((header))
    ftsout_header_destroy(header);
  if ((thecube.points))
    free((thecube.points));
  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Make a qfits header suitable for coolgal output */
static qfits_header *makerenzohdr(hdrinf *hdr, int planes, int refine) 
{
  char key[9], value[21];
  int j;
  fint level = 0;
  fint err = 0;
  qfits_header *header = NULL;

  /* The bitpix is -32 */
  if (!(header = ftsout_putcard(header, "BITPIX","-32"))) 
    goto error;

  /* The number of axes is set to three */
  if (!ftsout_putcard(header, "NAXIS","3")) 
    goto error;

  /* Now get the axis numbers */
  sprintf(value, "%i", hdr -> bsize1*refine);
  if (!ftsout_putcard(header, "NAXIS1",value))
    goto error;
  sprintf(value, "%i", hdr -> bsize2*refine);
  if (!ftsout_putcard(header, "NAXIS2",value))
    goto error;

  /* The third axis is simply the number of planes */
  sprintf(value, "%i", planes );
  if (!ftsout_putcard(header, "NAXIS3",value))
    goto error;

  /* May contain an extension */
  if (!ftsout_putcard(header, "EXTEND","T"))
    goto error;
  
  /* These are clear */
  if (!ftsout_putcard(header, "BSCALE","1"))
    goto error;
  if (!ftsout_putcard(header, "BZERO","0"))
    goto error;

  /* The bunit is nothing */
  if (!ftsout_putcard(header, "BUNIT","' '"))
    goto error;

  /* The cdelt is taken from the hdr struct, this should be ok with the unit being DEGREE*/  
  sprintf(value, "%.12E", hdr -> userglobcdelt[0]/refine);
  if (!ftsout_putcard(header, "CDELT1", value))
    goto error;

  /* The crpix is copied from the header of the inset */
  sprintf(value, "%.12E", (hdr -> setcrpix[0]-0.5)*refine+0.5);
  if (!ftsout_putcard(header, "CRPIX1", value))
    goto error;

  /* The crval in user units -> degree */
  sprintf(value, "%.12E", hdr -> userglobcrval[0]);
  if (!ftsout_putcard(header, "CRVAL1", value))
    goto error;

  /* This is nasty, because we have to re-read the info */
  sprintf(key, "CTYPE%i", hdr -> inaxperm[0]);
  for (j = 0; j < 20; ++j)
    value[j] = ' ';
  value[20] = '\0';
  gdsd_rchar_c(tofchar(hdr -> inset), tofchar(key), &(level), tofchar(value), &err);
  if (!ftsout_putcard(header, "CTYPE1", value))
    goto error;
  if (!ftsout_putcard(header, "CUNIT1", "'DEGREE            '"))
    goto error;
  
  /* The cdelt is taken from the hdr struct, this should be ok with the unit being DEGREE*/  
  sprintf(value, "%.12E", hdr -> userglobcdelt[1]/refine);
  if (!ftsout_putcard(header, "CDELT2", value))
    goto error;

  /* The crpix is copied from the header of the inset */
  sprintf(value, "%.12E", (hdr -> setcrpix[1]-0.5)*refine+0.5);
  if (!ftsout_putcard(header, "CRPIX2", value))
    goto error;

  /* The crval in user units -> degree */
  sprintf(value, "%.12E", hdr -> userglobcrval[1]);
  if (!ftsout_putcard(header, "CRVAL2", value))
    goto error;

  /* This is nasty, because we have to re-read the info */
  sprintf(key, "CTYPE%i", hdr -> inaxperm[1]);
  for (j = 0; j < 20; ++j)
    value[j] = ' ';
  value[20] = '\0';
  gdsd_rchar_c(tofchar(hdr -> inset), tofchar(key), &(level), tofchar(value), &err);
  if (!ftsout_putcard(header, "CTYPE2", value))
    goto error;
  if (!ftsout_putcard(header, "CUNIT2", "'DEGREE            '"))
    goto error;

  /* The third axis is the artificial one */

  /* The cdelt is 1 */
  sprintf(value, "%.12E", 1.0);
  if (!ftsout_putcard(header, "CDELT3", value))
    goto error;

/* crpix is at the start */
  sprintf(value, "%.12E", 1.0);
  if (!ftsout_putcard(header, "CRPIX3", value))
    goto error;

  /* This is exactly 0 */
  if (!ftsout_putcard(header, "CRVAL3", "1.0"))
    goto error;

  /* The type is somthing without projection, this should do */
  if (!ftsout_putcard(header, "CTYPE3", "' '"))
    goto error;

  /* This is nothing again */
  if (!ftsout_putcard(header, "CUNIT3", "' '"))
    goto error;

  return header;
  
 error:
  if ((header)) 
    ftsout_header_destroy(header);
  header = NULL;
  return header;
}

/* ------------------------------------------------------------ */

/*************/
/* Addendums under construction */
/*************/
/* #include "constr.c" */
/*************/

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: tirific.c,v $
   Revision 1.69  2011/05/10 00:30:16  jozsa
   Left work

   Revision 1.68  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.67  2007/08/22 15:58:45  gjozsa
   Left work

   Revision 1.66  2007/03/23 17:21:09  gjozsa
   Changed back the changes from rev. 1.64, instead corrected the gridding: If the velocity increases with channel number, the pa changes by 180 deg w.r.t version pre-1.64, otherways it stays. For post-1.64 one has to change the pa by changing its signum and adding or subtracting 180 deg.

   Revision 1.65  2007/02/23 10:28:10  gjozsa
   BUGFIX in tirout: Works now for TIRACC > 6. Enlargened accuracy in textlog.

   Revision 1.64  2007/01/17 15:54:52  gjozsa
   Changed coordinate system in srconst by mirroring pp[0] to get a right hand coordinate system. In order not to change the pa definition changed the conversion functions interntoglob globtointern etc. Also did some changes to the graphics functions of which I don't know the effect. One can spot the changes via searching for 180.0 and DEGTORAD in the source

   Revision 1.63  2006/12/11 12:42:07  gjozsa
   BUGFIX: removed reading beam from header: too much confusion

   Revision 1.62  2006/11/22 14:16:21  gjozsa
   Bugfix concerning RASH and horizontal/vertical lines

   Revision 1.61  2006/11/10 15:53:10  gjozsa
   minor bugfix

   Revision 1.60  2006/11/09 14:42:55  gjozsa
   minor change

   Revision 1.59  2006/11/08 14:05:03  gjozsa
   included line drawing with keywords GR_VERL_i GR_HORL_i GR_VLVA_i GR_HLVA_i GR_VLCA_i GR_HLCA_i

   Revision 1.58  2006/11/03 12:08:59  gjozsa
   Small bugfix

   Revision 1.57  2006/11/03 10:57:38  gjozsa
   Introduced logarithmic scaling keywords: GR_XLOG, GR_YLOG_i, introduced hms dms for xpos and ypos in graphics output, introduced keywords RFREQ (restfrequency in Hertz) and ITOU (conversion factor from intensity in Jy/squarearcsec in u/squarecentimeter), changed DOUBLE_ACCURACY to 3E-15 to account for near zero events

   Revision 1.56  2006/07/18 09:33:02  gjozsa
   Left work

   Revision 1.55  2006/04/11 11:46:00  gjozsa
   Removed the positive SBR restriction in input

   Revision 1.54  2006/04/06 10:40:25  gjozsa
   Bugfix: Call of engalmod_chflgs() after changing the input cube after chisquare initialisation

   Revision 1.53  2006/04/03 11:47:57  gjozsa
   Left work

   Revision 1.52  2005/10/12 14:50:59  gjozsa
   Not really a Bugfix: Corrected the calculation of the ring normal vector

   Revision 1.51  2005/10/12 09:53:45  gjozsa
   Included Brigg's plots

   Revision 1.50  2005/09/29 17:46:00  gjozsa
   BUGFIX in the golden_section() function: refreshing pointsource lists is a crucial point

   Revision 1.49  2005/08/25 10:15:05  gjozsa
   Slight bug in the plot routines

   Revision 1.48  2005/08/18 13:06:52  gjozsa
   Left work

   Revision 1.47  2005/08/15 13:15:03  gjozsa
   BUGFIX: At 12523, not copying to the par array will result in funny results, when the only output is a .def file. Don't know whether this will cause sequals

   Revision 1.45  2005/07/27 14:27:34  gjozsa
   Again improved the graphics output

   Revision 1.44  2005/07/27 14:01:30  gjozsa
   Improved the graphics output

   Revision 1.43  2005/06/28 13:28:08  gjozsa
   Changed the out of range behaviour in golden_section()

   Revision 1.42  2005/06/24 16:44:51  gjozsa
   added interpolation possibility for the TIRDEF= output, not yet for TIRSMOOTH=

   Revision 1.41  2005/06/24 12:00:30  gjozsa
   Left work

   Revision 1.43  2005/06/17 14:56:45  gjozsa
   Bugfix

   Revision 1.42  2005/06/17 14:50:45  gjozsa
   Bugfix

   Revision 1.41  2005/06/17 14:23:48  gjozsa
   Added penalty for outliers

   Revision 1.40  2005/06/13 10:40:29  gjozsa
   Added possibility just to examine results

   Revision 1.39  2005/06/09 14:07:45  gjozsa
   Left work

   Revision 1.38  2005/06/09 08:22:58  gjozsa
   BUGFIX: Multiple Parameter fitting was not working properly, fixed that

   Revision 1.37  2005/05/25 15:47:39  gjozsa
   Added inclinogram output

   Revision 1.36  2005/05/24 15:59:08  gjozsa
   Added LON and LMV to table output

   Revision 1.34  2005/05/24 10:42:03  gjozsa
   Included graphics

   Revision 1.33  2005/05/03 12:42:18  gjozsa
   Left work

   Revision 1.32  2005/04/28 12:44:44  gjozsa
   bugfix

   Revision 1.31  2005/04/28 10:13:47  gjozsa
   Full introduction of pointsource lists

   Revision 1.28  2005/04/26 11:44:53  gjozsa
   Seems to work

   Revision 1.25  2005/04/20 14:33:39  gjozsa
   bug

   Revision 1.24  2005/04/20 13:26:25  gjozsa
   Left work

   Revision 1.23  2005/04/19 13:58:50  gjozsa
   Left work

   Revision 1.22  2005/04/19 15:29:28  gjozsa
   Finished the output functions

   Revision 1.21  2005/04/19 10:59:13  gjozsa
   Extended the possibilities for the histogram output

   Revision 1.19  2005/04/19 07:44:43  gjozsa
   Left work

   Revision 1.18  2005/04/18 15:53:40  gjozsa
   Added histogram functions

   Revision 1.17  2005/04/18 15:02:02  gjozsa
   Included TIR functions

   Revision 1.16  2005/04/15 15:52:09  gjozsa
   Left work

   Revision 1.15  2005/04/15 15:39:13  gjozsa
   Bugfix: in fct get_ringparms, documented as BUGFIX , in fct decodestring, also reported

   Revision 1.14  2005/04/14 14:26:05  gjozsa
   Left work

   Revision 1.13  2005/04/14 10:32:16  gjozsa
   Left work

   Revision 1.10  2005/04/12 14:54:33  gjozsa
   Changed the character of PARMAX= and PARMIN=

   Revision 1.9  2005/04/11 14:23:37  gjozsa
   Left work

   Revision 1.8  2005/04/08 15:30:40  gjozsa
   Taking into account the whole cube now, no counting for the user

   Revision 1.7  2005/04/08 07:27:44  gjozsa
   Bugfixes

   Revision 1.6  2005/04/08 07:25:59  gjozsa
   Bugfixes

   Revision 1.5  2005/04/07 15:15:16  gjozsa
   Bugfix in galmod(): subring velocity was overwritten by a radius, I hacked a bit, not nic at the moment

   Revision 1.3  2005/04/06 15:46:25  gjozsa
   Bugfixes, included monitoring of golden_section

   Revision 1.2  2005/04/05 16:06:06  gjozsa
   Left work

   Revision 1.1  2005/04/05 11:07:37  gjozsa
   The former tiridev, officially release 1

   Revision 1.41  2005/04/04 08:42:09  gjozsa
   removed bug

   Revision 1.40  2005/04/01 15:31:54  gjozsa
   Introduced writecubup and a lot of debugging, check whether the output is not too large

   Revision 1.39  2005/03/29 15:56:24  gjozsa
   left work

   Revision 1.36  2005/03/25 18:17:20  gjozsa
   Left work

   Revision 1.35  2005/03/23 17:48:49  gjozsa
   Implemented hdu_3 support, seems to work

   Revision 1.32  2005/03/23 13:44:33  gjozsa
   Implemented and tested 2nd hdu i/o

   Revision 1.31  2005/03/22 17:48:07  gjozsa
   Left work

   Revision 1.30  2005/03/21 18:54:17  gjozsa
   Left work

   Revision 1.29  2005/03/19 17:55:52  gjozsa
   Left work

   Revision 1.26  2005/03/17 18:00:50  gjozsa
   Left work

   Revision 1.25  2005/03/16 17:52:00  gjozsa
   Left work

   Revision 1.23  2005/03/15 18:53:08  gjozsa
   Left work

   Revision 1.22  2005/03/15 17:28:59  gjozsa
   Last changes to get a clear program structure, not ideal, but ok. Some debugging, deleting the fortran thingies

   Revision 1.21  2005/03/12 16:48:33  gjozsa
   Removed all clutter from readringparms and associated structs

   Revision 1.19  2005/03/12 13:24:49  gjozsa
   Removed all clutter from hdrinit

   Revision 1.17  2005/03/12 11:37:46  gjozsa
   Rearranged completely galmod, debugged and tested version of new galmod, including convolution routines, changed position angle to angle with respect to minor

   Revision 1.16  2005/03/11 17:45:55  gjozsa
   Left work

   Revision 1.15  2005/03/10 17:56:39  gjozsa
   Left work

   Revision 1.13  2005/03/08 17:55:07  gjozsa
   Left work

   Revision 1.12  2005/03/05 17:56:09  gjozsa
   Left work

   Revision 1.11  2005/03/04 18:13:53  gjozsa
   Left work

   Revision 1.10  2005/03/03 18:00:49  gjozsa
   Left work

   Revision 1.9  2005/03/02 17:56:09  gjozsa
   Left work

   Revision 1.8  2005/03/01 17:46:21  gjozsa
   Left work

   Revision 1.6  2005/02/25 18:13:08  gjozsa
   Left work

   Revision 1.5  2005/02/25 13:34:29  gjozsa
   cube io finished

   Revision 1.4  2005/02/25 11:38:27  gjozsa
   Created a header struct

   Revision 1.3  2005/02/24 17:48:46  gjozsa
   Left work

   Revision 1.2  2004/12/09 16:17:14  gjozsa
   Changed some floating point operations from double to float accuracy

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


   ------------------------------------------------------------ */
