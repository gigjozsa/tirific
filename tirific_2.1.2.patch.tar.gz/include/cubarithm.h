/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file cubarithm.h
   @brief Simple arithmetics with Cubes

   This module contains all mathematical operations done solely on
   cubes as a stand-alone. All operations that work on cubes alone are
   packed in here, while interfacing between Cubes and other internal
   structures (as Pointsource ll's) is defined and documented
   elsewhere.
   
   $Source: /Volumes/DATA_J_II/data/CVS/tirific/include/cubarithm.h,v $
   $Date: 2009/05/26 07:56:39 $
   $Revision: 1.3 $
   $Author: jozsa $
   $Log: cubarithm.h,v $
   Revision 1.3  2009/05/26 07:56:39  jozsa
   Left work

   Revision 1.2  2007/08/22 15:58:33  gjozsa
   Left work

   Revision 1.1.1.1  2004/10/29 11:13:05  gjozsa
   Added to CVS control


*/
/* ------------------------------------------------------------ */



/* Include guard */
#ifndef CUBARITHM_H
#define CUBARITHM_H


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <globals.h>


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* MACROS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* TYPEDEFS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* STRUCTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
    @fn void *cuberase(Cube *cube)
    @brief Setting all pixels in a Cube cube to 0.
    
    @param cube (Cube *) The input cube
    
    @return void
*/
/* ------------------------------------------------------------ */
void cuberase(Cube *cube);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn float *findpixel(Cube *cube, int x, int y, int v)
  @brief Finds the member of the array in cube corresponding to
  the absolute coordinates x, y, v.

  @param cube (Cube *) The input cube
  @param x    (int)    x coordinate
  @param y    (int)    y coordinate
  @param v    (int)    v coordinate

  @return (success) float *findpixel: Pointer to the pixel\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
float *findpixel(Cube *cube, int x, int y, int v);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn float *findpixelrel(Cube *cube, int x, int y, int v, int padding)
  @brief Find the relative pixel in a Cube

  Finds the member of the array in cube corresponding to the relative
  coordinates x, y, z with an explicite padding.

  @param cube    (Cube *) The input cube
  @param x       (int)    relative x coordinate
  @param y       (int)    relative y coordinate
  @param v       (int)    relative v coordinate
  @param padding (int)    Padding

  @return (success) float *findpixelrel: Pointer to the pixel\n
          (error) NULL

*/
/* ------------------------------------------------------------ */
float *findpixelrel(Cube *cube, int x, int y, int v, int padding);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn int *calcbordergauss(float sigma_maj, float sigma_min, float sigma_v, float *cossinpa, float n)
  @brief Returns the measure of a cube containing an ellipsoid

  Returns an allocated array of the measure of a cube just large
  enough to contain an ellipsoid decribed by the parameters. The
  ellipsoid has the axes sigma_min/2 in x-direction, sigma_max/2 in y
  direction, sigma_v/2 in v-direction and is then rotated
  counterclockwise about the v-axis with the angle pa, and finally
  inflated by a factor n. The output has to be deallocated

  @param sigma_maj (float)   Diameter of ellipsoid in y-direction 
  before rotation
  @param sigma_min (float)   Diameter of ellipsoid in x-direction 
  before rotation
  @param sigma_v   (float)   Diameter of ellipsoid in v-direction
  @param cossinpa  (float *) Array with sin and cos of the rotation 
  angle of the ellipsoid (couterclockwise) in the xy-plane
  @param n         (float)   Factor to inflate ellipsoid

  @return int *calcbordergauss Cube diameter in x, y, and v direction
*/
/* ------------------------------------------------------------ */
int *calcbordergauss(float sigma_maj, float sigma_min, float sigma_v, float *cossinpa, float n);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn Cube *padcubex(Cube *cube)
  @brief Change the padding in a cube
  
  Change the padding of a cube. Some routines will need a padded cube
  for a calculation. padcubex will automatically change the padding to
  the right value, either back or forth.

  @param cube (Cube *) The cube

  @return (success) Cube *padcubex: The same cube with different 
  padding\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
Cube *padcubex(Cube *cube);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn Cube *addcubes(Cube *cube1, Cube *cube2)
  @brief Adds cubes in the overlapping region

  Adds cube2 to cube1 in the overlapping region. cube1 will be
  replaced with the result.

  @param cube1 (Cube *) Cube on which the other cube will be added
  @param cube2 (Cube *) Cube added to cube1 in the overlapping region

  @return (success) Cube  *addcubes: The same pointer to the cube1 passed into the function\n
          (error) NULL

*/
/* ------------------------------------------------------------ */
Cube *addcubes(Cube *cube1, Cube *cube2);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: cubarithm.h,v $
   Revision 1.3  2009/05/26 07:56:39  jozsa
   Left work

   Revision 1.2  2007/08/22 15:58:33  gjozsa
   Left work

   Revision 1.1.1.1  2004/10/29 11:13:05  gjozsa
   Added to CVS control


   ------------------------------------------------------------ */

/* Include guard */
#endif
