/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file ftsoutput.h 

   @brief Producing fits output

   This module has the only purpose to encapsulate the qfits the fftw
   library and some convolution functionality in this module. Is maybe
   a bit dull.

   $Source: /Volumes/DATA_J_II/data/CVS/tirific/include/ftsoutput.h,v $
   $Date: 2011/05/25 22:25:25 $
   $Revision: 1.5 $
   $Author: jozsa $
   $Log: ftsoutput.h,v $
   Revision 1.5  2011/05/25 22:25:25  jozsa
   Left work

   Revision 1.4  2009/05/26 07:56:39  jozsa
   Left work

   Revision 1.3  2007/08/22 15:58:33  gjozsa
   Left work

   Revision 1.2  2005/04/19 15:29:41  gjozsa
   Left work

   Revision 1.1  2005/04/14 10:32:03  gjozsa
   Added to cvs control

*/
/* ------------------------------------------------------------ */



/* Include guard */
#ifndef FTSOUTPUT_H
#define FTSOUTPUT_H



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */

/* added for qfits */
#include <qfits.h>


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def _MEMORY_HERE_ON
   @brief Controls the use of the memory_here module

   If you don't want to use the memory_here facility comment this
   define, otherways it will be included.

*/
/* ------------------------------------------------------------ */
#define _MEMORY_HERE_ON
/* #include <memory_here.h> */
/* #include <maths.h> */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* MACROS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* GLOBAL VARIABLES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* TYPEDEFS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* STRUCTS */
/* ------------------------------------------------------------ */

/* include guard */
#ifndef QHEADER_DEFINED
#define QHEADER_DEFINED

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct 
   @brief A header struct 

   Structure to be used in some functions. A list of header items that
   can be accessed by the module functions.
*/
/* ------------------------------------------------------------ */
/* typedef struct qfits_header { */
/*         void *  first ;         /\* Pointer to list start *\/ */
/*         void *  last ;          /\* Pointer to list end *\/ */
/*         int     n ;             /\* Number of cards in list *\/ */
/* } qfits_header ; */

#endif

/* Some define guard */
#ifndef CUBE_DEFINED
#define CUBE_DEFINED

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Cube
   @brief A datacube with absolute position information

   A datacube. According to the internal coordinate structure its
   position is determined by the reference pixel (the coordinates of
   the first pixel points[0] in the adopted coordinate system. The
   left lowest pixel of the reference cube is the origin) and the
   size. The array with the data is ordered not exactly according to
   fits rules. x is axis1, y axis2, and v axis 3, i.e. pixel (x,y,z)
   is points[x+cube.size_x*(y+cube.size_y*z)]

   Layout: 
   @li @c int @c refpix_x         x-coordinate of the reference pixel
   @li @c int @c refpix_y         y-coordinate of the reference pixel
   @li @c int @c refpix_v         v-coordinate of the reference pixel
	    
   @li @c int @c size_x           size in pixels in x direction
   @li @c int @c size_y           size in pixels in y direction
   @li @c int @c size_v           size in pixels in v direction

   @li @c float @c scale          a scale factor
   @li @c int @c padding          number of pixels the cube is padded with
   @li @c float @c *points        array of floats containing the information
*/
/* ------------------------------------------------------------ */
typedef struct Cube
{
  /** @brief x-coordinate of the reference pixel */
  int refpix_x;
  /** @brief y-coordinate of the reference pixel */
  int refpix_y;
  /** @brief v-coordinate of the reference pixel */
  int refpix_v;

  /** @brief size in pixels in x direction */
  int size_x;
  /** @brief size in pixels in y direction */
  int size_y;
  /** @brief size in pixels in v direction */
  int size_v;

  /** @brief a scale factor */
  float scale;
  /** @brief number of pixels the cube is padded with */
  int padding;

  /** @brief array of floats containing the information */
  float *points;
} Cube;

#endif

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn qfits_header *qfits_header_update(qfits_header *old, qfits_header *new)
  @brief Update an old header with a new one

  Updates a qfits header old object with the header object new
  following the rules:
  @li Every card of new that exists in old will be overwritten. If
  there are multiple cards except COMMENT, the last card with the same
  keyword in old will be written into old instead of the card with the
  same keyword in old.
  @li every COMMENT HISTORY or blank card will be appended to old.
  @li cards that don't exist in new will stay the same

  @param old (qfits_header *) The header object to be updated
  @param new (qfits_header *) The header object with which the old
  header will be updated.

  @return (success) qfits_header *qfits_header_update: Pointer to the
  updated old header \n
          (error) NULL
*/
/* ------------------------------------------------------------ */
qfits_header *qfits_header_update(qfits_header *old, qfits_header *new);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn int ftsout_putcard(qfits_header *old, char *key, char *value)
   @brief Add a card to a header

   Adds a card with the keyword *key (8 characters) to a header with
   the value contained in value. Except for a blank HISTORY or COMMENT
   key, the function will update header items if they are already
   present. For a blank, HISTORY, or COMMENT key, the values are
   appended. In case of a blank, HISTORY, or COMMENT key, the value
   may contain 70 characters, in all other cases, it may contain 20
   characters. For a string it should contain 18 cahracters. For this
   the user has to care. If no header struct is passed (NULL as first
   argument), ftsout_putcard will create a standard primary header.

   @param old (qfits_header *) A qfits header item or NULL
   @param key    (char *)         A keyword
   @param value  (char *)         The value of the keyword

   @return (success) qfits_header *ftsout_putcard: The input or an allocated object \n
           (error) NULL
 */
/* ------------------------------------------------------------ */
qfits_header *ftsout_putcard(qfits_header *old, char *key, char *value);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @fn void ftsout_header_destroy(qfits_header *header)
   @brief Synonyme of qfits_header_destroy

   Destroys the header item header.

   @param header (qfits_header *) A properly created qfits_header

   @return void
*/
/* ------------------------------------------------------------ */
void ftsout_header_destroy(qfits_header *header);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn int *ftsout_writecube(char *filename, Cube *cubename, qfits_header *header)
  @brief Write a cube using the reference frame in header

  Writes the cube cubename into the fitsfile filename, using the
  information about the coordinate system in the qfits_header
  structure as reference coordinate system.

  @param filename (char *) FITS file to be written
  @param cubename (Cube *) Cube structure to be written.
  @param header   (qfits_header *) qfits_header structure with 
  reference frame information

  @return (success) int writecube: 1\n
          (error) 0
*/
/* ------------------------------------------------------------ */
int ftsout_writecube(char *filename, Cube *cubename, qfits_header *header); 



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn int *ftsout_writeimage(char *filename, float *array, qfits_header *header, int nx, int ny)
  @brief Writes an image to a file filename

  Writes the fits image filename with BITPIX= -32.

  @param filename (char *)         FITS file to be written
  @param array    (float *)        Array with the points to be written
  @param header   (qfits_header *) qfits_header structure with complete information
  @param nx       (int)            size of image in x-direction
  @param ny       (int)            size of image in y-direction
  @return (success) int writecube: 1\n
          (error) 0
*/
/* ------------------------------------------------------------ */
int ftsout_writeimage(char *filename, float *array, qfits_header *header, int nx, int ny); 



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: ftsoutput.h,v $
   Revision 1.5  2011/05/25 22:25:25  jozsa
   Left work

   Revision 1.4  2009/05/26 07:56:39  jozsa
   Left work

   Revision 1.3  2007/08/22 15:58:33  gjozsa
   Left work

   Revision 1.2  2005/04/19 15:29:41  gjozsa
   Left work

   Revision 1.1  2005/04/14 10:32:03  gjozsa
   Added to cvs control


   ------------------------------------------------------------ */

/* Include guard */
#endif

