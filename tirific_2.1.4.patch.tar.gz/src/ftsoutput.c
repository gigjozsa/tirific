/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file ftsoutput.c
   @brief Producing fits output

   This module has the only purpose to encapsulate the qfits the fftw
   library and some convolution functionality in this module. Is maybe
   a bit dull.

   $Source: /Volumes/DATA_J_II/data/CVS/tirific/src/ftsoutput.c,v $
   $Date: 2011/05/25 22:25:26 $
   $Revision: 1.7 $
   $Author: jozsa $
   $Log: ftsoutput.c,v $
   Revision 1.7  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.6  2011/05/10 00:30:15  jozsa
   Left work

   Revision 1.5  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.4  2007/08/22 15:58:40  gjozsa
   Left work

   Revision 1.3  2005/04/20 13:26:25  gjozsa
   Left work

   Revision 1.2  2005/04/19 15:29:28  gjozsa
   Finished the output functions

   Revision 1.1  2005/04/14 10:32:02  gjozsa
   Added to cvs control

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


*/
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */

#include <qfits.h>
#include <ftsoutput.h>

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def _MEMORY_HERE_ON
   @brief Controls the use of the memory_here module

   If you don't want to use the memory_here facility comment this
   define, otherways it will be included.

*/
/* ------------------------------------------------------------ */
/* #define _MEMORY_HERE_ON */
/* #include <memory_here.h> */
#include <maths.h>
#include <cubarithm.h>


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE MACROS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* (PRIVATE) GLOBAL VARIABLES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE TYPEDEFS */
/* ------------------------------------------------------------ */




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE STRUCTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION CODE */
/* ------------------------------------------------------------ */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Update an old header with a new one */

qfits_header *qfits_header_update(qfits_header *old, qfits_header *new)
{
  qfits_header *dummy;
  int i;
  char key[9],value[72],comment[72], appendline[9], *string, string2[9];

  /* Ensure that a copy is possible, at least very crudely */
  if (!(new && old && (dummy = qfits_header_copy(new))))
    return NULL;
  else {
    qfits_header_destroy(dummy);
  }
  
  /* Now we think that we can append new to old */
  
  /* check for the first comment in old */
  for (i = 0; i < old -> n; ++i) {
	qfits_header_getitem(old, i, key, NULL, NULL, NULL);
	if (!(strcmp(key,"COMMENT") && strcmp(key,"HISTORY") && strcmp(key,""))) {
	  break;
	}
  }
  
    /* If we got to the end we must take one step back */
  if (i == old -> n)
    --i;

/* This is the line where things are appended if they are not a comment */
  qfits_header_getitem(old, i-1, appendline, NULL, NULL, NULL);

  /* Now go through new */
  for (i = 0; i < new -> n; ++i) {
	qfits_header_getitem(new, i, key, value, comment, NULL);

	if((string = qfits_header_findmatch(old, key))){
	  sprintf(string2,"%s",string);
	}

	/* if we encounter a comment the whole card will be appended to the end of old */
	if (!(strcmp(key,"COMMENT") && strcmp(key,"HISTORY") && strcmp(key,""))) {

	  /* qfits reads the comment as a value */
	  qfits_header_add(old, key, value, NULL, NULL);
	}
	/* Everything else is being modified */

	/* if we find the matching key replace it */
	else if (!strcmp(string2, key)) {
	    qfits_header_mod(old, key, value, comment);
	}

	/* if we don't find it we append it to the body containing valuable information */
	else {
	  qfits_header_add_after(old, appendline, key, value, comment, NULL);
	}
  }

  /* That's it */
  return old;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Update an old header with a new card */

qfits_header *ftsout_putcard(qfits_header *old, char *key, char *value)
{
  qfits_header *new;
  int i;
  char keyl[9],valuel[72],comment[72], appendline[9], *string, string2[9];

  /* If old is NULL, we create old */
  if (!(old)) {
    if (!(old = qfits_header_default()))
      return NULL;
  }

  /* Make one header with the valuel */
  if (!(new = qfits_header_new())) {
    qfits_header_destroy(old);
    return NULL;
  }
  qfits_header_append(new, key, value, NULL, NULL);

  /* Now we think that we can append new to old */
  
  /* check for the first comment in old */
  for (i = 0; i < old -> n; ++i) {
    qfits_header_getitem(old, i, keyl, NULL, NULL, NULL);
    if (!(strcmp(keyl,"COMMENT") && strcmp(keyl,"HISTORY") && strcmp(keyl,""))) {
      break;
    }
  }
  
  /* If we got to the end we must take one step back */
  if (i == old -> n)
    --i;


  /* This is the line where things are appended if they are not a comment */
  qfits_header_getitem(old, i-1, appendline, NULL, NULL, NULL);
  
  /* Now go through new */
  for (i = 0; i < new -> n; ++i) {
    qfits_header_getitem(new, i, keyl, valuel, comment, NULL);
    
    if((string = qfits_header_findmatch(old, keyl))){
      sprintf(string2,"%s",string);
    }
    
    /* if we encounter a comment the whole card will be appended to the end of old */
    if (!(strcmp(keyl,"COMMENT") && strcmp(keyl,"HISTORY") && strcmp(keyl,""))) {
      
      /* qfits reads the comment as a valuel */    
      qfits_header_add(old, keyl, valuel, NULL, NULL);
    }
    /* Everything else is being modified */
    
    /* if we find the matching keyl replace it */
    else if (!strcmp(string2, keyl)) {
      qfits_header_mod(old, keyl, valuel, comment);
    }
    
    /* if we don't find it we append it to the body containing valuable information */
    else {
      qfits_header_add_after(old, appendline, keyl, valuel, comment, NULL);
    }
  }

  qfits_header_destroy(new);
  return old;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Synonyme of qfits_header_destroy */
void ftsout_header_destroy(qfits_header *header)
{
  qfits_header_destroy(header);
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Write a cube using the reference frame in header */

int ftsout_writecube(char *filename, Cube *cubename, qfits_header *header)
{
  FILE *output;
  qfits_header *outheader;
  qfitsdumper qdumper;
  char value[21];
  char *comment;

  /* quickly check if the cube is there */
  if ((!cubename) || (!(*cubename).points))
    return 0;

  /* open the file and check if writeable */
  if ((output = fopen(filename,"w")) == 0)
    return 0;

  /* Now copy the header */
  outheader = qfits_header_copy(header);

  /* The changes to be made is the size of the cube, and the reference
     pixel. All other stuff has been done before */

  /* size of the cube */
  comment = qfits_header_getcom(outheader,"NAXIS1");
  sprintf(value,"%u",(*cubename).size_x);
  qfits_header_mod(outheader,"NAXIS1",value,comment);
  
  comment = qfits_header_getcom(outheader,"NAXIS2");
  sprintf(value,"%u",(*cubename).size_y);
  qfits_header_mod(outheader,"NAXIS2",value,comment);
  
  comment = qfits_header_getcom(outheader,"NAXIS3");
  sprintf(value,"%u",(*cubename).size_v);
  qfits_header_mod(outheader,"NAXIS3",value,comment);
  
  /* reference pixel */
  comment = qfits_header_getcom(outheader,"CRPIX1");
  sprintf(value,"%0.13E",qfits_header_getdouble(outheader,"CRPIX1",0)-(double)(*cubename).refpix_x);
  qfits_header_mod(outheader,"CRPIX1",value,comment);
  
  comment = qfits_header_getcom(outheader,"CRPIX2");
  sprintf(value,"%0.13E",qfits_header_getdouble(outheader,"CRPIX2",0)-(double)(*cubename).refpix_y);
  qfits_header_mod(outheader,"CRPIX2",value,comment);
  
  comment = qfits_header_getcom(outheader,"CRPIX3");
  sprintf(value,"%0.13E",qfits_header_getdouble(outheader,"CRPIX3",0)-(double)(*cubename).refpix_v);
  qfits_header_mod(outheader,"CRPIX3",value,comment);
  
  comment = qfits_header_getcom(outheader,"BSCALE");
  sprintf(value,"%0.13E", (double)(*cubename).scale);
  qfits_header_mod(outheader,"BSCALE",value,comment);

  /* Now write the modified header in the file and close it */
  qfits_header_dump(outheader,output);
  fclose(output);

  /* check the padding */
  if ((*cubename).padding)
    padcubex(cubename);
  
  /* Fill the qdumper fields */
  qdumper.filename = filename;
  qdumper.npix = (*cubename).size_x*(*cubename).size_y*(*cubename).size_v;
  qdumper.ptype = PTYPE_FLOAT;
  qdumper.fbuf = (*cubename).points;
  qdumper.out_ptype = BPP_IEEE_FLOAT;
     
  /* write the cube */
  qfits_pixdump(&qdumper);

  /* now pad the fitsfile with zeros */
  qfits_zeropad(filename);
  
  /* don't forget to destroy the header */
  
  qfits_header_destroy(outheader);

  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Write a cube using the reference frame in header */

int ftsout_writeimage(char *filename, float *array, qfits_header *header, int nx, int ny)
{
  FILE *output;
  qfitsdumper qdumper;
  char value[21];

  /* quickly check if the cube is there */
  if (!array)
    return 0;

  /* open the file and check if writeable */
  if ((output = fopen(filename,"w")) == 0)
    return 0;

  /* The pressing changes to be made is the sizes and the naxis keyword */
  sprintf(value,"%u", nx);
  ftsout_putcard(header, "NAXIS1", value);

  sprintf(value,"%u", ny);
  ftsout_putcard(header, "NAXIS2", value);

  sprintf(value,"%0.12E", 1.0);
  ftsout_putcard(header, "BSCALE", value);

  sprintf(value,"%0.12E", 0.0);
  ftsout_putcard(header, "BZERO", value);

  /* Now write the modified header in the file and close it */
  qfits_header_dump(header,output);
  fclose(output);

  /* Fill the qdumper fields */
  qdumper.filename = filename;
  qdumper.npix = nx*ny;
  qdumper.ptype = PTYPE_FLOAT;
  qdumper.fbuf = array;
  qdumper.out_ptype = BPP_IEEE_FLOAT;

  /* write the cube */
  qfits_pixdump(&qdumper);

  /* now pad the fitsfile with zeros */
  qfits_zeropad(filename);

  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: ftsoutput.c,v $
   Revision 1.7  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.6  2011/05/10 00:30:15  jozsa
   Left work

   Revision 1.5  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.4  2007/08/22 15:58:40  gjozsa
   Left work

   Revision 1.3  2005/04/20 13:26:25  gjozsa
   Left work

   Revision 1.2  2005/04/19 15:29:28  gjozsa
   Finished the output functions

   Revision 1.1  2005/04/14 10:32:02  gjozsa
   Added to cvs control


   ------------------------------------------------------------ */
