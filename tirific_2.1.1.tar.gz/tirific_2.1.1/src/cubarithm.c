/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file cubarithm.c
   @brief Simple arithmetics with Cubes

   This module contains all mathematical operations done solely on
   cubes as a stand-alone. All operations that work on cubes alone are
   packed in here, while interfacing between Cubes and other internal
   structures (as Pointsource ll's) is defined and documented
   elsewhere.

   $Source: /Volumes/DATA_J_II/data/CVS/tirific/src/cubarithm.c,v $
   $Date: 2011/05/25 22:25:26 $
   $Revision: 1.6 $
   $Author: jozsa $
   $Log: cubarithm.c,v $
   Revision 1.6  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.5  2011/05/10 00:30:15  jozsa
   Left work

   Revision 1.4  2009/05/26 07:56:40  jozsa
   Left work

   Revision 1.3  2007/08/23 15:23:25  gjozsa
   Left work

   Revision 1.2  2007/08/22 15:58:40  gjozsa
   Left work

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


*/
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */

#include <cubarithm.h>

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def _MEMORY_HERE_ON
   @brief Controls the use of the memory_here module

   If you don't want to use the memory_here facility comment this
   define, otherways it will be included.

*/
/* ------------------------------------------------------------ */
/* #define _MEMORY_HERE_ON */
/* #include <memory_here.h> */
#include <maths.h>



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE MACROS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* (PRIVATE) GLOBAL VARIABLES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE TYPEDEFS */
/* ------------------------------------------------------------ */




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE STRUCTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION CODE */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Setting all pixels in a Cube cube to 0 */

void cuberase(Cube *cube)
{
  int i,j,k, newsize;

  newsize = (*cube).size_x+(*cube).padding;

  /* Do it */
  for (i = 0; i < newsize; ++i)
    for (j = 0; j < (*cube).size_y; ++j)
      for (k = 0; k < (*cube).size_v; ++k)
	(*cube).points[i+newsize*(j+(*cube).size_y*k)] = 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Find the absolute pixel in a Cube */

float *findpixel(Cube *cube, int x, int y, int v)
{
  if (x-(*cube).refpix_x >= 0 && x-(*cube).refpix_x < (*cube).size_x && y-(*cube).refpix_y >= 0 && y-(*cube).refpix_y < (*cube).size_y && v-(*cube).refpix_v >= 0 && v-(*cube).refpix_v < (*cube).size_v)
    return &((*cube).points)[(x-(*cube).refpix_x)+((*cube).size_x+(*cube).padding)*((y-(*cube).refpix_y)+(*cube).size_y*(v-(*cube).refpix_v))];
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Find the relative pixel in a Cube */

float *findpixelrel(Cube *cube, int x, int y, int v, int padding)
{
  if (x >= 0 && x < (*cube).size_x && y >= 0 && y < (*cube).size_y && v >= 0 && v < (*cube).size_v)
    return &((*cube).points)[x+((*cube).size_x+padding)*(y+(*cube).size_y*v)];
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns the measure of a cube containing an ellipsoid */

int *calcbordergauss(float sigma_maj, float sigma_min, float sigma_v, float *cossinpa, float n)
{
  float calcbordergauss[3];
  int *calcbordergaussint;
  float t;

  if (fabs(cossinpa[0]) <= 1 && fabs(cossinpa[1]) <= 1 && sigma_maj >= 0 && sigma_min >= 0 && n >= 0 ) {

    if (cossinpa[1] && sigma_min)
      t = atan(-(cossinpa[0]*sigma_maj)/(cossinpa[1]*sigma_min));
    else 
      t =  cossinpa[0]*PI_HERE/(2*fabs(cossinpa[0]));

    *calcbordergauss = n*fabs((cossinpa[1]*sigma_min*cos(t))-cossinpa[0]*sigma_maj*sin(t));

    if (cossinpa[0] && sigma_maj)
      t = atan((cossinpa[1]*sigma_maj)/(cossinpa[0]*sigma_min));
    else
      t =  cossinpa[1]*PI_HERE/(2*fabs(cossinpa[1]));

    *(calcbordergauss+1) = n*fabs((cossinpa[0]*sigma_min*cos(t))+cossinpa[1]*sigma_maj*sin(t));

    *(calcbordergauss+2) = n*sigma_v;

    calcbordergaussint = imax(calcbordergauss);
  }						  
  else {
    calcbordergaussint = NULL;
  }
  return calcbordergaussint;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Change the padding in a cube */

Cube *padcubex(Cube *cube)
{
  int i,j,k;
  size_t counter;
  float *dummy;

  if (cube) {
    /* if the cube contains a padding it should be removed */
    if ((*cube).padding) {
      
      /* This is important to do in the right order the lowest index changes most rapid */
      for(k = 0; k < (*cube).size_v; ++k)
	for(j = 0; j < (*cube).size_y; ++j)
	  for(i = 0; i < (*cube).size_x; ++i)
	    *findpixelrel(cube, i, j, k, 0) = *findpixelrel(cube, i, j, k, (*cube).padding);
      /* Now the padding has been removed. Realloc the array */
/*       realloc((*cube).points, (*cube).size_v*(*cube).size_y*(*cube).size_x*sizeof(float)); */
      dummy = (float *) malloc((*cube).size_v*(*cube).size_y*(*cube).size_x*sizeof(float));
      for (counter = 0; counter < cube -> size_v*cube -> size_y*cube -> size_x; ++counter)
	dummy[counter] = cube -> points[counter];
/*       free(cube -> points); */
      cube -> points = dummy;

      /* Change the padding */
      (*cube).padding = 0;
    }
    
    /* if there's no padding then create some */
    else {
      /* Now realloc first */
/*       return NULL; */
/*       realloc(cube -> points, (*cube).size_v*(*cube).size_y*(((*cube).size_x/2)*2+2)*sizeof(float)); */
      dummy = (float *) malloc((*cube).size_v*(*cube).size_y*(((*cube).size_x/2)*2+2)*sizeof(float));
      for (counter = 0; counter < cube -> size_v*cube -> size_y*cube -> size_x; ++counter)
	dummy[counter] = cube -> points[counter];
/*       free(cube -> points); */
      cube -> points = dummy;

      /* change the padding */
      (*cube).padding = ((*cube).size_x/2)*2+2-(*cube).size_x;
      
      /* Then change the contents according to the padding start with the last pixel and work the way backwards through */
      for(k = (*cube).size_v-1; k >= 0; --k)
	for(j = (*cube).size_y-1; j >= 0; --j)
	  for(i = (*cube).size_x-1; i >= 0; --i)
	    *findpixelrel(cube, i, j, k, (*cube).padding) = *findpixelrel(cube, i, j, k, 0);
      
    }
  }
  return cube;  
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Adding cubes in the overlapping region */

Cube *addcubes(Cube *cube1, Cube *cube2)
{
  int xmin, xmax, ymin, ymax, vmin, vmax, i, j, k;
  float *pointertoapixel;
  float scale;

  if (cube1 && cube2 && (*cube1).points && (*cube2).points) {
  /* find the region in which cubes will be added */
    
  /* Start finding the absolute pixel coordinates of the maximum and the minimum in x */
    if ((*cube1).refpix_x <= (*cube2).refpix_x)
      xmin = (*cube2).refpix_x;
    else
      xmin = (*cube1).refpix_x;
    if (((*cube1).refpix_x + (*cube1).size_x - 1) <= ((*cube2).refpix_x + (*cube2).size_x - 1))
      xmax = ((*cube1).refpix_x + (*cube1).size_x - 1);
    else
      xmax = ((*cube2).refpix_x + (*cube2).size_x - 1);
    
  /* stop if the regions prove disjunct */
    if (xmax >= xmin) {
      /* Start finding the absolute pixel coordinates of the maximum and the minimum in y */
      if ((*cube1).refpix_y <= (*cube2).refpix_y)
	ymin = (*cube2).refpix_y;
      else
	ymin = (*cube1).refpix_y;
      if (((*cube1).refpix_y + (*cube1).size_y - 1) <= ((*cube2).refpix_y + (*cube2).size_y - 1))
	ymax = ((*cube1).refpix_y + (*cube1).size_y - 1);
      else
	ymax = ((*cube2).refpix_y + (*cube2).size_y - 1);
      
      /* stop if the regions prove disjunct */
      if (ymax >= ymin) {
	/* Start finding the absolute pixel coordinates of the maximum and the minimum in v */
	if ((*cube1).refpix_v <= (*cube2).refpix_v)
	vmin = (*cube2).refpix_v;
	else
	  vmin = (*cube1).refpix_v;
	if (((*cube1).refpix_v + (*cube1).size_v - 1) <= ((*cube2).refpix_v + (*cube2).size_v - 1))
	  vmax = ((*cube1).refpix_v + (*cube1).size_v - 1);
	else
	  vmax = ((*cube2).refpix_v + (*cube2).size_v - 1);
	
    /* stop if the regions prove disjunct */
	if (vmax >= vmin) {
	  
	  /* the scale of the cubes could be different, so calculate the scale */
	  scale = (*cube2).scale/(*cube1).scale;

	  /* Now add cube2 on cube1 in the overlap region */
	  for (i = xmin; i <= xmax; ++i) {
	    for (j = ymin; j <= ymax; ++j) {
	      for (k = vmin; k <= vmax; ++k) {
		pointertoapixel = findpixel(cube1, i, j, k);
		*pointertoapixel = *pointertoapixel+scale**findpixel(cube2, i, j, k);
	      }
	    }
	  }
	}
      }
    }
    return cube1;
  }
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: cubarithm.c,v $
   Revision 1.6  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.5  2011/05/10 00:30:15  jozsa
   Left work

   Revision 1.4  2009/05/26 07:56:40  jozsa
   Left work

   Revision 1.3  2007/08/23 15:23:25  gjozsa
   Left work

   Revision 1.2  2007/08/22 15:58:40  gjozsa
   Left work

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


   ------------------------------------------------------------ */
