/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file xmemory.pure.h 
   @brief Basically a removal of all xmemory (Nicolas Devillard)
   functionality
   
   xmemory was meant to be an efficient module for memory handling,
   coming with the qfits library. For some purposes xmemory is a
   brilliant tool. However, not for all. This is a version of xmemory
   that takes away all functionality of xmemory, restoring all the old
   memory allocation functions. The only function qfits depends on,
   falloc is rewritten such that a normal free on a mapped file
   works. In course of compilation the old xmemory modules are removed
   and replaced with these.

   $Source: /Volumes/DATA_J_II/data/CVS/tirific/xmemory/xmemory.pure.h,v $
   $Date: 2009/05/26 07:56:41 $
   $Revision: 1.4 $
   $Author: jozsa $
   $Log: xmemory.pure.h,v $
   Revision 1.4  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.3  2007/07/03 17:28:08  gjozsa
   Left work

   Revision 1.2  2006/11/22 14:16:22  gjozsa
   Bugfix concerning RASH and horizontal/vertical lines

   Revision 1.1.1.1  2004/10/29 11:13:39  gjozsa
   Added to CVS control

   Revision 1.1.1.1  2004/10/28 14:47:36  gjozsa
   Added to CVS control

   
*/
/* ------------------------------------------------------------ */



/* Include guard */
#ifndef _MAINPROG_H
#define _MAINPROG_H



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* DEFINES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def falloc(f,o,s)
   @brief Very nasty trick to redefine the standard falloc
   
   This is the one public function of xmemory that has to be kept. To
   circumvene every redefinition of falloc, this macro changes all
   falloc calls into calls in this module. This is absolutely NASTY
   and should NEVER be done. Nevertheless it is required to keep the
   qfits compilable. I'll remove this in due course!!!
*/
/* ------------------------------------------------------------ */
#define falloc(f,o,s)   xmemory_falloc(f,o,s)



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* STRUCTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTIONS */
/* ------------------------------------------------------------ */

char *xmemory_falloc(char *, size_t, size_t *) ;



/* Include guard */
#endif



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: xmemory.pure.h,v $
   Revision 1.4  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.3  2007/07/03 17:28:08  gjozsa
   Left work

   Revision 1.2  2006/11/22 14:16:22  gjozsa
   Bugfix concerning RASH and horizontal/vertical lines

   Revision 1.1.1.1  2004/10/29 11:13:39  gjozsa
   Added to CVS control

   Revision 1.1.1.1  2004/10/28 14:47:36  gjozsa
   Added to CVS control



   ------------------------------------------------------------ */



/* vim: set ts=4 et sw=4 tw=75 */
