/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file globals.h
   @brief Global struct definition, construction and destruction

   This file contains all structs and symbolic constants needed
   globally plus constructors and destructors for these. This file can
   be included principally.
   
   $Source: /Volumes/DATA_J_II/data/CVS/tirific/include/globals.h,v $
   $Date: 2009/05/26 07:56:39 $
   $Revision: 1.9 $
   $Author: jozsa $
   $Log: globals.h,v $
   Revision 1.9  2009/05/26 07:56:39  jozsa
   Left work

   Revision 1.8  2007/08/22 15:58:34  gjozsa
   Left work

   Revision 1.7  2005/04/14 10:32:11  gjozsa
   Left work

   Revision 1.6  2004/11/16 18:18:32  gjozsa
   Left work

   Revision 1.4  2004/11/10 15:47:49  gjozsa
   Added functions getfirstel_para and getlastel_para

   Revision 1.3  2004/11/09 15:59:17  gjozsa
   fixed minor bug

   Revision 1.2  2004/10/29 14:39:21  gjozsa
   changed error_msg

   Revision 1.1.1.1  2004/10/29 11:13:05  gjozsa
   Added to CVS control


*/
/* ------------------------------------------------------------ */



/* Include guard */
#ifndef GLOBALS_H
#define GLOBALS_H


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <qfits.h>


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def DISK
   @brief Symbolic constant to mark a disk structure as a number
*/
/* ------------------------------------------------------------ */
#define DISK 0



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def RING
   @brief Symbolic constant to mark a ring structure as a number
*/
/* ------------------------------------------------------------ */
#define RING 1



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def SECTOR
   @brief Symbolic constant to mark a sector structure as a number
*/
/* ------------------------------------------------------------ */
#define SECTOR 2



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* TYPEDEFS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @typedef float fpoint
   @brief Floating point accuracy

   I switched to using this typedef to enable a faster conversion to
   different floating-point accuracy. A lot of code was written
   though, so the conversion of all variables of type float to fpoint
   has to be done yet.

   @todo Conversion from float variables to type fpoint throughout the
   code
*/
/* ------------------------------------------------------------ */
typedef float fpoint;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* STRUCTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Pointsource
   @brief Element of a Sectorpoints ll

   @li @c float @c x  x position in arcsec (grids)
   @li @c float @c y  y position in arcsec (grids)
   @li @c float @c v  v position in km/s (grids)
   @li @c Pointsource @c *next  pointer to the next pointsource

   Element of the ll Sectorpoints, containing x
   position, y position, and v position.

*/
/* ------------------------------------------------------------ */
typedef struct Pointsource
{
  /** @brief x position in arcsec (grids) */
  float x;
  /** @brief y position in arcsec (grids) */
  float y;
  /** @brief v position in arcsec (grids) */
  float v;
  /** @brief pointer to the next pointsource */
  struct Pointsource *next;
} Pointsource;


/* Some define guard */
#ifndef CUBE_DEFINED
#define CUBE_DEFINED

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Cube
   @brief A datacube with absolute position information

   A datacube. According to the internal coordinate structure its
   position is determined by the reference pixel (the coordinates of
   the first pixel points[0] in the adopted coordinate system. The
   left lowest pixel of the reference cube is the origin) and the
   size. The array with the data is ordered not exactly according to
   fits rules. x is axis1, y axis2, and v axis 3, i.e. pixel (x,y,z)
   is points[x+cube.size_x*(y+cube.size_y*z)]

   Layout: 
   @li @c int @c refpix_x         x-coordinate of the reference pixel
   @li @c int @c refpix_y         y-coordinate of the reference pixel
   @li @c int @c refpix_v         v-coordinate of the reference pixel
	    
   @li @c int @c size_x           size in pixels in x direction
   @li @c int @c size_y           size in pixels in y direction
   @li @c int @c size_v           size in pixels in v direction

   @li @c float @c scale          a scale factor
   @li @c int @c padding          number of pixels the cube is padded with
   @li @c float @c *points        array of floats containing the information
*/
/* ------------------------------------------------------------ */
typedef struct Cube
{
  /** @brief x-coordinate of the reference pixel */
  int refpix_x;
  /** @brief y-coordinate of the reference pixel */
  int refpix_y;
  /** @brief v-coordinate of the reference pixel */
  int refpix_v;

  /** @brief size in pixels in x direction */
  int size_x;
  /** @brief size in pixels in y direction */
  int size_y;
  /** @brief size in pixels in v direction */
  int size_v;

  /** @brief a scale factor */
  float scale;
  /** @brief number of pixels the cube is padded with */
  int padding;

  /** @brief array of floats containing the information */
  float *points;
} Cube;

#endif

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Sectorpoints
   @brief Element of the dll Ringpoints

   Description: Element of the dll Ringpoints, containing flux
   of a pointsource, the number of pointsources in the sector, the
   link to the next pointsource, next and previous sector, and an
   associated cube.

   Layout: 
   @li @c float @c *f                         flux of one pointsource
   @li @c Pointsource @c *next_point          pointer to the ll of 
                                              Pointsources
   @li @c @c struct @c Sectorpoints @c *next  pointer to the next element
   @li @c @c struct @c Sectorpoints @c *prev  pointer to the previous element
   @li @c Cube @c *cube                       pointer to associated cube

*/
/* ------------------------------------------------------------ */
typedef struct Sectorpoints
{
  /** @brief flux of one pointsource */  
  float *f;
  /** @brief pointer to the ll of Pointsources */  
  Pointsource *next_point;
  /** @brief pointer to the next element */  
  struct Sectorpoints *next;
  /** @brief pointer to the previous element */  
  struct Sectorpoints *prev;
  /** @brief pointer to associated cube */  
  Cube *cube;
} Sectorpoints;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Ringpoints
   @brief Element of the dll Diskpoints

   Element of the dll Diskpoints, absolute flux, pointsourcedensity of
   the ring, pointer to the first sector of the ring, next and
   previous rings, associated cube.

   Layout: 
   @li @c Sectorpoints @c *next_sector       pointer to the ll of Sectorpoints
   @li @c @c struct @c Ringpoints @c *next   pointer to the next element
   @li @c @c struct @c Ringpoints @c *prev   pointer to the previous element
   @li @c @c @c Cube @c *cube                pointer to associated cube
*/

/* ------------------------------------------------------------ */
typedef struct Ringpoints
{
  /** @brief Pointer to the ll of Sectorpoints */
  Sectorpoints *next_sector;
  /** @brief Pointer to the next element */
  struct Ringpoints *next;
  /** @brief Pointer to the previous element */
  struct Ringpoints *prev;
  /** @brief Pointer to associated cube */
  Cube *cube;
} Ringpoints;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**

   @struct Diskpoints
   @brief Header of the Ringpoints dll 

   Header of the dll of Ringpoints describing a disk, absolute flux,
   relative x, y, and v position of the ring (in arcsec or grids), and
   pointer to the first sector one ring, and an associated cube. The
   first element of the dll contains the position of the reference
   pixel.

   Layout: 
   @li @c float @c *x                        x position in deg (grids)
   @li @c float @c *y                        y position in deg (grids)
   @li @c float @c *v                        v position in km/s (grids)
   @li @c struct @c Ringpoints @c *next_ring    Pointer to the next ring
   @li @c Cube @c *cube                     pointer to associated cube
*/
/* ------------------------------------------------------------ */
typedef struct Diskpoints
{
  /** @brief x position in deg (grids) */
  float *x;
  /** @brief y position in deg (grids) */
  float *y;
  /** @brief v position in km/s (grids) */
  float *v;
  /** @brief Pointer to the next ring */
  struct Ringpoints *next_ring;
  /** @brief Pointer to associated cube */
  Cube *cube;
} Diskpoints;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**

  @struct Globals
  @brief The global controlstructure

  Controlstructure containing the global parameters plus information
  about the input cube using the qfits header structure. The internal
  coordinate system is defined as follows: The coordinate unit is
  pixels. Coordinates are relative to the first pixel of the fits file
  which has the coordinates 0,0,0. Pixel values are the values after
  the multiplication with bunit.

  Layout:
  The read header:
  @li @c qfits_header @c *hd  Qfits structure containing the header
                              information of the initial cube.
   
  fits related:               Information in the cube transformed 
                              to the internal coordinate system

  @li @c float @c *centerra   RA of the centre
  @li @c float @c *centerdec  DEC of the centre
  @li @c float @c *centervel  VELO of the centre
  @li @c float @c velres      Velocity resolution in km/s (pixel)
  @li @c char  @c *hanning;   Hanning present (1) or not (0)
  @li @c float @c noise       The rms noise in bunit/beam
  @li @c float @c *pointdens  Mean pointsourcedensity (per beam/per pixel)
  @li @c float @c *cloudflux  Desired flux of one cloud
*/

/* ------------------------------------------------------------ */
typedef struct Globals
{
  /** @brief  qfits structure containing the header information of the initial cube. */
  qfits_header *hd;
  /** @brief RA of the centre */
  float *centerra;
  /** @brief DEC of the centre */
  float *centerdec;
  /** @brief VELO of the centre */
  float *centervel;
              
  /** @brief Velocity resolution in km/s (pixel) */
  float *velres;
  /** @brief Hanning present (1) or not (0) */
  char  *hanning;

  /** @brief The rms noise in bunit/beam */
  float *noise;

  /** @brief Mean pointsourcedensity (per beam/per pixel) */
  float *pointdens;
  /** @brief Desired flux of one cloud */
  float *cloudflux;
} Globals;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Parele
   @brief Element of a ll which is an element of the Para parameter list

   Element of a ll containing the parameters in the disk that steer
   the Monte-Carlo integration of the disk, e.g., a set of phases and
   amplitudes for a harmonic analysis. The values are defined as
   pointers to make a control of more global structures easier.

   Layout:
   @li @c float            @c p      The parameter itself
   @li @c float            @c pmax   Its maximum
   @li @c float            @c pmin   Its minimum
   @li @c char             @c cycle  0: not a cyclic variable 
                                     1: cyclic variable
   @li @c struct @c Parele @c *next  It's an ll 
*/
/* ------------------------------------------------------------ */
typedef struct Parele {
  /** @brief The parameter itself */
  float p;    
  /** @brief Its maximum */
  float pmax; 
  /** @brief Its minimum */
  float pmin; 
  /** @brief 0: not a cyclic variable 1: cyclic variable */
  char cycle; 
  /** @brief It's an ll */
  struct Parele *next;
} Parele;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Para
   @brief Element of a dll containing the information to construct a model

   Element of a dll containing the parameters in the disk, enough
   information to construct the disk. Contains redundant information.
   The user provides in the parameter file the structures, separated
   by a |. Each field of the parameter line contains in that order:

@li 0) number
@li 1) type (DISK:0 RING:1 SECTOR:2)
@li 2) disknr
@li 3) ringnr or -1
@li 4) number of substructures
   
   Layout: 
   identification:
   
     @li @c int            @c number       Number of the actual \
                                           structure in the dll
     @li @c char           @c type         Type of the structure DISK, \
                                           RING, or SECTOR
     @li @c void           @c *points      The associated pointsource \
                                           structure (including the \
                                           possible cube)
     @li @c int            @c disknr       Number of the disk (top) structure 
     @li @c int            @c ringnr       Number of the ring (top) structure \                                           or -1

     @li @c struct @c Para @c *disk        The disk (top) structure 
     @li @c struct @c Para @c *ring        The ring (top) structure or NULL
     
     @li @c struct @c Para @c *next        Next element of the dll
     @li @c struct @c Para @c *before      Previous element of the dll
     @li @c struct @c Para @c *lower       Next lower level structure
     
     @li @c int            @c nsub         Number of substructures
     
   geometry and flux:

     @li @c float          @c centerx      The center of the structure
     @li @c float          @c centery      The center of the structure
     @li @c float          @c centerv      The center of the structure
     

     @li @c float          @c flux         The total flux of the structure
     @li @c float          @c area         The area of the structure
     @li @c float          @c sdensity     The surface-pointsourcedensity of 
                                           the structure
     @li @c float          @c volume       The volume of the structure
     @li @c float          @c pointdensity The pointsourcedensity of 
                                           the structure
     @li @c float          @c pointflux    The flux of one pointsource
     @li @c int            @c pointnumber  The number of pointsources
     
     @li @c float          @c r            The radius of the corresponding ring
     @li @c float          @c dr           The width of the corresponding ring
     @li @c float          @c z            The z-distance of the ring (middle)
     @li @c float          @c dz           The height of the ring
     @li @c float          @c p            The azimuth (turn-radius)
     @li @c float          @c dp           The azimuthal width
     
     @li @c float          @c i            inclination
     @li @c float          @c pa           position angle

   other parameters and gaussian integration:

     @li @c int            @c construct_sector identifier of THE function \
                                               to construct a sector

     @li @c Parele         @c *parm        a ll of parameters

     @li @c unsigned @c long @c seed       The seed used for the random \
                                           generator
     @li @c float          @c scale        The scale factor to multiply \
                                           with afterwards
*/
/* ------------------------------------------------------------ */
typedef struct Para {
  /** @brief Number of the actual structure in the dll */
  int number;
  /** @brief Type of the structure DISK, RING, or SECTOR */
  char type;
  /** @brief The associated pointsource structure (including the possible cube) */
  void *points;
  /** @brief Number of the disk (top) structure */
  int disknr;
  /** @brief Number of the ring (top) structure or -1 */
  int ringnr;

  /** @brief The disk (top) structure */
  struct Para *disk;
  /** @brief The ring (top) structure or NULL */
  struct Para *ring;
  /** @brief Next element of the dll */
  struct Para *next;
  /** @brief Previous element of the dll */
  struct Para *before;
  /** @brief Next lower level structure */
  struct Para *lower;
  /** @brief Number of substructures */
  int nsub;     
  /** @brief The center of the structure */
  float centerx;
  /** @brief The center of the structure */
  float centery;       
  /** @brief The center of the structure */
  float centerv;       
  /** @brief The total flux of the structure */
  float flux;          
  /** @brief The area of the structure */
  float area;          
  /** @brief The surface-pointsourcedensity of the structure */
  float sdensity;  
  /** @brief The volume of the structure */
  float volume;        
  /** @brief The pointsourcedensity of the structure */
  float pointdensity;  
  /** @brief The flux of one pointsource */
  float pointflux;     
  /** @brief The number of pointsources */
  int pointnumber;     
  /** @brief The radius of the corresponding ring */
  float r;             
  /** @brief The width of the corresponding ring */
  float dr;            
  /** @brief The z-distance of the ring (middle) */
  float z;             
  /** @brief The height of the ring */
  float dz;            
  /** @brief The azimuth (turn-radius) */
  float p;             
  /** @brief The azimuthal width */
  float dp;            
  /** @brief inclination */
  float i;             
  /** @brief position angle */
  float pa;            
  /** @brief identifier of THE function to construct a sector */
  int construct_sector;
  /** @brief a ll of parameters */
  Parele *parm;
  /** @brief The seed used for the random generator */
  unsigned long seed;             
  /** @brief The scale factor to multiply with afterwards */
  float scale;
} Para;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Steerele
   @brief Double linked list of steering file

   Double linked list of steering commands

   Layout:
   @li @c int                 @c bla       nothing yet
   @li @c struct @c Steerele @c *before    previous element
   @li @c struct @c Steerele @c *after     next element
*/
/* ------------------------------------------------------------ */
typedef struct Steerele 
{
  /** @brief nothing yet */
  int bla;
  /** @brief previous element */
  struct Steerele *before;
  /** @brief next element */
  struct Steerele *after;
} Steerele;


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct Body
   @brief Main control structure with all structures manipulated in tirific

   Main control structure with all structures manipulated in tirific,
   this is where all things can be found, instead of external
   decalaration of the single elements.

   Layout:
   @li @c qfits_header @c *global      The globals structure in stored form
   @li @c Cube         @c *residual    The read-in cube
   @li @c Para         @c *current     Current best model
   @li @c Para         @c *changed     Changed parameter structure
   @li @c Para         @c *connected   Structure connected with the changed one
   @li @c Steerele     @c *steer       Current order ll
   @li @c float        @c *variable    Any variables (will be completed)      
*/

/* ------------------------------------------------------------ */
typedef struct Body {
  /** @brief The globals structure */
  qfits_header *global;
  /** @brief The read-in cube */
  Cube *residual;       
  /** @brief Current best model */
  Para *current;        
  /** @brief Changed parameter structure */
  Para *changed;        
  /** @brief Structure connected with the changed one */
  Para *connected;      
  /** @brief Current order ll */
  Steerele *steer;      
  /** @brief Any variables (will be completed) */
  float *variable;      
} Body;


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
    @fn void freecube(Cube *cube)
    @brief Destroy a cube

    Destroys the input Cube
    
    @param cube (Cube *) Cube structure to be destroyed
*/
/* ------------------------------------------------------------ */
void freecube(Cube *cube);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
    @fn Pointsource *newpointsource(void)
    @brief Creates a Pointsource and sets the Pointer to the next
    pointsource to 0

    @return (success)  Pointsource *newpointsource: Pointer to the new 
                       Pointsource structure \n
            (error)    NULL
*/
/* ------------------------------------------------------------ */
Pointsource *newpointsource(void);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
    @fn Pointsource *catpointsource(Pointsource *previous)
    @brief Cats a newly created, allocated, and initialised Pointsource 
    to a previous one

    Creates a new Pointsource, initialises the pointers to 0, sets the
    next_point element to the new Pointsource and returns the pointer
    to the new element.

    @param previous (Pointsource *) Pointer to the first Pointsource 
    structure

    @return (success) Pointsource *catpointsource: pointer to the new
                      Pointsource structure \n
            (error) NULL
*/
/* ------------------------------------------------------------ */
Pointsource *catpointsource(Pointsource *previous);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
    @fn freepointsource(Pointsource *lastpointsource)
    @brief Deletes a part of a Pointsource ll

    Deletes the Pointsources after lastpointsource and sets the
    pointer to the next pointsource to NULL

    @param lastpointsource (Pointsource *) Pointer to the last
    Pointsource structure
*/
/* ------------------------------------------------------------ */
void freepointsource(Pointsource *lastpointsource);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Sectorpoints *newsectorpoints(void)
  @brief Creates a new Sectorpoints structure and sets 
         all pointers to NULL

  Creates a new Sectorpoints structure, initialises all pointers to
  NULL, and returns a pointer to the new Sectorpoints element.

@return (success) Sectorpoints *newsectorpoints: pointer to the new 
                  Sectorpoints structure \n
        (error) NULL
*/
/* ------------------------------------------------------------ */
Sectorpoints *newsectorpoints(void);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Sectorpoints *catsectorpoints(Sectorpoints *previous)
  @brief Creates a new Sectorpoints structure and concatenates 
         it to the old

  Creates a new Sectorpoints structure, initialises the pointers to
  NULL, and concatenates it with the old Sectorpoints structure.

  @param previous (Sectorpoints *) pointer to the actual Sectorpoints 
  structure

  @return (success) Sectorpoints *catsectorpoints: pointer to the 
          created Sectorpoints structure
	  (error) NULL
*/
/* ------------------------------------------------------------ */
Sectorpoints *catsectorpoints(Sectorpoints *previous);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Sectorpoints *sectorpointsalloc(Sectorpoints *destiny)
  @brief Allocates memory for the floating points in the
  destiny structure destiny.

  Allocates memory for the floating points in the
  destiny structure destiny.

  @param destiny (Sectorpoints *) pointer to the actual Sectorpoints
  structure

@return (success) Sectorpoints *sectorpointsalloc: pointer to the 
same Sectorpoints structure \n
        (error) NULL
*/
/* ------------------------------------------------------------ */
Sectorpoints *sectorpointsalloc(Sectorpoints *destiny);

/* freeringpoints */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Ringpoints *newringpoints(void)
  @brief Create a new Ringpoints structure and set all pointers to NULL

  Creates a new Ringpoints structure, initialises all pointers to
  NULL, and returns a pointer to the new Ringpoints element.

@return (success) Ringpoints *newringpoints: pointer to the new Ringpoints structure \n
        (error) NULL
*/
/* ------------------------------------------------------------ */
Ringpoints *newringpoints(void);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Ringpoints *catringpoints(Ringpoints *previous)
  @brief Creates a new Ringpoints structure and concatenates
  it to the old

  Creates a new Ringpoints structure, initialises the pointers to
  NULL, and concatenates it with the old Ringpoints structure.

  @param previous (Ringpoints *): Pointer to the actual Ringpoints 
  structure

  @return (success) Ringpoints *catringpoints: Pointer to the created 
  Ringpoints structure \n
  (error) NULL
*/
/* ------------------------------------------------------------ */
Ringpoints *catringpoints(Ringpoints *previous);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn freediskpoints(Ringpoints *firstringpoints)
  @brief Deletes the following Ringpoints structures including 
  firstringpoints

  @param firstringpoints (Ringpoints *) Pointer to a Ringpoints structure

  @return void

  @todo Misguiding name, should be changed
*/
/* ------------------------------------------------------------ */
void freediskpoints(Ringpoints *firstringpoints);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Diskpoints *newdiskpoints(void)
  @brief Create a new Diskpoints structure and set all pointers to NULL

  Creates a new Diskpoints structure, initialises all pointers to
  NULL, and returns a pointer to the new Diskpoints element.

  @return (success) Diskpoints *newdiskpoints: Pointer to the new 
  Ringpoints structure \n
  (error) NULL
*/
/* ------------------------------------------------------------ */
Diskpoints *newdiskpoints(void);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Ringpoints *catfirstring(Diskpoints *diskpoints)
  @brief Creates a new Ringpoints structure and concatenate it to 
  the Diskpoints structure

  Creates a new Ringpoints structure, initialises the pointers to
  NULL, and concatenates it with the Diskpoints structure.

  @param diskpoints (Diskpoints *) Pointer to the actual Diskpoints 
  structure

  @return (success) Ringpoints *catfirstring Pointer to the created 
  Ringpoints structure \n
  (error) NULL
*/
/* ------------------------------------------------------------ */
Ringpoints *catfirstring(Diskpoints *diskpoints);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Diskpoints *diskpointsalloc(Diskpoints *destiny)
  @brief Allocates memory for the floating points in the
  destiny structure.

  @param destiny (Diskpoints *) Pointer to the actual Diskpoints 
  structure

  @return (success) Diskpoints *diskpointsalloc: Pointer to the same 
  Diskpoints structure \n
  (error) NULL
*/
/* ------------------------------------------------------------ */
Diskpoints *diskpointsalloc(Diskpoints *destiny);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn void freedisk(Diskpoints *diskpoints)
  @brief Deletes the complete Diskpoints structure.

  @param diskpoints (Diskpoints *) Pointer to the Diskpoints 
  structure

  @return void
*/
/* ------------------------------------------------------------ */
void freedisk(Diskpoints *diskpoints);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn void error_msg(char *call_file, char *call_function, char *call_msg, int line)
  @brief Generic error message

  Generates a generic error message to stderr, reporting the occurance
  of an error, the file, the function, and a message. If an input
  string is empty, no message will be generated concerning the item.

  @param call_file     (char *) The file from which the call is made
  @param call_function (char *) The function from which the call is made
  @param call_msg      (char *) The error message
  @param line          (int *)  Linenumber printed if not 0 in input

  @return void
*/
/* ------------------------------------------------------------ */
void error_msg(char *call_file, char *call_function, char *call_msg, int line);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn void freeringpoints(Sectorpoints *firstsectorpoints)
  @brief Deletes the Sectorpoints structures following 
  firstsectorpoints including firstsectorpoints.

  @param firstsectorpoints (Sectorpoints *) pointer to a Sectorpoints
  structure

  @return void

  @todo This name is misguiding. Should be changed.
*/
/* ------------------------------------------------------------ */
void freeringpoints(Sectorpoints *firstsectorpoints);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Para *getfirstel_para(Para *element) 
  @brief Returns a pointer to the first element of a properly
  constructed Parameter list at the same level of a given element

  This means if there is a Para structure that describes a ring, it
  will return the adress of the first ring in the dll.

  @param element (Para *) An element of the dll Para

  @return Para *getfirstel_para A pointer to the first element of the
  Parameter list at the same level, no error handling.
*/
/* ------------------------------------------------------------ */
Para *getfirstel_para(Para *element);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Para *getlastel_para(Para *element) 
  @brief Returns a pointer to the last element of a properly
  constructed Parameter list at the same level of a given element

  This means if there is a Para structure that describes a ring, it
  will return the adress of the last ring in the dll.

  @param element (Para *) An element of the dll Para

  @return Para *getlastel_para A pointer to the first element of the
  Parameter list at the same level, no error handling.
*/
/* ------------------------------------------------------------ */
Para *getlastel_para(Para *element);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn void freepara(Para *parameterlist)
  @brief Free a read-parameter list

  Destroys the parameterlist, the consequent parameter-lists, all
  sublists in the destroyd parameter lists and the additional Parele
  lists. All ohter objects that are pointed to, like pointslists,
  cubes, are untouched.

  @param parameterlist (Para *) The first Para structure to be deleted

  @return void
*/
/* ------------------------------------------------------------ */
void freepara(Para *parameterlist);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn void freeparele(Parele *parameterlist)
  @brief Free a read-parameter list

  Destroys the parameterlist without closing a hole

  @param parameterlist (Parele *) The first Parele structure to be
  deleted

  @return void
*/
/* ------------------------------------------------------------ */
void freeparele(Parele *parameterlist);




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: globals.h,v $
   Revision 1.9  2009/05/26 07:56:39  jozsa
   Left work

   Revision 1.8  2007/08/22 15:58:34  gjozsa
   Left work

   Revision 1.7  2005/04/14 10:32:11  gjozsa
   Left work

   Revision 1.6  2004/11/16 18:18:32  gjozsa
   Left work

   Revision 1.4  2004/11/10 15:47:49  gjozsa
   Added functions getfirstel_para and getlastel_para

   Revision 1.3  2004/11/09 15:59:17  gjozsa
   fixed minor bug

   Revision 1.2  2004/10/29 14:39:21  gjozsa
   changed error_msg

   Revision 1.1.1.1  2004/10/29 11:13:05  gjozsa
   Added to CVS control


   ------------------------------------------------------------ */

/* Include guard */
#endif
