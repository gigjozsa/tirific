/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file gridnconvol.h
   @brief Gridding and convolution routines

   Gridding and convolution related routines come with this
   module. Also informal parsing of the Diskpoints structure is
   contained here.
   
   $Source: /Volumes/DATA_J_II/data/CVS/tirific/include/gridnconvol.h,v $
   $Date: 2009/05/26 07:56:39 $
   $Revision: 1.5 $
   $Author: jozsa $
   $Log: gridnconvol.h,v $
   Revision 1.5  2009/05/26 07:56:39  jozsa
   Left work

   Revision 1.4  2007/08/22 15:58:34  gjozsa
   Left work

   Revision 1.3  2005/04/14 10:32:12  gjozsa
   Left work

   Revision 1.2  2004/12/08 16:22:48  gjozsa
   Left work

   Revision 1.1.1.1  2004/10/29 11:13:05  gjozsa
   Added to CVS control


*/
/* ------------------------------------------------------------ */



/* Include guard */
#ifndef GRIDNCONVOL_H
#define GRIDNCONVOL_H


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <globals.h>



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def BORDERS_DISK
   @brief numerical synonym (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define BORDERS_DISK 0



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def BORDERS_RING
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define BORDERS_RING 1



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def BORDERS_SECTOR
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define BORDERS_SECTOR 2




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def BORDERS_NEXT
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define BORDERS_NEXT 0 



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def BORDERS_INTER
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define BORDERS_INTER 1



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def BORDERS_HYBRID
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define BORDERS_HYBRID 2



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def BORDERS_DIRECT
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define BORDERS_DIRECT 0




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def FFT
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define FFT 0



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def DIRECT
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define DIRECT 1



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def GRIDDING 2
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define GRIDDING 2




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def COLLECT
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define COLLECT 0



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def NONCOLLECT
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define NONCOLLECT 1




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def SIZE
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define SIZE 0



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def POINTS
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define POINTS 1




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def NEW
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define NEW 0



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def COPY
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define COPY 1



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def POINTER
   @brief numerical synonyme (see functions in this module)
*/
/* ------------------------------------------------------------ */
#define POINTER 2



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* MACROS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* TYPEDEFS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* STRUCTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Cube *gridon(Cube *cube, void *points, char stype, char gmode, float twosigmasq)
  @brief Grids a ll of pointsources on a Cube adding to the Cube

  Grids the points in the structure points, either a disk, a ring, or
  a sector on the Cube cube, which should be a dynamically allocated
  Cube. The values are added. Stype is either BORDERS_DISK,
  BORDERS_RING, or BORDERS_SECTOR, describing the type of the
  structure. The cube should be large enough for the gridding
  procedure (Which can be made sure when producing the cube with
  cubecreat). gmode describes the gridding mode, either BORDERS_NEXT,
  or BORDERS_INTER. NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. twosigmasq is only important when chosing
  gmode BORDERS_INTER or BORDERS_HYBRID. When doing a gaussian
  interpolation the eight (four) nearest pixels will get a value
  exp(dist^2/twosigmasq), where dist is the distance between the pixel
  and the point and then will be normalised to conserve the flux.

  @param cube       (Cube *) Cube onto which the gridding takes place
  @param points     (void *) Structure to be gridded
  @param stype      (char) Type of structure BORDERS_DISK, 
  BORDERS_RING, or BORDERS_SECTOR
  @param gmode      (char)   Gridding mode BORDERS_NEXT or BORDERS_INTER
  @param twosigmasq (float)  Size of the convolution kernel (in 2*sigma^2)
  
  @return (success) Cube *gridding: The same pointer to the cube passed 
  into the function\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
Cube *gridon(Cube *cube, void *points, char stype, char gmode, float twosigmasq);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn Cube *gridding(Cube *cube, void *points, char stype, char gmode, float twosigmasq)
  @brief Grids a ll of pointsources on a Cube erasing the Cube
    
  Grids the points in the structure points, either a disk, a ring, or
  a sector on the Cube cube, which should be a dynamically allocated
  Cube. The content of cube is deleted. Stype is either BORDERS_DISK,
  BORDERS_RING, or BORDERS_SECTOR, describing the type of the
  structure. The cube should be large enough for the gridding
  procedure (Which can be made sure when producing the cube with
  cubecreat). gmode describes the gridding mode, either BORDERS_NEXT,
  or BORDERS_INTER. BORDERS_NEXT is the gridding on the next pixel,
  BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. twosigmasq is only important when chosing
  gmode BORDERS_INTER or BORDERS_HYBRID. When doing a gaussian
  interpolation the eight (four) nearest pixels will get a value
  exp(dist^2/twosigmasq), where dist is the distance between the pixel
  and the point and then will be normalised to conserve the flux.

    @param cube       (Cube *) Cube onto which the gridding takes place
    @param points     (void *) Structure to be gridded
    @param stype      (char) Type of structure BORDERS_DISK, 
    BORDERS_RING, or BORDERS_SECTOR
    @param gmode      (char)   Gridding mode BORDERS_NEXT or BORDERS_INTER
    @param twosigmasq (float)  Size of the convolution kernel (in 2*sigma^2)

    @return (success) Cube *gridding The same pointer to the cube passed 
    into the function\n
            (error) NULL
*/
/* ------------------------------------------------------------ */
Cube *gridding(Cube *cube, void *points, char stype, char gmode, float twosigmasq);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn Cube *cubecreat(void *points, char stype, char gmode, int border_x, int border_y, int border_v, int padding, char produce)
  @brief Creates a cube suitable for gridding points of the input
  structure

  Returns a cube suitable to grid *points, which is either the disk, a
  ring, or a sector in the Diskpoints dll. stype describes the
  character of *points, which can be BORDERS_DISK, BORDERS_RING, or
  BORDERS_SECTOR. mode describes the gridding mode, either
  BORDERS_NEXT, or BORDERS_INTER. NEXT is the gridding on the next
  pixel, BORDERS_INTER is a gaussian interpolation to the 8 pixels
  surrounding the sources. After the size of the cube in which all
  pointsources fit in is known a border of uprounded border pixels is
  added, to prevent aliasing when convolving with a gaussian. The
  border added is the round up value of border_axis. If the padding is
  set to 1 the cube will be padded with extra-memory to be added for
  an fft convolution. The (*cubecreat).points array is allocated. Mark
  that the return value is NULL if either there are memory problems or
  if there are no points present. Make sure to get the information
  first. The points array is not initialised. produce informs if the
  cube returned will have the points already allocated or if the
  points value is NULL.

  @param points   (void *) Structure to be gridded
  @param stype    (char)   Type of structure BORDERS_DISK, BORDERS_RING,
  or BORDERS_SECTOR
  @param gmode    (char)   Gridding mode BORDERS_NEXT or BORDERS_INTER
  @param border_x (int)    Additional border in x direction
  @param border_y (int)    Additional border in y direction
  @param border_v (int)    Additional border in v direction
  @param padding  (int)    1: pad the cube to a suitable size for fftw, 
  0: Don't do a padding
  @param produce  (char) SIZE or POINTS, when SIZE, no memory for 
  the points will be allocated

  @return (success) Cube *cubecreat: Cube with the right dimensions to grid the structure\n
        (error) NULL
*/
/* ------------------------------------------------------------ */
Cube *cubecreat(void *points, char stype, char gmode, int border_x, int border_y, int border_v, int padding, char produce);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn Cube *collectcubes(Cube *cube, void *points, char stype)
  @brief Searches the structure points for existing cubes and adds
  each top level cube to cube.

  @param cube   (Cube *) Cube onto which the adding takes place
  @param points (void *) Structure to be searched
  @param stype  (char)   Type of structure DISK, RING, or SECTOR

  @return (success) Cube *collectcubes: The same pointer to the 
  cube passed into the function\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
Cube *collectcubes(Cube *cube, void *points, char stype);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn Cube *gridnconvol(void *points, char stype, char contype, char
  conmode, char gmode, int **bordersgaussint, float **expofacsffts,
  float **expofacsdirects, float sigma_major_axis, float
  sigma_minor_axis, float sigma_v, float position_angle, float
  sizeofgauss, float twosigmasq, char produce, char create)
  @brief Do a convolution or a gridding of a structure on a cube that
  is allocated in various ways

  Returns a pointer to an allocated Cube, on which the points of the
  structure points are gridded and possibly convolved with a
  gaussian. points is a pointer to the structure to be brought on a
  cube. stype describes the structure which is gridded, either DISK,
  RING, or SECTOR. contype is the type of gridding/convolution of the
  structure, three possibilities, a direct conovolution DIRECT,
  assumed to be the slowest but the most accurate, FFT using an FFT
  based convolution after gridding of the pointsources on the cube
  (which might be considerably slower though depending on the size of
  the cube and the number of pointsources), GRIDDING means just a flux
  conserving gridding of the pointsources on the cube conmode
  describes the strategy while calculating the final cube, COLLECT
  will assume that cubes belonging to substructure are already
  convolved or gridded in the right way and will not take into account
  the content of the substructure but merely add the cube belonging to
  the substructure on the resulting cube, saving time. NONCOLLECT does
  not make this assumption and will use all the pointsources in the
  structure points to grid those on the cube. gmode describes the
  gridding mode, which is BORDERS_NEXT, BORDERS_INTER, BORDERS_HYBRID,
  or BORDERS_DIRECT. BORDERS_NEXT is the gridding of one pointsource
  on the next pixel, BORDERS_INTER is a gaussian interpolation to the
  8 pixels surrounding the sources (with renormalisation to conserve
  the flux), BORDERS_HYBRID is a gaussian interpolation in the xy
  plane, but search for the next pixel in v (which can be used if one
  wants to calculate the 0th moment but still wants an interpolation
  method). BORDERS_DIRECT has no meaning for the gridding, as this is
  omitted for a direct convolution, but is an information needed for
  the allocation of a large enough cube. bordersgaussint is pointing
  to an allocated array of three int values describing the (uprounded)
  half size of the convolution kernel, needed if doing a direct
  convolution. However, if the content points to NULL, this value will
  be calculated from sigma_major_axis, sigma_minor_axis, sigma_v,
  position_angle, sizeofgauss, where sizeofgauss gives the half size
  of the convolution kernel in units of the sigma of the corresponding
  axis. The (floating point) bounding box of an ellipsoid with the
  given measures is computed, inflated by a factor sizeofgauss, and
  then rounded up to the next integer points. The content will then be
  a pointer to an allocated array of 3 values. The floating points
  expofacsfft and expofacsdirect are factors derived from
  sigma_major_axis, sigma_minor_axis, sigma_sigma_v, position_angle
  needed by the single convolution routines, and don't need to be
  calculated unless the convolution function changes. If the passed
  pointer points to a pointer to zero, the zero will be replaced by an
  allocated array of 5 values for the type of convolution desired. A
  gaussian convolution is determined by sigma_major_axis,
  sigma_minor_axis, sigma_v, position_angle, sizeofgauss, however if
  one of the sigmas is zero, the convolution will not take place in
  that direction (as the program doesn't consider a delta-function
  is).  The gaussian is determined by a sigma for the major axis, the
  minor axis and a position angle (angle between major axis and y axis
  counterclockwise) and sigma for the v axis. twosigmasq is only
  important when chosing gmode BORDERS_INTER or BORDERS_HYBRID. When
  doing a gaussian interpolation the eight (four) nearest pixels will
  get a value exp(dist^2/twosigmasq), where dist is the distance
  between the pixel and the point and then will be normalised to
  conserve the flux. produce tells gridnconvol whether to produce the
  cube with the actual cube or if it should only pass an initialised
  cube without a filled pointsource but with the right information
  about the size. create is information about what old information is
  used and what is passed to the user. NEW means to produce a new cube
  and no information in the cube structure will be used to calculate
  it, i.e. the cube is copied if it's there. COPY means to produce a
  new cube but to use the possible information in the cube structure
  stored in the structure points. If this is not possible, it defaults
  to NEW. POINTER means to actually produce no new cube but only pass
  the old cube and the points within to the user if possible. If there
  is no cube, a new one will be produced, but not be placed into the
  structure. If there is a cube but no points, the points will be
  created and placed into the structure. Take care when chosing COPY
  or POINTER, as all the information will be taken seriously.

  @param points           (void *)   Input structure, either a disk, a
  ring, or a sector
  @param stype            (char)     Type of input structure DISK,
  RING, or SECTOR
  @param contype          (char)     Type of process to put the
  structure on the cube DIRECT, FFT, or GRIDDING
  @param conmode         (char)      Collecting existing cubes of
  substructures or not, COLLECT, or NONCOLLECT
  @param gmode            (char)     Mode of gridding process,
  BORDERS_NEXT, BORDERS_INTER, BORDERS_HYBRID, BORDERS_DIRECT

  @param bordersgaussint  (int **)   Pointer to an array with the half
  sizes of the convolution kernel
  @param expofacsffts     (float **) Pointer to an array of 5 values
  needed for the fft convolution (or pointer to a pointer to NULL)
  @param expofacsdirects  (float **) Pointer to an array of 5 values
  needed for the fft convolution (or pointer to a pointer to NULL)

  @param sigma_major_axis (float)    Sigma of the major axis, not used
  if bordersgaussint and expofacsfft or expofacsdirect contains an
  array
  @param sigma_minor_axis (float)    Sigma of the minor axis, not used
  if bordersgaussint and expofacsfft or expofacsdirect contains an
  array
  @param sigma_v          (float)    Sigma of the v axis, not used if
  bordersgaussint and expofacsfft or expofacsdirect contains an array
  @param position_angle   (float)    Position angle of the gaussian,
  not used if bordersgaussint and expofacsfft or expofacsdirect
  contains an array
  @param sizeofgauss      (float)    Half size of the convolution
  kernel in units of sigma

  @param twosigmasq       (float)    Size of the convolution kernel
  for weighted gridding

  @param produce          (char)     Producing information: SIZE,
  POINTS
  @param create           (char)       Shall it produce a new cube or
  pass a pointer if possible: NEW, POINTER, COPY


@return (success) Cube *gridnconvol Pointer to an allocated cube
containing the gridded or convolved or marked input structure \n
        (error) NULL

*/
/* ------------------------------------------------------------ */
Cube *gridnconvol(void *points, char stype, char contype, char conmode, char gmode, int **bordersgaussint, float **expofacsffts, float **expofacsdirects, float sigma_major_axis, float sigma_minor_axis, float sigma_v, float position_angle, float sizeofgauss, float twosigmasq, char produce, char create);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn float fftgaussian (int nx, int ny, int nv, float *expofacs)
  @brief Calculate a gaussian

  Returns the value of a gaussian in dependence of expofacs. 
  gaussian  =  exp((expofacs[0]*nx*nx+expofacs[1]*nx*ny+expofacs[2]*
  ny*ny+expofacs[3]*nv*nv+expofacs[4])).
  To be used by convolgaussfft. No modulation with respect of the
  signum of the coordinates will be done. For a number in the exponent
  lesser than MINEXPONENT the return value is 0.

  @todo Implement the last thing in the description

  @param nx       (int)     Relative pixelposition in x
  @param ny       (int)     Relative pixelposition in x
  @param nv       (int)     Relative pixelposition in x
  @param expofacs (float *) Factors in the gaussian, calculated by 
  expofacsfft and normalised with respect to the sizes of the array

  @return float fftgaussian The gaussian at the desired position
*/
/* ------------------------------------------------------------ */
float fftgaussian (int nx, int ny, int nv, float *expofacs);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn float fftgaussian2d (int nx, int ny, float *expofacs)
  @brief Calculate a gaussian

  Returns the value of a gaussian in dependence of expofacs with 
  nu_v  = 0. gaussian = exp((expofacs[0]*nx*nx+expofacs[1]*nx*ny+
  expofacs[2]*ny*ny+expofacs[4])).
  To be used by convolgaussfft. No modulation with respect of the
  signum of the coordinates will be done. For a number in the exponent
  lesser than MINEXPONENT the return value is 0 (see fftgaussian).

  @todo The last item in the description to be implemented

  @param nx       (int)     Relative pixelposition in x
  @param ny       (int)     Relative pixelposition in y
  @param expofacs (float *) Factors in the gaussian, calculated by 
  expofacsfft and normalised with respect to the sizes of the array

  @return float fftgaussian2d: The gaussian at the desired position,
  no error handling.
*/
/* ------------------------------------------------------------ */
float fftgaussian2d(int nx, int ny, float *expofacs);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn Cube *convolgaussfft(Cube *cube, float *expofacsfft)
  @brief Convolve a cube with a gaussian via fft

  In-place convolution of a cube Cube with a gaussian via fft. The
  convolution is not normalised in the xy-plane but in v. No
  convolution takes place in v-direction in case of only one
  plane. See function expofacsfft for definition of expofacsfft
  parameter.

  @param cube        (Cube *)  The cube
  @param expofacsfft (float *) Factors in the exponent of the gaussian

  @return (success) Cube *convolgaussfft: The convolved cube\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
Cube *convolgaussfft(Cube *cube, float *expofacsfft);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static float *expofacsfft(float sigma_maj, float sigma_min, float sigma_v, float *sincosofangle)
  @brief Calculate factors needed by convolgaussfft

  Returns an allocated array containing factors needed by
  convolgaussfft to convolve an array with a gaussian with sigma at
  the major axis sigma_major, minor axis sigma_minor, v axis sigma_v
  axis. These factors are calculated from the measures of the
  convolution kernel and won't change during the whole program.

  @param sigma_maj     (float)   The sigma in direction of the major axis
  @param sigma_min     (float)   The sigma in direction of the minor axis
  @param sigma_v       (float)   The sigma in v-direction
  @param sincosofangle (float *) An array containing the sin and the cos 
  of the position angle

  @return (success) float *expofacsfft: The factors wanted\n
          (error) NULL
*/
/* ------------------------------------------------------------ */
float *expofacsfft(float sigma_maj, float sigma_min, float sigma_v, float *sincosofangle);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: gridnconvol.h,v $
   Revision 1.5  2009/05/26 07:56:39  jozsa
   Left work

   Revision 1.4  2007/08/22 15:58:34  gjozsa
   Left work

   Revision 1.3  2005/04/14 10:32:12  gjozsa
   Left work

   Revision 1.2  2004/12/08 16:22:48  gjozsa
   Left work

   Revision 1.1.1.1  2004/10/29 11:13:05  gjozsa
   Added to CVS control


   ------------------------------------------------------------ */

/* Include guard */
#endif
