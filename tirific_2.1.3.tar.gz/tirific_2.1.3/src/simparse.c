/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file simparse.c
   @brief A utility for parsing files

   All-purpose parsing functions, excluded from the main source for
   portability reasons.

   $Source: /Volumes/DATA_J_II/data/CVS/tirific/src/simparse.c,v $
   $Date: 2011/05/25 22:25:26 $
   $Revision: 1.4 $
   $Author: jozsa $
   $Log: simparse.c,v $
   Revision 1.4  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.3  2011/05/10 00:30:16  jozsa
   Left work

   Revision 1.2  2010/03/18 15:50:55  jozsa
   Left work

   Revision 1.5  2010/02/17 01:21:40  jozsa
   finished decomp complex

   Revision 1.4  2009/06/19 17:31:59  jozsa
   Bug removal evaluating the sep option in parsenext

   Revision 1.3  2009/03/27 11:17:12  jozsa
   Left work

   Revision 1.2  2009/03/09 12:02:46  jozsa
   included decomposer input functions

   Revision 1.1.1.1  2009/03/06 12:57:04  jozsa
   imported

   Revision 1.5  2007/08/22 15:58:42  gjozsa
   Left work

   Revision 1.4  2004/12/07 10:31:45  gjozsa
   Left work

   Revision 1.3  2004/11/16 18:18:34  gjozsa
   Left work

   Revision 1.2  2004/11/09 15:52:54  gjozsa
   Fixed bug while counting lines in fct parsenext

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control

   @todo putparsed seems to have a problem with keeping a maximum length
   of an output line.


*/
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <string.h>
#include <stddef.h>
#include <stdlib.h>


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <simparse.h>

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE MACROS */
/* ------------------------------------------------------------ */
/* #define malloc(a) malloc_here(a) */
/* #define free(a)   free_here(a) */
/* #define realloc(a,b) realloc_here(a,b) */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* (PRIVATE) GLOBAL VARIABLES */
/* ------------------------------------------------------------ */
/* static int numberofmallocs = 0; */
/* static int numberoffrees = 0; */
/* static int numberofreallocs = 0; */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE TYPEDEFS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE STRUCTS */
/* ------------------------------------------------------------ */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct dcp_listll
   @brief element of a return linked list

*/
/* ------------------------------------------------------------ */
typedef struct dcp_listll
{
  /** @brief number and position of scanned element */
  int nupo[2];

  /** @brief next element */
  struct dcp_listll *next;

} dcp_listll;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct dcp_pall
   @brief element of a parameter description linked list

*/
/* ------------------------------------------------------------ */
typedef struct dcp_pall
{
  /** @brief parameter name */
  char *name;

  /** @brief position in array */
  int posi;

  /** @brief number of elements with that name */
  int numb;

  /** @brief next element */
  struct dcp_pall *next;
}
  dcp_pall;

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @struct dcp_control
   @brief Control structure for decomp functions

*/
/* ------------------------------------------------------------ */
typedef struct dcp_control
{
  /** @brief group separator */
  char grse;

  /** @brief decompose indicator */
  char dein;

  /** @brief decompose character of number sequences */
  char deco;

  /** @brief number of indexed indices */
  int ninin;

  /** @brief list of indexed indices */
  int *inin;

  /** @brief linked list of names and positions */
  dcp_pall *pall;

  /** @brief error message */
  char *error;
}
dcp_control;



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static int *dcp_get(dcp_control *dcp_controlv, char *input, decomp_listel **output, int nega)

  @brief Returns a null terminated list of positions

  @return (success)decomp_listel *dcp_get the info you want to get \n
          (error): NULL
*/
/* ------------------------------------------------------------ */
static int dcp_get(dcp_control *dcp_controlv, char *input, decomp_listel **output, int nega);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static dcp_control dcp_init(void)

  @brief Returns a control structure for decomp functions

  @return (success) decomp_control decomp_init: decomp control structure\n
          (error): NULL
*/
/* ------------------------------------------------------------ */
static dcp_control *dcp_init(void);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static void dcp_swapll(dcp_listll *first, dcp_listll *after, dcp_listll *beforeafter)

  @brief puts after behind first and mends the ll

@param first (dcp_listll *)        first element
@param after (dcp_listll *)        second element
@param beforeafter (dcp_listll *) element before second element


@return void This is not robust against errors, i.e., passing NULL will fail
*/
/* ------------------------------------------------------------ */
static void dcp_swapll(dcp_listll *first, dcp_listll *after, dcp_listll *beforeafter);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static int dcp_putsep(dcp_control *dcp_controlv, char grse, char dein, char deco)

  @brief Define separators
  @param grse            (char)           Separator for groups
  @param dein            (char)           Indicator for decomposing into single elements
  @param deco            (char)           Decoding character for number sequences

  @return (success) 0\n
          (fail)    1: separators are similar, 2: dcp_controlv is empty

*/
/* ------------------------------------------------------------ */
static int dcp_putsep(dcp_control *dcp_controlv, char grse, char dein, char deco);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static int dcp_checkiden(char *string, dcp_pall *pall, int *info)
  @brief Check ll pall for occurrence of an identifier in string

  @param string          (char *)         string to be identified
  @param pall            (dcp_pall *)     linked list with identifiers and information
  @param infor           (int *)          information is stored here: info[0]: posi info[1]: numb

  @return (success) 0\n
          (fail)    1: not in list.

*/
/* ------------------------------------------------------------ */
static int dcp_checkiden(char *string, dcp_pall *pall, int *info);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static void dcp_dest(dcp_control *dcp_controlv)

  @brief Destroys dcp_controlv

  @return void
*/
/* ------------------------------------------------------------ */
static void dcp_dest(dcp_control *dcp_controlv);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static void bubble(int length, float *array)

  @brief Bubble-sort array of length length

  @return void
*/
/* ------------------------------------------------------------ */
static void bubble(int length, int *array);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static void dcp_listll_dest(dcp_listll **dcp_listllv)

  @brief destroys the dcp_listll ll and sets *dcp_listllv = NULL

  @param dcp_listllv (dcp_listll **) pointer to a ll (take care to pass some allocated stuff, mostly &bla if bla is the ll)

  @return void
*/
/* ------------------------------------------------------------ */
 static void dcp_listll_dest(dcp_listll **dcp_listllv);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static dcp_listll *dcp_listll_app(int *startlength, char *input, int *error, char sep)

  @brief Returns to dcp_listll dcp_listlls elements dechiffering input

  Error codes in error: 
    0: No error
    1: allocation problems

  @param dcp_listllv (dcp_listll *) pointer to a ll or 0;
  @param startlength (int *)        Two-element array 0: start position 1: length
  @param input       (char *)       Input string to decipher
  @param error       (int *)        Container for error code, pass allocated *int
  @param sep         (char)         Separator for fields

  @return success: dcp_listll *dcp_listll_app pointer to last appended element
          error:   NULL, error will be set

*/
/* ------------------------------------------------------------ */
static dcp_listll *dcp_listll_app(int *startlength, char *input, int *error, char sep, int nega);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static int dcp_index(dcp_control *dcp_controlv, int number, int *list)

  @brief Replaces the indexed list in dcp_controlv with the list given. Makes a local copy

  @param dcp_controlv (dcp_control *) dcp control object containing the linked list
  @param number       (int *)         number of elements
  @param list         (int *)         list 

  @return (success) int dcp_index 0
          (failure) 1: empty dcp_controlv
                    2: allocation problems

*/
/* ------------------------------------------------------------ */
static int dcp_index(dcp_control *dcp_controlv, int number, int *list);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static int *dcp_inp(dcp_control *dcp_controlv, const char* pana, int papo, int pale)

  @brief Creates an element of dcp_pall liked list and appends it to list. pana will be copied loacally.

  @param dcp_controlv (dcp_control *) dcp control object containing the linked list
  @param pana         (const char *)  Parameter name
  @param papo         (int)           Parameter position in array
  @param pale         (int)           Parameter length, zero forbids to specify a length and the parameter has length 1

  @return (success): int dcp_inp 0\n
          (error): 1
*/
/* ------------------------------------------------------------ */
static int dcp_inp(dcp_control *dcp_controlv, const char* pana, int papo, int pale);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static  dcp_pall *dcp_pall_dest(dcp_pall *dcp_pallv)

  @brief Destroys dcp_pallv and returns the next element

  @param dcp_pallv (dcp_pall *) linked list element

  @return dcp_pall *dcp_pall_dest next element

*/
/* ------------------------------------------------------------ */
static  dcp_pall *dcp_pall_dest(dcp_pall *dcp_pallv);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn char *dcp_errmsg(dcp_control *dcp_controlv)
  @brief Returns the current error message

  On error this returns an allocated error message. Do not try to free
  this, deallocation is done via calling decomp_dest(). On no
  error, error = NULL.

  @param decomp_controlv (decomp_control) Decomp control structure

  @return success: char *decomp_errmsg Error message
          fail:    NULL If no error has occurred
*/
/* ------------------------------------------------------------ */
static char *dcp_errmsg(dcp_control *dcp_controlv);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
   @fn static char isinstring(char *string, char character)`
   @brief Test if a character is in a string
   
   Returns 1 if it is contained in the string string, 0 otherways

   @param string (char *)   A constant string
   @param character (char)  The character in which string is contained
   
   @return (success) 1 if it is found\n
    (error) 0 if it is not found
*/
/* ------------------------------------------------------------ */
static char isinstring(char *string, char character);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static char **intparsenext(char *fieldseperator, char *lineseperator,char *whitespaces, char *clamper, char *commentsep, int maxfield, char **string, int *line, char sep) 
  @brief The core of sparsenext and parsenext
  
  Returns an allocated array of allocated char arrays parsenext (freed
  by freeparsed) containing the words seperated by fieldseperator
  until the next line denoted by lineseperator (or \0) is reached or
  a number maxfield of output fields is reached. The content of string is
  set to the start of the next line or to the end of the array. On
  error (memory problems) or if nothing is to be read anymore, NULL is
  returned. Whitespaces are ignored, i.e. kjgh lkfj in a field is
  returned as kjghlkfj, if ' ' is a whitespace. Inside two clamper
  symbols whitespaces, commentsep and fieldseperators are
  ignored. Inside two comment symbols everything but the lineseperator
  is ignored. The last component of parsenext is always NULL to denote
  the end of the array. 

  @param fieldseperator (char *) The field seperators seperating
                                   single words
  @param lineseperator  (char *) The line seperators seperating lines
  @param whitespaces    (char *) Whitespaces ignored when reading
  @param clamper        (char *) Inside two clamper symbols whitespaces
                                 are taken literally and fs are ignored
  @param commentsep     (char *) Inside two commentsep's everything 
                                 is ignored but the linesep
  @param maxfield       (int)    Maximum number of fields to read 
                                 before passing the result
  @param string         (char **) The input string, the content will be changed to the start of the next line
  @param line           (int *)  The line where the search started, 
                                 any number, will be increased by 
                                 the number of encountered '@\ns'.
  @param sep (char) If set (!=0) suppress every empty field.
  @param countout (int *)     The number of chars to proceed (output, must be a pointer to an allocated int)
  
  @return (success) char **parsenext: allocated array of 
                                      allocated char arrays\n
  (error) NULL if EOF is reached or an error occured
*/
/* ------------------------------------------------------------ */
static char **intparsenext(char *fieldseperator, char *lineseperator, \
              char *whitespaces, char *clamper, char *commentsep, \
              int maxfield, char **string, int *line, char sep, int *countout);


   
/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
  @fn static int checklinelength(FILE *stream, char yesno, int maxlength, int *current_length, char *word)
  @brief Silly helper for the putparsed function, checking the length of
  a line

  If yesno is 1, then this function will do something, otherways not a
  thing. If current_length plus wordlength exceeds
  maxlength an '\n' is inserted into stream and current_length is set
  to 0. This action takes only place if current_length is not 0. An
  error occurs only if the writing to the stream fails.

  @param stream         (FILE *)
  @param yesno          (char)
  @param maxlength      (int)
  @param current_length (int *)
  @param wordlength     (int)

  @return (success) int checklinelength: 1 except if the writing into
  stream fails\n
          (error) 0
*/
/* ------------------------------------------------------------ */
static int checklinelength(FILE *stream, char yesno, int maxlength,\
			   int *current_length, int wordlength);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static void error_msg_parser(char *call_file, char *call_function, char *call_msg, int line)
  @brief Generic error message in this module

  Generates a generic error message to stderr, reporting the occurance
  of an error, the file, the function, and a message. If an input
  string is empty, no message will be generated concerning the item. A
  similar function can appear elsewhere, but this is kept private for
  prtability reasons.

  @param call_file     (char *) The file from which the call is made
  @param call_function (char *) The function from which the call is made
  @param call_msg      (char *) The error message
  @param line          (int *)  Linenumber printed if not 0 in input

  @return void
*/
/* ------------------------------------------------------------ */
static void error_msg_parser(char *call_file, char *call_function, char *call_msg, int line);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static int dcp_get_inlist(dcp_control *dcp_controlv, decomp_inlist *decomp_inlistv)
  @brief Returns a struct containing the next active indices of indexed indices

  Wrapper around decomp_get_inlist

  @param decomp_inlistv (decomp_inlist *) allocated and properly configured decomp_inlist struct (as returned by decomp_get_inlist())
  @param dcp_controlv (dcp_control *) Decomp control structure

  @return 0: success
          1: index is not represented in input groups
          2: all parameters indexed inside group
*/
/* ------------------------------------------------------------ */
static int dcp_get_inlist(dcp_control *dcp_controlv, decomp_inlist *decomp_inlistv);



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/** 
  @fn static int matchint(int val, int nelem, int *thelist)

  @brief Search an int list for a match

  @param val (int) the value to be searched for
  @param nelem (int) the number of elements in the list
  @param thelist (int) the list

  @return int matchint: 1 found match
                        0 did not find match
*/
/* ------------------------------------------------------------ */
static int matchint(int val, int nelem, int *thelist);


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION CODE */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* read in the next words from a file into an array of words */

char **parsenext(char *fieldseperator, char *lineseperator, char *whitespace, char *clamper, char *commentsep, int maxfield, FILE *filepointer, int *line, char sep)

{
  char **parsenext = NULL;
  char *nextline = NULL;
  char nextcharacter;
  fpos_t position ;
  int charcounter = 0, countout = 0, sizer = 0;
  
  /* check if EOF is reached or only whitespaces are found */
  fgetpos(filepointer, &position);

  if (getc(filepointer) == EOF) {
    goto error;
  }

  /* wind back */
  fsetpos(filepointer, &position);

  /* We'll copy it as it will be returned */

  /* First find the number of characters in the next line */
  while ((nextcharacter = fgetc(filepointer)) != EOF && !isinstring(lineseperator, nextcharacter)) {
    ++charcounter;
  }
    
  if (nextcharacter == EOF) {
    ++sizer;
  }

  /* Now read in the line */
  fsetpos(filepointer, &position);

  if (!(nextline = (char *) malloc((charcounter+1)*sizeof(char)))) {
    goto error;
  }
  if (charcounter)
    if (fread(nextline, sizeof(char), charcounter, filepointer))
      ;
  nextline[charcounter] = '\0';

  /* put the filepointer one step forward */
/*   getc(filepointer); */

  /* Do not free nextline, this is done in intparsenext */
  if (!(parsenext = intparsenext(fieldseperator, lineseperator, whitespace, clamper, commentsep, maxfield, &nextline, line, sep, &countout)))
    goto error;
  
/* Spool back to the place numberofwords have been read */
  fsetpos(filepointer, &position);
  fseek(filepointer, countout-sizer, SEEK_CUR);

  return parsenext;
  
 error:
  if (nextline)
    free(nextline);
  fsetpos(filepointer, &position);
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* read in the next words from a string into an array of words */

char **sparsenext(char *fieldseperator, char *lineseperator, char *whitespace, char *clamper, char *commentsep, int maxfield, char **string, int *line, char sep, char reset)

{
  char **parsenext = NULL;
  char *nextline = NULL;
  char nextcharacter;
  char *position = NULL;
  int charcounter = 0,  countout = 0, sizer = 0;

  if ((string == NULL) || (*string == NULL)) {
    goto error;
  }

  /* check if EOF is reached or only whitespaces are found */
  position = *string;

  /* We'll copy it as it will be returned */

  /* First find the number of characters in the next line */
  while ((nextcharacter = **string) != '\0' && !isinstring(lineseperator, nextcharacter)) {
    ++charcounter;
    ++(*string);
  }
    
  if (nextcharacter == '\0') {
    ++sizer;
  }

  /* Now read in the line */
  *string = position;

  if (!(nextline = (char *) malloc((charcounter+1)*sizeof(char)))) {
    goto error;
  }

  if (charcounter) {
    for (countout = 0; countout < charcounter; ++countout)
      nextline[countout] = (*string)[countout];
  }
  nextline[charcounter] = '\0';

  /* Do not free nextline, this is done in intparsenext */
  if (!(parsenext = intparsenext(fieldseperator, lineseperator, whitespace, clamper, commentsep, maxfield, &nextline, line, sep, &countout)))
    goto error;

  if (!reset)
    *string = position+countout-sizer;

  return parsenext;
  
 error:
  if (nextline)
    free(nextline);
  if (position)
    *string = position;
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* read in the next words from a string into an array of words */

static char **intparsenext(char *fieldseperator, char *lineseperator, char *whitespace, char *clamper, char *commentsep, int maxfield, char **string, int *line, char sep, int *countout)

{
  char **parsenext = NULL;
  char *nextline = NULL, *nextline2;
  char comment_on = 0, clamper_on = 0;
  int charcounter = 0, numberofwords = 0, charsinword;
  int i;

  nextline = *string;

  /* The string nextline contains everything we want to hack into pieces */
  nextline2 = nextline;

  /* Reset numberofwords and charcounter */
  charcounter = 0;
  numberofwords = 1;
  
  /* Count the number of fields to be stored */
  while (nextline[charcounter] != '\0') {

    /* if a fieldseperator is encountered then the number of fields gets increased */
    if (isinstring(fieldseperator, nextline[charcounter])) {

      /* except inside a comment or a clamper */
      if (comment_on)
	;
      else if (clamper_on)
	;
      else
	++numberofwords;
    }

    /* if a comment sign is encountered comment_on will be switched except in a clamper */
    if (isinstring(commentsep, nextline[charcounter])) {

      /* except inside a clamper */
      if (clamper_on)
	;
      else
	comment_on = !comment_on;
    }

    /* if a clamper sign is encountered clamper_on will be switched except in a comment */
    if (isinstring(clamper, nextline[charcounter])) {

      /* except inside a comment */
      if (comment_on)
	;
      else
	clamper_on = !clamper_on;
    }

    ++charcounter;
  }

  /* Compare the number of the words with the maximum number of words */
  numberofwords = ((maxfield > 0) && (maxfield < numberofwords)) ? maxfield : numberofwords;

  /* Now we know the number of words, so we can allocate for the array */
  if (!(parsenext = (char **) malloc((numberofwords+1)*sizeof(char *))))
    goto error;

  /* We will set everything to NULL for the error handling */
  for (i = 0; i <= numberofwords; ++i) 
    parsenext[i] = NULL;

  /* Now we will allocate memory for the single fields, i.e. first sort out the memory problems */

  /* We will need to come back here */
  comment_on = 0;
  clamper_on = 0;
  charcounter = 0;

  /* count the characters in the words */

  for (i = 0; i < numberofwords; ++i) {
    charsinword = 0;
    while (nextline[charcounter] != '\0') {
      
      /* if a fieldseperator is encountered then go to the next word */
      if (isinstring(fieldseperator, nextline[charcounter])) {

	/* except inside a comment or a clamper */
	if (comment_on)
	  ;
	else if (clamper_on)
	  ++charsinword;
	else
	  break;
      }
      
      /* if a comment sign is encountered comment_on will be switched except in a clamper */
      else if (isinstring(commentsep, nextline[charcounter])) {
	
	/* except inside a clamper */
	if (clamper_on)
	  ++charsinword;
	else
	  comment_on = !comment_on;
      }
      
      /* if a clamper sign is encountered clamper_on will be switched except in a comment */
      else if (isinstring(clamper, nextline[charcounter])) {
	
	/* except inside a comment */
	if (comment_on)
	  ;
	else
	  clamper_on = !clamper_on;
      }
      
      /* if a whitespace is encountered it will be ignored except if clamped */
      else if (isinstring(whitespace, nextline[charcounter])) {
	
	/* except inside a clamper */
	if (clamper_on)
	  ++charsinword;
      }

      /* Otherwise we have a normal character */
      else  {
	
	/* except inside a comment */
	if (!comment_on)
	  ++charsinword;
      }


    ++charcounter;
    }

    /* Now allocate memeory */
    if (!(parsenext[i] = (char *) malloc((charsinword+1)*sizeof(char))))
      goto error;
    /* If the memory is allocated make a string out of it */
    *(parsenext[i]+charsinword) = '\0';

    /* Hop over the next sign (we counted the words) */
    charcounter = charcounter+1;
  }

  /* Now that we have safely allocated all the space, we can continue */

  /* Now we can change the lines and put back the FILE pointer */

  /* Count the number of \ns and change line accordingly */

  /* if the lineseperator contains an \n then we increase the number by one */
  if (isinstring(lineseperator, '\n')){
    charsinword = 1;
  }

  /* if not, then count them */
  else {

    charsinword=0;
    for (i = 0; i < charcounter-1; ++i) {

      /* if a \n is encountered then the number of charsinword gets increased */
      if (isinstring("\n", nextline[i]))

	/* We abuse charsinword here for counting lines */
	++charsinword;

    }
  }
  /* Change the linenumber */
  *line = *line + charsinword;
  
  /*****************************/
  /*****************************/

/* Spool back to the place numberofwords have been read */
/*   fsetpos(filepointer, &position); */
/*   fseek(filepointer, charcounter, SEEK_CUR); */

/* Instead of this, we output charcounter */
  *countout = charcounter;

  /*****************************/
  /*****************************/
  /* should be able to define a common function for parsenext and sparsenext for this part */

  /* The last point is to read in all the stuff */
/* We will need to come back here */
  comment_on = 0;
  clamper_on = 0;
  charcounter = 0;

  /* count the characters in the words */
  for (i = 0; i < numberofwords; ++i) {
    charsinword = 0;
    while (nextline[charcounter] != '\0') {
      
      /* if a fieldseperator is encountered then go to the next word */
      if (isinstring(fieldseperator, nextline[charcounter])) {

	/* except inside a comment or a clamper */
	if (comment_on)
	  ;
	else if (clamper_on) {
	  *(parsenext[i]+charsinword) = nextline[charcounter];
	  ++charsinword;
	}
	else
	  break;
      }
      
      /* if a comment sign is encountered comment_on will be switched except in a clamper */
      else if (isinstring(commentsep, nextline[charcounter])) {
	
	/* except inside a clamper */
	if (clamper_on) {
	  *(parsenext[i]+charsinword) = nextline[charcounter];
	  ++charsinword;
	}
	else
	  comment_on = !comment_on;
      }
      
      /* if a clamper sign is encountered clamper_on will be switched except in a comment */
      else if (isinstring(clamper, nextline[charcounter])) {
	
	/* except inside a comment */
      if (comment_on)
	;
      else
	clamper_on = !clamper_on;
      }
      
      /* if a whitespace is encountered it will be ignored except if clamped */
      else if (isinstring(whitespace, nextline[charcounter])) {
	
	/* except inside a clamper */
	if (clamper_on) {
	  *(parsenext[i]+charsinword) = nextline[charcounter];
	  ++charsinword;
	}
      }

      /* There is the possibility that we encountered a normal character */
      else {
	if (!comment_on) {
	  *(parsenext[i]+charsinword) = nextline[charcounter];
	  ++charsinword;
	}
      }


      ++charcounter;
    }

    /* Hop over the next sign (we counted the words) */
    charcounter = charcounter+1;
  }

  free(nextline);

  /* Now, delete every empty element, if demanded */
  if ((sep)) {
    numberofwords = 0;
    charsinword = 0;
    
    /* As long as there is no NULL check if there is an empty line */
    while ((parsenext[numberofwords])) {
      
      /* If there is an empty line, place everything one step back */
      if (parsenext[numberofwords][0] == '\0') {
	/* Simply delete the string first */
	free(parsenext[numberofwords]);
	
	charsinword = 0;
	while((parsenext[numberofwords+charsinword])) {
	  parsenext[numberofwords+charsinword] = parsenext[numberofwords+charsinword+1];
	  ++charsinword;
	}
      }
      else {
	++numberofwords;
      }
    }
    
    if ((sep)) {
      parsenext = (char **) realloc(parsenext,(numberofwords+1)*sizeof(char *));
    }
  }
  
  return parsenext;
 
 error:
  if (parsenext) {
    for (i = 0; i < numberofwords; ++i)
      free(parsenext[i]);
    free(parsenext);
  }
  return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Test if a character is in a string */

static char isinstring(char *string, char character)
{
  char simplearray[2];

  /* Make a string from the character */
  simplearray[0] = character;
  simplearray[1] = '\0';

  /* Then test if it is in the string */
  if (strpbrk(string, simplearray)) {
    return 1;
  }
  else {
    return 0;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destroys an char ** array that is created by parsenext */

void freeparsed(char **parsenext)
{
  int i = 0;

  if (parsenext) {

    while(parsenext[i]) {
      free(parsenext[i]);
      ++i;
    }

    free(parsenext);
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Count the words in a char * array */

int countwordsinwarr(char **thearray)
{
  int countwordsinwarr = 0;

  if (!(thearray)) {
    return -1;
  }

  while (*thearray) {
    ++countwordsinwarr;
    ++thearray;  
  }

  return countwordsinwarr;
}

/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* compare two strings up to minmatch characters */

char comp(char *constring1, char *constring2, int minmatch)
{
  char i = 0;

  /* return 0 if the length of the first argument is higher than the
     length of the second or if length of first argument is
     insufficient for identification */

  if (strlen(constring1) > strlen(constring2) || strlen(constring1) < minmatch)
       return 0;

  /* now compare the two strings until the end of first argument is
     reached */

  while (i < strlen(constring1)){
    if (*(constring1+i) != *(constring2+i)){

      /* return 0 if words differ */

      return 0;
    }
    ++i;
  }
  
  /* return 1 for success */

    return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Check if the first characters of word1 match with word2 */

int comp2words(char *word1, char *word2)
{ 
  int i = 0;
  if ( strlen(word1) > strlen(word2))
    return 0;
  else
    while (i < strlen(word1)) {
      if (*(word1+i) != *(word2+i)) {
	
	/* return 0 if words differ */
	
	return 0;
      }
      ++i;
    }
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Check the number of newlines until the next word is 
  reached */

int checkline(FILE *input)
{
  int checkline = 0;
  char nextchar;
 while ((nextchar = fgetc(input)) == '\t' || nextchar == '\r' || \
	nextchar == '\v' || nextchar == '\f' || nextchar == '\n' || \
	nextchar == ' ')
   if (nextchar == '\n')
     ++checkline;
 ungetc(nextchar,input);
 return checkline;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* read the next numberofnumbers numbers into an array */

float *nextnumbers(FILE *input, int *line, int numberofnumbers)
{
  int testnumber, lineerror, i = 0;
  float number;
  fpos_t fileposition;
  float *nextnumber;
  
  /* allocating space */
  if ((nextnumber = (float *) malloc(numberofnumbers*sizeof(float))))
    ;
  else
    return NULL;

  /* find out about the current line */
  lineerror = *line;

  /* find out about the file pointer */
  fgetpos(input, &fileposition);

  /* find out about the current line just before the next word */
  *line = *line+checkline(input);

  /* read in the numbers */
  while (++i <= numberofnumbers) {

    /* if there is no error */
    if ((testnumber = fscanf(input, "%e", &number))) {
      
      /* and if EOF is not reached */
      if (testnumber != EOF) {
	
	/* read in the number */
	*(nextnumber+i-1) = number;
	
	/* track the line */
	*line = *line+checkline(input);
      }

      /* on any error leave */
      else {
	*line = lineerror;
	fsetpos(input, &fileposition);
	free(nextnumber);
	return NULL;
      }
    }

    /* on any error leave */
    else {
      *line = lineerror;
      free(nextnumber);
      fsetpos(input, &fileposition);
      return NULL;
    }
  }
  
  /* return the array */
    return nextnumber;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Read the next numberofnumbers numbers into an array */

float *nextnumbers2(FILE *input, int *line, int numberofnumbers)
{
  int testnumber, i = 0;
  float number;
  float *nextnumber;
  
  /* allocating space */
  if ((nextnumber = (float *) malloc(numberofnumbers*sizeof(float))))
    ;
  else
    return NULL;

  /* find out about the current line */

  /* find out about the file pointer */

  /* find out about the current line just before the next word */
  *line = *line+checkline(input);

  /* read in the numbers */
  while (++i <= numberofnumbers) {

    /* if there is no error */
    if ((testnumber = fscanf(input, "%e", &number))) {
      
      /* and if EOF is not reached */
      if (testnumber != EOF) {
	
	/* read in the number */
	*(nextnumber+i-1) = number;
	
	/* track the line */
	*line = *line+checkline(input);
      }

      /* on any error leave */
      else {
	free(nextnumber);
	return NULL;
      }
    }

    /* on any error leave */
    else {
      free(nextnumber);
      return NULL;
    }
  }
  
  /* return the array */
    return nextnumber;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Read the next numberofnumbers numbers into an array */

int *nextnumbersint(FILE *input, int *line, int numberofnumbers)
{
  int testnumber, lineerror, i = 0;
  int number;
  fpos_t fileposition;
  int *nextnumber;
  
  /* allocating space */
  if ((nextnumber = (int *) malloc(numberofnumbers*sizeof(int))))
    ;
  else
    return NULL;

  /* find out about the current line */
  lineerror = *line;

  /* find out about the file pointer */
  fgetpos(input, &fileposition);

  /* find out about the current line just before the next word */
  *line = *line+checkline(input);

  /* read in the numbers */
  while (++i <= numberofnumbers) {

    /* if there is no error */
    if ((testnumber = fscanf(input, "%i", &number))) {
      
      /* and if EOF is not reached */
      if (testnumber != EOF) {
	
	/* read in the number */
	*(nextnumber+i-1) = number;
	
	/* track the line */
	*line = *line+checkline(input);
      }

      /* on any error leave */
      else {
	*line = lineerror;
	fsetpos(input, &fileposition);
	free(nextnumber);
	return NULL;
      }
    }

    /* on any error leave */
    else {
      *line = lineerror;
      free(nextnumber);
      fsetpos(input, &fileposition);
      return NULL;
    }
  }
  
  /* return the array */
    return nextnumber;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Read the next numberofnumbers numbers into an array */

int *nextnumbersint2(FILE *input, int *line, int numberofnumbers)
{
  int testnumber, i = 0;
  int number;
  int *nextnumber;
  
  /* allocating space */
  if ((nextnumber = (int *) malloc(numberofnumbers*sizeof(int))))
    ;
  else
    return NULL;

  /* find out about the current line */

  /* find out about the file pointer */

  /* find out about the current line just before the next word */
  *line = *line+checkline(input);

  /* read in the numbers */
  while (++i <= numberofnumbers) {

    /* if there is no error */
    if ((testnumber = fscanf(input, "%i", &number))) {
      
      /* and if EOF is not reached */
      if (testnumber != EOF) {
	
	/* read in the number */
	*(nextnumber+i-1) = number;
	
	/* track the line */
	*line = *line+checkline(input);
      }

      /* on any error leave */
      else {
	free(nextnumber);
	return NULL;
      }
    }

    /* on any error leave */
    else {
      free(nextnumber);
      return NULL;
    }
  }
  
  /* return the array */
    return nextnumber;
}

/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* check if EOF is reached, ignoring whitespaces, leave the FILE pointer unchanged */

int checkeof(FILE *inputfile)
{
  fpos_t position;
  char nextchar;

  fgetpos(inputfile, &position);
  while ((nextchar = fgetc(inputfile)) != EOF) {
    if (nextchar != '\t' && nextchar != '\r' && nextchar != '\v' && nextchar != '\f' && nextchar != '\n' && nextchar != ' ') {
	fsetpos(inputfile, &position);
	return 0;
    }
  }
  fsetpos(inputfile, &position);
  return EOF;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Append an array of words with a certain format to a FILE */

int putparsed(FILE *filepointer, char **array,\
	      char fieldseparator, char lineseparator,\
	      char whitespace, char clamper, char comment,\
	      int fields, int linelength, int current_length)
{
  char linebreak = 1;
  fpos_t position;

  fgetpos(filepointer, &position);
  
  /* Check if any of the special characters is a linebreak or if
     linelength is an impossible value */
  if (fieldseparator == '\n' || lineseparator == '\n' || whitespace == '\n' || clamper == '\n' || comment == '\n' || !linelength)
    /* If yes we won't break any line artificially */
    linebreak = 0;
  
  /* If this is a comment then put the comment sign at the start and
     terminate any other sign that is a comment sign */
  if ((comment)) {
    if (fieldseparator == comment)
      fieldseparator = '\0';
    if (lineseparator == comment)
      lineseparator = '\0';
    if (whitespace == comment)
      whitespace = '\0';
    if (clamper == comment)
      clamper = '\0';
    
    /* Put a comment symbol */
    if (!checklinelength(filepointer, linebreak, linelength, &current_length, 1+ !!whitespace))
      goto error;
    if (fputc(comment, filepointer) == EOF)
      goto error;
    ++current_length;
    /* If whitespace is set we use one here */
    if ((whitespace)) {
      if (fputc(whitespace, filepointer) == EOF)
	goto error;
      ++current_length;
    }
  }
  
  if (*array) {
    /* Put out the first word */
    if (fields) {
      /* Check the first word for special symbols to be clamped and take
	 steps */
      if ((clamper)) {
	if (isinstring(*array,fieldseparator) || isinstring(*array, lineseparator) || isinstring(*array, comment) || isinstring(*array, whitespace)) {
	  
	  /* Check for the length of the line */
	  if ((whitespace)) {
	    if (!checklinelength(filepointer, linebreak, linelength, &current_length, 2))
	      goto error;
	  }
	  else
	    {	  if (!checklinelength(filepointer, linebreak, linelength, &current_length, 1))
	      goto error;
	    }
	  if (fputc(clamper,filepointer) == EOF)
	    goto error;
	  else
	    ++current_length;
	  if ((whitespace)) {
	    if (fputc(whitespace,filepointer) == EOF)
	      goto error;
	    else
	      ++current_length;
	  }
	}
      }
      
      /* Now we really put out the word */
      
      /* Check for the linelength, at least a semicolon has to follow,
	 thus '+1'*/
      if (!checklinelength(filepointer, linebreak, linelength, &current_length, strlen(*array)+!!(fieldseparator)))
	goto error;

      /* put the word in the stream */

      /* We have to check for the length of the array, because
	 otherwise fprintf would report an error in case of an empty
	 string */
      if ((strlen(*array))) {
	if (fprintf(filepointer, "%s", *array) < 0)
	  goto error;
	current_length = current_length + strlen(*array);
      }

      /* Now the story with the clamper again */
      if ((clamper)) {
	if (isinstring(*array,fieldseparator) || isinstring(*array, lineseparator) || isinstring(*array, comment) || isinstring(*array, whitespace)) {
	  
	  /* Check for the length of the line */
	  if ((whitespace)) {
	    if (!checklinelength(filepointer, linebreak, linelength, &current_length, 2+!!(fieldseparator)))
	      goto error;
	  }
	  else {
	    if (!checklinelength(filepointer, linebreak, linelength, &current_length, 1+!!(fieldseparator)))
	      goto error;
	  }
	  
	  if ((whitespace)) {
	    if (fputc(whitespace,filepointer) == EOF)
	      goto error;
	    else
	      ++current_length;
	    if (fputc(clamper,filepointer) == EOF)
	      goto error;
	    else
	      ++current_length;
	  }
	}
      }
      --fields;
    }
  }

  ++array;
  /* Now put the content of the rest of the array in the file */
  while ((*array)) {

    /* We put the fieldseparator */
    if ((fieldseparator))
      if (fputc(fieldseparator,filepointer) == EOF)
	goto error;

    /* If the maximum nuber of fields is reached stop */
    if (!(fields))
      break;

    /* Now sort out if we need clamping */
    if ((clamper)) {
      if (isinstring(*array,fieldseparator) || isinstring(*array, lineseparator) || isinstring(*array, comment) || isinstring(*array, whitespace) ) {

	/* Check for the length of the line */
	if ((whitespace)) {
	  if (!checklinelength(filepointer, linebreak, linelength, &current_length, 2))
	      goto error;
	}
	else {
	  if (!checklinelength(filepointer, linebreak, linelength, &current_length, 1))
	    goto error;
	}

	if (fputc(clamper,filepointer) == EOF)
	  goto error;
	else
	  ++current_length;
	if ((whitespace)) {
	  if (fputc(whitespace,filepointer) == EOF)
	    goto error;
	  else
	    ++current_length;
	}
      }
    }

    /* Now put out the word */
    if (!checklinelength(filepointer, linebreak, linelength, &current_length, strlen(*array) + !!whitespace))
      goto error;

    /* If we are at the start of a line we put no blank, if not we do */
    if ((whitespace)) {
      if ((current_length)) {
	if (fputc(whitespace, filepointer) == EOF)
	  goto error;
	current_length = current_length + !!current_length;
      }
    }

    /* We have to check for the length of the array, because otherwise fprintf would report an error in case of an empty string */
    if ((strlen(*array))) {
    if (fprintf(filepointer, "%s", *array) < 0)
      goto error;
    current_length = current_length + strlen(*array);
    }

    /* At the end, again, check for the clamping */
    if ((clamper)) {
      if (isinstring(*array,fieldseparator) || isinstring(*array, lineseparator) || isinstring(*array, comment) || isinstring(*array, whitespace)) {

	/* Check for the length of the line */
	if ((whitespace)) {
	  if (!checklinelength(filepointer, linebreak, linelength, &current_length, 2+!!(fieldseparator)))
	    goto error;
	}
	else {
	  if (!checklinelength(filepointer, linebreak, linelength, &current_length, 1+!!(fieldseparator)))
	    goto error;
	}
	
	if ((whitespace)) {
	  if (fputc(whitespace,filepointer) == EOF)
	    goto error;
	  else
	    ++current_length;
	  if (fputc(clamper,filepointer) == EOF)
	    goto error;
	  else
	    ++current_length;
	}
      }
    }

    ++array;
    --fields;
  }

  /* Now we are through and have to put as a last word a lineseparator
     which we shouldn't have done */

  if ((lineseparator)) {
    /* This should work now */
      if (fputc(lineseparator,filepointer) == EOF)
	goto error;
  }

  /* At the end we search if there should be another comment sign */
  if ((comment)) {

    /* If whitespace is set we use one here */
    if ((whitespace)) {
      if (!checklinelength(filepointer, linebreak, linelength, &current_length, 2))
	goto error;
      if (fputc(whitespace, filepointer) == EOF)
	goto error;
      ++current_length;
    }
    else
      {	  if (!checklinelength(filepointer, linebreak, linelength, &current_length, 1))
	goto error;
      }

    /* Put a comment symbol */
    if (fputc(comment, filepointer) == EOF)
      goto error;
    ++current_length;
  }

  return 1;

  /* The error we may encounter is that we cannot write into stream, which is constantly checked */  
 error:
  error_msg_parser("parser.c","putparsed","Error writing to open file: disk error?",0);
  fsetpos(filepointer, &position);
  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Silly helper for the putparsed function, checking the length of
   a line */

static int checklinelength(FILE *stream, char yesno, int maxlength, \
int *current_length, int wordlength)
{
  if (!(yesno))
    return 1;
  if (*current_length) {
    if (wordlength + *current_length > maxlength) {
      if (fputc('\n',stream) == EOF)
	return 0;
      *current_length = 0;
    }
  }
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Generic error message */

static void error_msg_parser(char *call_file, char *call_function, char *call_msg, int line)
{
  fprintf(stderr,"ERROR REPORTED\n");
  if (*call_file != '\0')
  fprintf(stderr,"FILE: %s\n", call_file);
  if (*call_function != '\0')
  fprintf(stderr,"FUNCTION: %s\n", call_function);
  if (*call_msg != '\0')
  fprintf(stderr,"MESSAGE: %s \n", call_msg);
  if (line != 0)
  fprintf(stderr,"Line: %i\n", line);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a control structure for decomp functions */
static dcp_control *dcp_init(void)
{
  dcp_control *dcp_init;

  if (!(dcp_init = (dcp_control *) malloc(sizeof(dcp_control))))
    return NULL;

  /* initialise */
  dcp_init -> grse = ',';
  dcp_init -> dein = '*';
  dcp_init -> deco = ':';
  dcp_init -> ninin = 0;
  dcp_init -> inin = NULL;
  dcp_init -> pall = NULL;
  dcp_init -> error = NULL;

  return dcp_init;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a control structure for decomp functions */
decomp_control decomp_init(void)
{
  return (decomp_control) dcp_init();
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destroys dcp_controlv */
static void dcp_dest(dcp_control *dcp_controlv)
{
  dcp_pall *pall;

  if (dcp_controlv) {
    if (dcp_controlv -> inin)
      free(dcp_controlv -> inin);
    if (dcp_controlv -> error)
      free(dcp_controlv -> error);

    pall = dcp_controlv -> pall;
    while ((pall = dcp_pall_dest(pall)))
      ;
    free(dcp_controlv);
  }

  return;
}
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destructs decomp_controlv */
void decomp_dest(decomp_control decomp_controlv)
{
  dcp_dest((dcp_control *) decomp_controlv);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destructs decomp_controlv */
static char *dcp_errmsg(dcp_control *dcp_controlv)
{
  return dcp_controlv -> error;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destructs decomp_controlv */
char *decomp_errmsg(decomp_control decomp_controlv)
{
return  dcp_errmsg((dcp_control *) decomp_controlv);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates an element of dcp_pall liked list and appends it to list. pana will be copied loacally. */
static int dcp_inp(dcp_control *dcp_controlv, const char* pana, int papo, int pale)
{
  dcp_pall *dcp_pall_app = NULL;
  dcp_pall *count;
  int pananlen;

  if (!dcp_controlv)
    goto error;

  /* Allocate the element */
  if (!(dcp_pall_app = (dcp_pall *) malloc(sizeof(dcp_pall))))
    goto error;

  dcp_pall_app -> name = NULL;
  dcp_pall_app -> next = NULL;


  /* Check pana */
  if (!pana)
    goto error;

  /* Count words in pana */
  pananlen = 0;
  while (pana[pananlen++])
    ;

  /* Allocate and copy pana */
  if (!(dcp_pall_app -> name = (char *) malloc(pananlen*sizeof(int))))
    goto error;
  strcpy(dcp_pall_app -> name,pana);

  /* Put papo and pale into place */
  dcp_pall_app -> posi = papo;
  dcp_pall_app -> numb = pale;

  /* link it */
  if ((count = dcp_controlv -> pall)) {
    
    while (count -> next)
      count = count -> next;
    
    count -> next = dcp_pall_app;
  }
  else {
    dcp_controlv -> pall = dcp_pall_app;
  }

  return 0;

 error:
  dcp_pall_dest(dcp_pall_app);
  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Input a parameter with name, position, and length */
int decomp_inp(decomp_control decomp_controlv, const char* pana, int papo, int pale)
{
  return dcp_inp((dcp_control *) decomp_controlv, pana, papo, pale);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destroys dcp_pallv and returns the next element */
static  dcp_pall *dcp_pall_dest(dcp_pall *dcp_pallv)
{
  dcp_pall *dcp_pall_dest;

  if (dcp_pallv) {
    if (dcp_pallv -> name)
      free(dcp_pallv -> name);
    dcp_pall_dest = dcp_pallv -> next;
    free(dcp_pallv);
    return dcp_pall_dest;
  }
  return NULL;
}

/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Define separators */
static int dcp_putsep(dcp_control *dcp_controlv, char grse, char dein, char deco)
{
  if (!dcp_controlv)
    return 2;

  if (grse == dein || dein == deco || deco == grse)
    return 1;

  dcp_controlv -> grse = grse;
  dcp_controlv -> dein = dein;
  dcp_controlv -> deco = deco;

  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Replaces the indexed list in dcp_controlv with the list given. Makes a local copy */
static int dcp_index(dcp_control *dcp_controlv, int number, int *list)
{
  int *internlist;
  int length;

  if (!dcp_controlv || number < 0)
    return 1;

  if (number > 0) {
    if (!(internlist = (int *) malloc(number*sizeof(int))))
      return 1;
    dcp_controlv -> ninin = number;
  }
  else {
    internlist = NULL;
    dcp_controlv -> ninin = 0;
  }


  if (dcp_controlv -> inin)
    free(dcp_controlv -> inin);

  length = number;

  while(number--)
    internlist[number] = list[number];

  bubble(number, internlist);

  dcp_controlv -> inin = internlist;

  return 0;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Replaces the indexed list in decomp_controlv with the list given. Makes a local copy */
int decomp_index(decomp_control decomp_controlv, int number, int *list)
{
  return dcp_index((dcp_control *) decomp_controlv, number, list);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Define separators */
int decomp_putsep(decomp_control decomp_controlv, char grse, char dein, char deco)
{
  return dcp_putsep((dcp_control *) decomp_controlv, grse, dein, deco);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destructor for a null terminated array of decomp_listel structs */
void decomp_list_dest(decomp_listel *decomp_listelv)
{
  int i = 0;

  if (!decomp_listelv)
    return;

  while ((decomp_listelv + i) -> nuel != -1) {
    if ((decomp_listelv + i) -> nuel) {
      if ((decomp_listelv + i) -> poli)
	free((decomp_listelv + i) -> poli);
    }
    ++i;
  }
  
  free(decomp_listelv);
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a null terminated list of positions */

#define ERROR_LENGTH 43 /* length of error message */

static int dcp_get(dcp_control *dcp_controlv, char *input, decomp_listel **output, int nega)
{

  decomp_listel *decomp_listelv = NULL;
  char **prs_1 = NULL;
  char **prs_2 = NULL;
  char fs[2];
  char dein = 0;
  int i, action;
  int justname;
  int elinf[2];
  int line = 0;
  int group = 0;
  int elnum_out = 0;
  int minindex = 0, maxindex = 0;
  size_t position;
  dcp_listll *llstart = NULL,*llrun = NULL, *llfirst, *llbefn = NULL, **lltop;
  int errcode = 0;
  int run = 0;
  int listi;
  int nupocur;
  char *inputstart;
  

  if (dcp_controlv -> error)
    free(dcp_controlv -> error);

  if (!(dcp_controlv -> error = (char *) malloc((ERROR_LENGTH+1)*sizeof(char))))
    return 1;

  if ((!dcp_controlv)) {
    sprintf(dcp_controlv -> error,"No decomp_controlv");
    errcode = 2;
    goto error;
  }

  if ((!input)) {
    sprintf(dcp_controlv -> error,"No input");
    errcode = 2;
    goto error;
  }

  /* make a string of the group separator */
  fs[0] = dcp_controlv -> grse;
  fs[1] = '\0';

  inputstart = input;
  
  /* start with checking if the input string contains only whitespaces */
  i = 0;
  listi = 1;

  while (input[i]) {
    if (input[i] != '\t' || input[i] != ' ') {
      listi = 0;
      break;
    }
    ++i;
  }
  
  /* If now we have encountered an empty string, we return a list containing a list of one listel with -1 elements of content (indicating end of list) */

  if ((listi)) { 
    if (!(decomp_listelv = (decomp_listel *) malloc(sizeof(decomp_listel)))) {
	sprintf(dcp_controlv -> error,"Memory allocation problems");
	errcode = 1;
	goto error;
    }

    /* fill this with content */
    decomp_listelv -> nuel = -1;
    decomp_listelv -> grnr = 0;
    decomp_listelv -> poli = NULL;

    *output = decomp_listelv;
    return 0;
  }

  listi = 0;

  /* one time we count, the next time we produce the object */
  while (run < 2) {
    
    input = inputstart;

    /* essential to be here and not out of the loop */
    if (!(prs_1 = sparsenext(fs, "", "", "", "", 0, &input, &line, 0, 1))) {
      sprintf(dcp_controlv -> error ,"input is NULL or memory allocation problems");
      errcode = 1;
      goto error;
    }

    while (prs_1[group]) {
      /* look if the first character in the group is a decompose indicator */
      position = 0;
      while (prs_1[group][position] == ' ' || prs_1[group][position] == '\t')
	++position;

      if (prs_1[group][position] == dcp_controlv -> dein) {
	dein = 1;
	prs_1[group][position] = ' ';
      }

      /* Hack this field into chunks, separated by whitespaces */
      if (!(prs_2 = sparsenext(" \t", "", "", "", "", 0, prs_1+group, &line, 1, 1))) {
	sprintf(dcp_controlv -> error,"Memory allocation problems");
	errcode = 1;
	goto error;
      }

      /* Check if the first element in the group is reasonable, i.e., must be a known name */
      i = 0;

      if (prs_2[i]) {
	if (dcp_checkiden(prs_2[i], dcp_controlv -> pall, elinf)) {
	  sprintf(dcp_controlv -> error,"Syntax: ");
	  strncpy(dcp_controlv -> error+8, prs_1[group], ERROR_LENGTH-8);
	  errcode = 2;
	  goto error;
	}
      }
      else {
	sprintf(dcp_controlv -> error,"Syntax: ");
	strncpy(dcp_controlv -> error+8, "empty field", ERROR_LENGTH-8);
	errcode = 2;
	goto error;      
      }

      ++i;
      /* Indicates that a name has just been read */
      justname = 1;
      
      /* Now go through the list making a ll */
      
      lltop = &llstart;
      llrun = NULL;

      while(prs_2[i]) {

	action = 0;

	if (dcp_checkiden(prs_2[i], dcp_controlv -> pall, elinf)){
	  
	  /* Check for two consecutive similar parameters */
	  
	  llrun = dcp_listll_app(elinf, prs_2[i], &errcode, dcp_controlv -> deco, nega);
	  action = 1;
	  
	  justname = 0;
	}
	else if (justname) {
	  dcp_checkiden(prs_2[i-1], dcp_controlv -> pall, elinf);
	  
	  llrun = dcp_listll_app(elinf, "", &errcode, dcp_controlv -> deco, nega);
	  dcp_checkiden(prs_2[i], dcp_controlv -> pall, elinf);
	  action = 1;
	  justname = 1;
	}
	else {
	  dcp_checkiden(prs_2[i-1], dcp_controlv -> pall, elinf);
	  
/* 	  llrun = dcp_listll_app(elinf, "", &errcode, dcp_controlv -> deco, nega); */
/* 	  dcp_checkiden(prs_2[i], dcp_controlv -> pall, elinf); */
	  action = 0;
	  justname = 1;
	}
	++i;
	
	if (llrun) {
	  if (action) {
	    *lltop = llrun;
	    while (llrun -> next) {
	      llrun = llrun -> next;
	    }
	    
	    lltop = &(llrun -> next);
	  }
	}
	else {
	  /* print some error message here */
	  if (errcode == 2) {
	    sprintf(dcp_controlv -> error,"Syntax: ");
	    strncpy(dcp_controlv -> error+8, prs_1[group], ERROR_LENGTH-8);
	  }
	  else if (errcode == 1) {
	    sprintf(dcp_controlv -> error,"Memory allocation problems");
	  }
	  goto error;
	}
      }
      
      
      /* The last element has been reached, but it's a name, followed by nothing */
      if (justname) {
	dcp_checkiden(prs_2[i-1], dcp_controlv -> pall, elinf);
	
	llrun = dcp_listll_app(elinf, "", &errcode, dcp_controlv -> deco, nega);
	
	if (llrun) {
	  *lltop = llrun;
	  while (llrun -> next) {
	    llrun = llrun -> next;
	  }
	  
	  lltop = &(llrun -> next);
	}
	else {
	  /* print some error message here */
	  if (errcode ==2) {
	    sprintf(dcp_controlv -> error,"Syntax: ");
	    strncpy(dcp_controlv -> error+8, prs_2[i-1], ERROR_LENGTH-8);
	  }
	  else if (errcode == 1) {
	    sprintf(dcp_controlv -> error,"Memory allocation problems");
	  }
	  goto error;
	}
      }    
      
            
      /* delete things that are on the index */
      llrun = llstart;
      lltop = &llstart;

      /* First all indexed items at the top of the list */	
      while (llrun) {
	for (i = 0; i < dcp_controlv -> ninin; ++i) {
	  if (llrun -> nupo[0] == dcp_controlv -> inin[i]) {
	    llbefn = llrun;
	    llrun = llrun -> next;
	    free(llbefn);
	    llstart = llrun;
	    lltop = &llstart;
	    break;
	  }
	}

	if (i == dcp_controlv -> ninin) {
	  break;
	}
      }


      /* Then delete the rest */
      llrun = llstart;

      while (llrun) {
	for (i = 0; i < dcp_controlv -> ninin; ++i) {
	  if (llrun -> nupo[0] == dcp_controlv -> inin[i]) {
	    break;
	  }
	}
	if (i == dcp_controlv -> ninin) {
	  llbefn = llrun;
	  llrun = llrun -> next;
	}
	else {
	  llbefn -> next = llrun -> next;
	  free(llrun);
	  llrun = llbefn -> next;
	}
      }

      /******* check *****/
      /******************/
/*       fprintf(stderr,"start check for group after delete \n"); */
      
/*       llrun = llstart; */
/*       while (llrun) { */
/* 	fprintf(stderr,"%i ",llrun -> nupo[0]); */
/* 	llrun = llrun -> next; */
/*       } */
/*       fprintf(stderr,"\n"); */
/*       llrun = llstart; */
/*       while (llrun) { */
/* 	fprintf(stderr,"%i ",llrun -> nupo[1]); */
/* 	llrun = llrun -> next; */
/*       } */
/*       fprintf(stderr,"\n\n"); */
      /*******************/

      /* Now sort */

      /* continue here */
      if (!dein) {
	;
      }
      else {
	/* first find start and end number */
	llrun = llstart;
	lltop = &llstart;
	
	if (llrun)
	  minindex = maxindex = llrun -> nupo[1];
	
	while (llrun) {
	  minindex = minindex > llrun -> nupo[1] ? llrun -> nupo[1] : minindex;	
	  maxindex = maxindex < llrun -> nupo[1] ? llrun -> nupo[1] : maxindex;	
	  lltop = &(llrun -> next);
	  llrun = llrun -> next;
	}      

	/* Then go through the list and swap, if necessary */

	for (i = minindex; i <= maxindex; ++i) {
	  llrun = llstart;
	  llfirst = NULL;
	  llbefn = NULL;
	  
	  while (llrun) {
	    if (llrun -> nupo[1] == i) {
	      if (llfirst) {
		dcp_swapll(llfirst,llrun,llbefn);
	      }
	      llfirst = llrun;
	    }
	    llbefn = llrun;
	    llrun = llrun -> next;
	  } 
	}
      }
      
      /* check if there is something to be sent to the output, issue a warning, not an error */
      if (!llstart) {
	sprintf(dcp_controlv -> error,"Warning, on Index: ");
	strncpy(dcp_controlv -> error+19, prs_1[group], ERROR_LENGTH-19);
	/* 	goto error;    */
      }

      /* count memory for the output in a first run */
      if (run == 0) {
	if (dein) {
	  nupocur = minindex - 1;
	  if ((llrun = llstart))
	    ++elnum_out;
	  while (llrun) {
	    llrun = llrun -> next;
	    if (llrun && (llrun -> nupo[1] != nupocur)) {
	      ++elnum_out;
	      nupocur = llrun -> nupo[1];
	    }
	  }
	}
	else
	  ++elnum_out;
      }
      
      /* continue filling the decomp_listel table in a second run */
      else {
	if (dein) {
	  llfirst = llrun = llstart;
	  if (llrun)
	    nupocur = llrun -> nupo[1];
	  while (llrun) {
	    i = 0;

	    while(llrun && (llrun -> nupo[1] == nupocur)) {
	      ++i;
	      llrun = llrun -> next;
	    }

	    if (!((decomp_listelv + listi) -> poli = (int *) malloc(i*sizeof(int)))) {
	      sprintf(dcp_controlv -> error,"Memory allocation problems");
	      errcode = 1;
	      goto error;
	    }
	    llrun = llfirst;

	    (decomp_listelv + listi) -> nuel = i;
	    (decomp_listelv + listi) -> grnr = group;

	    i = 0;
	    while(llrun && (llrun -> nupo[1] == nupocur)) {
	      (decomp_listelv + listi) -> poli[i] = llrun -> nupo[0];
	      llrun = llrun -> next;
	      ++i;
	    }
	    if (llrun)
	      nupocur = llrun -> nupo[1];
	    llfirst = llrun;
	    ++listi;
	  }
	}
	else {
	  llrun = llstart;
	  i = 0;
	  while (llrun) {
	    ++i;
	    llrun = llrun -> next;
	  }
	  if (!((decomp_listelv + listi) -> poli = (int *) malloc(i*sizeof(int)))) {
	    sprintf(dcp_controlv -> error,"Memory allocation problems");
	    errcode = 1;
	    goto error;
	  }
	  (decomp_listelv + listi) -> nuel = i;
	  (decomp_listelv + listi) -> grnr = group;

	  llrun = llstart;
	  i = 0;
	  while (llrun) {
	    (decomp_listelv + listi) -> poli[i] = llrun -> nupo[0];
	    llrun = llrun -> next;
	    ++i;
	  }
	  ++listi;
	}
      }
      freeparsed(prs_2);
      dcp_listll_dest(&llstart);

      dein = 0;

      ++group;
    }
    dein = 0;
    line = 0;
    group = 0;
    dcp_listll_dest(&llstart);
    dcp_listll_dest(&llrun);
    freeparsed(prs_1);

    if ((!run)) {
      if (!(decomp_listelv = (decomp_listel *) malloc((elnum_out+1)*sizeof(decomp_listel)))) {
	sprintf(dcp_controlv -> error,"Memory allocation problems");
	errcode = 1;
	goto error;
      }
      for (i = 0; i < (elnum_out+1);++i) {
	(decomp_listelv + i) -> poli = NULL;
      }
    }
    ++run;
 }

  /* -1-terminate the last element */
  (decomp_listelv + listi) -> nuel = -1;

  dcp_listll_dest(&llstart);
  dcp_listll_dest(&llrun);

  /* finis */
  *output = decomp_listelv;
  return errcode;

 error:
  if (prs_1)
    freeparsed(prs_1);
  if (prs_2)
    freeparsed(prs_2);
  dcp_listll_dest(&llstart);
  dcp_listll_dest(&llrun);
  decomp_list_dest(decomp_listelv);
  return errcode;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a null terminated list of positions */
int decomp_get(decomp_control decomp_controlv, char *input, decomp_listel **output, int nega)
{
  return dcp_get((dcp_control *) decomp_controlv, input, output, nega);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* puts after behind first and mends the ll */
static void dcp_swapll(dcp_listll *first, dcp_listll *after, dcp_listll *beforeafter) 
{
  dcp_listll *dummy;

  dummy = first -> next;

  if (first == beforeafter) {
    return;
  }

  first -> next = after;
  beforeafter -> next = after -> next;
  after -> next = dummy;

  return;
}

/* ------------------------------------------------------------ */

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Bubble-sort array of length length */

static void bubble(int length, int *array)
{
  int dummy;
  int counter = 0, goon = 1;

  while (goon) {
    counter = 0;
    goon = 0;
    while (++counter < length) {      
      if (array[counter-1] > array[counter]) {
	dummy = array[counter-1];
	array[counter-1] = array[counter];
	array[counter] = dummy;
	goon = 1;
	while (++counter < length) {
	  dummy = array[counter-1];
	  array[counter-1] = array[counter];
	  array[counter] = dummy;
	}
      }
    }
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Check ll pall for occurrence of an identifier in string */
static int dcp_checkiden(char *string, dcp_pall *pall, int *info)
{
  while (pall) {
  
    if (!strcmp(pall -> name, string)) {
      info[0] = pall -> posi;
      info[1] = pall -> numb;
      return 0;
    }
    pall = pall -> next;
  }

  return 1;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* destroys the dcp_listll ll and sets *dcp_listllv = NULL */
 static void dcp_listll_dest(dcp_listll **dcp_listllv)
{
  dcp_listll *ll, *ll2;
  if (!dcp_listllv)
    return;

  if (!*dcp_listllv)
    return;

  ll = *dcp_listllv;

  while (ll) {
    ll2 = ll -> next;
    free(ll);
    ll = ll2;
  }
  
  *dcp_listllv = NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Appends to dcp_listll dcp_listlls elements dechiffering input */
 static dcp_listll *dcp_listll_app(int *startlength, char *input, int *error, char sep, int nega)
{
  dcp_listll *ll, *llstart = NULL;
  char **input_content;
  char separ[2];
  int line, els;
  int start,end,step;

  separ[0] = sep;
  separ[1] = '\0';

  if (!(input_content = sparsenext(separ, "", "", "", "", 0, &input, &line, 0, 1))) {
    *error = 1;
    return NULL;
  }

  els = 0;
  if (input[0]) {
    while (input_content[els])
      ++els;
  }

  if (els > 3) {
    *error = 2;
    goto error;
  }
  
  if (els > 0) {
    if (!startlength[1]) {
      *error = 2;
      goto error;
    }
    
    /* read in the start */
    if (!(sscanf(input_content[0],"%i",&start)>0)) {
      if (input_content[0][0] == '\0') {
	start = 1;
      }
      else {
	*error = 2;
	goto error;
      }
    }
    
    /* read in the end */
    if (els > 1) {
      if (!(sscanf(input_content[1],"%i",&end) > 0)) {
	if (input_content[1][0] == '\0') {
	  end = startlength[1];
	}
	else {
	  *error = 2;
	  goto error;
	}
      }
    }
    else {
      end = start;
    }

    /* read in the step */
    if (els > 2) {
      if (!(sscanf(input_content[2],"%i",&step) > 0)) {
	*error = 2;
	goto error;	
      }
    }
    else {
      if (start > end)
	step = -1;
      else
	step = 1;
    }
  } 
  else {
    start = 1;
    end = startlength[1]?startlength[1]:1;
    step = 1;
  }

  if (!nega) {
    if (start < 1 || end < 1) {
      *error = 2;
      goto error;
    }
    if ((start > startlength[1]) || (end > startlength[1])) {
      if (!((start == 1) && (end == 1) && (startlength[1] == 0))) {
	*error = 2;
	goto error;
      }
    }
  }

  if (!step) {
      *error = 2;
      goto error;
  }

  if (start > end) {
    if (step >= 0) {
      *error = 2;
      goto error;
    }
  }
  else if (end > start) {
    if (step <= 0) {
      *error = 2;
      goto error;
    }
  }


  /* Make the ll */
  if (!(ll = llstart = (dcp_listll *) malloc(sizeof(dcp_listll)))) {
    goto error;
  }
  ll -> next = NULL;
  ll -> nupo[0] = startlength[0]+start-1;
  ll -> nupo[1] = start;
  start = start + step;

  if (step > 0) {
    while (start <= end) {
      
      if (!(ll -> next = (dcp_listll *) malloc(sizeof(dcp_listll)))) {
	goto error;
      }
      ll = ll -> next;
      ll -> next = NULL;
      ll -> nupo[0] = startlength[0]+start-1;
      ll -> nupo[1] = start;    
      start = start + step;
    }
  }
  else {
    while (start >= end) {
      
      if (!(ll -> next = (dcp_listll *) malloc(sizeof(dcp_listll)))) {
	goto error;
      }
      ll = ll -> next;
      ll -> next = NULL;
      ll -> nupo[0] = startlength[0]+start-1;
      ll -> nupo[1] = start;    
      start = start + step;
    }
  }

  ll = llstart;
  while (ll) {
    ll = ll -> next;
  }
  ll = llstart;
  while (ll) {
    ll = ll -> next;
  }
  /*******************/
  /***************/
  
  freeparsed(input_content);
  return llstart;
  
 error:
  dcp_listll_dest(&llstart);
  freeparsed(input_content);
  return NULL;
}
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Constructor for a decomp_inlist struct */
decomp_inlist *decomp_inlist_init(void)
{
  decomp_inlist *decomp_inlist_init;
  if (!(decomp_inlist_init = (decomp_inlist *) malloc(sizeof(decomp_inlist))))
    return NULL;
  decomp_inlist_init -> ipa = NULL;
  decomp_inlist_init -> inpal = NULL;
  decomp_inlist_init -> inpah = NULL;
  decomp_inlist_init -> ripa = NULL;
  decomp_inlist_init -> rinpal = NULL;
  decomp_inlist_init -> rinpah = NULL;
  decomp_inlist_init -> nuel = 0;

  return decomp_inlist_init;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destructor for a decomp_inlist struct */
void decomp_inlist_dest(decomp_inlist *decomp_inlistv)
{
  if (decomp_inlistv) {
    if (decomp_inlistv -> ipa)
      free(decomp_inlistv -> ipa);
    if (decomp_inlistv -> inpal)
      free(decomp_inlistv -> inpal);
    if (decomp_inlistv -> inpah)
      free(decomp_inlistv -> inpah);
    if (decomp_inlistv -> ripa)
      free(decomp_inlistv -> ripa);
    if (decomp_inlistv -> rinpal)
      free(decomp_inlistv -> rinpal);
    if (decomp_inlistv -> rinpah)
      free(decomp_inlistv -> rinpah);
    
    free(decomp_inlistv);
  }
  return;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a struct containing the next active indices of indexed indices */
int decomp_get_inlist(decomp_control decomp_controlv, decomp_inlist *decomp_inlistv)
{
  return dcp_get_inlist((dcp_control *) decomp_controlv, decomp_inlistv);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Search an int list for a match */
static int matchint(int val, int nelem, int *thelist)
{
  int i, j = 0;

  for (i = 0; i < nelem; ++i) {
    if (val == thelist[i]) {
      j = 1;
      break;
    }
  }

  return j;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a struct containing the next active indices of indexed indices */
static int dcp_get_inlist(dcp_control *dcp_controlv, decomp_inlist *decomp_inlistv)
{

  dcp_pall *pall_cur;
  int i, dcp_get_inlist = 0, start, ende, number, found;
  int *ipa = NULL, *inpal = NULL, *inpah = NULL;
  int *ripa = NULL, *rinpal = NULL, *rinpah = NULL;



  /* allocate and deallocate in the inlist struct */
  if (decomp_inlistv -> ipa)
    free(decomp_inlistv -> ipa);
  if (decomp_inlistv -> inpal)
    free(decomp_inlistv -> inpal);
  if (decomp_inlistv -> inpah)
    free(decomp_inlistv -> inpah);
  if (decomp_inlistv -> ripa)
    free(decomp_inlistv -> ripa);
  if (decomp_inlistv -> rinpal)
    free(decomp_inlistv -> rinpal);
  if (decomp_inlistv -> rinpah)
    free(decomp_inlistv -> rinpah);
  
  if ((dcp_controlv -> ninin)) {
    if (!(ipa = (int *) malloc((dcp_controlv -> ninin)*sizeof(int)))) {
      goto error;
    }
    if (!(inpal = (int *) malloc((dcp_controlv -> ninin)*sizeof(int)))) {
      goto error;
    }
    if (!(inpah = (int *) malloc((dcp_controlv -> ninin)*sizeof(int)))) {
      goto error;
    }
    if (!(ripa = (int *) malloc((dcp_controlv -> ninin)*sizeof(int)))) {
      goto error;
    }
    if (!(rinpal = (int *) malloc((dcp_controlv -> ninin)*sizeof(int)))) {
      goto error;
    }
    if (!(rinpah = (int *) malloc((dcp_controlv -> ninin)*sizeof(int)))) {
      goto error;
    }
  }

  decomp_inlistv -> nuel = dcp_controlv -> ninin;
  decomp_inlistv -> ipa = ipa;
  decomp_inlistv -> inpal = inpal;
  decomp_inlistv -> inpah = inpah;
  decomp_inlistv -> ripa = ripa;
  decomp_inlistv -> rinpal = rinpal;
  decomp_inlistv -> rinpah = rinpah;


  /* Go through the indices */
  for (i = 0; i < dcp_controlv -> ninin; ++i) {

    decomp_inlistv -> ipa[i] = dcp_controlv -> inin[i];

    /* Search the group */
    pall_cur = dcp_controlv -> pall;
      found = 0;

    while (pall_cur) {
      if ((dcp_controlv -> inin[i] >= (start = pall_cur -> posi)) && (dcp_controlv -> inin[i] <= (ende = (pall_cur -> posi + pall_cur -> numb-1)))) {
	
	found = 1;

	/* Check if all parameters are indexed */
	number = 0;
	while (start <= ende) {
	  if ((number = !matchint(start, dcp_controlv -> ninin, dcp_controlv -> inin))) {
	    break;
	  }
	  ++start;
	}

	if (!number) {
	  decomp_inlistv -> inpal[i] = dcp_controlv -> inin[i];
	  decomp_inlistv -> inpah[i] = dcp_controlv -> inin[i];
	  dcp_get_inlist = dcp_get_inlist | 2;
	} 
	else {
	  start = pall_cur -> posi;
	  
	  /* Now find the highest element that is not indexed */
	  number = start-1;
	  while (start < dcp_controlv -> inin[i]) {
	    if (!matchint(start, dcp_controlv -> ninin, dcp_controlv -> inin))
	      number = start;
	    ++start;
	  }
	  
	  if (number == (pall_cur -> posi-1)) {
	    decomp_inlistv -> inpal[i] = dcp_controlv -> inin[i];
	  }
	  else {
	    decomp_inlistv -> inpal[i] = number;
	  }
	  
	  /* Now find the lowest element that is not indexed */
	  number = ende+1;
	  while (ende > dcp_controlv -> inin[i]) {
	    if (!matchint(ende, dcp_controlv -> ninin, dcp_controlv -> inin))
	      number = ende;
	    --ende;
	  }
	  
	  if (number == (pall_cur -> posi + pall_cur -> numb)) {
	    decomp_inlistv -> inpah[i] = dcp_controlv -> inin[i];
	  }
	  else {
	    decomp_inlistv -> inpah[i] = number;
	  }
	}
        break;
      }
      pall_cur = pall_cur -> next;
    }
    if (!found) {
      decomp_inlistv -> inpal[i] = decomp_inlistv -> ipa[i];
      decomp_inlistv -> inpah[i] = decomp_inlistv -> ipa[i];
      dcp_get_inlist = dcp_get_inlist | 1;
    }
    if (decomp_inlistv -> inpal[i] == decomp_inlistv -> ipa[i]) {
      decomp_inlistv -> inpal[i] = decomp_inlistv -> inpah[i];
    }
    if (decomp_inlistv -> inpah[i] == decomp_inlistv -> ipa[i]) {
      decomp_inlistv -> inpah[i] = decomp_inlistv -> inpal[i];
    }

    /* Now fill in the relative positions */

    if (found) {
      decomp_inlistv -> ripa[i] = decomp_inlistv -> ipa[i]- pall_cur -> posi;
      decomp_inlistv -> rinpal[i] = decomp_inlistv -> inpal[i] - pall_cur -> posi;
      decomp_inlistv -> rinpah[i] = decomp_inlistv -> inpah[i] - pall_cur -> posi;
    }

    /* here it makes no sense */
    else {
      decomp_inlistv -> ripa[i] = decomp_inlistv -> rinpal[i] = decomp_inlistv -> rinpah[i] = decomp_inlistv -> ipa[i];
    }

}

  return dcp_get_inlist;

 error:
  if (ipa)
    free(ipa);
  if(inpal)
    free(inpal);
  if (inpah)
    free(inpah);
  if (ripa)
    free(ripa);
  if(rinpal)
    free(rinpal);
  if (rinpah)
    free(rinpah);
  return 3;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: simparse.c,v $
   Revision 1.4  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.3  2011/05/10 00:30:16  jozsa
   Left work

   Revision 1.2  2010/03/18 15:50:55  jozsa
   Left work

   Revision 1.5  2010/02/17 01:21:40  jozsa
   finished decomp complex

   Revision 1.4  2009/06/19 17:31:59  jozsa
   Bug removal evaluating the sep option in parsenext

   Revision 1.3  2009/03/27 11:17:12  jozsa
   Left work

   Revision 1.2  2009/03/09 12:02:46  jozsa
   included decomposer input functions
   +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* #undef malloc */
/* #undef free */
/* #undef realloc */

/* void *malloc_here(size_t size) */
/* { */
/*   ++numberofmallocs; */
/*   return malloc(size); */
/* } */

/* void free_here(void *where) */
/* { */
/*   ++numberoffrees; */
/*   return free(where); */
/* } */

/* void *realloc_here(void *where, size_t size) */
/* { */
/*   ++numberofreallocs; */
/*   return realloc(where, size); */
/* } */

/* void stats_here() */
/* { */
/*   printf("malloc: %i   free: %i   realloc: %i\n", numberofmallocs, numberoffrees, numberofreallocs); */
/*   return; */
/* } */



/* ------------------------------------------------------------ */

/* +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

   Revision 1.1.1.1  2009/03/06 12:57:04  jozsa
   imported

   Revision 1.5  2007/08/22 15:58:42  gjozsa
   Left work

   Revision 1.4  2004/12/07 10:31:45  gjozsa
   Left work

   Revision 1.3  2004/11/16 18:18:34  gjozsa
   Left work

   Revision 1.2  2004/11/09 15:52:54  gjozsa
   Fixed bug while counting lines in fct parsenext

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


   ------------------------------------------------------------ */
