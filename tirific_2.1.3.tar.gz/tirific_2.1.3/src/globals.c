/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @file globals.c
   @brief Global struct definition, construction and destruction

   This file contains all structs and symbolic constants needed
   globally plus constructors and destructors for these. This file can
   be included principally.

   $Source: /Volumes/DATA_J_II/data/CVS/tirific/src/globals.c,v $
   $Date: 2011/05/25 22:25:26 $
   $Revision: 1.10 $
   $Author: jozsa $
   $Log: globals.c,v $
   Revision 1.10  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.9  2011/05/10 00:30:15  jozsa
   Left work

   Revision 1.8  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.7  2007/08/22 15:58:41  gjozsa
   Left work

   Revision 1.6  2005/04/14 14:26:04  gjozsa
   Left work

   Revision 1.5  2004/11/13 16:55:09  gjozsa
   Left work

   Revision 1.4  2004/11/10 15:47:49  gjozsa
   Added functions getfirstel_para and getlastel_para

   Revision 1.3  2004/10/29 14:43:14  gjozsa
   *** empty log message ***

   Revision 1.2  2004/10/29 14:39:21  gjozsa
   changed error_msg

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


*/
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* EXTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <stdio.h>


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* INTERNAL INCLUDES */
/* ------------------------------------------------------------ */
#include <globals.h>

/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/**
   @def _MEMORY_HERE_ON
   @brief Controls the use of the memory_here module

   If you don't want to use the memory_here facility comment this
   define, otherways it will be included.

*/
/* ------------------------------------------------------------ */
/* #define _MEMORY_HERE_ON */
/* #include <memory_here.h> */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE SYMBOLIC CONSTANTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE MACROS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* (PRIVATE) GLOBAL VARIABLES */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE TYPEDEFS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE STRUCTS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* PRIVATE FUNCTION DECLARATIONS */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* FUNCTION CODE */
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Destroy a cube */

void freecube(Cube *cube) 
{
  if ((*cube).points)
    free((*cube).points);
  free(cube);
}

/* ------------------------------------------------------------ */


/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a ne Pointsource and sets the Pointer to the next
   pointsource to 0 */

Pointsource *newpointsource(void)
{
  Pointsource *newpointsource = (Pointsource *) malloc(sizeof(Pointsource));
  if (newpointsource != NULL)
    (*newpointsource).next = NULL;
  else 
    printf("Newpointsource: Couldn't allocate memory for next pointsource \n");
  return newpointsource;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Cats a newly created, allocated, and initialised Pointsource to a
   previous one */

Pointsource *catpointsource(Pointsource *previous)
{
  Pointsource *catpointsource = newpointsource();
  if (catpointsource != NULL)
    previous -> next = catpointsource;
  return catpointsource;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Deletes a part of a Pointsource ll */

void freepointsource(Pointsource *lastpointsource)
{
  Pointsource *nextpointsource;
  while((*lastpointsource).next != NULL) {
    nextpointsource = (*(*lastpointsource).next).next;
    free((*lastpointsource).next);
    (*lastpointsource).next = nextpointsource;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a new Sectorpoints structure and sets all pointers to NULL*/

Sectorpoints *newsectorpoints(void)
{
  Sectorpoints *newsectorpoints = (Sectorpoints *) malloc(sizeof(Sectorpoints));
  if (newsectorpoints != NULL) {
    (*newsectorpoints).f = NULL;
    (*newsectorpoints).next = NULL;
    (*newsectorpoints).prev = NULL;
    (*newsectorpoints).next_point = NULL;
    (*newsectorpoints).cube = NULL;
  }
  else
    printf("Newsectorpoints: Couldn't allocate memory for new sector \n");
  return newsectorpoints;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a new Sectorpoints structure and concatenates it to the old */

Sectorpoints *catsectorpoints(Sectorpoints *previous)
{
  Sectorpoints *catsectorpoints = newsectorpoints();
  if (catsectorpoints != NULL) {
    previous -> next = catsectorpoints;
    catsectorpoints -> prev = previous;
  }
  return catsectorpoints;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* allocates memory for the floating points in the Sectorpoints structure destiny */

Sectorpoints *sectorpointsalloc(Sectorpoints *destiny)
{
  if (((*destiny).f = (float *) malloc(sizeof(float))))
    return destiny;
  else {
    printf("Sectorpointsalloc: Couldn't allocate memory to fill new sector \n");
    return NULL;
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Delete the following Sectorpoints structures including firstringpoints */

void freeringpoints(Sectorpoints *firstsectorpoints)
{
  Sectorpoints *nextsectorpoints;

  /* check if firstsectorpoints is empty */
  if (firstsectorpoints) {

  /* Set the pointer to firstsectorpoints in the possibly previous
     sectorpoints structure to NULL */

  if ((*firstsectorpoints).prev)
    (firstsectorpoints -> prev) -> next = NULL;

  nextsectorpoints = firstsectorpoints;

  /* Now delete everything */  

  while (nextsectorpoints) {
    firstsectorpoints = nextsectorpoints;
    if ((*firstsectorpoints).next_point) {
      freepointsource((*firstsectorpoints).next_point);
      free((*firstsectorpoints).next_point);
    }
    nextsectorpoints = (*firstsectorpoints).next;

    /* free the elements of the sector, except .f which should never be allocated */
/*     if ((*firstsectorpoints).f) */
/*       free((*firstsectorpoints).f); */
    if ((*firstsectorpoints).cube)
      freecube((*firstsectorpoints).cube);

    free(firstsectorpoints);
  }
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */
/* Create a new Ringpoints structure and set all pointers to NULL */

Ringpoints *newringpoints(void)
{
  Ringpoints *newringpoints = (Ringpoints *) malloc(sizeof(Ringpoints));
  if (newringpoints != NULL) {
    (*newringpoints).next = NULL;
    (*newringpoints).prev = NULL;
    (*newringpoints).next_sector= NULL;
    (*newringpoints).cube = NULL;
  }
  else
    printf("Newringpoints: Couldn't allocate memory for new ring");
  return newringpoints;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Create a new Ringpoints structure and concatenate it to the old */

Ringpoints *catringpoints(Ringpoints *previous)
{
  Ringpoints *catringpoints = newringpoints();
  if (catringpoints != NULL) {
    previous -> next = catringpoints;
    catringpoints -> prev = previous;
  }
  return catringpoints;
}

/* ------------------------------------------------------------ */




/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Delete the following Ringpoints structures including firstringpoints */

void freediskpoints(Ringpoints *firstringpoints)
{
  Ringpoints *nextringpoints;

  /*check if the pointer is a dummy */
  if (firstringpoints) {

    /* Set the pointer to firstringpoints in the possibly previous
       ringpoints structure to NULL */
    
    if ((*firstringpoints).prev)
      (firstringpoints -> prev) -> next = NULL;
    
    nextringpoints = firstringpoints;
    
    /* Now delete everything */  
    
    while(nextringpoints) {
      firstringpoints = nextringpoints;
      if ((*firstringpoints).next_sector)
	freeringpoints((*firstringpoints).next_sector);
      nextringpoints = (*firstringpoints).next;
      
      /* free the elements of the ring */
      if ((*firstringpoints).cube)
	freecube((*firstringpoints).cube);
      /* delete the ring */
      free(firstringpoints);
    }
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Create a new Diskpoints structure and set all pointers to NULL */

Diskpoints *newdiskpoints(void)
{
  Diskpoints *newdiskpoints = (Diskpoints *) malloc(sizeof(Diskpoints));
  if (newdiskpoints != NULL) {
    (*newdiskpoints).x = NULL;
    (*newdiskpoints).y = NULL;
    (*newdiskpoints).v = NULL;
    (*newdiskpoints).next_ring = NULL;
    (*newdiskpoints).cube = NULL;
  }
  else
    printf("Newdiskpoints: Couldn't allocate memory for new ring");
  return newdiskpoints;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Creates a new Ringpoints structure and concatenate it to the 
   Diskpoints structure */

Ringpoints *catfirstring(Diskpoints *diskpoints)
{
  Ringpoints *catringpoints = newringpoints();
  if (catringpoints != NULL) {
    diskpoints -> next_ring = catringpoints;
  }
  return catringpoints;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* allocate memory for the floating points in destiny Diskpoints structure */

Diskpoints *diskpointsalloc(Diskpoints *destiny)
{
  if (((*destiny).x = (float *) malloc(sizeof(float))) && ((*destiny).y = (float *) malloc(sizeof(float))) && ((*destiny).v = (float *) malloc(sizeof(float))))
    return destiny;
  else
    return NULL;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Deletes the following Ringpoints structures including 
   firstringpoints */

void freedisk(Diskpoints *diskpoints)
{
  /* check if the pointer isn't a dummy */

  if (diskpoints) {
    
    /* if there is one ring delete all rings */
    if ((*diskpoints).next_ring)
      freediskpoints((*diskpoints).next_ring);
  
    /* There are the rules that we only delete things from the top-structure. These lines are therefore deleted as the content of these lines will always be linked against the content of the corresponding Para structure */
/*     if ((*diskpoints).x) */
/*       free((*diskpoints).x); */
/*     if ((*diskpoints).y) */
/*       free((*diskpoints).y); */
/*     if ((*diskpoints).v) */
/*       free((*diskpoints).v); */
    if ((*diskpoints).cube)
      freecube((*diskpoints).cube);

    /* finally delete the structure itself */
    free(diskpoints);
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Generic error message */

void error_msg(char *call_file, char *call_function, char *call_msg, int line)
{
  fprintf(stderr,"TIRIFIC: ERROR REPORTED\n");
  if (*call_file != '\0')
  fprintf(stderr,"FILE: %s\n", call_file);
  if (*call_function != '\0')
  fprintf(stderr,"FUNCTION: %s\n", call_function);
  if (*call_msg != '\0')
  fprintf(stderr,"MESSAGE: %s \n", call_msg);
  if (line != 0)
  fprintf(stderr,"Line: %i\n", line);
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a pointer to the first element of a properly constructed
  Parameter list at the same level of a given element */

Para *getfirstel_para(Para *element)
{
  while((element -> before))
    element = element -> before;
  return element;
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Returns a pointer to the last element of a properly constructed
  Parameter list at the same level of a given element */

Para *getlastel_para(Para *element)
{
  while (element -> next)
    element = element -> next;
  return element;

}
/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Free a read-parameter list */

void freepara(Para *parameterlist)
{

  /* first check if there is anything to be freed at all */
  if ((parameterlist)) {
   
    /* go through the whole subsequent list always calling this function */
    while ((parameterlist -> next || parameterlist -> lower)) {
      if (parameterlist -> next)
	freepara(parameterlist -> next);
      else
	freepara(parameterlist -> lower);
    }

    /* Only if the very last element is reached, we free it and go on with all the other calls */
    if ((parameterlist -> before))
      (parameterlist -> before) -> next = NULL;
    /* if there is a Parm list, this will be deleted */
    if (parameterlist -> parm) {
      freeparele(parameterlist -> parm);
    }
    free(parameterlist);
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ */

/* Free a read-parameter list */

void freeparele(Parele *parameterlist)
{
  /* first check if there is anything to be freed at all */
  if ((parameterlist)) {
    
    /* go through the whole subsequent list always calling this function */
    while ((parameterlist -> next)) {
	freeparele(parameterlist -> next);
    }

    /* Only if the very last element is reached, we free it and go on with all the other calls */
    free(parameterlist);
  }
}

/* ------------------------------------------------------------ */



/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++ 

   $Log: globals.c,v $
   Revision 1.10  2011/05/25 22:25:26  jozsa
   Left work

   Revision 1.9  2011/05/10 00:30:15  jozsa
   Left work

   Revision 1.8  2009/05/26 07:56:41  jozsa
   Left work

   Revision 1.7  2007/08/22 15:58:41  gjozsa
   Left work

   Revision 1.6  2005/04/14 14:26:04  gjozsa
   Left work

   Revision 1.5  2004/11/13 16:55:09  gjozsa
   Left work

   Revision 1.4  2004/11/10 15:47:49  gjozsa
   Added functions getfirstel_para and getlastel_para

   Revision 1.3  2004/10/29 14:43:14  gjozsa
   *** empty log message ***

   Revision 1.2  2004/10/29 14:39:21  gjozsa
   changed error_msg

   Revision 1.1.1.1  2004/10/29 11:13:20  gjozsa
   Added to CVS control


   ------------------------------------------------------------ */
